import type { ReactNode } from 'react';
import { BrandMark } from './brand';

type WorkspaceSectionItem = {
  id: string;
  label: string;
};

type WorkspaceMetric = {
  label: string;
  value: ReactNode;
};

type WorkspaceShellProps = {
  eyebrow: string;
  title: string;
  description?: string;
  userEmail: string;
  userRole: string;
  sections: ReadonlyArray<WorkspaceSectionItem>;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onOpenAccount: () => void;
  onLogout: () => void;
  accountLabel: string;
  logoutLabel: string;
  navigationLabel: string;
  sectionsLabel: string;
  metricsLabel: string;
  metrics?: ReadonlyArray<WorkspaceMetric>;
  children: ReactNode;
};

export function WorkspaceShell({
  eyebrow,
  title,
  description,
  userEmail,
  userRole,
  sections,
  activeSection,
  onSectionChange,
  onOpenAccount,
  onLogout,
  accountLabel,
  logoutLabel,
  navigationLabel,
  sectionsLabel,
  metricsLabel,
  metrics = [],
  children,
}: WorkspaceShellProps) {
  return (
    <main className="workspace-shell">
      <aside className="workspace-sidebar" aria-label={navigationLabel}>
        <BrandMark mode="full" size={42} label="Autonexis" />
        <nav className="workspace-nav" aria-label={sectionsLabel.replace('{title}', title)}>
          {sections.map((section) => (
            <button
              className={section.id === activeSection ? 'active' : undefined}
              key={section.id}
              type="button"
              onClick={() => onSectionChange(section.id)}
            >
              {section.label}
            </button>
          ))}
        </nav>
      </aside>

      <div className="workspace-content">
        <header className="workspace-topbar">
          <div className="workspace-title-block">
            <p className="eyebrow">{eyebrow}</p>
            <h1>{title}</h1>
            {description && <p className="muted">{description}</p>}
          </div>
          <div className="user-card workspace-user-card">
            <span>{userEmail}</span>
            <strong>{userRole}</strong>
            <button className="secondary-button" type="button" onClick={onOpenAccount}>
              {accountLabel}
            </button>
            <button className="secondary-button" type="button" onClick={onLogout}>
              {logoutLabel}
            </button>
          </div>
        </header>

        {metrics.length > 0 && (
          <div className="workspace-metrics" aria-label={metricsLabel}>
            {metrics.map((metric) => (
              <article className="metric-card" key={metric.label}>
                <span>{metric.label}</span>
                <strong>{metric.value}</strong>
              </article>
            ))}
          </div>
        )}

        <div className="workspace-body">{children}</div>
      </div>
    </main>
  );
}

export function WorkspaceSection({
  active,
  children,
}: {
  active: boolean;
  children: ReactNode;
}) {
  return (
    <div className="workspace-section-pane" hidden={!active}>
      {children}
    </div>
  );
}
