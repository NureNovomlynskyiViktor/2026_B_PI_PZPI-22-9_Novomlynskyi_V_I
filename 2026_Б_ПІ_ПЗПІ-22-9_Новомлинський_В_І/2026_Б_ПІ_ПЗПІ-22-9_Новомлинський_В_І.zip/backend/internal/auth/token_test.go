package auth

import (
	"errors"
	"testing"
	"time"
)

func TestJWTManagerGenerateAndValidate(t *testing.T) {
	now := time.Date(2026, 6, 16, 10, 0, 0, 0, time.UTC)
	manager := NewJWTManager("test-secret", time.Hour)
	manager.now = func() time.Time { return now }

	token, expiresAt, err := manager.Generate(User{
		ID:    "22222222-2222-2222-2222-222222222222",
		Email: "user@example.com",
		Role:  DefaultRoleCode,
	})
	if err != nil {
		t.Fatalf("Generate() returned an error: %v", err)
	}
	if !expiresAt.Equal(now.Add(time.Hour)) {
		t.Fatalf("unexpected expiration: %s", expiresAt)
	}

	claims, err := manager.Validate(token)
	if err != nil {
		t.Fatalf("Validate() returned an error: %v", err)
	}
	if claims.Subject != "22222222-2222-2222-2222-222222222222" ||
		claims.Email != "user@example.com" ||
		claims.Role != DefaultRoleCode {
		t.Fatalf("unexpected claims: %#v", claims)
	}
}

func TestJWTManagerRejectsInvalidAndExpiredTokens(t *testing.T) {
	now := time.Date(2026, 6, 16, 10, 0, 0, 0, time.UTC)
	manager := NewJWTManager("test-secret", time.Hour)
	manager.now = func() time.Time { return now }

	token, _, err := manager.Generate(User{
		ID:    "22222222-2222-2222-2222-222222222222",
		Email: "user@example.com",
		Role:  DefaultRoleCode,
	})
	if err != nil {
		t.Fatalf("Generate() returned an error: %v", err)
	}

	otherManager := NewJWTManager("other-secret", time.Hour)
	if _, err := otherManager.Validate(token); !errors.Is(err, ErrInvalidToken) {
		t.Fatalf("expected ErrInvalidToken for wrong secret, got %v", err)
	}

	manager.now = func() time.Time { return now.Add(2 * time.Hour) }
	if _, err := manager.Validate(token); !errors.Is(err, ErrInvalidToken) {
		t.Fatalf("expected ErrInvalidToken for expired token, got %v", err)
	}
}
