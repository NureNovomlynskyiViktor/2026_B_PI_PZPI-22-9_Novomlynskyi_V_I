import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { api, errorMessage, isUnauthorizedError } from '../api/client';
import { useMessages } from '../i18n';
import type { AdminAuditFilters, AdminAuditListResponse } from '../api/types';
import { formatRoleLabel, formatStructuredLabel, formatTimestamp } from '../utils/presentation';

const auditPageSize = 25;


type Props = {
  token: string;
  refreshKey: number;
  onSessionExpired: () => void;
};

type FilterDraft = {
  action: string;
  actorSearch: string;
  entityType: string;
  entityID: string;
  dateFrom: string;
  dateTo: string;
};

const emptyDraft: FilterDraft = {
  action: '',
  actorSearch: '',
  entityType: '',
  entityID: '',
  dateFrom: '',
  dateTo: '',
};

export function AdminAuditLogPanel({
  token,
  refreshKey,
  onSessionExpired,
}: Props) {
  const { admin, common, structuredLabels } = useMessages();
  const auditMessages = admin.audit;
  const [draft, setDraft] = useState<FilterDraft>(emptyDraft);
  const [appliedFilters, setAppliedFilters] =
    useState<AdminAuditFilters>({});
  const [offset, setOffset] = useState(0);
  const [response, setResponse] = useState<AdminAuditListResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [manualRefreshKey, setManualRefreshKey] = useState(0);

  const auditActions = [
    { value: '', label: auditMessages.allActions },
    { value: 'user.deactivated', label: auditMessages.userDeactivated },
    { value: 'user.reactivated', label: auditMessages.userReactivated },
    { value: 'service_request.assigned', label: auditMessages.serviceRequestAssigned },
    { value: 'service_request.reassigned', label: auditMessages.serviceRequestReassigned },
    { value: 'service_request.cancelled', label: auditMessages.serviceRequestCancelled },
    { value: 'vehicle.activation_created', label: auditMessages.vehicleActivationCreated },
    { value: 'alert.resolution_confirmed', label: auditMessages.alertResolutionConfirmed },
  ];

  const pagination = response?.pagination;
  const rangeLabel = useMemo(() => {
    if (!pagination || pagination.total === 0) {
      return common.noData;
    }

    const start = pagination.offset + 1;
    const end = Math.min(pagination.offset + pagination.limit, pagination.total);
    return auditMessages.range
      .replace('{start}', String(start))
      .replace('{end}', String(end))
      .replace('{total}', String(pagination.total));
  }, [auditMessages.range, common.noData, pagination]);

  useEffect(() => {
    let isCurrent = true;
    setIsLoading(true);
    setError(null);

    api
      .listAdminAuditLogs(token, {
        ...appliedFilters,
        limit: auditPageSize,
        offset,
      })
      .then((result) => {
        if (isCurrent) {
          setResponse(result);
        }
      })
      .catch((err) => {
        if (isCurrent) {
          if (isUnauthorizedError(err)) {
            onSessionExpired();
            return;
          }

          setError(errorMessage(err, auditMessages.loadError));
        }
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoading(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [appliedFilters, auditMessages.loadError, manualRefreshKey, offset, onSessionExpired, refreshKey, token]);

  function updateDraft(field: keyof FilterDraft, value: string) {
    setDraft((current) => ({ ...current, [field]: value }));
    setError(null);
  }

  function handleApply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const filters = buildFilters(draft);
    if (!filters) {
      setError(auditMessages.dateFilterError);
      return;
    }

    setAppliedFilters(filters);
    setOffset(0);
    setError(null);
  }

  function handleClear() {
    setDraft(emptyDraft);
    setAppliedFilters({});
    setOffset(0);
    setError(null);
  }

  function handleRefresh() {
    setManualRefreshKey((current) => current + 1);
    setError(null);
  }

  return (
    <section className="panel audit-log-panel">
      <div className="panel-header">
        <div>
          <h2>{auditMessages.title}</h2>
          <p className="muted">{auditMessages.description}</p>
        </div>
        <button
          className="secondary-button"
          disabled={isLoading}
          type="button"
          onClick={handleRefresh}
        >
          {isLoading ? common.refreshing : common.refresh}
        </button>
      </div>

      <form
        className="audit-filter-grid"
        aria-label={auditMessages.title}
        onSubmit={handleApply}
      >
        <label>
          {auditMessages.action}
          <select
            value={draft.action}
            onChange={(event) => updateDraft('action', event.target.value)}
          >
            {auditActions.map((action) => (
              <option key={action.value} value={action.value}>
                {action.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          {auditMessages.actorSearch}
          <input
            placeholder={auditMessages.nameOrEmail}
            value={draft.actorSearch}
            onChange={(event) => updateDraft('actorSearch', event.target.value)}
          />
        </label>
        <label>
          {auditMessages.entityType}
          <input
            placeholder="user"
            value={draft.entityType}
            onChange={(event) => updateDraft('entityType', event.target.value)}
          />
        </label>
        <label>
          {auditMessages.entityId}
          <input
            placeholder={auditMessages.relatedEntityId}
            value={draft.entityID}
            onChange={(event) => updateDraft('entityID', event.target.value)}
          />
        </label>
        <label>
          {auditMessages.dateFrom}
          <input
            type="datetime-local"
            value={draft.dateFrom}
            onChange={(event) => updateDraft('dateFrom', event.target.value)}
          />
        </label>
        <label>
          {auditMessages.dateTo}
          <input
            type="datetime-local"
            value={draft.dateTo}
            onChange={(event) => updateDraft('dateTo', event.target.value)}
          />
        </label>
        <div className="audit-filter-actions">
          <button className="primary-button" disabled={isLoading} type="submit">
            {auditMessages.applyFilters}
          </button>
          <button
            className="secondary-button"
            disabled={isLoading}
            type="button"
            onClick={handleClear}
          >
            {auditMessages.clearFilters}
          </button>
        </div>
      </form>

      {error && <p className="error-box">{error}</p>}

      {isLoading ? (
        <p className="info-box">{common.loadingAuditLogs}</p>
      ) : response && response.items.length === 0 ? (
        <p className="empty-state">{auditMessages.noMatches}</p>
      ) : response ? (
        <>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>{auditMessages.actor}</th>
                  <th>{auditMessages.action}</th>
                  <th>{auditMessages.entity}</th>
                  <th>{auditMessages.timestamp}</th>
                  <th>{auditMessages.metadata}</th>
                </tr>
              </thead>
              <tbody>
                {response.items.map((item) => (
                  <tr key={item.id}>
                    <td>
                      {item.actor ? (
                        <div className="user-identity">
                          <strong>
                            {item.actor.full_name || item.actor.email}
                          </strong>
                          <small>{item.actor.email}</small>
                          <span className="badge">
                            {formatRoleLabel(item.actor.role, structuredLabels)}
                          </span>
                        </div>
                      ) : (
                        <span className="muted">{auditMessages.deletedActor}</span>
                      )}
                    </td>
                    <td>
                      <span className="status-pill active">
                        {actionLabel(item.action, auditMessages)}
                      </span>
                    </td>
                    <td>
                      <strong>{entityLabel(item.entity_type, auditMessages, common.notAvailable, structuredLabels)}</strong>
                      <small>{item.entity_id ?? common.notAvailable}</small>
                    </td>
                    <td>{formatTimestamp(item.created_at, common.notAvailable)}</td>
                    <td>
                      <details className="metadata-details">
                        <summary>{auditMessages.viewJson}</summary>
                        <pre>{JSON.stringify(item.metadata ?? {}, null, 2)}</pre>
                      </details>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pagination-row">
            <span className="muted">{rangeLabel}</span>
            <div className="button-row compact">
              <button
                className="secondary-button"
                disabled={isLoading || offset === 0}
                type="button"
                onClick={() =>
                  setOffset((current) => Math.max(0, current - auditPageSize))
                }
              >
                {auditMessages.previous}
              </button>
              <button
                className="secondary-button"
                disabled={isLoading || !response.pagination.has_more}
                type="button"
                onClick={() => setOffset((current) => current + auditPageSize)}
              >
                {auditMessages.next}
              </button>
            </div>
          </div>
        </>
      ) : null}
    </section>
  );
}

function buildFilters(draft: FilterDraft): AdminAuditFilters | null {
  const filters: AdminAuditFilters = {};

  if (draft.action) {
    filters.action = draft.action;
  }
  if (draft.actorSearch.trim()) {
    filters.actor_search = draft.actorSearch.trim();
  }
  if (draft.entityType.trim()) {
    filters.entity_type = draft.entityType.trim();
  }
  if (draft.entityID.trim()) {
    filters.entity_id = draft.entityID.trim();
  }
  if (draft.dateFrom) {
    const value = toRFC3339(draft.dateFrom);
    if (!value) {
      return null;
    }
    filters.date_from = value;
  }
  if (draft.dateTo) {
    const value = toRFC3339(draft.dateTo);
    if (!value) {
      return null;
    }
    filters.date_to = value;
  }

  return filters;
}

function toRFC3339(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return null;
  }

  return date.toISOString();
}

function normalizeAuditCode(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function actionLabel(action: string, labels: Record<string, string>) {
  switch (normalizeAuditCode(action)) {
    case 'user_deactivated':
      return labels.userDeactivated;
    case 'user_reactivated':
      return labels.userReactivated;
    case 'service_request_assigned':
      return labels.serviceRequestAssigned;
    case 'service_request_reassigned':
      return labels.serviceRequestReassigned;
    case 'service_request_cancelled':
      return labels.serviceRequestCancelled;
    case 'vehicle_activation_created':
      return labels.vehicleActivationCreated;
    case 'alert_resolution_confirmed':
      return labels.alertResolutionConfirmed;
    default:
      return action;
  }
}

function entityLabel(
  entityType: string,
  labels: Record<string, string>,
  fallback: string,
  structuredLabels: Partial<Record<string, string>>,
) {
  switch (normalizeAuditCode(entityType)) {
    case 'alert':
      return labels.entityAlert;
    case 'service_request':
      return labels.entityServiceRequest;
    case 'user':
      return labels.entityUser;
    case 'vehicle':
      return labels.entityVehicle;
    default:
      return formatStructuredLabel(entityType, fallback, structuredLabels);
  }
}
