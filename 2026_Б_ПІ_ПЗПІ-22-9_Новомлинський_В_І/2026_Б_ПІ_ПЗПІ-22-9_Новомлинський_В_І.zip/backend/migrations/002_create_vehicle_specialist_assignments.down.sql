BEGIN;

DROP TABLE IF EXISTS vehicle_specialist_assignments;

COMMIT;
