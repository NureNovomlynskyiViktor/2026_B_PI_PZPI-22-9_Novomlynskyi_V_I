BEGIN;

DROP INDEX IF EXISTS audit_logs_entity_type_entity_id_idx;
DROP INDEX IF EXISTS audit_logs_action_idx;
DROP INDEX IF EXISTS audit_logs_user_id_idx;
DROP INDEX IF EXISTS audit_logs_created_at_id_idx;

COMMIT;
