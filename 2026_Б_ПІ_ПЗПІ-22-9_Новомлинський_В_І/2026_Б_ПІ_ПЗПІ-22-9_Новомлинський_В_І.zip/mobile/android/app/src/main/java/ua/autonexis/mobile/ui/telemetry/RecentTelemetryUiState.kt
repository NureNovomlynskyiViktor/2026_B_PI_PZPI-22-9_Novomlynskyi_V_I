package ua.autonexis.mobile.ui.telemetry

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.TelemetryRecord

internal data class RecentTelemetryUiState(
    val vehicleId: String = "",
    val vehicleLabel: String = "Selected vehicle",
    val records: List<TelemetryRecord> = emptyList(),
    val selectedMetricKey: String = RecentTelemetryPresentation.DEFAULT_METRIC_KEY,
    val isHistoryExpanded: Boolean = false,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
)

internal class RecentTelemetryViewModel {
    var uiState by mutableStateOf(RecentTelemetryUiState())
        private set

    fun showInitialLoading(vehicleId: String, vehicleLabel: String) {
        uiState = RecentTelemetryUiState(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            isLoading = true,
            message = "Loading recent telemetry...",
        )
    }

    fun showTelemetry(
        vehicleId: String = uiState.vehicleId,
        vehicleLabel: String = uiState.vehicleLabel,
        records: List<TelemetryRecord>,
        message: String? = null,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            records = RecentTelemetryPresentation.newestFirst(records),
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = isError,
        )
    }

    fun failInitialLoad(vehicleId: String, vehicleLabel: String, message: String) {
        uiState = RecentTelemetryUiState(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun selectMetric(metricKey: String) {
        if (!RecentTelemetryPresentation.isKnownMetricKey(metricKey)) {
            return
        }
        uiState = uiState.copy(selectedMetricKey = metricKey)
    }

    fun toggleHistoryExpanded() {
        uiState = uiState.copy(isHistoryExpanded = !uiState.isHistoryExpanded)
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing telemetry...",
            isError = false,
        )
        return true
    }

    fun finishRefresh(records: List<TelemetryRecord>, message: String? = null) {
        uiState = uiState.copy(
            records = RecentTelemetryPresentation.newestFirst(records),
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = false,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = true,
        )
    }
}