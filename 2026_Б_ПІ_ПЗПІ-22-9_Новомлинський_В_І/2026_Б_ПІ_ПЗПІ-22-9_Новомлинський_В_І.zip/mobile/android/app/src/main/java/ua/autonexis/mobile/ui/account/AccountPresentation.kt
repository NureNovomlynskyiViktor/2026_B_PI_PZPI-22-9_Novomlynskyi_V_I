﻿package ua.autonexis.mobile.ui.account

import androidx.annotation.StringRes
import ua.autonexis.mobile.AppearanceMode
import ua.autonexis.mobile.AuthMethods
import ua.autonexis.mobile.LanguageMode
import ua.autonexis.mobile.R
import ua.autonexis.mobile.User
import java.util.Locale

internal object AccountPresentation {
    @StringRes
    fun roleLabelRes(user: User?): Int {
        return when (user?.role?.trim()?.lowercase(Locale.US)) {
            "vehicle_owner" -> R.string.role_vehicle_owner
            "technical_specialist" -> R.string.role_technical_specialist
            "administrator" -> R.string.role_administrator
            else -> R.string.role_account
        }
    }

    fun roleLabel(user: User?): String {
        return when (user?.role?.trim()?.lowercase(Locale.US)) {
            "vehicle_owner" -> "Vehicle owner"
            "technical_specialist" -> "Technical specialist"
            "administrator" -> "Administrator"
            else -> "Account"
        }
    }

    @StringRes
    fun passwordMethodLabelRes(methods: AuthMethods?): Int {
        return if (methods?.passwordEnabled == true) R.string.method_enabled else R.string.method_not_enabled
    }

    fun passwordMethodLabel(methods: AuthMethods?): String {
        return if (methods?.passwordEnabled == true) "Enabled" else "Not enabled"
    }

    @StringRes
    fun googleMethodLabelRes(methods: AuthMethods?): Int {
        return if (methods?.googleLinked == true) R.string.method_connected else R.string.method_not_connected
    }

    fun googleMethodLabel(methods: AuthMethods?): String {
        return if (methods?.googleLinked == true) "Connected" else "Not connected"
    }

    @StringRes
    fun appearanceModeLabelRes(mode: AppearanceMode): Int {
        return when (mode) {
            AppearanceMode.SYSTEM -> R.string.appearance_system
            AppearanceMode.LIGHT -> R.string.appearance_light
            AppearanceMode.DARK -> R.string.appearance_dark
        }
    }

    fun appearanceModeLabel(mode: AppearanceMode): String {
        return when (mode) {
            AppearanceMode.SYSTEM -> "System default"
            AppearanceMode.LIGHT -> "Light"
            AppearanceMode.DARK -> "Dark"
        }
    }

    @StringRes
    fun appearanceModeDescriptionRes(mode: AppearanceMode): Int {
        return when (mode) {
            AppearanceMode.SYSTEM -> R.string.appearance_system_description
            AppearanceMode.LIGHT -> R.string.appearance_light_description
            AppearanceMode.DARK -> R.string.appearance_dark_description
        }
    }

    fun appearanceModeDescription(mode: AppearanceMode): String {
        return when (mode) {
            AppearanceMode.SYSTEM -> "Follow this device setting"
            AppearanceMode.LIGHT -> "Use the bright Autonexis theme"
            AppearanceMode.DARK -> "Use the dark Autonexis theme"
        }
    }

    @StringRes
    fun languageModeLabelRes(mode: LanguageMode): Int {
        return when (mode) {
            LanguageMode.SYSTEM -> R.string.language_system
            LanguageMode.ENGLISH -> R.string.language_english
            LanguageMode.UKRAINIAN -> R.string.language_ukrainian
        }
    }

    @StringRes
    fun languageModeDescriptionRes(mode: LanguageMode): Int {
        return when (mode) {
            LanguageMode.SYSTEM -> R.string.language_system_description
            LanguageMode.ENGLISH -> R.string.language_english_description
            LanguageMode.UKRAINIAN -> R.string.language_ukrainian_description
        }
    }

    fun canConnectGoogle(state: AccountUiState): Boolean {
        return state.googleConfigured && state.methods?.googleLinked == false && !state.isLinkingGoogle
    }
}
