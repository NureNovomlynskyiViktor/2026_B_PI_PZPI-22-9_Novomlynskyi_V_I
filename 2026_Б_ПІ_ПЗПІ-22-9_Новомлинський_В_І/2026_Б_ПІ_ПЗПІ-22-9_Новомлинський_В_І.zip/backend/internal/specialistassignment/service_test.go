package specialistassignment

import (
	"context"
	"errors"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testVehicleID    = "22222222-2222-2222-2222-222222222222"
	testOwnerID      = "11111111-1111-1111-1111-111111111111"
	testSpecialistID = "33333333-3333-3333-3333-333333333333"
)

type stubRepository struct {
	user      auth.User
	err       error
	createErr error
}

func (r *stubRepository) GetUserByEmail(context.Context, string) (auth.User, error) {
	if r.err != nil {
		return auth.User{}, r.err
	}
	return r.user, nil
}

func (r *stubRepository) GetUserByID(context.Context, string) (auth.User, error) {
	if r.err != nil {
		return auth.User{}, r.err
	}
	return r.user, nil
}

func (r *stubRepository) ListSpecialists(context.Context) ([]auth.User, error) {
	return []auth.User{r.user}, r.err
}

func (r *stubRepository) CountBySpecialist(context.Context) (map[string]int, error) {
	return map[string]int{testSpecialistID: 1}, r.err
}

func (r *stubRepository) Create(
	context.Context,
	string,
	auth.User,
	string,
) (Assignment, error) {
	return Assignment{ID: "44444444-4444-4444-4444-444444444444"}, r.createErr
}

func (r *stubRepository) ListByVehicle(context.Context, string) ([]Assignment, error) {
	return []Assignment{}, r.err
}

func (r *stubRepository) Delete(context.Context, string, string) error {
	return r.err
}

func (r *stubRepository) ListVehiclesForSpecialist(
	context.Context,
	string,
) ([]vehicle.Vehicle, error) {
	return []vehicle.Vehicle{{ID: testVehicleID}}, r.err
}

func (r *stubRepository) GetAssignedVehicle(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testVehicleID}, r.err
}

func TestAssignByEmailRequiresTechnicalSpecialist(t *testing.T) {
	service := NewService(&stubRepository{
		user: auth.User{ID: testSpecialistID, Role: auth.DefaultRoleCode},
	})

	_, err := service.AssignByEmail(
		context.Background(),
		testVehicleID,
		"user@example.com",
		testOwnerID,
	)

	if !errors.Is(err, ErrInvalidRole) {
		t.Fatalf("expected ErrInvalidRole, got %v", err)
	}
}

func TestAssignByIDRequiresTechnicalSpecialist(t *testing.T) {
	service := NewService(&stubRepository{
		user: auth.User{ID: testSpecialistID, Role: auth.DefaultRoleCode},
	})

	_, err := service.AssignByID(
		context.Background(),
		testVehicleID,
		testSpecialistID,
		testOwnerID,
	)

	if !errors.Is(err, ErrInvalidRole) {
		t.Fatalf("expected ErrInvalidRole, got %v", err)
	}
}

func TestAssignRejectsInactiveTechnicalSpecialist(t *testing.T) {
	service := NewService(&stubRepository{
		user: auth.User{
			ID:       testSpecialistID,
			Role:     auth.TechnicalSpecialistRoleCode,
			IsActive: false,
		},
	})

	_, err := service.AssignByEmail(
		context.Background(),
		testVehicleID,
		"specialist@example.com",
		testOwnerID,
	)
	if !errors.Is(err, ErrUserNotFound) {
		t.Fatalf("expected ErrUserNotFound for inactive specialist email assignment, got %v", err)
	}

	_, err = service.AssignByID(
		context.Background(),
		testVehicleID,
		testSpecialistID,
		testOwnerID,
	)
	if !errors.Is(err, ErrUserNotFound) {
		t.Fatalf("expected ErrUserNotFound for inactive specialist ID assignment, got %v", err)
	}
}

func TestAssignByEmailReturnsDuplicate(t *testing.T) {
	service := NewService(&stubRepository{
		user: auth.User{
			ID:       testSpecialistID,
			Role:     auth.TechnicalSpecialistRoleCode,
			IsActive: true,
		},
		createErr: ErrDuplicate,
	})

	_, err := service.AssignByEmail(
		context.Background(),
		testVehicleID,
		"specialist@example.com",
		testOwnerID,
	)

	if !errors.Is(err, ErrDuplicate) {
		t.Fatalf("expected ErrDuplicate, got %v", err)
	}
}

func TestGetAssignedVehicleRejectsInvalidUUID(t *testing.T) {
	service := NewService(&stubRepository{})

	_, err := service.GetAssignedVehicle(context.Background(), testSpecialistID, "bad")

	if !errors.Is(err, ErrInvalidVehicleID) {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}
}
