package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse

class GoogleAuthSupportTest {
    @Test
    fun googleBackendRequestUsesIdTokenField() {
        val json = googleLoginRequestBody("fake-id-token")

        assertEquals("{\"id_token\":\"fake-id-token\"}", json)
        assertFalse(json.contains("access_token"))
        assertFalse(json.contains("\"token\""))
    }

    @Test
    fun authenticationSuccessPreservesBackendUserRole() {
        val result = AuthResult(
            user = User(
                id = "user-1",
                email = "admin@example.com",
                role = "administrator",
                fullName = "Admin User",
            ),
            accessToken = "autonexis-jwt",
        )

        val success = authenticationSuccess(" http://10.0.2.2:8080/ ", result)

        assertEquals("administrator", success.user.role)
        assertEquals("autonexis-jwt", success.accessToken)
        assertEquals("http://10.0.2.2:8080", success.baseUrl)
        assertFalse(success.opensOwnerDashboard)
    }
}