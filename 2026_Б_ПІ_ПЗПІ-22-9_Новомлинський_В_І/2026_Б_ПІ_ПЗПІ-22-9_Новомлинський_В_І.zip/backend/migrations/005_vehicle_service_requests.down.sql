BEGIN;

DROP TABLE IF EXISTS vehicle_service_requests;

COMMIT;
