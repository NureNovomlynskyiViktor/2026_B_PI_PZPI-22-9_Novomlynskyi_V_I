package ua.autonexis.mobile

object ServiceRequestDefaults {
    fun fromAlert(alert: Alert, title: String, recommendationLabel: String): ServiceRequestDraft {
        val descriptionParts = mutableListOf<String>()
        if (alert.message.isNotBlank()) {
            descriptionParts += alert.message
        }
        if (!alert.recommendation.isNullOrBlank()) {
            descriptionParts += "$recommendationLabel: ${alert.recommendation}"
        }

        return ServiceRequestDraft(
            title = title,
            description = descriptionParts.joinToString("\n\n"),
            priority = if (alert.severity.equals("critical", ignoreCase = true)) "high" else "normal",
            sourceAlertId = alert.id,
        )
    }
}