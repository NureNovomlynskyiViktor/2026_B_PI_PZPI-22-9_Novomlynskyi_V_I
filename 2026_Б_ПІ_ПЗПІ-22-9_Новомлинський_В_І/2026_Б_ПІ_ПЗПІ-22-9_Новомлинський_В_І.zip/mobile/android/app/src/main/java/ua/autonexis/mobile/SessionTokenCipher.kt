package ua.autonexis.mobile

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal data class TokenCipherResult(
    val ciphertext: ByteArray,
    val iv: ByteArray,
)

internal interface SessionTokenCipherContract {
    fun encrypt(plaintextToken: String): TokenCipherResult
    fun decrypt(ciphertext: ByteArray, iv: ByteArray): String
}

internal class SessionTokenCipher(
    private val keyAlias: String = KEY_ALIAS,
    private val associatedData: ByteArray = ASSOCIATED_DATA.toByteArray(Charsets.UTF_8),
) : SessionTokenCipherContract {
    override fun encrypt(plaintextToken: String): TokenCipherResult {
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
            cipher.updateAAD(associatedData)
            TokenCipherResult(
                ciphertext = cipher.doFinal(plaintextToken.toByteArray(Charsets.UTF_8)),
                iv = cipher.iv,
            )
        } catch (exception: Exception) {
            throw SessionTokenCryptoException("Unable to encrypt session token.", exception)
        }
    }

    override fun decrypt(ciphertext: ByteArray, iv: ByteArray): String {
        return try {
            val key = existingSecretKey()
                ?: throw SessionTokenCryptoException("Session token key is unavailable.")
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.updateAAD(associatedData)
            cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
        } catch (exception: SessionTokenCryptoException) {
            throw exception
        } catch (exception: Exception) {
            throw SessionTokenCryptoException("Unable to decrypt session token.", exception)
        }
    }

    private fun getOrCreateSecretKey(): SecretKey {
        existingSecretKey()?.let { return it }

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE,
        )
        val keySpec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(KEY_SIZE_BITS)
            .setUserAuthenticationRequired(false)
            .build()

        keyGenerator.init(keySpec)
        return keyGenerator.generateKey()
    }

    private fun existingSecretKey(): SecretKey? {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(keyAlias)) {
            return null
        }

        return keyStore.getKey(keyAlias, null) as? SecretKey
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_BITS = 128
        private const val KEY_SIZE_BITS = 256
        private const val KEY_ALIAS = "autonexis_session_token_key_v1"
        private const val ASSOCIATED_DATA = "ua.autonexis.mobile:session-token:v1"
    }
}

internal class SessionTokenCryptoException(
    message: String,
    cause: Throwable? = null,
) : RuntimeException(message, cause)
