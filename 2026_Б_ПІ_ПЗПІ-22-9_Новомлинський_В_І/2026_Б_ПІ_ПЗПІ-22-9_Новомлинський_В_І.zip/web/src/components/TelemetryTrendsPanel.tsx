import { useLocale, useMessages } from '../i18n';
import { formatTelemetryMetricDelta, formatTelemetryMetricValue, type TelemetryMetricKey } from '../utils/presentation';
import type { Locale } from '../i18n/types';
import type { TelemetryRecord } from '../api/types';

type MetricConfig = {
  key: TelemetryMetricKey;
  label: string;
  stableThreshold: number;
};

type Props = {
  records: TelemetryRecord[];
  isLoading?: boolean;
};

const chartWidth = 220;
const chartHeight = 72;
const chartPadding = 8;

function valueFor(record: TelemetryRecord, key: TelemetryMetricKey): number {
  return record[key];
}

function buildPoints(values: number[]): string {
  if (values.length === 0) {
    return '';
  }

  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  const range = maxValue - minValue;
  const normalizedRange = range === 0 ? 1 : range;
  const drawableWidth = chartWidth - chartPadding * 2;
  const drawableHeight = chartHeight - chartPadding * 2;
  const denominator = Math.max(values.length - 1, 1);

  return values
    .map((value, index) => {
      const x = chartPadding + (index / denominator) * drawableWidth;
      const y = chartPadding + (1 - (value - minValue) / normalizedRange) * drawableHeight;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
}

function deltaClass(delta: number, stableThreshold: number): string {
  if (Math.abs(delta) <= stableThreshold) {
    return 'trend-delta neutral';
  }

  return delta > 0 ? 'trend-delta upward' : 'trend-delta downward';
}

function formatDelta(delta: number, config: MetricConfig, stableLabel: string, locale: Locale): string {
  if (Math.abs(delta) <= config.stableThreshold) {
    return stableLabel;
  }

  return formatTelemetryMetricDelta(config.key, delta, locale);
}

function ChartCard({
  config,
  records,
  noDataMessage,
  stableLabel,
  locale,
}: {
  config: MetricConfig;
  records: TelemetryRecord[];
  noDataMessage: string;
  stableLabel: string;
  locale: Locale;
}) {
  const latest = records[0];
  const chronologicalValues = [...records]
    .reverse()
    .map((record) => valueFor(record, config.key))
    .filter((value) => Number.isFinite(value));
  const latestValue = latest ? valueFor(latest, config.key) : null;
  const oldestValue = chronologicalValues[0];
  const delta = latestValue === null || oldestValue === undefined ? 0 : latestValue - oldestValue;
  const hasTrend = chronologicalValues.length >= 2;
  const points = hasTrend ? buildPoints(chronologicalValues) : '';
  const latestPoint = points.split(' ')[points.split(' ').length - 1] ?? '';

  return (
    <article className="telemetry-trend-card">
      <div className="telemetry-trend-card-header">
        <span>{config.label}</span>
        <strong>
          {latestValue === null
            ? noDataMessage
            : formatTelemetryMetricValue(config.key, latestValue, locale)}
        </strong>
      </div>

      {hasTrend ? (
        <svg
          aria-hidden="true"
          className="telemetry-trend-chart"
          focusable="false"
          preserveAspectRatio="none"
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
        >
          <line className="telemetry-trend-grid-line" x1="0" x2={chartWidth} y1={chartHeight / 2} y2={chartHeight / 2} />
          <polyline className="telemetry-trend-line" fill="none" points={points} />
          {latestPoint && <circle className="telemetry-trend-marker" cx={latestPoint.split(',')[0]} cy={latestPoint.split(',')[1]} r="3" />}
        </svg>
      ) : (
        <div className="telemetry-trend-empty">{noDataMessage}</div>
      )}

      <small className={deltaClass(delta, config.stableThreshold)}>
        {hasTrend ? formatDelta(delta, config, stableLabel, locale) : noDataMessage}
      </small>
    </article>
  );
}

export function TelemetryTrendsPanel({ records, isLoading = false }: Props) {
  const { common, specialist, structuredLabels } = useMessages();
  const { locale } = useLocale();
  const diagnosticsMessages = specialist.diagnostics;
  const metricConfigs: MetricConfig[] = [
    {
      key: 'engine_temperature',
      label: structuredLabels.engine_temperature,
      stableThreshold: 0.05,
    },
    {
      key: 'battery_voltage',
      label: structuredLabels.battery_voltage,
      stableThreshold: 0.05,
    },
    {
      key: 'rpm',
      label: structuredLabels.rpm,
      stableThreshold: 1,
    },
    {
      key: 'speed',
      label: structuredLabels.speed,
      stableThreshold: 0.5,
    },
    {
      key: 'fuel_level',
      label: structuredLabels.fuel_level,
      stableThreshold: 0.05,
    },
    {
      key: 'vibration_level',
      label: structuredLabels.vibration_level,
      stableThreshold: 0.05,
    },
  ];

  return (
    <section className="panel telemetry-trends-panel">
      <div className="panel-header">
        <div>
          <h2>{diagnosticsMessages.trendsTitle}</h2>
          <p className="muted">{diagnosticsMessages.trendsDescription}</p>
        </div>
        {isLoading && <span className="badge">{common.refreshing}</span>}
      </div>

      {records.length === 0 ? (
        <p className="empty-state">{diagnosticsMessages.trendsNoData}</p>
      ) : records.length === 1 ? (
        <p className="info-box">{diagnosticsMessages.trendsInsufficientData}</p>
      ) : (
        <div className="telemetry-trends-grid">
          {metricConfigs.map((config) => (
            <ChartCard
              config={config}
              key={config.key}
              noDataMessage={diagnosticsMessages.trendsNoData}
              records={records}
              stableLabel={diagnosticsMessages.trendStable}
              locale={locale}
            />
          ))}
        </div>
      )}
    </section>
  );
}
