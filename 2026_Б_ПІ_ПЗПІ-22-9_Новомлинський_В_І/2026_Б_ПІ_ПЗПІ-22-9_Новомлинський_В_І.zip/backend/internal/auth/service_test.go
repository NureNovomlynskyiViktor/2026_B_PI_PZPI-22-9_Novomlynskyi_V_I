package auth

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"
)

const (
	testUserID = "22222222-2222-2222-2222-222222222222"
	testRoleID = "00000000-0000-0000-0000-000000000001"
)

type repositoryStub struct {
	role                   Role
	user                   User
	userWithPass           UserWithPassword
	errRole                error
	errCreate              error
	errEmailLookup         error
	errIDLookup            error
	errOAuthLookup         error
	errCreateOAuth         error
	errMethodStatus        error
	errLinkGoogle          error
	errUserOAuthLookup     error
	errProviderOAuthLookup error
	methodStatus           AuthMethodStatus
	linkStatus             AuthMethodStatus
	linkUserID             string
	linkProviderAccount    string
	userOAuthAccount       OAuthAccount
	providerOAuthAccount   OAuthAccount
	createRoleID           string
	createEmail            string
	createFullName         string
	createHash             string
	lookupEmail            string
	oauthUser              User
	oauthProvider          string
	oauthAccountID         string
	oauthLookupCalls       int
	createOAuthEmail       string
	createOAuthFullName    string
	createOAuthProvider    string
	createOAuthAccountID   string
	roleCode               string
}

func (r *repositoryStub) GetRoleByCode(_ context.Context, code string) (Role, error) {
	r.roleCode = code
	if r.errRole != nil {
		return Role{}, r.errRole
	}
	return r.role, nil
}

func (r *repositoryStub) CreateUser(
	_ context.Context,
	roleID string,
	email string,
	passwordHash string,
	fullName string,
) (User, error) {
	r.createRoleID = roleID
	r.createEmail = email
	r.createFullName = fullName
	r.createHash = passwordHash
	if r.errCreate != nil {
		return User{}, r.errCreate
	}
	return r.user, nil
}

func (r *repositoryStub) CreateOAuthUser(
	_ context.Context,
	roleID string,
	email string,
	fullName string,
	provider string,
	providerAccountID string,
) (User, error) {
	r.createRoleID = roleID
	r.createOAuthEmail = email
	r.createOAuthFullName = fullName
	r.createOAuthProvider = provider
	r.createOAuthAccountID = providerAccountID
	if r.errCreateOAuth != nil {
		return User{}, r.errCreateOAuth
	}
	return r.user, nil
}
func (r *repositoryStub) GetUserByEmail(_ context.Context, email string) (UserWithPassword, error) {
	r.lookupEmail = email
	if r.errEmailLookup != nil {
		return UserWithPassword{}, r.errEmailLookup
	}
	return r.userWithPass, nil
}

func (r *repositoryStub) GetUserByID(context.Context, string) (User, error) {
	if r.errIDLookup != nil {
		return User{}, r.errIDLookup
	}
	return r.user, nil
}

func (r *repositoryStub) GetUserByOAuthAccount(_ context.Context, provider string, providerAccountID string) (User, error) {
	r.oauthProvider = provider
	r.oauthAccountID = providerAccountID
	r.oauthLookupCalls++
	if r.errOAuthLookup != nil {
		if r.oauthLookupCalls > 1 && r.oauthUser.ID != "" {
			return r.oauthUser, nil
		}
		return User{}, r.errOAuthLookup
	}
	return r.oauthUser, nil
}

func (r *repositoryStub) GetAuthMethodStatus(_ context.Context, userID string) (AuthMethodStatus, error) {
	if r.errMethodStatus != nil {
		return AuthMethodStatus{}, r.errMethodStatus
	}
	return r.methodStatus, nil
}

func (r *repositoryStub) GetOAuthAccountByUser(_ context.Context, userID string, provider string) (OAuthAccount, error) {
	if r.errUserOAuthLookup != nil {
		return OAuthAccount{}, r.errUserOAuthLookup
	}
	return r.userOAuthAccount, nil
}

func (r *repositoryStub) GetOAuthAccountByProviderAccountID(_ context.Context, provider string, providerAccountID string) (OAuthAccount, error) {
	if r.errProviderOAuthLookup != nil {
		return OAuthAccount{}, r.errProviderOAuthLookup
	}
	return r.providerOAuthAccount, nil
}

func (r *repositoryStub) LinkGoogleAccount(_ context.Context, userID string, providerAccountID string) (AuthMethodStatus, error) {
	r.linkUserID = userID
	r.linkProviderAccount = providerAccountID
	if r.errLinkGoogle != nil {
		return AuthMethodStatus{}, r.errLinkGoogle
	}
	return r.linkStatus, nil
}

type hasherStub struct {
	hash     string
	valid    bool
	hashErr  error
	rawValue string
}

func (h *hasherStub) Hash(password string) (string, error) {
	h.rawValue = password
	return h.hash, h.hashErr
}

func (h *hasherStub) Verify(string, string) bool {
	return h.valid
}

type googleVerifierStub struct {
	identity GoogleIdentity
	err      error
	token    string
}

func (v *googleVerifierStub) Verify(_ context.Context, idToken string) (GoogleIdentity, error) {
	v.token = idToken
	return v.identity, v.err
}

type tokenManagerStub struct {
	token     string
	expiresAt time.Time
	claims    TokenClaims
	errGen    error
	errVal    error
}

func (t tokenManagerStub) Generate(User) (string, time.Time, error) {
	return t.token, t.expiresAt, t.errGen
}

func (t tokenManagerStub) Validate(string) (TokenClaims, error) {
	return t.claims, t.errVal
}

func TestServiceRegisterCreatesVehicleOwner(t *testing.T) {
	repository := &repositoryStub{
		role: Role{ID: testRoleID, Code: DefaultRoleCode},
		user: User{
			ID:       testUserID,
			RoleID:   testRoleID,
			Role:     DefaultRoleCode,
			Email:    "user@example.com",
			FullName: "Viktor Novomlynskyi",
			IsActive: true,
		},
	}
	hasher := &hasherStub{hash: "hashed-password"}
	service := NewService(
		repository,
		hasher,
		tokenManagerStub{token: "jwt", expiresAt: time.Unix(100, 0)},
	)

	result, err := service.Register(context.Background(), RegisterRequest{
		Email:     "USER@example.com",
		Password:  "StrongPassword123!",
		FirstName: "Viktor",
		LastName:  "Novomlynskyi",
	})
	if err != nil {
		t.Fatalf("Register() returned an error: %v", err)
	}
	if repository.createRoleID != testRoleID {
		t.Fatalf("expected vehicle_owner role ID, got %s", repository.createRoleID)
	}
	if repository.roleCode != DefaultRoleCode {
		t.Fatalf("expected vehicle_owner role lookup, got %s", repository.roleCode)
	}
	if repository.createEmail != "user@example.com" {
		t.Fatalf("expected normalized email, got %s", repository.createEmail)
	}
	if repository.createFullName != "Viktor Novomlynskyi" {
		t.Fatalf("expected full name to be built from first and last name, got %s", repository.createFullName)
	}
	if hasher.rawValue != "StrongPassword123!" {
		t.Fatal("password was not passed to hasher")
	}
	if repository.createHash != "hashed-password" {
		t.Fatalf("expected hashed password to be stored, got %q", repository.createHash)
	}
	if repository.createHash == hasher.rawValue {
		t.Fatal("plaintext password was stored")
	}
	if result.AccessToken != "jwt" || result.TokenType != "Bearer" {
		t.Fatalf("unexpected auth response: %#v", result)
	}
	if result.User.Role != DefaultRoleCode {
		t.Fatalf("expected registered user role vehicle_owner, got %s", result.User.Role)
	}
}

func TestServiceRegisterValidationAndDuplicateEmail(t *testing.T) {
	service := NewService(&repositoryStub{}, &hasherStub{}, tokenManagerStub{})
	if _, err := service.Register(context.Background(), RegisterRequest{
		Email:     "bad",
		Password:  "weak",
		FirstName: "Viktor",
	}); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}

	duplicateRepository := &repositoryStub{
		role:      Role{ID: testRoleID, Code: DefaultRoleCode},
		errCreate: ErrEmailAlreadyExists,
	}
	service = NewService(
		duplicateRepository,
		&hasherStub{hash: "hashed-password"},
		tokenManagerStub{},
	)
	if _, err := service.Register(context.Background(), RegisterRequest{
		Email:    "USER@example.com",
		Password: "StrongPassword123!",
		FullName: "Viktor Novomlynskyi",
	}); !errors.Is(err, ErrEmailAlreadyExists) {
		t.Fatalf("expected ErrEmailAlreadyExists, got %v", err)
	}
	if duplicateRepository.createEmail != "user@example.com" {
		t.Fatalf("expected duplicate check to use normalized email, got %s", duplicateRepository.createEmail)
	}
}

func TestServiceRegisterReturnsUsableJWTForCurrentUser(t *testing.T) {
	user := User{
		ID:       testUserID,
		RoleID:   testRoleID,
		Role:     DefaultRoleCode,
		Email:    "owner2@example.com",
		FullName: "New Vehicle Owner",
		IsActive: true,
	}
	repository := &repositoryStub{
		role: Role{ID: testRoleID, Code: DefaultRoleCode},
		user: user,
	}
	tokens := NewJWTManager("test-secret", time.Hour)
	service := NewService(
		repository,
		&hasherStub{hash: "hashed-password"},
		tokens,
	)

	result, err := service.Register(context.Background(), RegisterRequest{
		FullName: "New Vehicle Owner",
		Email:    "Owner2@Example.com",
		Password: "SecurePass123!",
	})
	if err != nil {
		t.Fatalf("Register() returned an error: %v", err)
	}

	current, err := service.CurrentUser(context.Background(), result.AccessToken)
	if err != nil {
		t.Fatalf("CurrentUser() with returned token failed: %v", err)
	}
	if current.ID != testUserID || current.Role != DefaultRoleCode {
		t.Fatalf("unexpected current user from returned token: %#v", current)
	}
}

func TestServiceLogin(t *testing.T) {
	hash := "hashed-password"
	repository := &repositoryStub{
		userWithPass: UserWithPassword{
			User: User{
				ID:       testUserID,
				Role:     DefaultRoleCode,
				Email:    "user@example.com",
				IsActive: true,
			},
			PasswordHash: &hash,
		},
	}
	service := NewService(
		repository,
		&hasherStub{valid: true},
		tokenManagerStub{token: "jwt"},
	)

	result, err := service.Login(context.Background(), LoginRequest{
		Email:    "user@example.com",
		Password: "StrongPassword123!",
	})
	if err != nil {
		t.Fatalf("Login() returned an error: %v", err)
	}
	if result.AccessToken != "jwt" {
		t.Fatalf("expected token jwt, got %s", result.AccessToken)
	}
	if repository.lookupEmail != "user@example.com" {
		t.Fatalf("expected normalized login email, got %s", repository.lookupEmail)
	}
}

func TestServiceLoginRejectsInvalidCredentials(t *testing.T) {
	service := NewService(
		&repositoryStub{errEmailLookup: ErrUserNotFound},
		&hasherStub{},
		tokenManagerStub{},
	)
	if _, err := service.Login(context.Background(), LoginRequest{
		Email:    "missing@example.com",
		Password: "StrongPassword123!",
	}); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("expected ErrInvalidCredentials for missing user, got %v", err)
	}

	service = NewService(
		&repositoryStub{userWithPass: UserWithPassword{User: User{IsActive: true}}},
		&hasherStub{valid: false},
		tokenManagerStub{},
	)
	if _, err := service.Login(context.Background(), LoginRequest{
		Email:    "user@example.com",
		Password: "WrongPassword123!",
	}); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("expected ErrInvalidCredentials for invalid password, got %v", err)
	}
}

func TestServiceLoginRejectsInactiveUserAndAllowsReactivatedUser(t *testing.T) {
	hash := "hashed-password"
	service := NewService(
		&repositoryStub{userWithPass: UserWithPassword{
			User:         User{Email: "user@example.com", IsActive: false},
			PasswordHash: &hash,
		}},
		&hasherStub{valid: true},
		tokenManagerStub{},
	)
	if _, err := service.Login(context.Background(), LoginRequest{
		Email:    "user@example.com",
		Password: "StrongPassword123!",
	}); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("expected ErrInvalidCredentials for inactive user, got %v", err)
	}

	service = NewService(
		&repositoryStub{userWithPass: UserWithPassword{
			User:         User{ID: testUserID, Email: "user@example.com", IsActive: true},
			PasswordHash: &hash,
		}},
		&hasherStub{valid: true},
		tokenManagerStub{token: "jwt"},
	)
	result, err := service.Login(context.Background(), LoginRequest{
		Email:    "user@example.com",
		Password: "StrongPassword123!",
	})
	if err != nil {
		t.Fatalf("expected reactivated user to login, got %v", err)
	}
	if result.AccessToken != "jwt" {
		t.Fatalf("expected jwt token, got %q", result.AccessToken)
	}
}

func TestServiceCurrentUser(t *testing.T) {
	service := NewService(
		&repositoryStub{user: User{ID: testUserID, Email: "user@example.com", IsActive: true}},
		&hasherStub{},
		tokenManagerStub{claims: TokenClaims{Subject: testUserID}},
	)

	user, err := service.CurrentUser(context.Background(), "jwt")
	if err != nil {
		t.Fatalf("CurrentUser() returned an error: %v", err)
	}
	if user.ID != testUserID {
		t.Fatalf("expected user ID %s, got %s", testUserID, user.ID)
	}

	service = NewService(
		&repositoryStub{},
		&hasherStub{},
		tokenManagerStub{errVal: ErrInvalidToken},
	)
	if _, err := service.CurrentUser(context.Background(), "bad"); !errors.Is(err, ErrUnauthorized) {
		t.Fatalf("expected ErrUnauthorized, got %v", err)
	}
}

func TestServiceCurrentUserRejectsExistingTokenForInactiveUser(t *testing.T) {
	service := NewService(
		&repositoryStub{user: User{ID: testUserID, Email: "user@example.com", IsActive: false}},
		&hasherStub{},
		tokenManagerStub{claims: TokenClaims{Subject: testUserID}},
	)

	if _, err := service.CurrentUser(context.Background(), "previously-issued-token"); !errors.Is(err, ErrUnauthorized) {
		t.Fatalf("expected ErrUnauthorized for inactive user token, got %v", err)
	}
}

func TestServiceGoogleLoginRejectsUnavailableAndInvalidInput(t *testing.T) {
	service := NewService(&repositoryStub{}, &hasherStub{}, tokenManagerStub{})
	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: ""}); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for empty token, got %v", err)
	}
	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"}); !errors.Is(err, ErrGoogleAuthUnavailable) {
		t.Fatalf("expected ErrGoogleAuthUnavailable, got %v", err)
	}
}

func TestServiceGoogleLoginRejectsInvalidAndUnverifiedIdentity(t *testing.T) {
	service := NewServiceWithGoogle(
		&repositoryStub{},
		&hasherStub{},
		tokenManagerStub{},
		&googleVerifierStub{err: ErrInvalidGoogleToken},
		true,
	)
	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "bad-token"}); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken, got %v", err)
	}

	service = NewServiceWithGoogle(
		&repositoryStub{},
		&hasherStub{},
		tokenManagerStub{},
		&googleVerifierStub{err: ErrGoogleVerificationUnavailable},
		true,
	)
	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"}); !errors.Is(err, ErrGoogleVerificationUnavailable) {
		t.Fatalf("expected ErrGoogleVerificationUnavailable, got %v", err)
	}

	service = NewServiceWithGoogle(
		&repositoryStub{},
		&hasherStub{},
		tokenManagerStub{},
		&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: false}},
		true,
	)
	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"}); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken for unverified email, got %v", err)
	}
}

func TestServiceGoogleLoginExistingLinkedUserReceivesJWTAndRoleIsPreserved(t *testing.T) {
	linked := User{
		ID:       testUserID,
		RoleID:   "00000000-0000-0000-0000-000000000003",
		Role:     AdministratorRoleCode,
		Email:    "admin@example.com",
		FullName: "Admin User",
		IsActive: true,
	}
	repository := &repositoryStub{oauthUser: linked}
	verifier := &googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "admin@example.com", EmailVerified: true}}
	service := NewServiceWithGoogle(
		repository,
		&hasherStub{},
		tokenManagerStub{token: "jwt", expiresAt: time.Unix(100, 0)},
		verifier,
		true,
	)

	result, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: " token "})
	if err != nil {
		t.Fatalf("GoogleLogin() returned an error: %v", err)
	}
	if verifier.token != "token" {
		t.Fatalf("expected trimmed token, got %q", verifier.token)
	}
	if result.AccessToken != "jwt" || result.User.Role != AdministratorRoleCode {
		t.Fatalf("expected existing linked admin auth response, got %#v", result)
	}
	if repository.lookupEmail != "" || repository.createOAuthEmail != "" {
		t.Fatal("existing linked user should not trigger email lookup or user creation")
	}
}

func TestServiceGoogleLoginRejectsInactiveLinkedUser(t *testing.T) {
	service := NewServiceWithGoogle(
		&repositoryStub{oauthUser: User{ID: testUserID, Email: "user@example.com", IsActive: false}},
		&hasherStub{},
		tokenManagerStub{},
		&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: true}},
		true,
	)

	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"}); !errors.Is(err, ErrInactiveUser) {
		t.Fatalf("expected ErrInactiveUser, got %v", err)
	}
}

func TestServiceGoogleLoginCreatesNewVehicleOwnerWithoutPassword(t *testing.T) {
	repository := &repositoryStub{
		errOAuthLookup: ErrUserNotFound,
		errEmailLookup: ErrUserNotFound,
		role:           Role{ID: testRoleID, Code: DefaultRoleCode},
		user: User{
			ID:       testUserID,
			RoleID:   testRoleID,
			Role:     DefaultRoleCode,
			Email:    "new@example.com",
			FullName: "New Owner",
			IsActive: true,
		},
	}
	service := NewServiceWithGoogle(
		repository,
		&hasherStub{},
		tokenManagerStub{token: "jwt"},
		&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: " NEW@example.com ", FullName: " New Owner ", EmailVerified: true}},
		true,
	)

	result, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"})
	if err != nil {
		t.Fatalf("GoogleLogin() returned an error: %v", err)
	}
	if result.User.Role != DefaultRoleCode {
		t.Fatalf("expected vehicle_owner, got %s", result.User.Role)
	}
	if repository.roleCode != DefaultRoleCode || repository.createRoleID != testRoleID {
		t.Fatalf("expected vehicle_owner role creation, roleCode=%s roleID=%s", repository.roleCode, repository.createRoleID)
	}
	if repository.createOAuthEmail != "new@example.com" {
		t.Fatalf("expected normalized email, got %s", repository.createOAuthEmail)
	}
	if repository.createOAuthFullName != "New Owner" {
		t.Fatalf("expected Google full name, got %q", repository.createOAuthFullName)
	}
	if repository.createOAuthProvider != GoogleProvider || repository.createOAuthAccountID != "google-sub" {
		t.Fatalf("unexpected OAuth identity: %s %s", repository.createOAuthProvider, repository.createOAuthAccountID)
	}
	if repository.createHash != "" {
		t.Fatal("Google user creation should not hash or store a password")
	}
}

func TestServiceGoogleLoginUsesEmailLocalPartFallbackName(t *testing.T) {
	repository := &repositoryStub{
		errOAuthLookup: ErrUserNotFound,
		errEmailLookup: ErrUserNotFound,
		role:           Role{ID: testRoleID, Code: DefaultRoleCode},
		user:           User{ID: testUserID, Role: DefaultRoleCode, IsActive: true},
	}
	service := NewServiceWithGoogle(
		repository,
		&hasherStub{},
		tokenManagerStub{token: "jwt"},
		&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "new.owner@example.com", EmailVerified: true}},
		true,
	)

	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"}); err != nil {
		t.Fatalf("GoogleLogin() returned an error: %v", err)
	}
	if repository.createOAuthFullName != "new owner" {
		t.Fatalf("expected fallback name from local part, got %q", repository.createOAuthFullName)
	}
}

func TestServiceGoogleLoginExistingEmailRequiresExplicitLinking(t *testing.T) {
	service := NewServiceWithGoogle(
		&repositoryStub{
			errOAuthLookup: ErrUserNotFound,
			userWithPass:   UserWithPassword{User: User{ID: testUserID, Email: "user@example.com", IsActive: true}},
		},
		&hasherStub{},
		tokenManagerStub{},
		&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: true}},
		true,
	)

	if _, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"}); !errors.Is(err, ErrGoogleEmailRequiresLinking) {
		t.Fatalf("expected ErrGoogleEmailRequiresLinking, got %v", err)
	}
}

func TestServiceGoogleLoginDuplicateOAuthCreationLoadsExistingUser(t *testing.T) {
	linked := User{ID: testUserID, Role: DefaultRoleCode, Email: "user@example.com", IsActive: true}
	repository := &repositoryStub{
		errOAuthLookup: ErrUserNotFound,
		errEmailLookup: ErrUserNotFound,
		errCreateOAuth: ErrOAuthAccountAlreadyExists,
		role:           Role{ID: testRoleID, Code: DefaultRoleCode},
		oauthUser:      linked,
	}
	service := NewServiceWithGoogle(
		repository,
		&hasherStub{},
		tokenManagerStub{token: "jwt"},
		&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: true}},
		true,
	)

	result, err := service.GoogleLogin(context.Background(), GoogleLoginRequest{IDToken: "token"})
	if err != nil {
		t.Fatalf("GoogleLogin() returned an error: %v", err)
	}
	if result.User.ID != testUserID || result.AccessToken != "jwt" {
		t.Fatalf("expected existing linked user after duplicate race, got %#v", result)
	}
}

func TestServiceAuthMethodsStatuses(t *testing.T) {
	tests := []struct {
		name   string
		status AuthMethodStatus
	}{
		{name: "password only", status: AuthMethodStatus{PasswordEnabled: true, GoogleLinked: false}},
		{name: "google only", status: AuthMethodStatus{PasswordEnabled: false, GoogleLinked: true}},
		{name: "both", status: AuthMethodStatus{PasswordEnabled: true, GoogleLinked: true}},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			service := NewServiceWithGoogle(
				&repositoryStub{methodStatus: tc.status},
				&hasherStub{},
				tokenManagerStub{},
				&googleVerifierStub{},
				true,
			)

			status, err := service.AuthMethods(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true})
			if err != nil {
				t.Fatalf("AuthMethods() returned an error: %v", err)
			}
			if status != tc.status {
				t.Fatalf("expected %#v, got %#v", tc.status, status)
			}
		})
	}
}

func TestServiceLinkGoogleSucceedsForAllRolesWithoutChangingRole(t *testing.T) {
	roles := []string{DefaultRoleCode, TechnicalSpecialistRoleCode, AdministratorRoleCode}
	for _, role := range roles {
		t.Run(role, func(t *testing.T) {
			repository := &repositoryStub{linkStatus: AuthMethodStatus{PasswordEnabled: true, GoogleLinked: true}}
			verifier := &googleVerifierStub{identity: GoogleIdentity{Subject: " google-sub ", Email: " USER@example.com ", EmailVerified: true}}
			service := NewServiceWithGoogle(
				repository,
				&hasherStub{},
				tokenManagerStub{},
				verifier,
				true,
			)

			status, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", Role: role, IsActive: true}, GoogleLinkRequest{IDToken: " token "})
			if err != nil {
				t.Fatalf("LinkGoogle() returned an error: %v", err)
			}
			if !status.GoogleLinked {
				t.Fatalf("expected linked status, got %#v", status)
			}
			if verifier.token != "token" {
				t.Fatalf("expected trimmed token, got %q", verifier.token)
			}
			if repository.linkUserID != testUserID || repository.linkProviderAccount != "google-sub" {
				t.Fatalf("unexpected link arguments: user=%s account=%s", repository.linkUserID, repository.linkProviderAccount)
			}
		})
	}
}

func TestServiceLinkGoogleValidationAndVerifierErrors(t *testing.T) {
	service := NewServiceWithGoogle(&repositoryStub{}, &hasherStub{}, tokenManagerStub{}, &googleVerifierStub{}, true)
	if _, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true}, GoogleLinkRequest{}); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for empty token, got %v", err)
	}

	service = NewServiceWithGoogle(&repositoryStub{}, &hasherStub{}, tokenManagerStub{}, &googleVerifierStub{}, false)
	if _, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true}, GoogleLinkRequest{IDToken: "token"}); !errors.Is(err, ErrGoogleAuthUnavailable) {
		t.Fatalf("expected ErrGoogleAuthUnavailable, got %v", err)
	}

	service = NewServiceWithGoogle(&repositoryStub{}, &hasherStub{}, tokenManagerStub{}, &googleVerifierStub{err: ErrInvalidGoogleToken}, true)
	if _, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true}, GoogleLinkRequest{IDToken: "raw-secret-token"}); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken, got %v", err)
	} else if strings.Contains(err.Error(), "raw-secret-token") {
		t.Fatal("error exposed raw token")
	}

	service = NewServiceWithGoogle(&repositoryStub{}, &hasherStub{}, tokenManagerStub{}, &googleVerifierStub{err: ErrGoogleVerificationUnavailable}, true)
	if _, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true}, GoogleLinkRequest{IDToken: "token"}); !errors.Is(err, ErrGoogleVerificationUnavailable) {
		t.Fatalf("expected ErrGoogleVerificationUnavailable, got %v", err)
	}
}

func TestServiceLinkGoogleRejectsInvalidIdentityAndEmailMismatch(t *testing.T) {
	tests := []struct {
		name     string
		identity GoogleIdentity
		want     error
	}{
		{name: "empty subject", identity: GoogleIdentity{Email: "user@example.com", EmailVerified: true}, want: ErrInvalidGoogleToken},
		{name: "unverified email", identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: false}, want: ErrInvalidGoogleToken},
		{name: "invalid email", identity: GoogleIdentity{Subject: "google-sub", Email: "bad", EmailVerified: true}, want: ErrInvalidGoogleToken},
		{name: "email mismatch", identity: GoogleIdentity{Subject: "google-sub", Email: "other@example.com", EmailVerified: true}, want: ErrGoogleEmailMismatch},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			service := NewServiceWithGoogle(
				&repositoryStub{},
				&hasherStub{},
				tokenManagerStub{},
				&googleVerifierStub{identity: tc.identity},
				true,
			)

			_, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true}, GoogleLinkRequest{IDToken: "token"})
			if !errors.Is(err, tc.want) {
				t.Fatalf("expected %v, got %v", tc.want, err)
			}
		})
	}
}

func TestServiceLinkGooglePropagatesRepositoryConflictsAndIdempotency(t *testing.T) {
	tests := []struct {
		name       string
		repository *repositoryStub
		want       error
	}{
		{name: "identity linked to another user", repository: &repositoryStub{errLinkGoogle: ErrGoogleIdentityLinkedToOtherUser}, want: ErrGoogleIdentityLinkedToOtherUser},
		{name: "user linked to different google", repository: &repositoryStub{errLinkGoogle: ErrUserLinkedToDifferentGoogle}, want: ErrUserLinkedToDifferentGoogle},
		{name: "insert failure rolls back in repository", repository: &repositoryStub{errLinkGoogle: errors.New("insert failed")}, want: errors.New("insert failed")},
		{name: "idempotent same user", repository: &repositoryStub{linkStatus: AuthMethodStatus{GoogleLinked: true}}, want: nil},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			service := NewServiceWithGoogle(
				tc.repository,
				&hasherStub{},
				tokenManagerStub{},
				&googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: true}},
				true,
			)

			status, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: true}, GoogleLinkRequest{IDToken: "token"})
			if tc.want == nil {
				if err != nil {
					t.Fatalf("LinkGoogle() returned an error: %v", err)
				}
				if !status.GoogleLinked {
					t.Fatalf("expected google linked status, got %#v", status)
				}
				return
			}
			if err == nil {
				t.Fatal("expected an error")
			}
			if !errors.Is(err, tc.want) && err.Error() != tc.want.Error() {
				t.Fatalf("expected %v, got %v", tc.want, err)
			}
		})
	}
}

func TestServiceLinkGoogleRejectsInactiveUser(t *testing.T) {
	verifier := &googleVerifierStub{identity: GoogleIdentity{Subject: "google-sub", Email: "user@example.com", EmailVerified: true}}
	service := NewServiceWithGoogle(
		&repositoryStub{},
		&hasherStub{},
		tokenManagerStub{},
		verifier,
		true,
	)

	if _, err := service.LinkGoogle(context.Background(), User{ID: testUserID, Email: "user@example.com", IsActive: false}, GoogleLinkRequest{IDToken: "token"}); !errors.Is(err, ErrInactiveUser) {
		t.Fatalf("expected ErrInactiveUser, got %v", err)
	}
	if verifier.token != "" {
		t.Fatal("inactive user should be rejected before verifier is called")
	}
}
