import { useLocale, useMessages } from '../i18n';
import { formatTelemetryMetricDelta, formatTelemetryMetricValue, formatTimestamp, type TelemetryMetricKey } from '../utils/presentation';
import type { TelemetryRecord } from '../api/types';

type Props = {
  records: TelemetryRecord[];
  isLoading: boolean;
  title?: string;
  description?: string;
  emptyMessage?: string;
  loadingMessage?: string;
};

type MetricSummary = {
  label: string;
  value: number;
  previous?: number;
  metric: TelemetryMetricKey;
};

function formatDelta(
  current: number,
  previous: number | undefined,
  metric: TelemetryMetricKey,
  messages: Record<string, string>,
  locale: 'en' | 'uk',
): string {
  if (previous === undefined) {
    return messages.firstSample;
  }

  const delta = current - previous;
  if (Math.abs(delta) < 0.05) {
    return messages.noChange;
  }

  return formatTelemetryMetricDelta(metric, delta, locale);
}

function deltaClass(current: number, previous?: number): string {
  if (previous === undefined || Math.abs(current - previous) < 0.05) {
    return 'trend-delta neutral';
  }

  return current > previous ? 'trend-delta upward' : 'trend-delta downward';
}

export function TelemetryHistory({
  records,
  isLoading,
  title,
  description,
  emptyMessage,
  loadingMessage,
}: Props) {
  const { common, specialist, structuredLabels } = useMessages();
  const { locale } = useLocale();
  const diagnosticsMessages = specialist.diagnostics;
  const resolvedTitle = title ?? diagnosticsMessages.telemetryTitle;
  const resolvedDescription = description ?? diagnosticsMessages.telemetryDescription;
  const resolvedEmptyMessage = emptyMessage ?? diagnosticsMessages.telemetryEmpty;
  const initialLoadingMessage = loadingMessage ?? common.loadingTelemetryHistory;
  const latest = records[0];
  const previous = records[1];
  const summaries: MetricSummary[] = latest
    ? [
        {
          label: structuredLabels.engine_temperature,
          value: latest.engine_temperature,
          previous: previous?.engine_temperature,
          metric: 'engine_temperature',
        },
        {
          label: structuredLabels.rpm,
          value: latest.rpm,
          previous: previous?.rpm,
          metric: 'rpm',
        },
        {
          label: structuredLabels.speed,
          value: latest.speed,
          previous: previous?.speed,
          metric: 'speed',
        },
        {
          label: structuredLabels.fuel_level,
          value: latest.fuel_level,
          previous: previous?.fuel_level,
          metric: 'fuel_level',
        },
      ]
    : [];

  return (
    <section className="panel telemetry-history">
      <div className="panel-header">
        <div>
          <h2>{resolvedTitle}</h2>
          <p className="muted">{resolvedDescription}</p>
        </div>
        {isLoading && <span className="badge">{common.refreshing}</span>}
      </div>

      {summaries.length > 0 && (
        <div className="trend-grid">
          {summaries.map((summary) => (
            <div className="trend-card" key={summary.label}>
              <span>{summary.label}</span>
              <strong>
                {formatTelemetryMetricValue(summary.metric, summary.value, locale)}
              </strong>
              <small className={deltaClass(summary.value, summary.previous)}>
                {formatDelta(summary.value, summary.previous, summary.metric, diagnosticsMessages, locale)}
              </small>
            </div>
          ))}
        </div>
      )}

      {isLoading && records.length === 0 ? (
        <p className="info-box">{initialLoadingMessage}</p>
      ) : records.length === 0 ? (
        <p className="empty-state">{resolvedEmptyMessage}</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{common.measuredAt}</th>
                <th>{diagnosticsMessages.temperatureShort}</th>
                <th>{structuredLabels.battery_voltage}</th>
                <th>{structuredLabels.vibration_level}</th>
                <th>{structuredLabels.rpm}</th>
                <th>{structuredLabels.speed}</th>
                <th>{structuredLabels.fuel_level}</th>
              </tr>
            </thead>
            <tbody>
              {records.map((record) => (
                <tr key={record.id}>
                  <td>{formatTimestamp(record.measured_at, common.notAvailable)}</td>
                  <td>{formatTelemetryMetricValue('engine_temperature', record.engine_temperature, locale)}</td>
                  <td>{formatTelemetryMetricValue('battery_voltage', record.battery_voltage, locale)}</td>
                  <td>{formatTelemetryMetricValue('vibration_level', record.vibration_level, locale)}</td>
                  <td>{formatTelemetryMetricValue('rpm', record.rpm, locale)}</td>
                  <td>{formatTelemetryMetricValue('speed', record.speed, locale)}</td>
                  <td>{formatTelemetryMetricValue('fuel_level', record.fuel_level, locale)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
