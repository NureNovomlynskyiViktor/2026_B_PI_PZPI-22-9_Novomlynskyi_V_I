package mqttconsumer

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/config"
)

func TestSupervisorReturnsQuicklyWhenMQTTStartFails(t *testing.T) {
	starter := newFakeStarter(errors.New("broker unavailable"))
	supervisor := newTestSupervisor(starter, 50*time.Millisecond)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	startedAt := time.Now()
	supervisor.Start(ctx)
	if elapsed := time.Since(startedAt); elapsed > 50*time.Millisecond {
		t.Fatalf("Start() blocked for %s", elapsed)
	}
	starter.waitForCalls(t, 1)

	supervisor.Close()
}

func TestSupervisorRetriesTemporaryMQTTFailuresWithoutExiting(t *testing.T) {
	starter := newFakeStarter(errors.New("connect failed"), nil)
	supervisor := newTestSupervisor(starter, time.Millisecond)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	supervisor.Start(ctx)
	starter.waitForCalls(t, 2)
	waitForDone(t, supervisor.done)

	if got := starter.calls(); got != 2 {
		t.Fatalf("unexpected start calls: %d", got)
	}
	if !starter.wasStartedSuccessfully() {
		t.Fatal("expected successful start to be recorded")
	}

	supervisor.Close()
}

func TestSupervisorRetryStopsWhenContextIsCancelled(t *testing.T) {
	starter := newFakeStarter(errors.New("connect failed"), errors.New("should not retry"))
	supervisor := newTestSupervisor(starter, time.Hour)
	ctx, cancel := context.WithCancel(context.Background())

	supervisor.Start(ctx)
	starter.waitForCalls(t, 1)
	cancel()
	waitForDone(t, supervisor.done)

	if got := starter.calls(); got != 1 {
		t.Fatalf("expected one start attempt before cancellation, got %d", got)
	}
	supervisor.Close()
}

func TestSupervisorBackoffIsBounded(t *testing.T) {
	supervisor := newTestSupervisor(newFakeStarter(), time.Second, 2*time.Second, 30*time.Second)

	cases := map[int]time.Duration{
		-1: time.Second,
		0:  time.Second,
		1:  2 * time.Second,
		2:  30 * time.Second,
		3:  30 * time.Second,
		99: 30 * time.Second,
	}
	for attempt, want := range cases {
		if got := supervisor.backoffForAttempt(attempt); got != want {
			t.Fatalf("backoffForAttempt(%d) = %s, want %s", attempt, got, want)
		}
	}
}

func TestSupervisorCloseIsSafeWhenConsumerNeverConnected(t *testing.T) {
	starter := newFakeStarter(errors.New("connect failed"), errors.New("still unavailable"))
	supervisor := newTestSupervisor(starter, time.Hour)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	supervisor.Start(ctx)
	starter.waitForCalls(t, 1)
	supervisor.Close()

	if got := starter.closeCalls(); got != 1 {
		t.Fatalf("expected one Close call, got %d", got)
	}
	if got := starter.calls(); got != 1 {
		t.Fatalf("expected no retry after Close, got %d start calls", got)
	}
}

func newTestSupervisor(starter *fakeStarter, backoff ...time.Duration) *Supervisor {
	return newSupervisorWithBackoff(
		starter,
		config.MQTTConfig{
			BrokerHost:     "broker.example.test",
			BrokerPort:     1883,
			ClientID:       "autonexis-test",
			TelemetryTopic: testTopicFilter,
		},
		slog.New(slog.NewTextHandler(io.Discard, nil)),
		backoff,
	)
}

type fakeStarter struct {
	mu        sync.Mutex
	results   []error
	callCount int
	closed    int
	started   bool
	callsCh   chan int
}

func newFakeStarter(results ...error) *fakeStarter {
	return &fakeStarter{
		results: results,
		callsCh: make(chan int, 16),
	}
}

func (s *fakeStarter) Start(context.Context) error {
	s.mu.Lock()
	s.callCount++
	call := s.callCount
	var err error
	if call <= len(s.results) {
		err = s.results[call-1]
	}
	if err == nil {
		s.started = true
	}
	s.mu.Unlock()

	s.callsCh <- call
	return err
}

func (s *fakeStarter) Close() {
	s.mu.Lock()
	s.closed++
	s.mu.Unlock()
}

func (s *fakeStarter) calls() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.callCount
}

func (s *fakeStarter) closeCalls() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.closed
}

func (s *fakeStarter) wasStartedSuccessfully() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.started
}

func (s *fakeStarter) waitForCalls(t *testing.T, want int) {
	t.Helper()
	deadline := time.After(time.Second)
	for {
		if s.calls() >= want {
			return
		}
		select {
		case <-s.callsCh:
		case <-deadline:
			t.Fatalf("timed out waiting for %d start calls; got %d", want, s.calls())
		}
	}
}

func waitForDone(t *testing.T, done <-chan struct{}) {
	t.Helper()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for supervisor to stop")
	}
}
