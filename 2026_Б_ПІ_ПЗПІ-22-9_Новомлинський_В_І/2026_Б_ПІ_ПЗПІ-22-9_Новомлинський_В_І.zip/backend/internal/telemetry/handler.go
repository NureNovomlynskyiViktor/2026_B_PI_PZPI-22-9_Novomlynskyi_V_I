package telemetry

import (
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) ListByVehicle(w http.ResponseWriter, r *http.Request) {
	vehicleID := r.PathValue("vehicle_id")
	limit, err := ParseLimit(r.URL.Query().Get("limit"))
	if err != nil {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}

	records, err := h.service.ListByVehicle(r.Context(), vehicleID, limit)
	if errors.Is(err, ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, ErrInvalidLimit) {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list telemetry records",
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, records)
}

func (h *Handler) LatestByVehicle(w http.ResponseWriter, r *http.Request) {
	vehicleID := r.PathValue("vehicle_id")

	record, err := h.service.LatestByVehicle(r.Context(), vehicleID)
	if errors.Is(err, ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, ErrNotFound) {
		response.Error(w, http.StatusNotFound, "telemetry not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get latest telemetry record",
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, record)
}
