# Autonexis ERD Notes

The authoritative database schema is defined by backend migrations:

- `backend/migrations/001_create_initial_schema.up.sql`
- `backend/migrations/002_create_vehicle_specialist_assignments.up.sql`
- `backend/migrations/003_create_specialist_competencies.up.sql`
- `backend/migrations/004_vehicle_activation_codes.up.sql`
- `backend/migrations/005_vehicle_service_requests.up.sql`
- `backend/migrations/006_service_request_alert_link.up.sql`
- `backend/migrations/007_service_request_notifications.up.sql`
- `backend/migrations/008_user_deactivation_tracking.up.sql`
- `backend/migrations/009_audit_log_read_indexes.up.sql`
- `backend/migrations/010_stabilized_alert_lifecycle.up.sql`
- `backend/migrations/011_alert_specialist_resolution.up.sql`

Development demo data is defined in:

- `backend/seeds/dev_seed.sql`

The written schema reference is:

- `docs/specification/database-schema.md`

## Major Domains

- Identity and access: users, roles, OAuth accounts, user activation/deactivation state.
- Vehicle ownership and onboarding: vehicles, devices, one-time vehicle activation codes.
- Telemetry and diagnostics: telemetry records, threshold settings, alert incidents.
- Service operations: service requests, specialist assignments, specialist competencies, maintenance records.
- Owner communication: notifications for alerts and service-request lifecycle events.
- Administration and traceability: audit logs for administrative actions.

## ERD Export Recommendation

Generate the final ERD from the migrations rather than drawing tables manually. Keep table names, foreign keys, nullability, and status/check constraints aligned with the migration files. Use this note as an index, not as a replacement for the SQL schema.

Recommended committed export formats:

- editable source, if produced by a diagram tool;
- SVG for diploma text and presentation slides;
- PNG only if the final document tool cannot consume SVG cleanly.

Avoid including local database connection strings, real user emails, tokens, or environment-specific values in ERD exports.

