package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNull

class ActivationCodeParserTest {
    @Test
    fun parsesCanonicalActivationUri() {
        val result = ActivationCodeParser.parseScannedValue(
            "autonexis://vehicle-activation?code=RNF6-CQSD",
        )

        assertEquals("RNF6-CQSD", assertIs<ParseResult.Success>(result).activationCode)
    }

    @Test
    fun parsesRawActivationCode() {
        val result = ActivationCodeParser.parseScannedValue(" rnf6 cqsd ")

        assertEquals("RNF6-CQSD", assertIs<ParseResult.Success>(result).activationCode)
    }

    @Test
    fun rejectsWrongSchemeMissingCodeBlankAndMalformedPayloads() {
        val invalidValues = listOf(
            "https://vehicle-activation?code=RNF6-CQSD",
            "autonexis://vehicle-activation",
            "   ",
            "autonexis://vehicle-activation?code=bad",
            "autonexis://%",
        )

        invalidValues.forEach { value ->
            assertIs<ParseResult.Invalid>(ActivationCodeParser.parseScannedValue(value))
        }
    }

    @Test
    fun preservesManualActivationCodeNormalization() {
        assertEquals("RNF6-CQSD", ActivationCodeParser.normalizeManualCode(" rnf6-cqsd "))
        assertEquals("RNF6-CQSD", ActivationCodeParser.normalizeManualCode("RNF6 CQSD"))
        assertNull(ActivationCodeParser.normalizeManualCode("RNF6-CQS1"))
    }
}
