package telemetry

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

const testVehicleID = "22222222-2222-2222-2222-222222222222"

type stubService struct {
	records []Record
	record  Record
	err     error
	limit   int
}

func (s *stubService) ListByVehicle(
	_ context.Context,
	_ string,
	limit int,
) ([]Record, error) {
	s.limit = limit
	return s.records, s.err
}

func (s *stubService) LatestByVehicle(context.Context, string) (Record, error) {
	return s.record, s.err
}

func TestHandlerListUsesDefaultLimit(t *testing.T) {
	service := &stubService{records: []Record{}}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/telemetry",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.limit != DefaultLimit {
		t.Fatalf("expected default limit %d, got %d", DefaultLimit, service.limit)
	}
	if body := recorder.Body.String(); strings.TrimSpace(body) != "[]" {
		t.Fatalf("expected empty JSON array, got %s", body)
	}
}

func TestHandlerListRejectsInvalidLimit(t *testing.T) {
	handler := NewHandler(&stubService{}, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/telemetry?limit=201",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerListRejectsInvalidVehicleID(t *testing.T) {
	handler := NewHandler(
		&stubService{err: ErrInvalidVehicleID},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/invalid/telemetry",
		nil,
	)
	request.SetPathValue("vehicle_id", "invalid")
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerLatestNotFound(t *testing.T) {
	handler := NewHandler(&stubService{err: ErrNotFound}, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/telemetry/latest",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.LatestByVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestHandlerDoesNotExposeInternalError(t *testing.T) {
	handler := NewHandler(
		&stubService{err: errors.New("database details")},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/telemetry",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, recorder.Code)
	}
	if strings.Contains(recorder.Body.String(), "database details") {
		t.Fatal("response exposed an internal error")
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
