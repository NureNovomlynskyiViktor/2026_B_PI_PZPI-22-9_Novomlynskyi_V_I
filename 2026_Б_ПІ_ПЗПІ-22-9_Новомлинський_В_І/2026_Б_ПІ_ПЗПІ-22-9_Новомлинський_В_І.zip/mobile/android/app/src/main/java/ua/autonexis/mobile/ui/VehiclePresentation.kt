package ua.autonexis.mobile.ui

internal object VehiclePresentation {
    private const val separator = " \u2022 "

    fun metadata(year: Int?, licensePlate: String?): String? {
        val normalizedYear = year?.takeIf { it > 0 }?.toString()
        val normalizedPlate = licensePlate?.trim()?.takeIf { it.isNotBlank() }
        return listOfNotNull(normalizedYear, normalizedPlate)
            .takeIf { it.isNotEmpty() }
            ?.joinToString(separator)
    }
}
