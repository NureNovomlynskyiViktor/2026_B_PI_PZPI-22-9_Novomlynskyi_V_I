import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

export type AppearanceMode = 'system' | 'light' | 'dark';
export type ResolvedTheme = 'light' | 'dark';

const appearanceModeStorageKey = 'autonexis_web_appearance_mode';

const AppearanceContext = createContext<{
  appearanceMode: AppearanceMode;
  resolvedTheme: ResolvedTheme;
  setAppearanceMode: (mode: AppearanceMode) => void;
} | null>(null);

function isAppearanceMode(value: string | null): value is AppearanceMode {
  return value === 'system' || value === 'light' || value === 'dark';
}

function getSystemTheme(): ResolvedTheme {
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function resolveTheme(mode: AppearanceMode, systemTheme: ResolvedTheme): ResolvedTheme {
  return mode === 'system' ? systemTheme : mode;
}

function readStoredAppearanceMode(): AppearanceMode {
  const storedMode = window.localStorage.getItem(appearanceModeStorageKey);
  return isAppearanceMode(storedMode) ? storedMode : 'system';
}

export function AppearanceProvider({ children }: { children: ReactNode }) {
  const [appearanceMode, setAppearanceModeState] = useState<AppearanceMode>(readStoredAppearanceMode);
  const [systemTheme, setSystemTheme] = useState<ResolvedTheme>(getSystemTheme);
  const resolvedTheme = resolveTheme(appearanceMode, systemTheme);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    function handleChange() {
      setSystemTheme(mediaQuery.matches ? 'dark' : 'light');
    }

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = resolvedTheme;
  }, [resolvedTheme]);

  function setAppearanceMode(mode: AppearanceMode) {
    setAppearanceModeState(mode);
    window.localStorage.setItem(appearanceModeStorageKey, mode);
  }

  const value = useMemo(
    () => ({ appearanceMode, resolvedTheme, setAppearanceMode }),
    [appearanceMode, resolvedTheme],
  );

  return <AppearanceContext.Provider value={value}>{children}</AppearanceContext.Provider>;
}

export function useAppearance() {
  const context = useContext(AppearanceContext);
  if (!context) {
    throw new Error('useAppearance must be used inside AppearanceProvider');
  }

  return context;
}
