import { useEffect, useRef, useState } from 'react';
import {
  initializeGoogleIdentity,
  renderGoogleSignInButton,
  type GoogleCredentialResponse,
} from '../../auth/googleIdentity';

type GoogleSignInStatus = 'loading' | 'ready' | 'unavailable';

type GoogleSignInLabels = {
  regionLabel: string;
  loading: string;
  exchangeInProgress: string;
  unavailable: string;
};

type Props = {
  clientID: string;
  disabled?: boolean;
  exchangeInProgress?: boolean;
  labels: GoogleSignInLabels;
  onCredential: (credential: string) => void;
};

const MIN_BUTTON_WIDTH = 220;
const MAX_BUTTON_WIDTH = 400;

export function GoogleSignInButton({
  clientID,
  disabled = false,
  exchangeInProgress = false,
  labels,
  onCredential,
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const credentialHandlerRef = useRef(onCredential);
  const [status, setStatus] = useState<GoogleSignInStatus>('loading');

  credentialHandlerRef.current = onCredential;

  useEffect(() => {
    let isActive = true;
    let observer: ResizeObserver | null = null;
    let lastRenderedWidth = 0;

    function renderButton() {
      const container = containerRef.current;
      if (!container) {
        return;
      }

      const availableWidth = Math.floor(container.getBoundingClientRect().width);
      const width = Math.max(
        MIN_BUTTON_WIDTH,
        Math.min(availableWidth || MAX_BUTTON_WIDTH, MAX_BUTTON_WIDTH),
      );

      if (width === lastRenderedWidth && container.childElementCount > 0) {
        return;
      }

      lastRenderedWidth = width;
      renderGoogleSignInButton(container, {
        type: 'standard',
        theme: 'outline',
        size: 'large',
        text: 'continue_with',
        shape: 'rectangular',
        logo_alignment: 'left',
        width: String(width),
      });
    }

    initializeGoogleIdentity(clientID, (response: GoogleCredentialResponse) => {
      credentialHandlerRef.current(response.credential?.trim() ?? '');
    })
      .then(() => {
        if (!isActive) {
          return;
        }

        setStatus('ready');
        renderButton();

        if (containerRef.current && 'ResizeObserver' in window) {
          observer = new ResizeObserver(() => {
            renderButton();
          });
          observer.observe(containerRef.current);
        }
      })
      .catch(() => {
        if (!isActive) {
          return;
        }
        setStatus('unavailable');
      });

    return () => {
      isActive = false;
      observer?.disconnect();
      containerRef.current?.replaceChildren();
    };
  }, [clientID]);

  const isInteractionBlocked = disabled || exchangeInProgress || status !== 'ready';

  return (
    <section className="google-signin-section" aria-label={labels.regionLabel}>
      <div
        ref={containerRef}
        className={
          isInteractionBlocked
            ? 'google-signin-button-wrap disabled'
            : 'google-signin-button-wrap'
        }
        aria-busy={exchangeInProgress || status === 'loading'}
      />

      {status === 'loading' && (
        <p className="auth-support-message">{labels.loading}</p>
      )}
      {status === 'unavailable' && (
        <p className="auth-support-message warning">{labels.unavailable}</p>
      )}
      {exchangeInProgress && (
        <p className="auth-support-message">{labels.exchangeInProgress}</p>
      )}
    </section>
  );
}
