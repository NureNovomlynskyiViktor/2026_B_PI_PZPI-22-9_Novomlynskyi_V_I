BEGIN;

DROP INDEX IF EXISTS alerts_vehicle_type_status_idx;

ALTER TABLE alerts
    DROP CONSTRAINT IF EXISTS alerts_current_state_check,
    DROP CONSTRAINT IF EXISTS alerts_recovery_streak_check,
    DROP CONSTRAINT IF EXISTS alerts_occurrence_count_check,
    DROP CONSTRAINT IF EXISTS alerts_current_severity_check,
    DROP CONSTRAINT IF EXISTS alerts_status_check;

UPDATE alerts
SET
    status = 'resolved',
    resolved_at = COALESCE(resolved_at, cleared_at, CURRENT_TIMESTAMP)
WHERE status = 'cleared';

ALTER TABLE alerts
    DROP COLUMN IF EXISTS last_triggered_at,
    DROP COLUMN IF EXISTS recovery_streak,
    DROP COLUMN IF EXISTS occurrence_count,
    DROP COLUMN IF EXISTS cleared_at,
    DROP COLUMN IF EXISTS current_severity;

ALTER TABLE alerts
    ADD CONSTRAINT alerts_status_check
        CHECK (status IN ('active', 'resolved'));

ALTER TABLE threshold_settings
    DROP CONSTRAINT IF EXISTS threshold_settings_recovery_samples_check,
    DROP CONSTRAINT IF EXISTS threshold_settings_recovery_margin_check;

ALTER TABLE threshold_settings
    DROP COLUMN IF EXISTS recovery_samples,
    DROP COLUMN IF EXISTS recovery_margin;

COMMIT;
