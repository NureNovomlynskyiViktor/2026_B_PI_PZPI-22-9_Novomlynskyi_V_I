package specialistvehicle

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testSpecialistID = "33333333-3333-3333-3333-333333333333"
	testVehicleID    = "22222222-2222-2222-2222-222222222222"
)

type stubAssignmentService struct {
	err error
}

func (s *stubAssignmentService) ListVehiclesForSpecialist(
	context.Context,
	string,
) ([]vehicle.Vehicle, error) {
	return []vehicle.Vehicle{{ID: testVehicleID}}, s.err
}

func (s *stubAssignmentService) GetAssignedVehicle(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testVehicleID}, s.err
}

type stubStatusService struct{}

func (stubStatusService) GetByVehicleID(
	context.Context,
	string,
) (vehiclestatus.VehicleStatus, error) {
	return vehiclestatus.VehicleStatus{
		Vehicle:       vehicle.Vehicle{ID: testVehicleID},
		ActiveAlerts:  []alert.Alert{},
		OverallStatus: "normal",
	}, nil
}

type stubThresholdService struct{}

func (stubThresholdService) ListByVehicle(
	context.Context,
	string,
) ([]threshold.Setting, error) {
	return []threshold.Setting{{
		ID:            "55555555-5555-5555-5555-555555555551",
		VehicleID:     testVehicleID,
		Parameter:     "engine_temperature",
		WarningValue:  90,
		CriticalValue: 105,
	}}, nil
}

type stubTelemetryService struct {
	limit int
	err   error
}

func (s *stubTelemetryService) ListByVehicle(
	context.Context,
	string,
	int,
) ([]telemetry.Record, error) {
	return []telemetry.Record{{ID: 1, VehicleID: testVehicleID}}, s.err
}

func (s *stubTelemetryService) ListByVehicleWithLimit(
	_ context.Context,
	_ string,
	limit int,
) ([]telemetry.Record, error) {
	s.limit = limit
	return []telemetry.Record{{ID: 1, VehicleID: testVehicleID}}, s.err
}

type stubAlertService struct {
	status string
	limit  int
	err    error
}

func (s *stubAlertService) ListByVehicleStatus(
	_ context.Context,
	_ string,
	status string,
	limit int,
) ([]alert.Alert, error) {
	s.status = status
	s.limit = limit
	return []alert.Alert{{ID: "44444444-4444-4444-4444-444444444444", VehicleID: testVehicleID}}, s.err
}

func TestListRequiresTechnicalSpecialistRole(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles",
		auth.DefaultRoleCode,
	)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestStatusForUnassignedVehicleReturnsNotFound(t *testing.T) {
	handler := testHandler(&stubAssignmentService{err: vehicle.ErrNotFound}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/status",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Status(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestThresholdsForAssignedVehicle(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/thresholds",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Thresholds(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
}

func TestThresholdsRejectInvalidVehicleID(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/not-a-uuid/thresholds",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.Thresholds(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestTelemetryForAssignedVehicleUsesDefaultLimit(t *testing.T) {
	telemetryService := &captureTelemetryService{}
	handler := testHandler(&stubAssignmentService{}, telemetryService, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/telemetry",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Telemetry(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if telemetryService.limit != telemetry.DefaultLimit {
		t.Fatalf("expected default limit %d, got %d", telemetry.DefaultLimit, telemetryService.limit)
	}
}

func TestTelemetryForAssignedVehicleUsesExplicitLimit(t *testing.T) {
	telemetryService := &captureTelemetryService{}
	handler := testHandler(&stubAssignmentService{}, telemetryService, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/telemetry?limit=25",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Telemetry(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if telemetryService.limit != 25 {
		t.Fatalf("expected explicit limit 25, got %d", telemetryService.limit)
	}
}

func TestTelemetryForUnassignedVehicleReturnsNotFound(t *testing.T) {
	handler := testHandler(&stubAssignmentService{err: vehicle.ErrNotFound}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/telemetry",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Telemetry(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestTelemetryRejectsInvalidLimit(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/telemetry?limit=0",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Telemetry(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestAlertsForAssignedVehicleDefaultsToAll(t *testing.T) {
	alertService := &stubAlertService{}
	handler := testHandler(&stubAssignmentService{}, nil, alertService)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if alertService.status != alert.StatusAll || alertService.limit != alert.DefaultLimit {
		t.Fatalf("expected status all and default limit, got status=%q limit=%d", alertService.status, alertService.limit)
	}
}

func TestAlertsForAssignedVehicleFiltersResolved(t *testing.T) {
	alertService := &stubAlertService{}
	handler := testHandler(&stubAssignmentService{}, nil, alertService)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts?status=resolved&limit=20",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if alertService.status != alert.StatusResolved || alertService.limit != 20 {
		t.Fatalf("expected status resolved and limit 20, got status=%q limit=%d", alertService.status, alertService.limit)
	}
}

func TestAlertsForAssignedVehicleFiltersActive(t *testing.T) {
	alertService := &stubAlertService{}
	handler := testHandler(&stubAssignmentService{}, nil, alertService)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts?status=active",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if alertService.status != alert.StatusActive {
		t.Fatalf("expected status active, got %q", alertService.status)
	}
}

func TestAlertsRejectInvalidStatus(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts?status=open",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestAlertsRejectInvalidLimit(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts?limit=201",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestAlertsRejectNonSpecialist(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts",
		auth.DefaultRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestAlertsRejectInvalidVehicleID(t *testing.T) {
	handler := testHandler(&stubAssignmentService{}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/not-a-uuid/alerts",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestAlertsForUnassignedVehicleReturnsNotFound(t *testing.T) {
	handler := testHandler(&stubAssignmentService{err: vehicle.ErrNotFound}, nil, nil)
	request := requestWithUser(
		http.MethodGet,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/alerts",
		auth.TechnicalSpecialistRoleCode,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Alerts(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

type captureTelemetryService struct {
	limit int
}

func (s *captureTelemetryService) ListByVehicle(
	_ context.Context,
	_ string,
	limit int,
) ([]telemetry.Record, error) {
	s.limit = limit
	return []telemetry.Record{{ID: 1, VehicleID: testVehicleID}}, nil
}

func testHandler(
	assignments AssignmentService,
	telemetryService TelemetryService,
	alertService AlertService,
) *Handler {
	if telemetryService == nil {
		telemetryService = &captureTelemetryService{}
	}
	if alertService == nil {
		alertService = &stubAlertService{}
	}

	return NewHandler(
		assignments,
		stubStatusService{},
		stubThresholdService{},
		telemetryService,
		alertService,
		testLogger(),
	)
}

func requestWithUser(method string, target string, role string) *http.Request {
	request := httptest.NewRequest(method, target, nil)
	return request.WithContext(auth.WithUser(
		request.Context(),
		auth.User{ID: testSpecialistID, Email: "specialist@example.com", Role: role},
	))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
