package specialistassignment

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

var (
	ErrNotFound     = errors.New("specialist assignment not found")
	ErrDuplicate    = errors.New("specialist already assigned")
	ErrUserNotFound = errors.New("user not found")
	ErrInvalidRole  = errors.New("user is not a technical specialist")
)

type Repository interface {
	GetUserByEmail(ctx context.Context, email string) (auth.User, error)
	GetUserByID(ctx context.Context, id string) (auth.User, error)
	ListSpecialists(ctx context.Context) ([]auth.User, error)
	Create(ctx context.Context, vehicleID string, specialist auth.User, assignedBy string) (Assignment, error)
	ListByVehicle(ctx context.Context, vehicleID string) ([]Assignment, error)
	CountBySpecialist(ctx context.Context) (map[string]int, error)
	Delete(ctx context.Context, vehicleID string, specialistID string) error
	ListVehiclesForSpecialist(ctx context.Context, specialistID string) ([]vehicle.Vehicle, error)
	GetAssignedVehicle(ctx context.Context, specialistID string, vehicleID string) (vehicle.Vehicle, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) GetUserByEmail(
	ctx context.Context,
	email string,
) (auth.User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE lower(users.email) = lower($1)
	`

	user, err := scanUser(r.db.QueryRowContext(ctx, query, email))
	if errors.Is(err, sql.ErrNoRows) {
		return auth.User{}, ErrUserNotFound
	}
	if err != nil {
		return auth.User{}, fmt.Errorf("query user by email: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) GetUserByID(ctx context.Context, id string) (auth.User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE users.id = $1
	`

	user, err := scanUser(r.db.QueryRowContext(ctx, query, id))
	if errors.Is(err, sql.ErrNoRows) {
		return auth.User{}, ErrUserNotFound
	}
	if err != nil {
		return auth.User{}, fmt.Errorf("query user by ID: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) ListSpecialists(ctx context.Context) ([]auth.User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE roles.code = $1
		  AND users.is_active = TRUE
		ORDER BY users.email, users.id
	`

	rows, err := r.db.QueryContext(ctx, query, auth.TechnicalSpecialistRoleCode)
	if err != nil {
		return nil, fmt.Errorf("query technical specialists: %w", err)
	}
	defer rows.Close()

	users := make([]auth.User, 0)
	for rows.Next() {
		user, err := scanUser(rows)
		if err != nil {
			return nil, fmt.Errorf("scan technical specialist: %w", err)
		}
		users = append(users, user)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate technical specialists: %w", err)
	}

	return users, nil
}

func (r *PostgresRepository) Create(
	ctx context.Context,
	vehicleID string,
	specialist auth.User,
	assignedBy string,
) (Assignment, error) {
	const query = `
		INSERT INTO vehicle_specialist_assignments (
			vehicle_id,
			specialist_id,
			assigned_by
		)
		VALUES ($1, $2, $3)
		RETURNING id, vehicle_id, specialist_id, assigned_by, created_at
	`

	item, err := scanAssignment(
		r.db.QueryRowContext(ctx, query, vehicleID, specialist.ID, assignedBy),
		specialist,
	)
	if isUniqueViolation(err) {
		return Assignment{}, ErrDuplicate
	}
	if err != nil {
		return Assignment{}, fmt.Errorf("insert specialist assignment: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ListByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Assignment, error) {
	const query = `
		SELECT
			assignments.id,
			assignments.vehicle_id,
			assignments.specialist_id,
			assignments.assigned_by,
			assignments.created_at,
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM vehicle_specialist_assignments assignments
		INNER JOIN users ON users.id = assignments.specialist_id
		INNER JOIN roles ON roles.id = users.role_id
		WHERE assignments.vehicle_id = $1
		ORDER BY assignments.created_at DESC, assignments.id
	`

	rows, err := r.db.QueryContext(ctx, query, vehicleID)
	if err != nil {
		return nil, fmt.Errorf("query specialist assignments: %w", err)
	}
	defer rows.Close()

	assignments := make([]Assignment, 0)
	for rows.Next() {
		item, err := scanAssignmentWithUser(rows)
		if err != nil {
			return nil, fmt.Errorf("scan specialist assignment: %w", err)
		}
		assignments = append(assignments, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate specialist assignments: %w", err)
	}

	return assignments, nil
}

func (r *PostgresRepository) CountBySpecialist(
	ctx context.Context,
) (map[string]int, error) {
	const query = `
		SELECT specialist_id, COUNT(*)
		FROM vehicle_specialist_assignments
		GROUP BY specialist_id
	`

	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("query specialist assignment counts: %w", err)
	}
	defer rows.Close()

	counts := make(map[string]int)
	for rows.Next() {
		var (
			specialistID string
			count        int
		)
		if err := rows.Scan(&specialistID, &count); err != nil {
			return nil, fmt.Errorf("scan specialist assignment count: %w", err)
		}
		counts[specialistID] = count
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate specialist assignment counts: %w", err)
	}

	return counts, nil
}

func (r *PostgresRepository) Delete(
	ctx context.Context,
	vehicleID string,
	specialistID string,
) error {
	result, err := r.db.ExecContext(
		ctx,
		`
			DELETE FROM vehicle_specialist_assignments
			WHERE vehicle_id = $1 AND specialist_id = $2
		`,
		vehicleID,
		specialistID,
	)
	if err != nil {
		return fmt.Errorf("delete specialist assignment: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("read deleted specialist assignment count: %w", err)
	}
	if rowsAffected == 0 {
		return ErrNotFound
	}

	return nil
}

func (r *PostgresRepository) ListVehiclesForSpecialist(
	ctx context.Context,
	specialistID string,
) ([]vehicle.Vehicle, error) {
	const query = `
		SELECT
			vehicles.id,
			vehicles.owner_id,
			vehicles.vin,
			vehicles.brand,
			vehicles.model,
			vehicles.year,
			vehicles.license_plate,
			vehicles.created_at,
			vehicles.updated_at
		FROM vehicle_specialist_assignments assignments
		INNER JOIN vehicles ON vehicles.id = assignments.vehicle_id
		WHERE assignments.specialist_id = $1
		ORDER BY vehicles.created_at DESC, vehicles.id
	`

	return queryVehicles(ctx, r.db, query, specialistID)
}

func (r *PostgresRepository) GetAssignedVehicle(
	ctx context.Context,
	specialistID string,
	vehicleID string,
) (vehicle.Vehicle, error) {
	const query = `
		SELECT
			vehicles.id,
			vehicles.owner_id,
			vehicles.vin,
			vehicles.brand,
			vehicles.model,
			vehicles.year,
			vehicles.license_plate,
			vehicles.created_at,
			vehicles.updated_at
		FROM vehicle_specialist_assignments assignments
		INNER JOIN vehicles ON vehicles.id = assignments.vehicle_id
		WHERE assignments.specialist_id = $1
		  AND assignments.vehicle_id = $2
	`

	item, err := scanVehicle(r.db.QueryRowContext(ctx, query, specialistID, vehicleID))
	if errors.Is(err, sql.ErrNoRows) {
		return vehicle.Vehicle{}, vehicle.ErrNotFound
	}
	if err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("query assigned specialist vehicle: %w", err)
	}

	return item, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanAssignment(row scanner, specialist auth.User) (Assignment, error) {
	var (
		item       Assignment
		assignedBy sql.NullString
	)
	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.SpecialistID,
		&assignedBy,
		&item.CreatedAt,
	); err != nil {
		return Assignment{}, err
	}
	if assignedBy.Valid {
		item.AssignedBy = &assignedBy.String
	}
	item.Specialist = specialist

	return item, nil
}

func scanAssignmentWithUser(row scanner) (Assignment, error) {
	var item Assignment
	var assignedBy sql.NullString
	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.SpecialistID,
		&assignedBy,
		&item.CreatedAt,
		&item.Specialist.ID,
		&item.Specialist.RoleID,
		&item.Specialist.Role,
		&item.Specialist.Email,
		&item.Specialist.FullName,
		&item.Specialist.IsActive,
		&item.Specialist.CreatedAt,
		&item.Specialist.UpdatedAt,
	); err != nil {
		return Assignment{}, err
	}
	if assignedBy.Valid {
		item.AssignedBy = &assignedBy.String
	}

	return item, nil
}

func scanUser(row scanner) (auth.User, error) {
	var user auth.User
	if err := row.Scan(
		&user.ID,
		&user.RoleID,
		&user.Role,
		&user.Email,
		&user.FullName,
		&user.IsActive,
		&user.CreatedAt,
		&user.UpdatedAt,
	); err != nil {
		return auth.User{}, err
	}

	return user, nil
}

type queryer interface {
	QueryContext(ctx context.Context, query string, args ...any) (*sql.Rows, error)
}

func queryVehicles(
	ctx context.Context,
	db queryer,
	query string,
	args ...any,
) ([]vehicle.Vehicle, error) {
	rows, err := db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query assigned vehicles: %w", err)
	}
	defer rows.Close()

	vehicles := make([]vehicle.Vehicle, 0)
	for rows.Next() {
		item, err := scanVehicle(rows)
		if err != nil {
			return nil, fmt.Errorf("scan assigned vehicle: %w", err)
		}
		vehicles = append(vehicles, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate assigned vehicles: %w", err)
	}

	return vehicles, nil
}

func scanVehicle(row scanner) (vehicle.Vehicle, error) {
	var (
		item         vehicle.Vehicle
		vin          sql.NullString
		year         sql.NullInt16
		licensePlate sql.NullString
	)

	if err := row.Scan(
		&item.ID,
		&item.OwnerID,
		&vin,
		&item.Brand,
		&item.Model,
		&year,
		&licensePlate,
		&item.CreatedAt,
		&item.UpdatedAt,
	); err != nil {
		return vehicle.Vehicle{}, err
	}

	if vin.Valid {
		item.VIN = &vin.String
	}
	if year.Valid {
		value := year.Int16
		item.Year = &value
	}
	if licensePlate.Valid {
		item.LicensePlate = &licensePlate.String
	}

	return item, nil
}

func isUniqueViolation(err error) bool {
	if err == nil {
		return false
	}

	message := err.Error()
	return strings.Contains(message, "vehicle_specialist_assignments_unique") ||
		strings.Contains(message, "duplicate key")
}
