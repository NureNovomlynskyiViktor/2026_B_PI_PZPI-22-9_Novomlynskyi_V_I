package adminaudit

import (
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

func TestListRequiresAdministrator(t *testing.T) {
	handler := NewHandler(&handlerServiceStub{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/admin/audit-logs", nil)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:   testActorID,
		Role: auth.DefaultRoleCode,
	}))
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestListParsesFiltersAndReturnsResponse(t *testing.T) {
	service := &handlerServiceStub{}
	handler := NewHandler(service, testLogger())
	request := adminRequest(
		"/api/v1/admin/audit-logs?action=user.deactivated&actor_id=" + testActorID +
			"&actor_search=admin&entity_type=user&entity_id=target&date_from=2026-06-18T10:00:00Z&date_to=2026-06-18T11:00:00Z&limit=10&offset=5",
	)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.filters.Action != "user.deactivated" ||
		service.filters.ActorID != testActorID ||
		service.filters.ActorSearch != "admin" ||
		service.filters.EntityType != "user" ||
		service.filters.EntityID != "target" ||
		service.filters.Limit != 10 ||
		service.filters.Offset != 5 {
		t.Fatalf("unexpected filters: %#v", service.filters)
	}
	if service.filters.DateFrom == nil || service.filters.DateTo == nil {
		t.Fatalf("expected parsed dates: %#v", service.filters)
	}

	var body ListResponse
	if err := json.NewDecoder(recorder.Body).Decode(&body); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	if len(body.Items) != 1 {
		t.Fatalf("expected one audit log, got %d", len(body.Items))
	}
	if body.Items[0].Actor == nil || body.Items[0].Actor.Email != "admin@example.com" {
		t.Fatalf("unexpected actor: %#v", body.Items[0].Actor)
	}
	if body.Items[0].EntityID == nil || *body.Items[0].EntityID != "target" {
		t.Fatalf("unexpected entity id: %#v", body.Items[0].EntityID)
	}
	if body.Items[0].Metadata["reason"] != "Administrative decision" {
		t.Fatalf("unexpected metadata: %#v", body.Items[0].Metadata)
	}
	if body.Pagination.Limit != 10 || body.Pagination.Offset != 5 || !body.Pagination.HasMore {
		t.Fatalf("unexpected pagination: %#v", body.Pagination)
	}
}

func TestListUsesDefaultPagination(t *testing.T) {
	service := &handlerServiceStub{}
	handler := NewHandler(service, testLogger())
	request := adminRequest("/api/v1/admin/audit-logs")
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.filters.Limit != DefaultLimit || service.filters.Offset != 0 {
		t.Fatalf("unexpected default pagination: %#v", service.filters)
	}
}

func TestListInvalidFiltersReturnBadRequest(t *testing.T) {
	tests := []string{
		"/api/v1/admin/audit-logs?actor_id=bad",
		"/api/v1/admin/audit-logs?date_from=bad",
		"/api/v1/admin/audit-logs?date_to=bad",
		"/api/v1/admin/audit-logs?limit=bad",
		"/api/v1/admin/audit-logs?limit=0",
		"/api/v1/admin/audit-logs?limit=101",
		"/api/v1/admin/audit-logs?offset=bad",
		"/api/v1/admin/audit-logs?offset=-1",
		"/api/v1/admin/audit-logs?date_from=2026-06-18T12:00:00Z&date_to=2026-06-18T11:00:00Z",
	}

	for _, target := range tests {
		t.Run(target, func(t *testing.T) {
			handler := NewHandler(&handlerServiceStub{}, testLogger())
			request := adminRequest(target)
			recorder := httptest.NewRecorder()

			handler.List(recorder, request)

			if recorder.Code != http.StatusBadRequest {
				t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
			}
		})
	}
}

type handlerServiceStub struct {
	filters ListFilters
}

func (s *handlerServiceStub) List(_ context.Context, filters ListFilters) (ListResponse, error) {
	s.filters = filters
	createdAt := time.Date(2026, 6, 18, 12, 0, 0, 0, time.UTC)
	entityID := "target"

	if _, err := normalizeFilters(filters); err != nil {
		return ListResponse{}, err
	}

	return ListResponse{
		Items: []Log{
			{
				ID: 1,
				Actor: &Actor{
					ID:       testActorID,
					Email:    "admin@example.com",
					FullName: "Admin User",
					Role:     auth.AdministratorRoleCode,
				},
				Action:     "user.deactivated",
				EntityType: "user",
				EntityID:   &entityID,
				Metadata: map[string]any{
					"reason": "Administrative decision",
				},
				CreatedAt: createdAt,
			},
		},
		Pagination: Pagination{
			Limit:   filters.Limit,
			Offset:  filters.Offset,
			Total:   20,
			HasMore: true,
		},
	}, nil
}

func adminRequest(target string) *http.Request {
	request := httptest.NewRequest(http.MethodGet, target, nil)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:    testActorID,
		Email: "admin@example.com",
		Role:  auth.AdministratorRoleCode,
	}))

	return request
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
