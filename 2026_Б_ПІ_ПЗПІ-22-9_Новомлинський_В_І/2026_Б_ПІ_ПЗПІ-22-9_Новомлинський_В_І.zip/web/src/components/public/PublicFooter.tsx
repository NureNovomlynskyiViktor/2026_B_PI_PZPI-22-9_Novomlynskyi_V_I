import { navigatePublic } from '../../navigation/publicNavigation';
import type { LocaleMessages } from '../../i18n';
import { BrandMark } from '../brand';

type Props = {
  footer: LocaleMessages['landing']['footer'];
  navigation: LocaleMessages['landing']['navigation'];
  supportEmail?: string;
};

export function PublicFooter({ footer, navigation, supportEmail }: Props) {
  const year = new Date().getFullYear();

  return (
    <footer className="public-footer">
      <div className="public-footer-grid">
        <div className="public-footer-brand">
          <BrandMark size={40} />
          <p>{footer.description}</p>
        </div>
        <nav aria-label={footer.navigationLabel} className="public-footer-links">
          <a href="#about">{navigation.about}</a>
          <a href="#capabilities">{navigation.capabilities}</a>
          <a href="#how-it-works">{navigation.howItWorks}</a>
          <a href="#connect">{navigation.connectVehicle}</a>
          <button type="button" onClick={() => navigatePublic('/login')}>
            {navigation.signIn}
          </button>
        </nav>
      </div>
      <div className="public-footer-bottom">
        <span>{footer.copyright.replace('{year}', String(year))}</span>
        {supportEmail && <a href={`mailto:${supportEmail}`}>{supportEmail}</a>}
      </div>
    </footer>
  );
}