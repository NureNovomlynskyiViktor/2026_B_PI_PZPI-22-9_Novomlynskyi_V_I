BEGIN;

CREATE INDEX audit_logs_created_at_id_idx
    ON audit_logs (created_at DESC, id DESC);

CREATE INDEX audit_logs_user_id_idx
    ON audit_logs (user_id);

CREATE INDEX audit_logs_action_idx
    ON audit_logs (action);

CREATE INDEX audit_logs_entity_type_entity_id_idx
    ON audit_logs (entity_type, entity_id);

COMMIT;
