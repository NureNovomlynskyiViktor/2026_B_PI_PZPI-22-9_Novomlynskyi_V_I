package adminspecialist

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

var ErrInvalidInput = errors.New("invalid admin specialist input")

type Service interface {
	Create(ctx context.Context, actor auth.User, request CreateRequest) (CreateResult, error)
}

type Repository interface {
	Create(ctx context.Context, input CreateInput) (CreateResult, error)
}

type PasswordHasher interface {
	Hash(password string) (string, error)
}

type service struct {
	repository Repository
	hasher     PasswordHasher
}

func NewService(repository Repository, hasher PasswordHasher) Service {
	return &service{
		repository: repository,
		hasher:     hasher,
	}
}

func (s *service) Create(
	ctx context.Context,
	actor auth.User,
	request CreateRequest,
) (CreateResult, error) {
	if !identifier.IsUUID(actor.ID) || actor.Role != auth.AdministratorRoleCode {
		return CreateResult{}, ErrInvalidInput
	}

	email := auth.NormalizeEmail(request.Email)
	fullName := normalizeFullName(request)
	if !auth.IsEmail(email) || fullName == "" || !auth.IsStrongPassword(request.Password) {
		return CreateResult{}, ErrInvalidInput
	}

	competencies, err := specialistcompetency.NormalizeCompetencyCodes(request.Competencies)
	if err != nil {
		return CreateResult{}, err
	}

	passwordHash, err := s.hasher.Hash(request.Password)
	if err != nil {
		return CreateResult{}, err
	}

	return s.repository.Create(ctx, CreateInput{
		ActorID:      actor.ID,
		Email:        email,
		PasswordHash: passwordHash,
		FullName:     fullName,
		Competencies: competencies,
	})
}

func normalizeFullName(request CreateRequest) string {
	if strings.TrimSpace(request.Name) != "" {
		return strings.TrimSpace(request.Name)
	}

	return strings.TrimSpace(request.FullName)
}
