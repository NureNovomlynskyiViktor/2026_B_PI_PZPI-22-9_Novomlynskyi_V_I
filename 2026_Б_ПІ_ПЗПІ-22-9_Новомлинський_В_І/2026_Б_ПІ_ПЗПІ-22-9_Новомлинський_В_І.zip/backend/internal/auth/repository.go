package auth

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
)

var (
	ErrUserNotFound                    = errors.New("user not found")
	ErrRoleNotFound                    = errors.New("role not found")
	ErrEmailAlreadyExists              = errors.New("email already exists")
	ErrOAuthAccountAlreadyExists       = errors.New("oauth account already exists")
	ErrGoogleIdentityLinkedToOtherUser = errors.New("google identity linked to another user")
	ErrUserLinkedToDifferentGoogle     = errors.New("user linked to different google identity")
)

type Repository interface {
	GetRoleByCode(ctx context.Context, code string) (Role, error)
	CreateUser(
		ctx context.Context,
		roleID string,
		email string,
		passwordHash string,
		fullName string,
	) (User, error)
	CreateOAuthUser(
		ctx context.Context,
		roleID string,
		email string,
		fullName string,
		provider string,
		providerAccountID string,
	) (User, error)
	GetUserByEmail(ctx context.Context, email string) (UserWithPassword, error)
	GetUserByID(ctx context.Context, id string) (User, error)
	GetUserByOAuthAccount(ctx context.Context, provider string, providerAccountID string) (User, error)
	GetAuthMethodStatus(ctx context.Context, userID string) (AuthMethodStatus, error)
	GetOAuthAccountByUser(ctx context.Context, userID string, provider string) (OAuthAccount, error)
	GetOAuthAccountByProviderAccountID(ctx context.Context, provider string, providerAccountID string) (OAuthAccount, error)
	LinkGoogleAccount(ctx context.Context, userID string, providerAccountID string) (AuthMethodStatus, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) GetRoleByCode(
	ctx context.Context,
	code string,
) (Role, error) {
	const query = `
		SELECT id, code
		FROM roles
		WHERE code = $1
	`

	var role Role
	if err := r.db.QueryRowContext(ctx, query, code).Scan(
		&role.ID,
		&role.Code,
	); errors.Is(err, sql.ErrNoRows) {
		return Role{}, ErrRoleNotFound
	} else if err != nil {
		return Role{}, fmt.Errorf("query role by code: %w", err)
	}

	return role, nil
}

func (r *PostgresRepository) CreateUser(
	ctx context.Context,
	roleID string,
	email string,
	passwordHash string,
	fullName string,
) (User, error) {
	const query = `
		INSERT INTO users (
			role_id,
			email,
			password_hash,
			full_name
		)
		VALUES ($1, $2, $3, $4)
		RETURNING
			id,
			role_id,
			$5::varchar,
			email,
			full_name,
			is_active,
			created_at,
			updated_at
	`

	user, err := scanUser(r.db.QueryRowContext(
		ctx,
		query,
		roleID,
		email,
		passwordHash,
		fullName,
		DefaultRoleCode,
	))
	if err != nil {
		if isUniqueEmailError(err) {
			return User{}, ErrEmailAlreadyExists
		}
		return User{}, fmt.Errorf("insert user: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) CreateOAuthUser(
	ctx context.Context,
	roleID string,
	email string,
	fullName string,
	provider string,
	providerAccountID string,
) (User, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return User{}, fmt.Errorf("begin oauth user transaction: %w", err)
	}
	defer tx.Rollback()

	const insertUserQuery = `
		INSERT INTO users (
			role_id,
			email,
			password_hash,
			full_name
		)
		VALUES ($1, $2, NULL, $3)
		RETURNING
			id,
			role_id,
			$4::varchar,
			email,
			full_name,
			is_active,
			created_at,
			updated_at
	`

	user, err := scanUser(tx.QueryRowContext(
		ctx,
		insertUserQuery,
		roleID,
		email,
		fullName,
		DefaultRoleCode,
	))
	if err != nil {
		if isUniqueEmailError(err) {
			return User{}, ErrEmailAlreadyExists
		}
		return User{}, fmt.Errorf("insert oauth user: %w", err)
	}

	const insertOAuthQuery = `
		INSERT INTO oauth_accounts (
			user_id,
			provider,
			provider_account_id
		)
		VALUES ($1, $2, $3)
	`
	if _, err := tx.ExecContext(ctx, insertOAuthQuery, user.ID, provider, providerAccountID); err != nil {
		if isUniqueOAuthAccountError(err) {
			return User{}, ErrOAuthAccountAlreadyExists
		}
		return User{}, fmt.Errorf("insert oauth account: %w", err)
	}

	if err := tx.Commit(); err != nil {
		return User{}, fmt.Errorf("commit oauth user transaction: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) GetUserByEmail(
	ctx context.Context,
	email string,
) (UserWithPassword, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at,
			users.password_hash
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE lower(users.email) = lower($1)
	`

	user, err := scanUserWithPassword(r.db.QueryRowContext(ctx, query, email))
	if errors.Is(err, sql.ErrNoRows) {
		return UserWithPassword{}, ErrUserNotFound
	}
	if err != nil {
		return UserWithPassword{}, fmt.Errorf("query user by email: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) GetUserByID(
	ctx context.Context,
	id string,
) (User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE users.id = $1
	`

	user, err := scanUser(r.db.QueryRowContext(ctx, query, id))
	if errors.Is(err, sql.ErrNoRows) {
		return User{}, ErrUserNotFound
	}
	if err != nil {
		return User{}, fmt.Errorf("query user by ID: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) GetUserByOAuthAccount(
	ctx context.Context,
	provider string,
	providerAccountID string,
) (User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM oauth_accounts
		INNER JOIN users ON users.id = oauth_accounts.user_id
		INNER JOIN roles ON roles.id = users.role_id
		WHERE oauth_accounts.provider = $1
		  AND oauth_accounts.provider_account_id = $2
	`

	user, err := scanUser(r.db.QueryRowContext(ctx, query, provider, providerAccountID))
	if errors.Is(err, sql.ErrNoRows) {
		return User{}, ErrUserNotFound
	}
	if err != nil {
		return User{}, fmt.Errorf("query user by oauth account: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) GetAuthMethodStatus(
	ctx context.Context,
	userID string,
) (AuthMethodStatus, error) {
	const query = `
		SELECT
			users.password_hash IS NOT NULL,
			EXISTS (
				SELECT 1
				FROM oauth_accounts
				WHERE oauth_accounts.user_id = users.id
				  AND oauth_accounts.provider = $2
			)
		FROM users
		WHERE users.id = $1
	`

	var status AuthMethodStatus
	if err := r.db.QueryRowContext(ctx, query, userID, GoogleProvider).Scan(
		&status.PasswordEnabled,
		&status.GoogleLinked,
	); errors.Is(err, sql.ErrNoRows) {
		return AuthMethodStatus{}, ErrUserNotFound
	} else if err != nil {
		return AuthMethodStatus{}, fmt.Errorf("query auth method status: %w", err)
	}

	return status, nil
}

func (r *PostgresRepository) GetOAuthAccountByUser(
	ctx context.Context,
	userID string,
	provider string,
) (OAuthAccount, error) {
	const query = `
		SELECT user_id, provider, provider_account_id
		FROM oauth_accounts
		WHERE user_id = $1
		  AND provider = $2
		ORDER BY created_at ASC, id ASC
		LIMIT 1
	`

	account, err := scanOAuthAccount(r.db.QueryRowContext(ctx, query, userID, provider))
	if errors.Is(err, sql.ErrNoRows) {
		return OAuthAccount{}, ErrUserNotFound
	}
	if err != nil {
		return OAuthAccount{}, fmt.Errorf("query oauth account by user: %w", err)
	}

	return account, nil
}

func (r *PostgresRepository) GetOAuthAccountByProviderAccountID(
	ctx context.Context,
	provider string,
	providerAccountID string,
) (OAuthAccount, error) {
	const query = `
		SELECT user_id, provider, provider_account_id
		FROM oauth_accounts
		WHERE provider = $1
		  AND provider_account_id = $2
	`

	account, err := scanOAuthAccount(r.db.QueryRowContext(ctx, query, provider, providerAccountID))
	if errors.Is(err, sql.ErrNoRows) {
		return OAuthAccount{}, ErrUserNotFound
	}
	if err != nil {
		return OAuthAccount{}, fmt.Errorf("query oauth account by provider account ID: %w", err)
	}

	return account, nil
}

func (r *PostgresRepository) LinkGoogleAccount(
	ctx context.Context,
	userID string,
	providerAccountID string,
) (AuthMethodStatus, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return AuthMethodStatus{}, fmt.Errorf("begin google link transaction: %w", err)
	}
	defer tx.Rollback()

	status, err := lockAuthMethodStatus(ctx, tx, userID)
	if err != nil {
		return AuthMethodStatus{}, err
	}

	currentAccount, err := getOAuthAccountByUserForUpdate(ctx, tx, userID, GoogleProvider)
	if err == nil {
		if currentAccount.ProviderAccountID == providerAccountID {
			status.GoogleLinked = true
			if err := tx.Commit(); err != nil {
				return AuthMethodStatus{}, fmt.Errorf("commit idempotent google link transaction: %w", err)
			}
			return status, nil
		}
		return AuthMethodStatus{}, ErrUserLinkedToDifferentGoogle
	}
	if !errors.Is(err, ErrUserNotFound) {
		return AuthMethodStatus{}, err
	}

	accountOwner, err := getOAuthAccountByProviderAccountIDForUpdate(ctx, tx, GoogleProvider, providerAccountID)
	if err == nil {
		if accountOwner.UserID == userID {
			status.GoogleLinked = true
			if err := tx.Commit(); err != nil {
				return AuthMethodStatus{}, fmt.Errorf("commit existing google link transaction: %w", err)
			}
			return status, nil
		}
		return AuthMethodStatus{}, ErrGoogleIdentityLinkedToOtherUser
	}
	if !errors.Is(err, ErrUserNotFound) {
		return AuthMethodStatus{}, err
	}

	const insertQuery = `
		INSERT INTO oauth_accounts (user_id, provider, provider_account_id)
		VALUES ($1, $2, $3)
		ON CONFLICT (provider, provider_account_id) DO NOTHING
	`
	result, err := tx.ExecContext(ctx, insertQuery, userID, GoogleProvider, providerAccountID)
	if err != nil {
		return AuthMethodStatus{}, fmt.Errorf("insert google oauth account: %w", err)
	}
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return AuthMethodStatus{}, fmt.Errorf("inspect google oauth insert result: %w", err)
	}
	if rowsAffected == 0 {
		accountOwner, lookupErr := getOAuthAccountByProviderAccountIDForUpdate(ctx, tx, GoogleProvider, providerAccountID)
		if lookupErr == nil && accountOwner.UserID == userID {
			status.GoogleLinked = true
			if err := tx.Commit(); err != nil {
				return AuthMethodStatus{}, fmt.Errorf("commit duplicate google link transaction: %w", err)
			}
			return status, nil
		}
		return AuthMethodStatus{}, ErrGoogleIdentityLinkedToOtherUser
	}

	status.GoogleLinked = true
	if err := tx.Commit(); err != nil {
		return AuthMethodStatus{}, fmt.Errorf("commit google link transaction: %w", err)
	}

	return status, nil
}

func lockAuthMethodStatus(
	ctx context.Context,
	tx *sql.Tx,
	userID string,
) (AuthMethodStatus, error) {
	const query = `
		SELECT password_hash IS NOT NULL
		FROM users
		WHERE id = $1
		FOR UPDATE
	`

	var status AuthMethodStatus
	if err := tx.QueryRowContext(ctx, query, userID).Scan(&status.PasswordEnabled); errors.Is(err, sql.ErrNoRows) {
		return AuthMethodStatus{}, ErrUserNotFound
	} else if err != nil {
		return AuthMethodStatus{}, fmt.Errorf("lock user for google link: %w", err)
	}

	return status, nil
}

func getOAuthAccountByUserForUpdate(
	ctx context.Context,
	tx *sql.Tx,
	userID string,
	provider string,
) (OAuthAccount, error) {
	const query = `
		SELECT user_id, provider, provider_account_id
		FROM oauth_accounts
		WHERE user_id = $1
		  AND provider = $2
		ORDER BY created_at ASC, id ASC
		LIMIT 1
		FOR UPDATE
	`

	account, err := scanOAuthAccount(tx.QueryRowContext(ctx, query, userID, provider))
	if errors.Is(err, sql.ErrNoRows) {
		return OAuthAccount{}, ErrUserNotFound
	}
	if err != nil {
		return OAuthAccount{}, fmt.Errorf("query locked oauth account by user: %w", err)
	}

	return account, nil
}

func getOAuthAccountByProviderAccountIDForUpdate(
	ctx context.Context,
	tx *sql.Tx,
	provider string,
	providerAccountID string,
) (OAuthAccount, error) {
	const query = `
		SELECT user_id, provider, provider_account_id
		FROM oauth_accounts
		WHERE provider = $1
		  AND provider_account_id = $2
		FOR UPDATE
	`

	account, err := scanOAuthAccount(tx.QueryRowContext(ctx, query, provider, providerAccountID))
	if errors.Is(err, sql.ErrNoRows) {
		return OAuthAccount{}, ErrUserNotFound
	}
	if err != nil {
		return OAuthAccount{}, fmt.Errorf("query locked oauth account by provider account ID: %w", err)
	}

	return account, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanOAuthAccount(row scanner) (OAuthAccount, error) {
	var account OAuthAccount
	if err := row.Scan(
		&account.UserID,
		&account.Provider,
		&account.ProviderAccountID,
	); err != nil {
		return OAuthAccount{}, err
	}

	return account, nil
}
func scanUser(row scanner) (User, error) {
	var user User
	if err := row.Scan(
		&user.ID,
		&user.RoleID,
		&user.Role,
		&user.Email,
		&user.FullName,
		&user.IsActive,
		&user.CreatedAt,
		&user.UpdatedAt,
	); err != nil {
		return User{}, err
	}

	return user, nil
}

func scanUserWithPassword(row scanner) (UserWithPassword, error) {
	var (
		user         UserWithPassword
		passwordHash sql.NullString
	)
	if err := row.Scan(
		&user.ID,
		&user.RoleID,
		&user.Role,
		&user.Email,
		&user.FullName,
		&user.IsActive,
		&user.CreatedAt,
		&user.UpdatedAt,
		&passwordHash,
	); err != nil {
		return UserWithPassword{}, err
	}
	if passwordHash.Valid {
		user.PasswordHash = &passwordHash.String
	}

	return user, nil
}

func isUniqueEmailError(err error) bool {
	message := err.Error()
	return strings.Contains(message, "users_email_key") ||
		strings.Contains(message, "duplicate key")
}

func isUniqueOAuthAccountError(err error) bool {
	message := err.Error()
	return strings.Contains(message, "oauth_accounts_provider_account_unique") ||
		strings.Contains(message, "duplicate key")
}
