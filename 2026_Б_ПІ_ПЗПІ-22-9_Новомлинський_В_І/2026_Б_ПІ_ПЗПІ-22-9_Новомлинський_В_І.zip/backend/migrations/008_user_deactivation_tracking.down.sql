BEGIN;

DROP INDEX IF EXISTS users_role_active_created_idx;

ALTER TABLE users
	DROP CONSTRAINT IF EXISTS users_deactivation_consistency_check;

ALTER TABLE users
	DROP COLUMN IF EXISTS deactivated_at;

COMMIT;
