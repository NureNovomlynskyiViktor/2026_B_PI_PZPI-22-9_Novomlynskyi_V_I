package servicerequest

import "time"

const (
	PriorityLow    = "low"
	PriorityNormal = "normal"
	PriorityHigh   = "high"

	StatusPending    = "pending"
	StatusAssigned   = "assigned"
	StatusInProgress = "in_progress"
	StatusCompleted  = "completed"
	StatusCancelled  = "cancelled"
)

type Request struct {
	ID                   string     `json:"id"`
	VehicleID            string     `json:"vehicle_id"`
	OwnerID              string     `json:"owner_id"`
	SourceAlertID        *string    `json:"source_alert_id,omitempty"`
	AssignedSpecialistID *string    `json:"assigned_specialist_id,omitempty"`
	AssignedBy           *string    `json:"assigned_by,omitempty"`
	Title                string     `json:"title"`
	Description          string     `json:"description"`
	Priority             string     `json:"priority"`
	Status               string     `json:"status"`
	ResultSummary        *string    `json:"result_summary,omitempty"`
	CreatedAt            time.Time  `json:"created_at"`
	UpdatedAt            time.Time  `json:"updated_at"`
	AssignedAt           *time.Time `json:"assigned_at,omitempty"`
	StartedAt            *time.Time `json:"started_at,omitempty"`
	CompletedAt          *time.Time `json:"completed_at,omitempty"`
	CancelledAt          *time.Time `json:"cancelled_at,omitempty"`
}

type CreateRequest struct {
	VehicleID     string
	OwnerID       string
	Title         string
	Description   string
	Priority      string
	SourceAlertID *string
}

type AssignRequest struct {
	RequestID    string
	SpecialistID string
	AdminID      string
}

type AdminCancelRequest struct {
	RequestID string
	AdminID   string
}
