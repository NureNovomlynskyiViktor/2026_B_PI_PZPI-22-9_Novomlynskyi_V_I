# Autonexis Wokwi ESP32 Telemetry Simulator

This directory contains a Wokwi-compatible ESP32 simulator for the IoT part of Autonexis. The simulator periodically publishes vehicle telemetry as JSON to MQTT so the backend can store telemetry, evaluate thresholds, generate alerts, and update vehicle status.

Architecture:

```text
ESP32/Wokwi -> MQTT broker -> backend MQTT consumer -> telemetry_records -> alert evaluation -> vehicle status
```

## MQTT Topic

The backend MQTT consumer subscribes to:

```text
autonexis/devices/+/telemetry
```

The simulator builds its publish topic from the single `DEVICE_UID` value in
`sketch.ino`:

```cpp
const char* DEVICE_UID = "esp32-demo-002";
```

With that configuration, it publishes to:

```text
autonexis/devices/esp32-demo-002/telemetry
```

The `esp32-demo-002` segment maps to `devices.device_uid` in PostgreSQL. To
simulate another registered vehicle, change only `DEVICE_UID`; the telemetry
topic and MQTT client ID are generated from it automatically.

## Payload Format

Example payload:

```json
{
  "engine_temperature": 98.2,
  "battery_voltage": 13.5,
  "vibration_level": 2.3,
  "rpm": 2700,
  "speed": 75,
  "fuel_level": 62.1
}
```

The simulator publishes a new message every 5 seconds. Engine temperature, battery voltage, vibration level, and RPM come from potentiometers. Speed and fuel level are generated automatically. Each published payload is printed to the Wokwi Serial Monitor.

## Interactive Controls

The Wokwi diagram includes four potentiometers:

- Engine temperature: GPIO34, mapped from ADC 0-4095 to 60.0-120.0 C.
- Battery voltage: GPIO35, mapped from ADC 0-4095 to 10.5-14.8 V.
- Vibration level: GPIO32, mapped from ADC 0-4095 to 0.0-3.0.
- RPM: GPIO33, mapped from ADC 0-4095 to 600-4500 rpm.

Each potentiometer is connected to ESP32 3.3V, GND, and its assigned ADC input pin.

Wokwi potentiometer `value` attributes use a 0-1023 range. The initial diagram
values are:

- Engine temperature: 358, approximately 35%, about 81 C.
- Battery voltage: 767, approximately 75%, about 13.7 V.
- Vibration level: 460, approximately 45%, about 1.35.
- RPM: 389, approximately 38%, about 2080 rpm.

The temperature control therefore starts below the 90 C warning threshold and
keeps the simulator in a normal state.

## Run in Wokwi

1. Open Wokwi.
2. Create a new ESP32 project or import this directory.
3. Use `sketch.ino`, `diagram.json`, and `libraries.txt`.
4. Start the simulation.
5. Open Serial Monitor to see WiFi, MQTT, topic, and payload logs.

The sketch uses:

- WiFi SSID: `Wokwi-GUEST`
- WiFi password: empty
- MQTT client library: `PubSubClient`

## Broker Modes

### 1. Local backend test mode

For reliable local validation, use the existing Docker Mosquitto broker and the backend README `mosquitto_pub` commands. This verifies the complete local path:

```text
Docker Mosquitto -> Go backend MQTT consumer -> PostgreSQL -> REST API
```

This is the preferred mode for checking backend behavior on the local machine.

### 2. Wokwi demo mode

Wokwi usually cannot access your local Docker Mosquitto through `localhost`, because `localhost` inside the Wokwi simulation is not your Windows host. For Wokwi demonstrations, use a public MQTT broker or another broker address reachable from Wokwi.

The sketch currently uses:

```cpp
const char* MQTT_SERVER = "broker.hivemq.com";
const char* DEVICE_UID = "esp32-demo-002";
```

Do not put passwords or private broker credentials into the sketch. If a private broker is needed later, use a controlled demo broker and document its setup separately.

## Local Backend MQTT Test

From the backend directory, run the backend with MQTT enabled:

```powershell
$env:MQTT_ENABLED = "true"
$env:MQTT_BROKER_HOST = "localhost"
$env:MQTT_BROKER_PORT = "1883"
$env:MQTT_CLIENT_ID = "autonexis-backend-local"
go run ./cmd/server
```

In another terminal, publish a demo payload through Docker Mosquitto:

```powershell
$payload = @{
  engine_temperature = 98.2
  battery_voltage = 13.5
  vibration_level = 2.3
  rpm = 2700
  speed = 75
  fuel_level = 62.1
} | ConvertTo-Json -Compress

$payload | docker exec -i vehicle-monitoring-mosquitto mosquitto_pub `
  -h localhost `
  -p 1883 `
  -q 1 `
  -t "autonexis/devices/esp32-demo-002/telemetry" `
  -s
```

Then verify through the backend REST API:

```powershell
$vehicleId = "<vehicle-id-registered-with-the-configured-device-uid>"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/telemetry/latest"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/status"
```

The backend logs should show successful MQTT ingestion with the device UID, telemetry ID, created alert count, and overall result.
