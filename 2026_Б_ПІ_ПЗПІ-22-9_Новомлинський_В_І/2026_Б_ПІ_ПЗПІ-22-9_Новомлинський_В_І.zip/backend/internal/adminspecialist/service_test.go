package adminspecialist

import (
	"context"
	"errors"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

const testAdminID = "11111111-1111-1111-1111-111111111111"

type repositoryStub struct {
	input CreateInput
	err   error
}

func (r *repositoryStub) Create(_ context.Context, input CreateInput) (CreateResult, error) {
	r.input = input
	if r.err != nil {
		return CreateResult{}, r.err
	}

	return CreateResult{
		User: auth.User{
			ID:       "22222222-2222-2222-2222-222222222222",
			Role:     auth.TechnicalSpecialistRoleCode,
			Email:    input.Email,
			FullName: input.FullName,
			IsActive: true,
		},
		Competencies: []specialistcompetency.Competency{{
			SpecialistID: "22222222-2222-2222-2222-222222222222",
			Code:         specialistcompetency.CodeEngineDiagnostics,
			Name:         "Engine diagnostics",
		}},
	}, nil
}

type hasherStub struct {
	raw string
	err error
}

func (h *hasherStub) Hash(password string) (string, error) {
	h.raw = password
	if h.err != nil {
		return "", h.err
	}

	return "hashed-password", nil
}

func TestCreateValidatesHashesAndNormalizesSpecialist(t *testing.T) {
	repository := &repositoryStub{}
	hasher := &hasherStub{}
	service := NewService(repository, hasher)

	result, err := service.Create(context.Background(), testAdminUser(), CreateRequest{
		Email:        " Specialist.New@Example.COM ",
		Password:     "DemoPass123!",
		Name:         " Demo New Specialist ",
		Competencies: []string{specialistcompetency.CodeEngineDiagnostics, specialistcompetency.CodeEngineDiagnostics},
	})
	if err != nil {
		t.Fatalf("create specialist: %v", err)
	}
	if result.User.Role != auth.TechnicalSpecialistRoleCode {
		t.Fatalf("expected technical specialist role, got %q", result.User.Role)
	}
	if hasher.raw != "DemoPass123!" {
		t.Fatalf("expected password to be passed to hasher, got %q", hasher.raw)
	}
	if repository.input.PasswordHash != "hashed-password" {
		t.Fatalf("expected hashed password, got %q", repository.input.PasswordHash)
	}
	if repository.input.PasswordHash == hasher.raw {
		t.Fatal("plaintext password was stored")
	}
	if repository.input.Email != "specialist.new@example.com" {
		t.Fatalf("expected normalized email, got %q", repository.input.Email)
	}
	if repository.input.FullName != "Demo New Specialist" {
		t.Fatalf("expected normalized name, got %q", repository.input.FullName)
	}
	if len(repository.input.Competencies) != 1 || repository.input.Competencies[0].Code != specialistcompetency.CodeEngineDiagnostics {
		t.Fatalf("unexpected competencies: %#v", repository.input.Competencies)
	}
}

func TestCreateRejectsInvalidInput(t *testing.T) {
	service := NewService(&repositoryStub{}, &hasherStub{})
	cases := []CreateRequest{
		{Email: "bad", Password: "DemoPass123!", Name: "Specialist"},
		{Email: "specialist@example.com", Password: "weak", Name: "Specialist"},
		{Email: "specialist@example.com", Password: "DemoPass123!", Name: ""},
	}

	for _, request := range cases {
		if _, err := service.Create(context.Background(), testAdminUser(), request); !errors.Is(err, ErrInvalidInput) {
			t.Fatalf("expected ErrInvalidInput for %#v, got %v", request, err)
		}
	}
}

func TestCreateRejectsUnknownCompetencyCode(t *testing.T) {
	service := NewService(&repositoryStub{}, &hasherStub{})

	_, err := service.Create(context.Background(), testAdminUser(), CreateRequest{
		Email:        "specialist@example.com",
		Password:     "DemoPass123!",
		Name:         "Specialist",
		Competencies: []string{"unknown_code"},
	})
	if !errors.Is(err, specialistcompetency.ErrInvalidCompetencyCode) {
		t.Fatalf("expected invalid competency code, got %v", err)
	}
}

func TestCreateRejectsNonAdministratorActor(t *testing.T) {
	service := NewService(&repositoryStub{}, &hasherStub{})
	_, err := service.Create(context.Background(), auth.User{
		ID:   testAdminID,
		Role: auth.TechnicalSpecialistRoleCode,
	}, CreateRequest{
		Email:    "specialist@example.com",
		Password: "DemoPass123!",
		Name:     "Specialist",
	})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}
}

func testAdminUser() auth.User {
	return auth.User{
		ID:    testAdminID,
		Email: "admin@example.com",
		Role:  auth.AdministratorRoleCode,
	}
}
