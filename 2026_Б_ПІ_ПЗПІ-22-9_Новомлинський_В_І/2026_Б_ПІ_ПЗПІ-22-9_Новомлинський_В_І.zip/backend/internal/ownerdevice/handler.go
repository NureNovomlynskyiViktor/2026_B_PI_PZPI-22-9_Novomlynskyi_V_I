package ownerdevice

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumDeviceRequestBodySize = 1 << 20

type DeviceService interface {
	ListByOwner(ctx context.Context, ownerID string) ([]device.Device, error)
	ListByVehicleForOwner(
		ctx context.Context,
		ownerID string,
		vehicleID string,
	) ([]device.Device, error)
	GetByIDForOwner(ctx context.Context, ownerID string, deviceID string) (device.Device, error)
	CreateForOwnedVehicle(
		ctx context.Context,
		ownerID string,
		vehicleID string,
		request device.CreateRequest,
	) (device.Device, error)
}

type VehicleService interface {
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
}

type Handler struct {
	devices  DeviceService
	vehicles VehicleService
	logger   *slog.Logger
}

func NewHandler(
	devices DeviceService,
	vehicles VehicleService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		devices:  devices,
		vehicles: vehicles,
		logger:   logger,
	}
}

func (h *Handler) ListByVehicle(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	if !h.verifyVehicleOwnership(w, r, user.ID, vehicleID) {
		return
	}

	devices, err := h.devices.ListByVehicleForOwner(r.Context(), user.ID, vehicleID)
	if err != nil {
		h.logger.Error(
			"failed to list owner vehicle devices",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, devices)
}

func (h *Handler) CreateForVehicle(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	if !h.verifyVehicleOwnership(w, r, user.ID, vehicleID) {
		return
	}

	var request device.CreateRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	item, err := h.devices.CreateForOwnedVehicle(r.Context(), user.ID, vehicleID, request)
	if errors.Is(err, device.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid device data")
		return
	}
	if errors.Is(err, device.ErrDuplicateUID) {
		response.Error(w, http.StatusConflict, "device UID already exists")
		return
	}
	if errors.Is(err, device.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to create owner device",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, item)
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	devices, err := h.devices.ListByOwner(r.Context(), user.ID)
	if err != nil {
		h.logger.Error("failed to list owner devices", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, devices)
}

func (h *Handler) GetByID(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	deviceID := r.PathValue("device_id")
	if !identifier.IsUUID(deviceID) {
		response.Error(w, http.StatusBadRequest, "invalid device_id")
		return
	}

	item, err := h.devices.GetByIDForOwner(r.Context(), user.ID, deviceID)
	if errors.Is(err, device.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "device not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get owner device",
			"user_id", user.ID,
			"device_id", deviceID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) verifyVehicleOwnership(
	w http.ResponseWriter,
	r *http.Request,
	userID string,
	vehicleID string,
) bool {
	if _, err := h.vehicles.GetByIDForOwner(r.Context(), userID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return false
		}
		h.logger.Error(
			"failed to verify owner vehicle",
			"user_id", userID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return false
	}

	return true
}

func currentUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumDeviceRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
