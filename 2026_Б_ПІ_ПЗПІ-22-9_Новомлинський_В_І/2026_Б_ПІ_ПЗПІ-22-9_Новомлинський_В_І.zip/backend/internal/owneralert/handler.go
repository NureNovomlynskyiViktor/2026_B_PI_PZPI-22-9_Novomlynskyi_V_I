package owneralert

import (
	"context"
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type AlertService interface {
	ListByVehicle(ctx context.Context, vehicleID string, limit int) ([]alert.Alert, error)
	ListActiveByVehicle(ctx context.Context, vehicleID string) ([]alert.Alert, error)
}

type VehicleService interface {
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
}

type Handler struct {
	alerts   AlertService
	vehicles VehicleService
	logger   *slog.Logger
}

func NewHandler(
	alerts AlertService,
	vehicles VehicleService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		alerts:   alerts,
		vehicles: vehicles,
		logger:   logger,
	}
}

func (h *Handler) ListByVehicle(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	limit, err := alert.ParseLimit(r.URL.Query().Get("limit"))
	if err != nil {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}

	if !h.verifyVehicleOwnership(w, r, user.ID, vehicleID) {
		return
	}

	alerts, err := h.alerts.ListByVehicle(r.Context(), vehicleID, limit)
	if errors.Is(err, alert.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, alert.ErrInvalidLimit) {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list owner alerts",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, alerts)
}

func (h *Handler) ListActiveByVehicle(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	if !h.verifyVehicleOwnership(w, r, user.ID, vehicleID) {
		return
	}

	alerts, err := h.alerts.ListActiveByVehicle(r.Context(), vehicleID)
	if errors.Is(err, alert.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list owner active alerts",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, alerts)
}

func (h *Handler) verifyVehicleOwnership(
	w http.ResponseWriter,
	r *http.Request,
	ownerID string,
	vehicleID string,
) bool {
	if _, err := h.vehicles.GetByIDForOwner(r.Context(), ownerID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return false
		}
		h.logger.Error(
			"failed to verify owner vehicle for alerts",
			"user_id", ownerID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return false
	}

	return true
}

func currentUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}

	return user, true
}
