import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { api, errorMessage, isUnauthorizedError } from '../../api/client';
import type { AuthenticationMethods, User } from '../../api/types';
import { useMessages } from '../../i18n';
import { AppearanceSelector } from '../appearance/AppearanceSelector';
import { GoogleSignInButton } from '../auth/GoogleSignInButton';
import { LanguageSelector } from '../i18n/LanguageSelector';

type Props = {
  token: string;
  user: User;
  onClose: () => void;
  onSessionExpired: () => void;
};

const googleClientID = (import.meta.env.VITE_GOOGLE_CLIENT_ID ?? '').trim();

export function AccountMethodsPanel({
  token,
  user,
  onClose,
  onSessionExpired,
}: Props) {
  const accountMessages = useMessages().account;
  const headingID = useId();
  const linkInFlightRef = useRef(false);
  const [methods, setMethods] = useState<AuthenticationMethods | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGoogleExchangeInProgress, setIsGoogleExchangeInProgress] =
    useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const loadMethods = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const loadedMethods = await api.getAuthenticationMethods(token);
      setMethods(loadedMethods);
    } catch (err) {
      if (isUnauthorizedError(err)) {
        onSessionExpired();
        return;
      }

      setError(errorMessage(err, accountMessages.refreshError));
    } finally {
      setIsLoading(false);
    }
  }, [accountMessages.refreshError, onSessionExpired, token]);

  useEffect(() => {
    void loadMethods();
  }, [loadMethods]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        onClose();
      }
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleGoogleCredential = useCallback(
    async (credential: string) => {
      if (linkInFlightRef.current) {
        return;
      }

      const trimmedCredential = credential.trim();
      if (!trimmedCredential) {
        setError(accountMessages.googleInvalidCredential);
        return;
      }

      linkInFlightRef.current = true;
      setIsGoogleExchangeInProgress(true);
      setError(null);
      setMessage(null);

      try {
        const updatedMethods = await api.linkGoogleAccount(token, {
          id_token: trimmedCredential,
        });
        setMethods(updatedMethods);
        setMessage(accountMessages.linkSuccess);
      } catch (err) {
        if (isUnauthorizedError(err)) {
          onSessionExpired();
          return;
        }

        setError(errorMessage(err, accountMessages.googleUnavailable));
      } finally {
        linkInFlightRef.current = false;
        setIsGoogleExchangeInProgress(false);
      }
    },
    [
      accountMessages.googleInvalidCredential,
      accountMessages.googleUnavailable,
      accountMessages.linkSuccess,
      onSessionExpired,
      token,
    ],
  );

  return (
    <div
      className="account-modal-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
    >
      <section
        aria-labelledby={headingID}
        aria-modal="true"
        className="account-modal"
        role="dialog"
      >
        <div className="account-modal-header">
          <div>
            <p className="eyebrow">Autonexis</p>
            <h2 id={headingID}>{accountMessages.heading}</h2>
          </div>
          <button className="secondary-button" type="button" onClick={onClose}>
            {accountMessages.close}
          </button>
        </div>

        <div className="account-summary-grid">
          <div>
            <span>{accountMessages.emailLabel}</span>
            <strong>{user.email}</strong>
          </div>
          <div>
            <span>{accountMessages.roleLabel}</span>
            <strong>{formatRole(user.role, accountMessages.roles)}</strong>
          </div>
        </div>

        <div className="account-preference-section account-preference-grid">
          <LanguageSelector />
          <AppearanceSelector />
        </div>

        {isLoading ? (
          <p className="info-box">{accountMessages.loading}</p>
        ) : (
          <div className="account-method-list">
            <MethodRow
              label={accountMessages.passwordMethod}
              status={
                methods?.password_enabled
                  ? accountMessages.enabled
                  : accountMessages.notEnabled
              }
              isEnabled={Boolean(methods?.password_enabled)}
            />
            <MethodRow
              label={accountMessages.googleMethod}
              status={
                methods?.google_linked
                  ? accountMessages.connected
                  : accountMessages.notConnected
              }
              isEnabled={Boolean(methods?.google_linked)}
            />
          </div>
        )}

        {message && <p className="success-box">{message}</p>}
        {error && <p className="error-box inline">{error}</p>}

        {!isLoading && methods && !methods.google_linked && (
          <section className="account-google-linking">
            <div>
              <h3>{accountMessages.linkHeading}</h3>
              <p className="muted">{accountMessages.linkExplanation}</p>
            </div>
            {googleClientID ? (
              <GoogleSignInButton
                clientID={googleClientID}
                disabled={isGoogleExchangeInProgress}
                exchangeInProgress={isGoogleExchangeInProgress}
                labels={{
                  regionLabel: accountMessages.googleRegionLabel,
                  loading: accountMessages.googleLoading,
                  exchangeInProgress: accountMessages.googleExchangeInProgress,
                  unavailable: accountMessages.googleUnavailable,
                }}
                onCredential={handleGoogleCredential}
              />
            ) : (
              <p className="info-box">{accountMessages.linkNotConfigured}</p>
            )}
          </section>
        )}
      </section>
    </div>
  );
}

function MethodRow({
  label,
  status,
  isEnabled,
}: {
  label: string;
  status: string;
  isEnabled: boolean;
}) {
  return (
    <div className="account-method-row">
      <strong>{label}</strong>
      <span className={isEnabled ? 'status-pill normal' : 'status-pill unknown'}>
        {status}
      </span>
    </div>
  );
}

function formatRole(
  role: string,
  labels: {
    vehicleOwner: string;
    technicalSpecialist: string;
    administrator: string;
    unknown: string;
  },
) {
  switch (role) {
    case 'vehicle_owner':
      return labels.vehicleOwner;
    case 'technical_specialist':
      return labels.technicalSpecialist;
    case 'administrator':
      return labels.administrator;
    default:
      return role || labels.unknown;
  }
}
