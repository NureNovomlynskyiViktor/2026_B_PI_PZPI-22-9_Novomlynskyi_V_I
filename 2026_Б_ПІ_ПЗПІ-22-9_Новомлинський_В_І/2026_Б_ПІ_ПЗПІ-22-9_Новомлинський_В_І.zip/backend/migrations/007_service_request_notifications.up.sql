BEGIN;

ALTER TABLE notifications
	ALTER COLUMN alert_id DROP NOT NULL;

ALTER TABLE notifications
	ADD COLUMN service_request_id UUID REFERENCES vehicle_service_requests(id) ON DELETE SET NULL,
	ADD COLUMN notification_type VARCHAR(64);

UPDATE notifications
SET notification_type = 'vehicle_alert'
WHERE notification_type IS NULL;

ALTER TABLE notifications
	ALTER COLUMN notification_type SET NOT NULL;

ALTER TABLE notifications
	ADD CONSTRAINT notifications_type_check
	CHECK (
		notification_type IN (
			'vehicle_alert',
			'service_request_assigned',
			'service_request_started',
			'service_request_completed'
		)
	);

CREATE INDEX notifications_service_request_idx
	ON notifications(service_request_id, created_at DESC, id DESC);

COMMIT;
