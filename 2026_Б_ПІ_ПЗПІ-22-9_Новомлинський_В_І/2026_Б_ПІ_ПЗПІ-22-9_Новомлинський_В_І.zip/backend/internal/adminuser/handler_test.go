package adminuser

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

func TestListRequiresAdministrator(t *testing.T) {
	handler := NewHandler(&handlerServiceStub{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/admin/users", nil)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:   testTargetUserID,
		Role: auth.TechnicalSpecialistRoleCode,
	}))
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestListParsesFilters(t *testing.T) {
	service := &handlerServiceStub{}
	handler := NewHandler(service, testLogger())
	request := adminRequest(
		http.MethodGet,
		"/api/v1/admin/users?role=vehicle_owner&is_active=false&search=owner",
		nil,
	)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.filters.Role != auth.DefaultRoleCode {
		t.Fatalf("expected role filter, got %q", service.filters.Role)
	}
	if service.filters.IsActive == nil || *service.filters.IsActive {
		t.Fatalf("expected inactive filter, got %#v", service.filters.IsActive)
	}
	if service.filters.Search != "owner" {
		t.Fatalf("expected search filter owner, got %q", service.filters.Search)
	}
}

func TestGetRejectsInvalidID(t *testing.T) {
	handler := NewHandler(&handlerServiceStub{getErr: ErrInvalidInput}, testLogger())
	request := adminRequest(http.MethodGet, "/api/v1/admin/users/not-a-uuid", nil)
	request.SetPathValue("user_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.Get(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestDeactivateStatusMapping(t *testing.T) {
	tests := []struct {
		name   string
		err    error
		status int
	}{
		{name: "self", err: ErrSelfDeactivation, status: http.StatusConflict},
		{name: "missing", err: ErrNotFound, status: http.StatusNotFound},
		{name: "already inactive", err: ErrAlreadyInactive, status: http.StatusConflict},
		{name: "last admin", err: ErrLastAdministrator, status: http.StatusConflict},
		{name: "assigned work", err: ErrSpecialistActiveWork, status: http.StatusConflict},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := NewHandler(&handlerServiceStub{deactivateErr: tt.err}, testLogger())
			request := adminRequest(
				http.MethodPatch,
				"/api/v1/admin/users/"+testTargetUserID+"/deactivate",
				strings.NewReader(`{"reason":"Administrative decision"}`),
			)
			request.SetPathValue("user_id", testTargetUserID)
			recorder := httptest.NewRecorder()

			handler.Deactivate(recorder, request)

			if recorder.Code != tt.status {
				t.Fatalf("expected status %d, got %d", tt.status, recorder.Code)
			}
		})
	}
}

func TestDeactivateAcceptsEmptyBody(t *testing.T) {
	handler := NewHandler(&handlerServiceStub{}, testLogger())
	request := adminRequest(
		http.MethodPatch,
		"/api/v1/admin/users/"+testTargetUserID+"/deactivate",
		nil,
	)
	request.SetPathValue("user_id", testTargetUserID)
	recorder := httptest.NewRecorder()

	handler.Deactivate(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
}

func TestReactivateConflict(t *testing.T) {
	handler := NewHandler(&handlerServiceStub{reactivateErr: ErrAlreadyActive}, testLogger())
	request := adminRequest(
		http.MethodPatch,
		"/api/v1/admin/users/"+testTargetUserID+"/reactivate",
		nil,
	)
	request.SetPathValue("user_id", testTargetUserID)
	recorder := httptest.NewRecorder()

	handler.Reactivate(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

type handlerServiceStub struct {
	filters       ListFilters
	getErr        error
	deactivateErr error
	reactivateErr error
}

func (s *handlerServiceStub) List(_ context.Context, filters ListFilters) ([]User, error) {
	s.filters = filters
	return []User{{ID: testTargetUserID, Role: auth.DefaultRoleCode}}, nil
}

func (s *handlerServiceStub) Get(context.Context, string) (User, error) {
	if s.getErr != nil {
		return User{}, s.getErr
	}
	return User{ID: testTargetUserID, Role: auth.DefaultRoleCode}, nil
}

func (s *handlerServiceStub) Deactivate(
	context.Context,
	auth.User,
	string,
	DeactivateRequest,
) (User, error) {
	if s.deactivateErr != nil {
		return User{}, s.deactivateErr
	}
	return User{ID: testTargetUserID, Role: auth.DefaultRoleCode, IsActive: false}, nil
}

func (s *handlerServiceStub) Reactivate(context.Context, auth.User, string) (User, error) {
	if s.reactivateErr != nil {
		return User{}, s.reactivateErr
	}
	return User{ID: testTargetUserID, Role: auth.DefaultRoleCode, IsActive: true}, nil
}

func adminRequest(method string, target string, body io.Reader) *http.Request {
	request := httptest.NewRequest(method, target, body)
	request = request.WithContext(auth.WithUser(request.Context(), testAdminUser()))

	return request
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
