package adminspecialist

import (
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

const (
	ActionTechnicalSpecialistCreated = "technical_specialist.created"
	EntityTypeUser                   = "user"
)

type CreateRequest struct {
	Email        string   `json:"email"`
	Password     string   `json:"password"`
	Name         string   `json:"name"`
	FullName     string   `json:"full_name"`
	Competencies []string `json:"competencies"`
}

type CreateResult struct {
	User         auth.User                         `json:"user"`
	Competencies []specialistcompetency.Competency `json:"competencies"`
}

type CreateInput struct {
	ActorID      string
	Email        string
	PasswordHash string
	FullName     string
	Competencies []specialistcompetency.SupportedCompetency
}

type createdCompetency struct {
	ID           string
	SpecialistID string
	Code         string
	Name         string
	CreatedAt    time.Time
}
