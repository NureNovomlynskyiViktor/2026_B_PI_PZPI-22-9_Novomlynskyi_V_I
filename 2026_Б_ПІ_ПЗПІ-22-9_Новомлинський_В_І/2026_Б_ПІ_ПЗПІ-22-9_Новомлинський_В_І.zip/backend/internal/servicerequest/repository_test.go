package servicerequest

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
)

func TestDuplicateOpenAlertRequestDetection(t *testing.T) {
	err := errors.New(
		`ERROR: duplicate key value violates unique constraint "vehicle_service_requests_open_source_alert_unique"`,
	)
	if !isDuplicateOpenAlertRequest(err) {
		t.Fatal("expected duplicate open alert request detection")
	}
}

func TestServiceRequestLifecycleNotificationInputs(t *testing.T) {
	item := Request{
		ID:      testRequestID,
		OwnerID: testOwnerID,
		Title:   "Engine diagnostics",
	}

	assigned := assignmentNotification(item)
	if assigned.UserID != testOwnerID ||
		assigned.ServiceRequestID == nil ||
		*assigned.ServiceRequestID != testRequestID ||
		assigned.NotificationType != notification.TypeServiceRequestAssigned ||
		assigned.Title != "Specialist assigned" ||
		!strings.Contains(assigned.Message, "Engine diagnostics") {
		t.Fatalf("unexpected assignment notification: %#v", assigned)
	}

	started := startedNotification(item)
	if started.NotificationType != notification.TypeServiceRequestStarted ||
		started.Title != "Service work started" ||
		!strings.Contains(started.Message, "Engine diagnostics") {
		t.Fatalf("unexpected started notification: %#v", started)
	}

	completed := completedNotification(item, "Battery terminal replaced.")
	if completed.NotificationType != notification.TypeServiceRequestCompleted ||
		completed.Title != "Service request completed" ||
		!strings.Contains(completed.Message, "Engine diagnostics") ||
		!strings.Contains(completed.Message, "Battery terminal replaced.") {
		t.Fatalf("unexpected completed notification: %#v", completed)
	}
}

func TestServiceRequestAuditActionAndMetadata(t *testing.T) {
	previousSpecialistID := "44444444-4444-4444-4444-444444444444"
	newSpecialistID := "55555555-5555-5555-5555-555555555555"
	previous := Request{
		ID:                   testRequestID,
		VehicleID:            testVehicleID,
		OwnerID:              testOwnerID,
		Title:                "Engine diagnostics",
		Priority:             PriorityHigh,
		Status:               StatusAssigned,
		AssignedSpecialistID: &previousSpecialistID,
	}
	next := previous
	next.Status = StatusAssigned
	next.AssignedSpecialistID = &newSpecialistID

	if action := assignmentAuditAction(Request{Status: StatusPending}); action != ActionServiceRequestAssigned {
		t.Fatalf("expected assigned action, got %q", action)
	}
	if action := assignmentAuditAction(previous); action != ActionServiceRequestReassigned {
		t.Fatalf("expected reassigned action, got %q", action)
	}

	metadata := lifecycleAuditMetadata(previous, next)
	if metadata["vehicle_id"] != testVehicleID ||
		metadata["owner_id"] != testOwnerID ||
		metadata["title"] != "Engine diagnostics" ||
		metadata["priority"] != PriorityHigh ||
		metadata["previous_status"] != StatusAssigned ||
		metadata["new_status"] != StatusAssigned ||
		metadata["previous_specialist_id"] != &previousSpecialistID ||
		metadata["new_specialist_id"] != &newSpecialistID {
		t.Fatalf("unexpected audit metadata: %#v", metadata)
	}
}

func TestServiceRequestAuditFailurePropagates(t *testing.T) {
	expected := auditlog.ErrWriteFailed
	writer := &fakeAuditWriter{err: expected}
	repository := &PostgresRepository{audits: writer}
	item := Request{
		ID:        testRequestID,
		VehicleID: testVehicleID,
		OwnerID:   testOwnerID,
		Title:     "Engine diagnostics",
		Priority:  PriorityNormal,
		Status:    StatusAssigned,
	}

	err := repository.writeLifecycleAudit(
		context.Background(),
		nil,
		testAdminID,
		ActionServiceRequestAssigned,
		Request{Status: StatusPending},
		item,
	)
	if !errors.Is(err, auditlog.ErrWriteFailed) {
		t.Fatalf("expected audit write failure, got %v", err)
	}
	if writer.entry.ActorID != testAdminID ||
		writer.entry.Action != ActionServiceRequestAssigned ||
		writer.entry.EntityType != EntityTypeServiceRequest ||
		writer.entry.EntityID != testRequestID {
		t.Fatalf("unexpected audit entry: %#v", writer.entry)
	}
}

type fakeAuditWriter struct {
	entry auditlog.Entry
	err   error
}

func (w *fakeAuditWriter) Write(
	_ context.Context,
	_ auditlog.Executor,
	entry auditlog.Entry,
) error {
	w.entry = entry
	return w.err
}
