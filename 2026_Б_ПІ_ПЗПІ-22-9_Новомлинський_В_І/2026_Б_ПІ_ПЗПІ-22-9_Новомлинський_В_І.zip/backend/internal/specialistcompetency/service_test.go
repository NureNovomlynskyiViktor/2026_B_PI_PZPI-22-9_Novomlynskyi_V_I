package specialistcompetency

import (
	"context"
	"errors"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

const testSpecialistID = "11111111-1111-1111-1111-111111111111"

type repositoryStub struct {
	user auth.User
}

func (r repositoryStub) GetSpecialistByID(
	context.Context,
	string,
) (auth.User, error) {
	return r.user, nil
}

func (repositoryStub) ListBySpecialist(
	context.Context,
	string,
) ([]Competency, error) {
	return []Competency{}, nil
}

func (repositoryStub) ListAll(context.Context) ([]Competency, error) {
	return []Competency{}, nil
}

func (repositoryStub) ReplaceForSpecialist(
	_ context.Context,
	specialistID string,
	competencies []SupportedCompetency,
) ([]Competency, error) {
	items := make([]Competency, 0, len(competencies))
	for _, competency := range competencies {
		items = append(items, Competency{
			SpecialistID: specialistID,
			Code:         competency.Code,
			Name:         competency.Name,
		})
	}

	return items, nil
}

func TestReplaceRejectsInvalidSpecialistID(t *testing.T) {
	service := NewService(repositoryStub{user: technicalSpecialist()})

	_, err := service.Replace(context.Background(), "bad-id", []string{CodeEngineDiagnostics})
	if !errors.Is(err, ErrInvalidSpecialistID) {
		t.Fatalf("expected ErrInvalidSpecialistID, got %v", err)
	}
}

func TestReplaceRejectsInvalidCompetencyCode(t *testing.T) {
	service := NewService(repositoryStub{user: technicalSpecialist()})

	_, err := service.Replace(context.Background(), testSpecialistID, []string{"unsafe_code"})
	if !errors.Is(err, ErrInvalidCompetencyCode) {
		t.Fatalf("expected ErrInvalidCompetencyCode, got %v", err)
	}
}

func TestReplaceRequiresTechnicalSpecialist(t *testing.T) {
	service := NewService(repositoryStub{
		user: auth.User{ID: testSpecialistID, Role: auth.DefaultRoleCode},
	})

	_, err := service.Replace(context.Background(), testSpecialistID, []string{CodeEngineDiagnostics})
	if !errors.Is(err, ErrInvalidSpecialistRole) {
		t.Fatalf("expected ErrInvalidSpecialistRole, got %v", err)
	}
}

func TestReplaceDeduplicatesCodes(t *testing.T) {
	service := NewService(repositoryStub{user: technicalSpecialist()})

	result, err := service.Replace(
		context.Background(),
		testSpecialistID,
		[]string{CodeEngineDiagnostics, CodeEngineDiagnostics, CodeVibrationAnalysis},
	)
	if err != nil {
		t.Fatalf("replace competencies: %v", err)
	}
	if len(result) != 2 {
		t.Fatalf("expected 2 competencies, got %d", len(result))
	}
}

func technicalSpecialist() auth.User {
	return auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	}
}
