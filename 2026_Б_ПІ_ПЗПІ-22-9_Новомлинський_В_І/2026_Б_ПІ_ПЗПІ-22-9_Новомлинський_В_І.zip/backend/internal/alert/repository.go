package alert

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
)

var ErrNotFound = errors.New("alert not found")

const (
	ActionAlertResolutionConfirmed = "alert.resolution_confirmed"
	EntityTypeAlert                = "alert"
)

type LifecycleAction string

const (
	LifecycleCreated   LifecycleAction = "created"
	LifecycleExisting  LifecycleAction = "existing"
	LifecycleEscalated LifecycleAction = "escalated"
	LifecycleUpdated   LifecycleAction = "updated"
	LifecycleCleared   LifecycleAction = "cleared"
	LifecycleReopened  LifecycleAction = "reopened"
)

type Repository interface {
	ListByVehicle(ctx context.Context, vehicleID string, limit int) ([]Alert, error)
	ListByVehicleStatus(ctx context.Context, vehicleID string, status string, limit int) ([]Alert, error)
	ListActiveByVehicle(ctx context.Context, vehicleID string) ([]Alert, error)
	GetByID(ctx context.Context, id string) (Alert, error)
	ResolveBySpecialist(ctx context.Context, request SpecialistResolution) (Alert, error)
}

type PostgresRepository struct {
	db            *sql.DB
	notifications notification.Writer
	audits        auditlog.Writer
}

type NewAlert struct {
	VehicleID         string
	TelemetryRecordID int64
	Type              string
	Severity          string
	Message           string
	Recommendation    string
}

type RecoveryInput struct {
	VehicleID         string
	TelemetryRecordID int64
	Type              string
	Recovered         bool
	RequiredSamples   int
}

const alertColumns = `
	id,
	vehicle_id,
	telemetry_record_id,
	type,
	severity,
	current_severity,
	status,
	message,
	recommendation,
	occurrence_count,
	recovery_streak,
	created_at,
	last_triggered_at,
	cleared_at,
	resolved_at,
	resolved_by_user_id,
	resolution_note,
	resolution_service_request_id
`

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{
		db:            db,
		notifications: notification.NewPostgresWriter(),
		audits:        auditlog.NewPostgresWriter(),
	}
}

func (r *PostgresRepository) ListByVehicle(
	ctx context.Context,
	vehicleID string,
	limit int,
) ([]Alert, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE vehicle_id = $1
		ORDER BY created_at DESC, id DESC
		LIMIT $2
	`

	return queryAlerts(ctx, r.db, query, vehicleID, limit)
}

func (r *PostgresRepository) ListByVehicleStatus(
	ctx context.Context,
	vehicleID string,
	status string,
	limit int,
) ([]Alert, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE vehicle_id = $1
		  AND status = $2
		ORDER BY created_at DESC, id DESC
		LIMIT $3
	`

	return queryAlerts(ctx, r.db, query, vehicleID, status, limit)
}

func (r *PostgresRepository) ListActiveByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Alert, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE vehicle_id = $1
		  AND status = 'active'
		ORDER BY created_at DESC, id DESC
	`

	return queryAlerts(ctx, r.db, query, vehicleID)
}

func (r *PostgresRepository) GetByID(ctx context.Context, id string) (Alert, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE id = $1
	`

	item, err := scanAlert(r.db.QueryRowContext(ctx, query, id))
	if errors.Is(err, sql.ErrNoRows) {
		return Alert{}, ErrNotFound
	}
	if err != nil {
		return Alert{}, fmt.Errorf("query alert by ID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ResolveBySpecialist(
	ctx context.Context,
	request SpecialistResolution,
) (Alert, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Alert{}, fmt.Errorf("begin specialist alert resolution transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	current, ownerID, err := alertForUpdate(ctx, tx, request.AlertID)
	if err != nil {
		return Alert{}, err
	}

	assigned, err := isSpecialistAssignedToVehicle(ctx, tx, request.SpecialistID, current.VehicleID)
	if err != nil {
		return Alert{}, err
	}
	if !assigned {
		return Alert{}, ErrNotFound
	}

	if current.Status == StatusActive {
		return Alert{}, ErrActiveNotResolved
	}
	if current.Status == StatusResolved {
		return current, nil
	}
	if current.Status != StatusCleared {
		return Alert{}, ErrActiveNotResolved
	}

	if request.ServiceRequestID != nil {
		if err := validateResolutionServiceRequest(ctx, tx, request, current); err != nil {
			return Alert{}, err
		}
	}

	item, err := updateSpecialistResolution(ctx, tx, request)
	if err != nil {
		return Alert{}, err
	}
	if err := r.writeResolutionAudit(ctx, tx, request, current, item); err != nil {
		return Alert{}, err
	}
	if err := r.createResolutionNotification(ctx, tx, ownerID, item, request.ResolutionNote); err != nil {
		return Alert{}, err
	}
	if err := tx.Commit(); err != nil {
		return Alert{}, fmt.Errorf("commit specialist alert resolution transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ApplyEvaluation(
	ctx context.Context,
	input NewAlert,
) (Alert, LifecycleAction, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Alert{}, "", fmt.Errorf("begin alert lifecycle transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	if err := lockAlertLifecycle(ctx, tx, input.VehicleID, input.Type); err != nil {
		return Alert{}, "", err
	}

	existing, err := nonResolvedByVehicleAndType(ctx, tx, input.VehicleID, input.Type)
	if err == nil {
		var (
			item   Alert
			action LifecycleAction
		)
		if existing.Status == StatusCleared {
			item, err = reopenAlert(ctx, tx, existing.ID, input)
			action = LifecycleReopened
		} else if shouldEscalate(existing.Severity, input.Severity) {
			item, err = updateActiveAlert(ctx, tx, existing.ID, input, true)
			action = LifecycleEscalated
		} else if currentSeverity(existing) != input.Severity {
			item, err = updateActiveAlert(ctx, tx, existing.ID, input, false)
			action = LifecycleUpdated
		} else {
			item, err = updateActiveAlert(ctx, tx, existing.ID, input, false)
			action = LifecycleExisting
		}
		if err != nil {
			return Alert{}, "", err
		}
		if err := tx.Commit(); err != nil {
			return Alert{}, "", fmt.Errorf("commit alert lifecycle update: %w", err)
		}
		return item, action, nil
	}
	if !errors.Is(err, sql.ErrNoRows) {
		return Alert{}, "", fmt.Errorf("query non-resolved alert by type: %w", err)
	}

	created, err := insertAlert(ctx, tx, input)
	if err != nil {
		return Alert{}, "", err
	}
	if err := tx.Commit(); err != nil {
		return Alert{}, "", fmt.Errorf("commit alert creation: %w", err)
	}

	return created, LifecycleCreated, nil
}

func (r *PostgresRepository) ApplyRecovery(
	ctx context.Context,
	input RecoveryInput,
) (Alert, LifecycleAction, error) {
	requiredSamples := input.RequiredSamples
	if requiredSamples < 1 {
		requiredSamples = 1
	}

	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Alert{}, "", fmt.Errorf("begin alert recovery transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	if err := lockAlertLifecycle(ctx, tx, input.VehicleID, input.Type); err != nil {
		return Alert{}, "", err
	}

	existing, err := activeByVehicleAndType(ctx, tx, input.VehicleID, input.Type)
	if errors.Is(err, sql.ErrNoRows) {
		if err := tx.Commit(); err != nil {
			return Alert{}, "", fmt.Errorf("commit empty alert recovery: %w", err)
		}
		return Alert{}, LifecycleExisting, nil
	}
	if err != nil {
		return Alert{}, "", fmt.Errorf("query active alert before recovery: %w", err)
	}

	var item Alert
	if input.Recovered {
		nextStreak := existing.RecoveryStreak + 1
		if nextStreak >= requiredSamples {
			item, err = clearAlert(ctx, tx, existing.ID, input.TelemetryRecordID)
			if err != nil {
				return Alert{}, "", err
			}
			if err := tx.Commit(); err != nil {
				return Alert{}, "", fmt.Errorf("commit alert clear: %w", err)
			}
			return item, LifecycleCleared, nil
		}

		item, err = updateRecoveryStreak(ctx, tx, existing.ID, input.TelemetryRecordID, nextStreak)
	} else {
		item, err = updateRecoveryStreak(ctx, tx, existing.ID, input.TelemetryRecordID, 0)
	}
	if err != nil {
		return Alert{}, "", err
	}
	if err := tx.Commit(); err != nil {
		return Alert{}, "", fmt.Errorf("commit alert recovery streak: %w", err)
	}

	return item, LifecycleExisting, nil
}

func (r *PostgresRepository) ResolveActiveByVehicleAndType(
	ctx context.Context,
	vehicleID string,
	alertType string,
) (Alert, bool, error) {
	item, action, err := r.ApplyRecovery(
		ctx,
		RecoveryInput{
			VehicleID:       vehicleID,
			Type:            alertType,
			Recovered:       true,
			RequiredSamples: 1,
		},
	)
	return item, action == LifecycleCleared, err
}

func (r *PostgresRepository) CreateOrGetActive(
	ctx context.Context,
	input NewAlert,
) (Alert, bool, error) {
	item, action, err := r.ApplyEvaluation(ctx, input)
	return item, action == LifecycleCreated, err
}

func alertForUpdate(
	ctx context.Context,
	tx txExecutor,
	alertID string,
) (Alert, string, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE id = $1
		FOR UPDATE
	`

	item, err := scanAlert(tx.QueryRowContext(ctx, query, alertID))
	if errors.Is(err, sql.ErrNoRows) {
		return Alert{}, "", ErrNotFound
	}
	if err != nil {
		return Alert{}, "", fmt.Errorf("query alert for specialist resolution: %w", err)
	}
	var ownerID sql.NullString
	if err := tx.QueryRowContext(
		ctx,
		`SELECT owner_id FROM vehicles WHERE id = $1`,
		item.VehicleID,
	).Scan(&ownerID); errors.Is(err, sql.ErrNoRows) {
		return Alert{}, "", ErrNotFound
	} else if err != nil {
		return Alert{}, "", fmt.Errorf("query alert vehicle owner: %w", err)
	}
	if !ownerID.Valid {
		return Alert{}, "", fmt.Errorf("alert vehicle has no owner")
	}

	return item, ownerID.String, nil
}

func isSpecialistAssignedToVehicle(
	ctx context.Context,
	tx txExecutor,
	specialistID string,
	vehicleID string,
) (bool, error) {
	var exists bool
	if err := tx.QueryRowContext(
		ctx,
		`
			SELECT EXISTS (
				SELECT 1
				FROM vehicle_specialist_assignments
				WHERE specialist_id = $1
				  AND vehicle_id = $2
			)
		`,
		specialistID,
		vehicleID,
	).Scan(&exists); err != nil {
		return false, fmt.Errorf("verify specialist alert assignment: %w", err)
	}

	return exists, nil
}

func validateResolutionServiceRequest(
	ctx context.Context,
	tx txExecutor,
	request SpecialistResolution,
	item Alert,
) error {
	var snapshot resolutionServiceRequestSnapshot
	if err := tx.QueryRowContext(
		ctx,
		`
			SELECT
				vehicle_id,
				source_alert_id,
				assigned_specialist_id,
				status
			FROM vehicle_service_requests
			WHERE id = $1
		`,
		*request.ServiceRequestID,
	).Scan(
		&snapshot.VehicleID,
		&snapshot.SourceAlertID,
		&snapshot.AssignedSpecialistID,
		&snapshot.Status,
	); errors.Is(err, sql.ErrNoRows) {
		return ErrInvalidResolutionServiceRequest
	} else if err != nil {
		return fmt.Errorf("query resolution service request: %w", err)
	}

	if !isValidResolutionServiceRequest(request, item, snapshot) {
		return ErrInvalidResolutionServiceRequest
	}

	return nil
}

type resolutionServiceRequestSnapshot struct {
	VehicleID            string
	SourceAlertID        sql.NullString
	AssignedSpecialistID sql.NullString
	Status               string
}

func isValidResolutionServiceRequest(
	request SpecialistResolution,
	item Alert,
	snapshot resolutionServiceRequestSnapshot,
) bool {
	return snapshot.VehicleID == item.VehicleID &&
		snapshot.SourceAlertID.Valid &&
		snapshot.SourceAlertID.String == item.ID &&
		snapshot.AssignedSpecialistID.Valid &&
		snapshot.AssignedSpecialistID.String == request.SpecialistID &&
		snapshot.Status == "completed"
}

func updateSpecialistResolution(
	ctx context.Context,
	tx txExecutor,
	request SpecialistResolution,
) (Alert, error) {
	query := `
		UPDATE alerts
		SET
			status = 'resolved',
			resolved_at = NOW(),
			resolved_by_user_id = $2,
			resolution_note = $3,
			resolution_service_request_id = $4
		WHERE id = $1
		  AND status = 'cleared'
		RETURNING ` + alertColumns

	item, err := scanAlert(tx.QueryRowContext(
		ctx,
		query,
		request.AlertID,
		request.SpecialistID,
		request.ResolutionNote,
		request.ServiceRequestID,
	))
	if errors.Is(err, sql.ErrNoRows) {
		return Alert{}, ErrNotFound
	}
	if err != nil {
		return Alert{}, fmt.Errorf("resolve alert by specialist: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) writeResolutionAudit(
	ctx context.Context,
	tx auditlog.Executor,
	request SpecialistResolution,
	previous Alert,
	next Alert,
) error {
	if r.audits == nil {
		return nil
	}

	err := r.audits.Write(ctx, tx, auditlog.Entry{
		ActorID:    request.SpecialistID,
		Action:     ActionAlertResolutionConfirmed,
		EntityType: EntityTypeAlert,
		EntityID:   next.ID,
		Metadata: map[string]any{
			"alert_id":                      next.ID,
			"vehicle_id":                    next.VehicleID,
			"type":                          next.Type,
			"severity":                      next.Severity,
			"previous_status":               previous.Status,
			"new_status":                    next.Status,
			"occurrence_count":              next.OccurrenceCount,
			"cleared_at":                    next.ClearedAt,
			"resolved_at":                   next.ResolvedAt,
			"specialist_id":                 request.SpecialistID,
			"resolution_service_request_id": request.ServiceRequestID,
			"resolution_note_length":        len([]rune(request.ResolutionNote)),
		},
	})
	if err != nil {
		return fmt.Errorf("write alert resolution audit: %w", err)
	}

	return nil
}

func (r *PostgresRepository) createResolutionNotification(
	ctx context.Context,
	tx notification.Executor,
	ownerID string,
	item Alert,
	note string,
) error {
	if r.notifications == nil {
		return nil
	}

	_, err := r.notifications.Create(
		ctx,
		tx,
		notification.NewNotification{
			UserID:           ownerID,
			AlertID:          &item.ID,
			NotificationType: notification.TypeVehicleAlert,
			Title:            "Alert resolution confirmed",
			Message: fmt.Sprintf(
				"A technical specialist confirmed resolution for %s. Note: %s",
				readableAlertType(item.Type),
				note,
			),
		},
	)
	if err != nil {
		return fmt.Errorf("create alert resolution notification: %w", err)
	}

	return nil
}

func readableAlertType(alertType string) string {
	readable := strings.TrimSpace(strings.ReplaceAll(alertType, "_", " "))
	if readable == "" {
		return "vehicle condition"
	}

	return readable
}

type txExecutor interface {
	ExecContext(ctx context.Context, query string, args ...any) (sql.Result, error)
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

func lockAlertLifecycle(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	alertType string,
) error {
	lockKey := vehicleID + ":" + alertType
	if _, err := tx.ExecContext(
		ctx,
		`SELECT pg_advisory_xact_lock(hashtextextended($1, 0))`,
		lockKey,
	); err != nil {
		return fmt.Errorf("lock alert lifecycle: %w", err)
	}
	return nil
}

func activeByVehicleAndType(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	alertType string,
) (Alert, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE vehicle_id = $1
		  AND type = $2
		  AND status = 'active'
		ORDER BY created_at DESC, id DESC
		LIMIT 1
	`

	return scanAlert(tx.QueryRowContext(ctx, query, vehicleID, alertType))
}

func nonResolvedByVehicleAndType(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	alertType string,
) (Alert, error) {
	query := `
		SELECT ` + alertColumns + `
		FROM alerts
		WHERE vehicle_id = $1
		  AND type = $2
		  AND status IN ('active', 'cleared')
		ORDER BY
			CASE status WHEN 'active' THEN 0 ELSE 1 END,
			created_at DESC,
			id DESC
		LIMIT 1
	`

	return scanAlert(tx.QueryRowContext(ctx, query, vehicleID, alertType))
}

func insertAlert(
	ctx context.Context,
	tx txExecutor,
	input NewAlert,
) (Alert, error) {
	query := `
		INSERT INTO alerts (
			vehicle_id,
			telemetry_record_id,
			type,
			severity,
			current_severity,
			status,
			message,
			recommendation,
			occurrence_count,
			recovery_streak,
			last_triggered_at
		)
		VALUES ($1, $2, $3, $4, $4, 'active', $5, $6, 1, 0, NOW())
		RETURNING ` + alertColumns

	created, err := scanAlert(
		tx.QueryRowContext(
			ctx,
			query,
			input.VehicleID,
			input.TelemetryRecordID,
			input.Type,
			input.Severity,
			input.Message,
			input.Recommendation,
		),
	)
	if err != nil {
		return Alert{}, fmt.Errorf("insert alert: %w", err)
	}

	return created, nil
}

func updateActiveAlert(
	ctx context.Context,
	tx txExecutor,
	alertID string,
	input NewAlert,
	updateMaximumSeverity bool,
) (Alert, error) {
	severityExpression := "severity"
	if updateMaximumSeverity {
		severityExpression = "$3"
	}

	query := `
		UPDATE alerts
		SET
			telemetry_record_id = $2,
			severity = ` + severityExpression + `,
			current_severity = $3,
			status = 'active',
			message = $4,
			recommendation = $5,
			recovery_streak = 0,
			last_triggered_at = NOW(),
			cleared_at = NULL
		WHERE id = $1
		RETURNING ` + alertColumns

	item, err := scanAlert(
		tx.QueryRowContext(
			ctx,
			query,
			alertID,
			input.TelemetryRecordID,
			input.Severity,
			input.Message,
			input.Recommendation,
		),
	)
	if err != nil {
		return Alert{}, fmt.Errorf("update active alert: %w", err)
	}

	return item, nil
}

func reopenAlert(
	ctx context.Context,
	tx txExecutor,
	alertID string,
	input NewAlert,
) (Alert, error) {
	query := `
		UPDATE alerts
		SET
			telemetry_record_id = $2,
			severity = CASE
				WHEN $3 = 'critical' AND severity <> 'critical' THEN $3
				ELSE severity
			END,
			current_severity = $3,
			status = 'active',
			message = $4,
			recommendation = $5,
			occurrence_count = occurrence_count + 1,
			recovery_streak = 0,
			last_triggered_at = NOW(),
			cleared_at = NULL
		WHERE id = $1
		RETURNING ` + alertColumns

	item, err := scanAlert(
		tx.QueryRowContext(
			ctx,
			query,
			alertID,
			input.TelemetryRecordID,
			input.Severity,
			input.Message,
			input.Recommendation,
		),
	)
	if err != nil {
		return Alert{}, fmt.Errorf("reopen alert: %w", err)
	}

	return item, nil
}

func clearAlert(
	ctx context.Context,
	tx txExecutor,
	alertID string,
	telemetryRecordID int64,
) (Alert, error) {
	query := `
		UPDATE alerts
		SET
			telemetry_record_id = $2,
			status = 'cleared',
			current_severity = NULL,
			cleared_at = NOW(),
			recovery_streak = 0
		WHERE id = $1
		RETURNING ` + alertColumns

	item, err := scanAlert(tx.QueryRowContext(ctx, query, alertID, telemetryRecordID))
	if err != nil {
		return Alert{}, fmt.Errorf("clear alert: %w", err)
	}

	return item, nil
}

func updateRecoveryStreak(
	ctx context.Context,
	tx txExecutor,
	alertID string,
	telemetryRecordID int64,
	streak int,
) (Alert, error) {
	query := `
		UPDATE alerts
		SET
			telemetry_record_id = $2,
			recovery_streak = $3
		WHERE id = $1
		RETURNING ` + alertColumns

	item, err := scanAlert(tx.QueryRowContext(ctx, query, alertID, telemetryRecordID, streak))
	if err != nil {
		return Alert{}, fmt.Errorf("update alert recovery streak: %w", err)
	}

	return item, nil
}

func shouldEscalate(currentSeverity string, nextSeverity string) bool {
	return severityRank(nextSeverity) > severityRank(currentSeverity)
}

func severityRank(severity string) int {
	switch severity {
	case "critical":
		return 2
	case "warning":
		return 1
	default:
		return 0
	}
}

func currentSeverity(item Alert) string {
	if item.CurrentSeverity != nil {
		return *item.CurrentSeverity
	}
	return item.Severity
}

type queryer interface {
	QueryContext(ctx context.Context, query string, args ...any) (*sql.Rows, error)
}

func queryAlerts(
	ctx context.Context,
	db queryer,
	query string,
	args ...any,
) ([]Alert, error) {
	rows, err := db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query alerts: %w", err)
	}
	defer rows.Close()

	alerts := make([]Alert, 0)
	for rows.Next() {
		item, err := scanAlert(rows)
		if err != nil {
			return nil, fmt.Errorf("scan alert: %w", err)
		}
		alerts = append(alerts, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate alerts: %w", err)
	}

	return alerts, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanAlert(row scanner) (Alert, error) {
	var (
		item                       Alert
		currentSeverity            sql.NullString
		recommendation             sql.NullString
		lastTriggeredAt            sql.NullTime
		clearedAt                  sql.NullTime
		resolvedAt                 sql.NullTime
		resolvedByUserID           sql.NullString
		resolutionNote             sql.NullString
		resolutionServiceRequestID sql.NullString
	)

	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.TelemetryRecordID,
		&item.Type,
		&item.Severity,
		&currentSeverity,
		&item.Status,
		&item.Message,
		&recommendation,
		&item.OccurrenceCount,
		&item.RecoveryStreak,
		&item.CreatedAt,
		&lastTriggeredAt,
		&clearedAt,
		&resolvedAt,
		&resolvedByUserID,
		&resolutionNote,
		&resolutionServiceRequestID,
	); err != nil {
		return Alert{}, err
	}

	if currentSeverity.Valid {
		item.CurrentSeverity = &currentSeverity.String
	}
	if recommendation.Valid {
		item.Recommendation = &recommendation.String
	}
	if lastTriggeredAt.Valid {
		value := lastTriggeredAt.Time
		item.LastTriggeredAt = &value
	}
	if clearedAt.Valid {
		value := clearedAt.Time
		item.ClearedAt = &value
	}
	if resolvedAt.Valid {
		value := resolvedAt.Time
		item.ResolvedAt = &value
	}
	if resolvedByUserID.Valid {
		item.ResolvedByUserID = &resolvedByUserID.String
	}
	if resolutionNote.Valid {
		item.ResolutionNote = &resolutionNote.String
	}
	if resolutionServiceRequestID.Valid {
		item.ResolutionServiceRequestID = &resolutionServiceRequestID.String
	}

	return item, nil
}

func scanAlertWithOwner(row scanner) (Alert, string, error) {
	var (
		item                       Alert
		currentSeverity            sql.NullString
		recommendation             sql.NullString
		lastTriggeredAt            sql.NullTime
		clearedAt                  sql.NullTime
		resolvedAt                 sql.NullTime
		resolvedByUserID           sql.NullString
		resolutionNote             sql.NullString
		resolutionServiceRequestID sql.NullString
		ownerID                    sql.NullString
	)

	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.TelemetryRecordID,
		&item.Type,
		&item.Severity,
		&currentSeverity,
		&item.Status,
		&item.Message,
		&recommendation,
		&item.OccurrenceCount,
		&item.RecoveryStreak,
		&item.CreatedAt,
		&lastTriggeredAt,
		&clearedAt,
		&resolvedAt,
		&resolvedByUserID,
		&resolutionNote,
		&resolutionServiceRequestID,
		&ownerID,
	); err != nil {
		return Alert{}, "", err
	}

	applyNullableAlertFields(
		&item,
		currentSeverity,
		recommendation,
		lastTriggeredAt,
		clearedAt,
		resolvedAt,
		resolvedByUserID,
		resolutionNote,
		resolutionServiceRequestID,
	)
	if !ownerID.Valid {
		return item, "", nil
	}

	return item, ownerID.String, nil
}

func applyNullableAlertFields(
	item *Alert,
	currentSeverity sql.NullString,
	recommendation sql.NullString,
	lastTriggeredAt sql.NullTime,
	clearedAt sql.NullTime,
	resolvedAt sql.NullTime,
	resolvedByUserID sql.NullString,
	resolutionNote sql.NullString,
	resolutionServiceRequestID sql.NullString,
) {
	if currentSeverity.Valid {
		item.CurrentSeverity = &currentSeverity.String
	}
	if recommendation.Valid {
		item.Recommendation = &recommendation.String
	}
	if lastTriggeredAt.Valid {
		value := lastTriggeredAt.Time
		item.LastTriggeredAt = &value
	}
	if clearedAt.Valid {
		value := clearedAt.Time
		item.ClearedAt = &value
	}
	if resolvedAt.Valid {
		value := resolvedAt.Time
		item.ResolvedAt = &value
	}
	if resolvedByUserID.Valid {
		item.ResolvedByUserID = &resolvedByUserID.String
	}
	if resolutionNote.Valid {
		item.ResolutionNote = &resolutionNote.String
	}
	if resolutionServiceRequestID.Valid {
		item.ResolutionServiceRequestID = &resolutionServiceRequestID.String
	}
}
