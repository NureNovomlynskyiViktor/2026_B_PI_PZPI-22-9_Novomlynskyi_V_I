package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.service.ServiceRequestDetailsOrigin
import ua.autonexis.mobile.ui.service.ServiceRequestFormOrigin
import ua.autonexis.mobile.ui.service.ServiceRequestsBackTarget
import ua.autonexis.mobile.ui.service.ServiceRequestsMode
import ua.autonexis.mobile.ui.service.ServiceRequestsDestination
import ua.autonexis.mobile.ui.service.ServiceRequestsPresentation
import ua.autonexis.mobile.ui.service.ServiceRequestsViewModel

class ServiceRequestsPresentationTest {
    @Test
    fun sortsRequestsNewestFirstUsingCreatedAtThenUpdatedAtFallback() {
        val requests = ServiceRequestsPresentation.newestFirst(
            listOf(
                serviceRequest("older", createdAt = "2026-06-17T10:00:00Z"),
                serviceRequest("fallback-newer", createdAt = "", updatedAt = "2026-06-19T10:00:00Z"),
                serviceRequest("newer", createdAt = "2026-06-18T10:00:00Z"),
            ),
        )

        assertEquals(listOf("fallback-newer", "newer", "older"), requests.map { it.id })
    }

    @Test
    fun presentsKnownAndUnknownStatusAndPriorityLabelsSafely() {
        assertEquals("Pending", ServiceRequestsPresentation.statusLabel("pending"))
        assertEquals("In progress", ServiceRequestsPresentation.statusLabel("in_progress"))
        assertEquals("Unknown", ServiceRequestsPresentation.statusLabel("deferred"))

        assertEquals("Low", ServiceRequestsPresentation.priorityLabel("low"))
        assertEquals("Normal", ServiceRequestsPresentation.priorityLabel("normal"))
        assertEquals("High", ServiceRequestsPresentation.priorityLabel("high"))
        assertEquals("Normal", ServiceRequestsPresentation.priorityLabel("urgent"))
    }

    @Test
    fun validatesAndSanitizesCreateDraft() {
        assertEquals(
            "Title is required.",
            ServiceRequestsPresentation.validateDraft(
                ServiceRequestDraft(title = " ", description = "Check brakes", priority = "normal"),
            ),
        )
        assertEquals(
            "Description is required.",
            ServiceRequestsPresentation.validateDraft(
                ServiceRequestDraft(title = "Brake inspection", description = " ", priority = "normal"),
            ),
        )

        val sanitized = ServiceRequestsPresentation.sanitizedDraft(
            ServiceRequestDraft(
                title = "  Brake inspection  ",
                description = "  Check brake vibration.  ",
                priority = "HIGH",
                sourceAlertId = "alert-1",
            ),
        )

        assertNull(ServiceRequestsPresentation.validateDraft(sanitized))
        assertEquals("Brake inspection", sanitized.title)
        assertEquals("Check brake vibration.", sanitized.description)
        assertEquals("high", sanitized.priority)
        assertEquals("alert-1", sanitized.sourceAlertId)
    }

    @Test
    fun pendingOnlyCancellationAndOpenStateRulesMatchBackendContract() {
        assertTrue(ServiceRequestsPresentation.canCancel(serviceRequest("pending", status = "pending")))
        assertFalse(ServiceRequestsPresentation.canCancel(serviceRequest("assigned", status = "assigned")))
        assertFalse(ServiceRequestsPresentation.canCancel(serviceRequest("completed", status = "completed")))

        assertTrue(ServiceRequestsPresentation.isOpen(serviceRequest("assigned", status = "assigned")))
        assertTrue(ServiceRequestsPresentation.isOpen(serviceRequest("in-progress", status = "in_progress")))
        assertFalse(ServiceRequestsPresentation.isOpen(serviceRequest("cancelled", status = "cancelled")))
    }


    @Test
    fun globalRequestsKeepNewestFirstOrderAndSafeVehicleLabels() {
        val requests = ServiceRequestsPresentation.newestFirst(
            listOf(
                serviceRequest("older", vehicleId = "vehicle-1", createdAt = "2026-06-17T10:00:00Z"),
                serviceRequest("newer", vehicleId = "vehicle-2", createdAt = "2026-06-18T10:00:00Z"),
            ),
        )

        assertEquals(listOf("newer", "older"), requests.map { it.id })
        assertEquals(
            "Toyota Corolla",
            ServiceRequestsPresentation.vehicleLabel(requests.last(), mapOf("vehicle-1" to "Toyota Corolla")),
        )
        assertEquals("Unknown vehicle", ServiceRequestsPresentation.vehicleLabel(requests.first(), emptyMap()))
    }

    @Test
    fun globalRequestsUseGlobalBackOriginAndDisableCreateAction() {
        val viewModel = ServiceRequestsViewModel()
        viewModel.showList(
            vehicleId = "",
            vehicleLabel = "All vehicles",
            requests = listOf(serviceRequest("global", vehicleId = "vehicle-2")),
            mode = ServiceRequestsMode.GLOBAL,
            vehicleLabels = mapOf("vehicle-2" to "Honda Civic"),
        )

        viewModel.openDetails("global", ServiceRequestDetailsOrigin.GLOBAL_LIST)

        assertEquals(ServiceRequestsMode.GLOBAL, viewModel.uiState.mode)
        assertEquals(ServiceRequestDetailsOrigin.GLOBAL_LIST, viewModel.uiState.detailsOrigin)
        assertFalse(ServiceRequestsPresentation.canCreateInMode(viewModel.uiState.mode))
    }


    @Test
    fun systemBackTargetsMatchServiceRequestOrigins() {
        assertEquals(
            ServiceRequestsBackTarget.VEHICLES,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.GLOBAL,
                destination = ServiceRequestsDestination.LIST,
                detailsOrigin = ServiceRequestDetailsOrigin.LIST,
                formOrigin = ServiceRequestFormOrigin.LIST,
            ),
        )
        assertEquals(
            ServiceRequestsBackTarget.VEHICLE_DETAILS,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.VEHICLE,
                destination = ServiceRequestsDestination.LIST,
                detailsOrigin = ServiceRequestDetailsOrigin.LIST,
                formOrigin = ServiceRequestFormOrigin.LIST,
            ),
        )
        assertEquals(
            ServiceRequestsBackTarget.REQUESTS_LIST,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.GLOBAL,
                destination = ServiceRequestsDestination.DETAILS,
                detailsOrigin = ServiceRequestDetailsOrigin.GLOBAL_LIST,
                formOrigin = ServiceRequestFormOrigin.LIST,
            ),
        )
        assertEquals(
            ServiceRequestsBackTarget.NOTIFICATIONS,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.VEHICLE,
                destination = ServiceRequestsDestination.DETAILS,
                detailsOrigin = ServiceRequestDetailsOrigin.NOTIFICATIONS,
                formOrigin = ServiceRequestFormOrigin.LIST,
            ),
        )
    }

    @Test
    fun systemBackTargetsMatchCreateRequestOrigins() {
        assertEquals(
            ServiceRequestsBackTarget.VEHICLE_DETAILS,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.VEHICLE,
                destination = ServiceRequestsDestination.CREATE,
                detailsOrigin = ServiceRequestDetailsOrigin.LIST,
                formOrigin = ServiceRequestFormOrigin.VEHICLE_DETAILS,
            ),
        )
        assertEquals(
            ServiceRequestsBackTarget.REQUESTS_LIST,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.VEHICLE,
                destination = ServiceRequestsDestination.CREATE,
                detailsOrigin = ServiceRequestDetailsOrigin.LIST,
                formOrigin = ServiceRequestFormOrigin.LIST,
            ),
        )
        assertEquals(
            ServiceRequestsBackTarget.REQUEST_DETAILS,
            ServiceRequestsPresentation.backTarget(
                mode = ServiceRequestsMode.VEHICLE,
                destination = ServiceRequestsDestination.CREATE,
                detailsOrigin = ServiceRequestDetailsOrigin.LIST,
                formOrigin = ServiceRequestFormOrigin.DETAILS,
            ),
        )
    }

    @Test
    fun viewModelKeepsDraftAfterFailedCreateAndClearsItAfterSuccess() {
        val viewModel = ServiceRequestsViewModel()
        viewModel.showList(
            vehicleId = "vehicle-1",
            vehicleLabel = "Toyota Corolla",
            requests = emptyList(),
        )
        viewModel.openCreate(
            draft = ServiceRequestDraft(
                title = "Cooling check",
                description = "Inspect cooling system.",
                priority = "high",
                sourceAlertId = "alert-1",
            ),
            origin = ServiceRequestFormOrigin.LIST,
        )

        viewModel.failCreate("Duplicate request")
        assertEquals(ServiceRequestsDestination.CREATE, viewModel.uiState.destination)
        assertEquals("Cooling check", viewModel.uiState.draft.title)
        assertEquals("alert-1", viewModel.uiState.draft.sourceAlertId)
        assertTrue(viewModel.uiState.isError)

        viewModel.finishCreate(listOf(serviceRequest("created", sourceAlertId = "alert-1")))
        assertEquals(ServiceRequestsDestination.LIST, viewModel.uiState.destination)
        assertEquals("", viewModel.uiState.draft.title)
        assertEquals(1, viewModel.uiState.requests.size)
        assertFalse(viewModel.uiState.isError)
    }

    @Test
    fun viewModelCancelConfirmationUpdatesReturnedRequestLocally() {
        val viewModel = ServiceRequestsViewModel()
        viewModel.showList(
            vehicleId = "vehicle-1",
            vehicleLabel = "Toyota Corolla",
            requests = listOf(serviceRequest("request-1", status = "pending")),
        )

        viewModel.requestCancel("request-1")
        assertEquals("request-1", viewModel.uiState.pendingCancelRequestId)

        assertTrue(viewModel.startCancel("request-1"))
        viewModel.finishCancel(serviceRequest("request-1", status = "cancelled"))

        assertEquals("cancelled", viewModel.uiState.requests.single().status)
        assertNull(viewModel.uiState.cancellingRequestId)
        assertEquals("Service request cancelled.", viewModel.uiState.message)
    }

    private fun serviceRequest(
        id: String,
        status: String = "pending",
        priority: String = "normal",
        sourceAlertId: String? = null,
        createdAt: String = "2026-06-18T08:00:00Z",
        updatedAt: String = "2026-06-18T09:00:00Z",
        vehicleId: String = "vehicle-1",
    ): ServiceRequest {
        return ServiceRequest(
            id = id,
            vehicleId = vehicleId,
            ownerId = "owner-1",
            sourceAlertId = sourceAlertId,
            assignedSpecialistId = if (status == "pending") null else "specialist-1",
            assignedBy = if (status == "pending") null else "admin-1",
            title = "Cooling inspection",
            description = "Inspect cooling system.",
            priority = priority,
            status = status,
            resultSummary = if (status == "completed") "Cooling system repaired." else null,
            createdAt = createdAt,
            updatedAt = updatedAt,
            assignedAt = if (status == "assigned" || status == "in_progress" || status == "completed") {
                "2026-06-18T09:10:00Z"
            } else {
                null
            },
            startedAt = if (status == "in_progress" || status == "completed") "2026-06-18T09:20:00Z" else null,
            completedAt = if (status == "completed") "2026-06-18T10:00:00Z" else null,
            cancelledAt = if (status == "cancelled") "2026-06-18T10:00:00Z" else null,
        )
    }
}
