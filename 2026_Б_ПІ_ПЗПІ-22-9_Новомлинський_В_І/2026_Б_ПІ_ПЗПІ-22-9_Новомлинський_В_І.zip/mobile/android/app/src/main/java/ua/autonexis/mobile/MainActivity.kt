package ua.autonexis.mobile

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ua.autonexis.mobile.ui.account.AccountRoot
import ua.autonexis.mobile.ui.account.AccountViewModel
import ua.autonexis.mobile.ui.auth.AuthRoot
import ua.autonexis.mobile.ui.auth.AuthViewModel
import ua.autonexis.mobile.ui.auth.isStrongPassword
import ua.autonexis.mobile.ui.auth.looksLikeEmail
import ua.autonexis.mobile.ui.maintenance.MaintenanceHistoryRoot
import ua.autonexis.mobile.ui.maintenance.MaintenanceHistoryViewModel
import ua.autonexis.mobile.ui.notification.NotificationsRoot
import ua.autonexis.mobile.ui.notification.NotificationsViewModel
import ua.autonexis.mobile.ui.owner.OwnerRoot
import ua.autonexis.mobile.ui.owner.OwnerViewModel
import ua.autonexis.mobile.ui.service.ServiceRequestDetailsOrigin
import ua.autonexis.mobile.ui.service.ServiceRequestFormOrigin
import ua.autonexis.mobile.ui.service.ServiceRequestsMode
import ua.autonexis.mobile.ui.service.ServiceRequestsPresentation
import ua.autonexis.mobile.ui.service.ServiceRequestsRoot
import ua.autonexis.mobile.ui.service.ServiceRequestsViewModel
import ua.autonexis.mobile.ui.telemetry.RecentTelemetryRoot
import ua.autonexis.mobile.ui.telemetry.RecentTelemetryViewModel
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsData
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsRoot
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsViewModel
import ua.autonexis.mobile.ui.theme.AutonexisTheme
import java.util.concurrent.Executors

private const val CAMERA_PERMISSION_REQUEST_CODE = 5401


class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val activityJob = SupervisorJob()
    private val activityScope = CoroutineScope(Dispatchers.Main + activityJob)

    private lateinit var sessionStore: SessionStore
    private lateinit var apiClient: ApiClient
    private lateinit var googleSignInManager: GoogleSignInManager
    private lateinit var appearanceController: AppearanceController
    private lateinit var languageController: LanguageController
    private lateinit var languageStore: LanguageStore

    private var currentUser: User? = null
    private var vehicles: List<Vehicle> = emptyList()
    private var notificationUnreadCount: Int = 0
    private var pendingActivationCode: String = ""
    private var isScannerLaunching: Boolean = false
    private val authViewModel = AuthViewModel()
    private val ownerViewModel = OwnerViewModel()
    private val vehicleDetailsViewModel = VehicleDetailsViewModel()
    private val serviceRequestsViewModel = ServiceRequestsViewModel()
    private val notificationsViewModel = NotificationsViewModel()
    private val recentTelemetryViewModel = RecentTelemetryViewModel()
    private val maintenanceHistoryViewModel = MaintenanceHistoryViewModel()
    private val accountViewModel = AccountViewModel()
    private var appearanceMode by mutableStateOf(AppearanceMode.SYSTEM)
    private var languageMode by mutableStateOf(LanguageMode.SYSTEM)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        languageStore = LanguageStore(SharedPreferencesLanguagePreferenceStorage(this))
        androidx.appcompat.app.AppCompatDelegate.setApplicationLocales(LanguageStore.localeListFor(languageStore.mode))
        sessionStore = SessionStore(this)
        apiClient = ApiClient(sessionStore.baseUrl)
        googleSignInManager = GoogleSignInManager(this)
        appearanceController = AppearanceController(
            AppearanceStore(SharedPreferencesAppearancePreferenceStorage(this)),
        )
        appearanceMode = appearanceController.mode
        languageController = LanguageController(languageStore)
        languageMode = languageController.mode

        val token = sessionStore.token
        if (token.isNullOrBlank()) {
            showLoginScreen()
        } else {
            loadOwnerDashboard(token, useComposeLoading = true)
        }
    }

    override fun onDestroy() {
        activityScope.cancel()
        executor.shutdown()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            isScannerLaunching = false
            if (result.contents.isNullOrBlank()) {
                showConnectVehicleScreen(getString(R.string.qr_scan_cancelled), pendingActivationCode, true)
                return
            }

            when (val parsed = ActivationCodeParser.parseScannedValue(result.contents)) {
                is ParseResult.Success -> {
                    pendingActivationCode = parsed.activationCode
                    showConnectVehicleScreen(
                        getString(R.string.qr_review_code),
                        parsed.activationCode,
                    )
                }
                is ParseResult.Invalid -> {
                    showConnectVehicleScreen(getString(parsed.messageRes), pendingActivationCode, true)
                }
            }
            return
        }

        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != CAMERA_PERMISSION_REQUEST_CODE) {
            return
        }

        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            launchActivationQrScanner()
        } else {
            isScannerLaunching = false
            showConnectVehicleScreen(getString(R.string.qr_camera_permission_required), pendingActivationCode, true)
        }
    }

    private fun showLoginScreen(message: String? = null, baseUrl: String = sessionStore.baseUrl) {
        authViewModel.showLogin(message = message, baseUrl = baseUrl)
        showAuthContent()
    }

    private fun showRegisterScreen(baseUrl: String = sessionStore.baseUrl, message: String? = null) {
        authViewModel.showRegister(baseUrl = baseUrl, message = message)
        showAuthContent()
    }

    private fun showSessionRestorationScreen(message: String? = null) {
        authViewModel.showLoading(message ?: getString(R.string.restore_session))
        showAuthContent()
    }

    private fun showAuthContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                AuthRoot(
                    state = authViewModel.uiState,
                    googleConfigured = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim().isNotBlank(),
                    onLogin = ::handlePasswordLogin,
                    onGoogleSignIn = ::handleGoogleSignIn,
                    onShowRegister = { baseUrl ->
                        showRegisterScreen(baseUrl.ifBlank { sessionStore.baseUrl })
                    },
                    onRegister = ::handleRegistration,
                    onShowLogin = { baseUrl ->
                        showLoginScreen(baseUrl = baseUrl.ifBlank { sessionStore.baseUrl })
                    },
                    onDismissStatusMessage = authViewModel::clearStatusMessage,
                    onLogout = ::logOutToLogin,
                )
            }
        }
    }


    private fun localizedLoginValidationError(
        baseUrl: String,
        email: String,
        password: String,
    ): String? {
        return when {
            baseUrl.isBlank() || email.isBlank() || password.isBlank() -> getString(R.string.auth_error_login_required)
            !looksLikeEmail(email) -> getString(R.string.auth_error_email_invalid)
            else -> null
        }
    }

    private fun localizedRegistrationValidationError(
        baseUrl: String,
        fullName: String,
        email: String,
        password: String,
        confirmPassword: String,
    ): String? {
        return when {
            baseUrl.isBlank() || fullName.isBlank() || email.isBlank() || password.isBlank() || confirmPassword.isBlank() -> getString(R.string.auth_error_register_required)
            !looksLikeEmail(email) -> getString(R.string.auth_error_email_invalid)
            !isStrongPassword(password) -> getString(R.string.auth_error_password_weak)
            password != confirmPassword -> getString(R.string.auth_error_password_mismatch)
            else -> null
        }
    }

    private fun handlePasswordLogin(baseUrl: String, email: String, password: String) {
        val validationError = localizedLoginValidationError(baseUrl, email, password)
        if (validationError != null) {
            authViewModel.showError(validationError)
            return
        }
        if (!authViewModel.tryStartAuthentication(getString(R.string.auth_logging_in))) {
            return
        }

        activityScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    apiClient.baseUrl = baseUrl
                    apiClient.login(email, password)
                }
                handleAuthenticationSuccess(baseUrl, result)
            } catch (error: Exception) {
                authViewModel.showError(error.userMessage())
            }
        }
    }

    private fun handleRegistration(
        baseUrl: String,
        fullName: String,
        email: String,
        password: String,
        confirmPassword: String,
    ) {
        val validationError = localizedRegistrationValidationError(
            baseUrl,
            fullName,
            email,
            password,
            confirmPassword,
        )
        if (validationError != null) {
            authViewModel.showError(validationError)
            return
        }
        if (!authViewModel.tryStartAuthentication(getString(R.string.auth_creating_account))) {
            return
        }

        activityScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    apiClient.baseUrl = baseUrl
                    apiClient.register(fullName, email, password)
                }
                handleAuthenticationSuccess(baseUrl, result)
            } catch (error: Exception) {
                authViewModel.showError(error.userMessage())
            }
        }
    }

    private fun handleGoogleSignIn(baseUrl: String) {
        if (baseUrl.isBlank()) {
            authViewModel.showError(getString(R.string.auth_backend_url_required))
            return
        }
        if (!authViewModel.tryStartAuthentication(getString(R.string.auth_opening_google))) {
            return
        }

        activityScope.launch {
            var idToken: String? = null
            try {
                idToken = googleSignInManager.signIn(
                    this@MainActivity,
                    BuildConfig.GOOGLE_WEB_CLIENT_ID,
                )
                authViewModel.showStatus(getString(R.string.auth_signing_in_google))
                val result = withContext(Dispatchers.IO) {
                    apiClient.baseUrl = baseUrl
                    apiClient.googleLogin(idToken.orEmpty())
                }
                handleAuthenticationSuccess(baseUrl, result)
            } catch (error: Exception) {
                authViewModel.showError(error.userMessage())
            } finally {
                idToken = null
            }
        }
    }

    private fun handleAuthenticationSuccess(baseUrl: String, result: AuthResult) {
        val success = authenticationSuccess(baseUrl, result)
        sessionStore.baseUrl = success.baseUrl
        sessionStore.token = success.accessToken
        currentUser = success.user
        authViewModel.finishAuthentication()
        if (!success.opensOwnerDashboard) {
            showUnsupportedRoleScreen(success.user)
        } else {
            loadOwnerDashboard(success.accessToken)
        }
    }


    private fun handleExpiredAutonexisSession() {
        sessionStore.clearToken()
        currentUser = null
        vehicles = emptyList()
        notificationUnreadCount = 0
        pendingActivationCode = ""
        ownerViewModel.clearAuthenticatedState()
        showLoginScreen(getString(R.string.session_expired_message))
    }

    private fun handleAuthenticatedRequestError(error: Exception, onTransientError: (Exception) -> Unit) {
        if (SessionRecoveryPolicy.isExpiredSession(error)) {
            handleExpiredAutonexisSession()
        } else {
            onTransientError(error)
        }
    }
    private fun logOutToLogin() {
        sessionStore.clearToken()
        activityScope.launch {
            try {
                googleSignInManager.clearCredentialState()
            } catch (_: Exception) {
                // Local logout should always return the user to the login screen.
            }
            showLoginScreen()
        }
    }

    private fun loadOwnerDashboard(token: String, useComposeLoading: Boolean = false) {
        ownerViewModel.showInitialLoading(
            if (useComposeLoading) getString(R.string.restore_session) else getString(R.string.loading_owner_dashboard),
        )
        showOwnerContent()
        runAsync(
            task = {
                val user = apiClient.currentUser(token)
                val ownerVehicles = apiClient.listOwnerVehicles(token)
                Pair(user, ownerVehicles)
            },
            onSuccess = { result ->
                val user = result.first
                currentUser = user
                if (user.role != "vehicle_owner") {
                    showUnsupportedRoleScreen(user)
                    return@runAsync
                }

                vehicles = result.second
                if (languageStore.restoreAccountAfterLanguageChange) {
                    languageStore.restoreAccountAfterLanguageChange = false
                    showAccountCenter()
                } else {
                    showVehiclesScreen(user, vehicles)
                }
                syncNotificationUnreadCountBestEffort(token)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    ownerViewModel.failRefresh(transientError.userMessage())
                }
            },
        )
    }


    private fun syncNotificationUnreadCountBestEffort(token: String) {
        runAsync(
            task = { apiClient.listNotifications(token).count { notification -> !notification.isRead } },
            onSuccess = { count ->
                notificationUnreadCount = count
                ownerViewModel.updateNotificationUnreadCount(count)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) {
                    // Notification count is best-effort and must not block owner dashboard entry.
                }
            },
        )
    }
    private fun showUnsupportedRoleScreen(user: User) {
        authViewModel.showUnsupportedRole(user)
        showAuthContent()
    }

    private fun showVehiclesScreen(user: User, ownerVehicles: List<Vehicle>) {
        ownerViewModel.showVehicles(
            user = user,
            vehicles = ownerVehicles,
            notificationUnreadCount = notificationUnreadCount,
        )
        showOwnerContent()
    }

    private fun showConnectVehicleScreen(
        message: String? = null,
        activationCode: String = pendingActivationCode,
        isError: Boolean = false,
    ) {
        pendingActivationCode = activationCode
        ownerViewModel.showConnectVehicle(message, activationCode, isError)
        showOwnerContent()
    }

    private fun showOwnerContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                OwnerRoot(
                    state = ownerViewModel.uiState,
                    onRefresh = ::refreshOwnerVehicles,
                    onVehicleSelected = ::showVehicleDetails,
                    onConnectVehicle = { showConnectVehicleScreen() },
                    onRequests = { showGlobalServiceRequests() },
                    onNotifications = { showNotifications() },
                    onAccount = { showAccountCenter() },
                    onLogout = ::logOutToLogin,
                    onBackToVehicles = {
                        currentUser?.let { showVehiclesScreen(it, vehicles) } ?: showLoginScreen()
                    },
                    onActivationCodeChange = { value ->
                        ownerViewModel.updateActivationCode(value)
                        pendingActivationCode = ownerViewModel.uiState.activationCode
                    },
                    onScanQr = {
                        pendingActivationCode = ownerViewModel.uiState.activationCode
                        startActivationQrScan()
                    },
                    onClaimVehicle = ::claimVehicleActivationFromOwnerScreen,
                )
            }
        }
    }

    private fun refreshOwnerVehicles() {
        val token = sessionStore.token ?: return showLoginScreen()
        if (!ownerViewModel.startRefresh()) {
            return
        }
        runAsync(
            task = {
                val user = apiClient.currentUser(token)
                val ownerVehicles = apiClient.listOwnerVehicles(token)
                Pair(user, ownerVehicles)
            },
            onSuccess = { result ->
                val user = result.first
                currentUser = user
                if (user.role != "vehicle_owner") {
                    showUnsupportedRoleScreen(user)
                    return@runAsync
                }
                vehicles = result.second
                ownerViewModel.finishRefresh(user, vehicles)
                syncNotificationUnreadCountBestEffort(token)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    ownerViewModel.failRefresh(transientError.userMessage())
                }
            },
        )
    }

    private fun claimVehicleActivationFromOwnerScreen() {
        val normalizedCode = ActivationCodeParser.normalizeManualCode(ownerViewModel.uiState.activationCode)
        if (normalizedCode == null) {
            ownerViewModel.failConnect(getString(R.string.activation_code_invalid))
            return
        }
        val token = sessionStore.token ?: return showLoginScreen()
        if (!ownerViewModel.startConnect()) {
            return
        }
        pendingActivationCode = normalizedCode
        runAsync(
            task = {
                apiClient.claimVehicleActivation(token, normalizedCode)
                val user = currentUser ?: apiClient.currentUser(token)
                val ownerVehicles = apiClient.listOwnerVehicles(token)
                Pair(user, ownerVehicles)
            },
            onSuccess = { result ->
                pendingActivationCode = ""
                currentUser = result.first
                vehicles = result.second
                ownerViewModel.finishConnect(result.first, result.second)
                syncNotificationUnreadCountBestEffort(token)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    ownerViewModel.failConnect(transientError.userMessage())
                }
            },
        )
    }

    private fun startActivationQrScan() {
        if (isScannerLaunching) {
            return
        }

        isScannerLaunching = true
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchActivationQrScanner()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE,
            )
        }
    }

    private fun launchActivationQrScanner() {
        try {
            IntentIntegrator(this).apply {
                setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                setPrompt(getString(R.string.qr_scan_prompt))
                setBeepEnabled(false)
                setOrientationLocked(false)
                initiateScan()
            }
        } catch (_: Exception) {
            isScannerLaunching = false
            showConnectVehicleScreen(getString(R.string.qr_scanner_start_failed), pendingActivationCode, true)
        }
    }

    private fun showAccountCenter(successMessage: String? = null) {
        val token = sessionStore.token ?: return showLoginScreen()
        accountViewModel.showInitialLoading(currentUser, googleConfigured = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim().isNotBlank())
        showAccountContent()

        runAsync(
            task = { apiClient.getAuthMethods(token) },
            onSuccess = { methods ->
                accountViewModel.showAccount(
                    user = currentUser,
                    methods = methods,
                    googleConfigured = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim().isNotBlank(),
                    message = successMessage,
                )
                showAccountContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    accountViewModel.failInitialLoad(
                        user = currentUser,
                        googleConfigured = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim().isNotBlank(),
                        message = transientError.userMessage(),
                    )
                    showAccountContent()
                }
            },
        )
    }

    private fun showAccountContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                AccountRoot(
                    state = accountViewModel.uiState,
                    appearanceMode = appearanceMode,
                    languageMode = languageMode,
                    notificationUnreadCount = notificationUnreadCount,
                    onVehicles = {
                        currentUser?.let { showVehiclesScreen(it, vehicles) } ?: showLoginScreen()
                    },
                    onRequests = { showGlobalServiceRequests() },
                    onNotifications = { showNotifications() },
                    onRefresh = ::refreshAccountCenter,
                    onRetry = { showAccountCenter() },
                    onConnectGoogle = ::linkGoogleAccount,
                    onAppearanceModeSelected = ::selectAppearanceMode,
                    onLanguageModeSelected = ::selectLanguageMode,
                    onLogout = ::logOutToLogin,
                )
            }
        }
    }

    private fun refreshAccountCenter() {
        val token = sessionStore.token ?: return showLoginScreen()
        if (!accountViewModel.startRefresh()) {
            return
        }
        showAccountContent()

        runAsync(
            task = { apiClient.getAuthMethods(token) },
            onSuccess = { methods ->
                accountViewModel.finishRefresh(methods)
                showAccountContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    accountViewModel.failRefresh(transientError.userMessage())
                    showAccountContent()
                }
            },
        )
    }

    private fun linkGoogleAccount() {
        val token = sessionStore.token ?: return showLoginScreen()
        if (!accountViewModel.startGoogleLink()) {
            return
        }
        showAccountContent()

        activityScope.launch {
            var idToken: String? = null
            try {
                idToken = googleSignInManager.signIn(
                    this@MainActivity,
                    BuildConfig.GOOGLE_WEB_CLIENT_ID,
                )
                val methods = withContext(Dispatchers.IO) {
                    apiClient.linkGoogleAccount(token, idToken.orEmpty())
                }
                accountViewModel.finishGoogleLink(methods)
                showAccountContent()
            } catch (error: Exception) {
                if (SessionRecoveryPolicy.isExpiredSession(error)) {
                    handleExpiredAutonexisSession()
                } else {
                    accountViewModel.failGoogleLink(error.userMessage())
                    showAccountContent()
                }
            } finally {
                idToken = null
            }
        }
    }
    private fun selectAppearanceMode(mode: AppearanceMode) {
        appearanceController.select(mode)
        appearanceMode = appearanceController.mode
        languageController = LanguageController(languageStore)
        languageMode = languageController.mode
    }

    private fun selectLanguageMode(mode: LanguageMode) {
        if (mode == languageMode) {
            return
        }
        languageStore.restoreAccountAfterLanguageChange = true
        languageController.select(mode)
        languageMode = languageController.mode
        showAccountContent()
    }
    private fun showNotifications(successMessage: String? = null) {
        val token = sessionStore.token ?: return showLoginScreen()
        notificationsViewModel.showInitialLoading()
        showNotificationsContent()

        runAsync(
            task = { apiClient.listNotifications(token) },
            onSuccess = { items ->
                showNotificationsScreen(items, successMessage)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    notificationsViewModel.failInitialLoad(transientError.userMessage())
                    showNotificationsContent()
                }
            },
        )
    }

    private fun showNotificationsScreen(
        items: List<OwnerNotification>,
        successMessage: String? = null,
    ) {
        notificationsViewModel.showNotifications(items, successMessage)
        updateNotificationUnreadCountFromState()
        showNotificationsContent()
    }

    private fun showNotificationsContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                NotificationsRoot(
                    state = notificationsViewModel.uiState,
                    onBackToVehicles = {
                        currentUser?.let { showVehiclesScreen(it, vehicles) } ?: showLoginScreen()
                    },
                    onRequests = { showGlobalServiceRequests() },
                    onRefresh = ::refreshNotifications,
                    onAccount = { showAccountCenter() },
                    onRetry = { showNotifications() },
                    onToggleUnreadOnly = {
                        notificationsViewModel.toggleUnreadOnly()
                        showNotificationsContent()
                    },
                    onMarkRead = ::markNotificationRead,
                    onViewServiceRequest = ::showNotificationServiceRequest,
                )
            }
        }
    }

    private fun refreshNotifications() {
        val token = sessionStore.token ?: return showLoginScreen()
        if (!notificationsViewModel.startRefresh()) {
            return
        }
        showNotificationsContent()

        runAsync(
            task = { apiClient.listNotifications(token) },
            onSuccess = { items ->
                notificationsViewModel.finishRefresh(items)
                updateNotificationUnreadCountFromState()
                showNotificationsContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    notificationsViewModel.failRefresh(transientError.userMessage())
                    updateNotificationUnreadCountFromState()
                    showNotificationsContent()
                }
            },
        )
    }

    private fun markNotificationRead(notificationId: String) {
        val token = sessionStore.token ?: return showLoginScreen()
        if (!notificationsViewModel.startMarkRead(notificationId)) {
            return
        }
        showNotificationsContent()

        runAsync(
            task = { apiClient.markNotificationRead(token, notificationId) },
            onSuccess = { notification ->
                notificationsViewModel.finishMarkRead(notification)
                updateNotificationUnreadCountFromState()
                showNotificationsContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    notificationsViewModel.failMarkRead(notificationId, transientError.userMessage())
                    updateNotificationUnreadCountFromState()
                    showNotificationsContent()
                }
            },
        )
    }

    private fun showNotificationServiceRequest(requestId: String) {
        val token = sessionStore.token ?: return showLoginScreen()
        if (requestId.isBlank()) {
            notificationsViewModel.failRefresh(getString(R.string.referenced_service_request_missing))
            showNotificationsContent()
            return
        }
        if (!notificationsViewModel.startRefresh()) {
            return
        }
        showNotificationsContent()

        runAsync(
            task = {
                val requests = apiClient.listServiceRequests(token)
                val request = requests.firstOrNull { item -> item.id == requestId }
                Pair(request, requests)
            },
            onSuccess = { result ->
                val request = result.first
                if (request == null) {
                    notificationsViewModel.failRefresh(getString(R.string.referenced_service_request_missing))
                    showNotificationsContent()
                    return@runAsync
                }

                notificationsViewModel.finishRefresh(notificationsViewModel.uiState.items)
                serviceRequestsViewModel.showList(
                    vehicleId = request.vehicleId,
                    vehicleLabel = vehicleLabelFor(request.vehicleId),
                    requests = result.second.filter { item -> item.vehicleId == request.vehicleId },
                )
                serviceRequestsViewModel.openDetails(request.id, ServiceRequestDetailsOrigin.NOTIFICATIONS)
                showServiceRequestsContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    notificationsViewModel.failRefresh(transientError.userMessage())
                    showNotificationsContent()
                }
            },
        )
    }

    private fun updateNotificationUnreadCountFromState() {
        notificationUnreadCount = notificationsViewModel.uiState.unreadCount
        ownerViewModel.updateNotificationUnreadCount(notificationUnreadCount)
    }
    private fun showVehicleDetails(vehicleId: String) {
        val token = sessionStore.token ?: return showLoginScreen()
        vehicleDetailsViewModel.showInitialLoading(vehicleId)
        showVehicleDetailsContent()

        runAsync(
            task = { loadVehicleDetailsData(token, vehicleId) },
            onSuccess = { result ->
                showVehicleStatusScreen(
                    result.status,
                    result.thresholds,
                    result.alerts,
                    result.serviceRequests,
                )
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    vehicleDetailsViewModel.failInitialLoad(vehicleId, transientError.userMessage())
                }
            },
        )
    }

    private fun refreshVehicleDetails() {
        val vehicleId = vehicleDetailsViewModel.uiState.vehicleId
        if (vehicleId.isBlank()) {
            return
        }
        val token = sessionStore.token ?: return showLoginScreen()
        if (vehicleDetailsViewModel.uiState.data == null) {
            showVehicleDetails(vehicleId)
            return
        }
        if (!vehicleDetailsViewModel.startRefresh()) {
            return
        }

        runAsync(
            task = { loadVehicleDetailsData(token, vehicleId) },
            onSuccess = { result ->
                showVehicleStatusScreen(
                    result.status,
                    result.thresholds,
                    result.alerts,
                    result.serviceRequests,
                )
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    vehicleDetailsViewModel.failRefresh(transientError.userMessage())
                }
            },
        )
    }

    private fun loadVehicleDetailsData(token: String, vehicleId: String): VehicleDetailsData {
        val status = apiClient.getVehicleStatus(token, vehicleId)
        val thresholds = apiClient.listVehicleThresholds(token, vehicleId)
        val alerts = apiClient.listVehicleAlerts(token, vehicleId, 50)
        val serviceRequests = apiClient.listServiceRequests(token)
            .filter { request -> request.vehicleId == vehicleId }
        return VehicleDetailsData(status, thresholds, alerts, serviceRequests)
    }

    private fun showVehicleDetailsContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                VehicleDetailsRoot(
                    state = vehicleDetailsViewModel.uiState,
                    notificationUnreadCount = notificationUnreadCount,
                    onBackToVehicles = {
                        currentUser?.let { showVehiclesScreen(it, vehicles) } ?: showLoginScreen()
                    },
                    onRefresh = ::refreshVehicleDetails,
                    onRequests = { showGlobalServiceRequests() },
                    onNotifications = { showNotifications() },
                    onAccount = { showAccountCenter() },
                    onRecentTelemetry = ::showTelemetryHistory,
                    onMaintenanceHistory = ::showMaintenanceHistory,
                    onServiceRequests = { vehicleId -> showServiceRequests(vehicleId) },
                    onCreateManualServiceRequest = { vehicleId, draft -> showServiceRequestForm(vehicleId, draft) },
                    onCreateServiceRequestForAlert = { vehicleId, draft -> showServiceRequestForm(vehicleId, draft) },
                    onShowResolvedHistory = {
                        vehicleDetailsViewModel.showResolvedHistory()
                        showVehicleDetailsContent()
                    },
                    onBackToOverview = {
                        vehicleDetailsViewModel.showOverview()
                        showVehicleDetailsContent()
                    },
                )
            }
        }
    }
    private fun showTelemetryHistory(vehicleId: String) {
        val token = sessionStore.token ?: return showLoginScreen()
        val label = vehicleLabelFor(vehicleId)
        recentTelemetryViewModel.showInitialLoading(vehicleId, label)
        showTelemetryHistoryContent()

        runAsync(
            task = { apiClient.listVehicleTelemetry(token, vehicleId) },
            onSuccess = { records ->
                showTelemetryHistoryScreen(vehicleId, records)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    recentTelemetryViewModel.failInitialLoad(vehicleId, label, transientError.userMessage())
                    showTelemetryHistoryContent()
                }
            },
        )
    }

    private fun showTelemetryHistoryScreen(vehicleId: String, records: List<TelemetryRecord>) {
        recentTelemetryViewModel.showTelemetry(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabelFor(vehicleId),
            records = records,
        )
        showTelemetryHistoryContent()
    }

    private fun showTelemetryHistoryContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                RecentTelemetryRoot(
                    state = recentTelemetryViewModel.uiState,
                    notificationUnreadCount = notificationUnreadCount,
                    onBackToVehicleDetails = { showVehicleDetails(recentTelemetryViewModel.uiState.vehicleId) },
                    onRefresh = ::refreshTelemetryHistory,
                    onRetry = { showTelemetryHistory(recentTelemetryViewModel.uiState.vehicleId) },
                    onMetricSelected = { metricKey ->
                        recentTelemetryViewModel.selectMetric(metricKey)
                        showTelemetryHistoryContent()
                    },
                    onToggleHistoryExpanded = {
                        recentTelemetryViewModel.toggleHistoryExpanded()
                        showTelemetryHistoryContent()
                    },
                    onRequests = { showGlobalServiceRequests() },
                    onNotifications = { showNotifications() },
                    onAccount = { showAccountCenter() },
                )
            }
        }
    }

    private fun refreshTelemetryHistory() {
        val vehicleId = recentTelemetryViewModel.uiState.vehicleId
        if (vehicleId.isBlank()) {
            return
        }
        val token = sessionStore.token ?: return showLoginScreen()
        if (!recentTelemetryViewModel.startRefresh()) {
            return
        }
        showTelemetryHistoryContent()

        runAsync(
            task = { apiClient.listVehicleTelemetry(token, vehicleId) },
            onSuccess = { records ->
                recentTelemetryViewModel.finishRefresh(records)
                showTelemetryHistoryContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    recentTelemetryViewModel.failRefresh(transientError.userMessage())
                    showTelemetryHistoryContent()
                }
            },
        )
    }

    private fun showMaintenanceHistory(vehicleId: String) {
        val token = sessionStore.token ?: return showLoginScreen()
        val label = vehicleLabelFor(vehicleId)
        maintenanceHistoryViewModel.showInitialLoading(vehicleId, label)
        showMaintenanceHistoryContent()

        runAsync(
            task = { apiClient.listMaintenanceRecords(token, vehicleId) },
            onSuccess = { records ->
                showMaintenanceHistoryScreen(vehicleId, records)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    maintenanceHistoryViewModel.failInitialLoad(vehicleId, label, transientError.userMessage())
                    showMaintenanceHistoryContent()
                }
            },
        )
    }

    private fun showMaintenanceHistoryScreen(vehicleId: String, records: List<MaintenanceRecord>) {
        maintenanceHistoryViewModel.showMaintenance(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabelFor(vehicleId),
            records = records,
        )
        showMaintenanceHistoryContent()
    }

    private fun showMaintenanceHistoryContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                MaintenanceHistoryRoot(
                    state = maintenanceHistoryViewModel.uiState,
                    notificationUnreadCount = notificationUnreadCount,
                    onBackToVehicleDetails = { showVehicleDetails(maintenanceHistoryViewModel.uiState.vehicleId) },
                    onRefresh = ::refreshMaintenanceHistory,
                    onRetry = { showMaintenanceHistory(maintenanceHistoryViewModel.uiState.vehicleId) },
                    onRequests = { showGlobalServiceRequests() },
                    onNotifications = { showNotifications() },
                    onAccount = { showAccountCenter() },
                )
            }
        }
    }

    private fun refreshMaintenanceHistory() {
        val vehicleId = maintenanceHistoryViewModel.uiState.vehicleId
        if (vehicleId.isBlank()) {
            return
        }
        val token = sessionStore.token ?: return showLoginScreen()
        if (!maintenanceHistoryViewModel.startRefresh()) {
            return
        }
        showMaintenanceHistoryContent()

        runAsync(
            task = { apiClient.listMaintenanceRecords(token, vehicleId) },
            onSuccess = { records ->
                maintenanceHistoryViewModel.finishRefresh(records)
                showMaintenanceHistoryContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    maintenanceHistoryViewModel.failRefresh(transientError.userMessage())
                    showMaintenanceHistoryContent()
                }
            },
        )
    }

    private fun showGlobalServiceRequests(successMessage: String? = null) {
        val token = sessionStore.token ?: return showLoginScreen()
        val labels = vehicleLabelMap()
        serviceRequestsViewModel.showInitialLoading(
            vehicleId = "",
            vehicleLabel = getString(R.string.all_vehicles),
            mode = ServiceRequestsMode.GLOBAL,
            vehicleLabels = labels,
        )
        showServiceRequestsContent()

        runAsync(
            task = { apiClient.listServiceRequests(token) },
            onSuccess = { requests ->
                showGlobalServiceRequestsScreen(requests, successMessage)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    serviceRequestsViewModel.failInitialLoad(
                        vehicleId = "",
                        vehicleLabel = getString(R.string.all_vehicles),
                        message = transientError.userMessage(),
                        mode = ServiceRequestsMode.GLOBAL,
                        vehicleLabels = labels,
                    )
                    showServiceRequestsContent()
                }
            },
        )
    }

    private fun showGlobalServiceRequestsScreen(
        requests: List<ServiceRequest>,
        successMessage: String? = null,
    ) {
        serviceRequestsViewModel.showList(
            vehicleId = "",
            vehicleLabel = getString(R.string.all_vehicles),
            requests = requests,
            mode = ServiceRequestsMode.GLOBAL,
            vehicleLabels = vehicleLabelMap(),
            message = successMessage,
        )
        showServiceRequestsContent()
    }
    private fun showServiceRequests(vehicleId: String, successMessage: String? = null) {
        val token = sessionStore.token ?: return showLoginScreen()
        val label = vehicleLabelFor(vehicleId)
        serviceRequestsViewModel.showInitialLoading(vehicleId, label)
        showServiceRequestsContent()

        runAsync(
            task = { loadServiceRequestsForVehicle(token, vehicleId) },
            onSuccess = { requests ->
                showServiceRequestsScreen(vehicleId, requests, successMessage)
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    serviceRequestsViewModel.failInitialLoad(vehicleId, label, transientError.userMessage())
                }
            },
        )
    }

    private fun showServiceRequestsScreen(
        vehicleId: String,
        requests: List<ServiceRequest>,
        successMessage: String? = null,
    ) {
        serviceRequestsViewModel.showList(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabelFor(vehicleId),
            requests = requests,
            message = successMessage,
        )
        showServiceRequestsContent()
    }

    private fun showServiceRequestForm(
        vehicleId: String,
        draft: ServiceRequestDraft,
        message: String? = null,
        isError: Boolean = false,
    ) {
        serviceRequestsViewModel.openCreate(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabelFor(vehicleId),
            draft = draft,
            origin = ServiceRequestFormOrigin.VEHICLE_DETAILS,
            message = message,
            isError = isError,
        )
        showServiceRequestsContent()
    }

    private fun showServiceRequestsContent() {
        setContent {
            AutonexisTheme(appearanceMode = appearanceMode) {
                ServiceRequestsRoot(
                    state = serviceRequestsViewModel.uiState,
                    notificationUnreadCount = notificationUnreadCount,
                    onBackToVehicleDetails = { backFromServiceRequestsToVehicleArea() },
                    onRequests = { showGlobalServiceRequests() },
                    onRefresh = ::refreshServiceRequests,
                    onNotifications = { showNotifications() },
                    onAccount = { showAccountCenter() },
                    onOpenDetails = { requestId ->
                        val origin = if (serviceRequestsViewModel.uiState.mode == ServiceRequestsMode.GLOBAL) {
                            ServiceRequestDetailsOrigin.GLOBAL_LIST
                        } else {
                            ServiceRequestDetailsOrigin.LIST
                        }
                        serviceRequestsViewModel.openDetails(requestId, origin)
                        showServiceRequestsContent()
                    },
                    onBackToList = {
                        serviceRequestsViewModel.backToList()
                        showServiceRequestsContent()
                    },
                    onBackFromDetails = ::backFromServiceRequestDetails,
                    onCreateManualRequest = {
                        serviceRequestsViewModel.openCreate(
                            draft = ServiceRequestDraft(title = "", description = "", priority = "normal"),
                            origin = ServiceRequestFormOrigin.LIST,
                        )
                        showServiceRequestsContent()
                    },
                    onTitleChange = { value ->
                        serviceRequestsViewModel.updateDraftTitle(value)
                    },
                    onDescriptionChange = { value ->
                        serviceRequestsViewModel.updateDraftDescription(value)
                    },
                    onPriorityChange = { value ->
                        serviceRequestsViewModel.updateDraftPriority(value)
                    },
                    onSubmitCreate = ::submitServiceRequestFromCompose,
                    onBackFromCreate = ::backFromServiceRequestForm,
                    onRequestCancel = { requestId ->
                        serviceRequestsViewModel.requestCancel(requestId)
                        showServiceRequestsContent()
                    },
                    onDismissCancel = {
                        serviceRequestsViewModel.dismissCancel()
                        showServiceRequestsContent()
                    },
                    onConfirmCancel = { requestId ->
                        cancelServiceRequest(requestId)
                    },
                )
            }
        }
    }

    private fun refreshServiceRequests() {
        val state = serviceRequestsViewModel.uiState
        val token = sessionStore.token ?: return showLoginScreen()
        if (state.mode == ServiceRequestsMode.VEHICLE && state.vehicleId.isBlank()) {
            return
        }
        if (!serviceRequestsViewModel.startRefresh()) {
            return
        }
        showServiceRequestsContent()

        runAsync(
            task = {
                if (state.mode == ServiceRequestsMode.GLOBAL) {
                    apiClient.listServiceRequests(token)
                } else {
                    loadServiceRequestsForVehicle(token, state.vehicleId)
                }
            },
            onSuccess = { requests ->
                serviceRequestsViewModel.finishRefresh(requests)
                showServiceRequestsContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    serviceRequestsViewModel.failRefresh(transientError.userMessage())
                    showServiceRequestsContent()
                }
            },
        )
    }

    private fun backFromServiceRequestsToVehicleArea() {
        val state = serviceRequestsViewModel.uiState
        if (state.mode == ServiceRequestsMode.GLOBAL || state.vehicleId.isBlank()) {
            currentUser?.let { showVehiclesScreen(it, vehicles) } ?: showLoginScreen()
        } else {
            showVehicleDetails(state.vehicleId)
        }
    }

    private fun localizedServiceRequestValidationError(draft: ServiceRequestDraft): String? {
        return when {
            draft.title.trim().isBlank() -> getString(R.string.request_error_title_required)
            draft.description.trim().isBlank() -> getString(R.string.request_error_description_required)
            draft.priority.trim().lowercase() !in setOf("low", "normal", "high") -> getString(R.string.request_error_priority_invalid)
            else -> null
        }
    }

    private fun submitServiceRequestFromCompose() {
        val vehicleId = serviceRequestsViewModel.uiState.vehicleId
        if (vehicleId.isBlank()) {
            serviceRequestsViewModel.failCreate(getString(R.string.select_vehicle_before_request))
            showServiceRequestsContent()
            return
        }
        val validationError = localizedServiceRequestValidationError(serviceRequestsViewModel.uiState.draft)
        if (validationError != null) {
            serviceRequestsViewModel.failCreate(validationError)
            showServiceRequestsContent()
            return
        }
        val token = sessionStore.token ?: return showLoginScreen()
        if (!serviceRequestsViewModel.startCreate()) {
            return
        }
        showServiceRequestsContent()

        val request = ServiceRequestsPresentation.sanitizedDraft(serviceRequestsViewModel.uiState.draft)
        runAsync(
            task = {
                apiClient.createServiceRequest(token, vehicleId, request)
                loadServiceRequestsForVehicle(token, vehicleId)
            },
            onSuccess = { requests ->
                serviceRequestsViewModel.finishCreate(requests)
                showServiceRequestsContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    val message = if (transientError is ApiException && transientError.statusCode == 409) {
                        val baseMessage = transientError.userMessage()
                        val suffix = getString(R.string.request_duplicate_alert_suffix)
                        if (baseMessage.contains(suffix, ignoreCase = true)) baseMessage else "$baseMessage $suffix"
                    } else {
                        transientError.userMessage()
                    }
                    serviceRequestsViewModel.failCreate(message)
                    showServiceRequestsContent()
                }
            },
        )
    }

    private fun backFromServiceRequestDetails() {
        if (serviceRequestsViewModel.uiState.detailsOrigin == ServiceRequestDetailsOrigin.NOTIFICATIONS) {
            showNotificationsContent()
            return
        }
        serviceRequestsViewModel.backToList()
        showServiceRequestsContent()
    }
    private fun backFromServiceRequestForm() {
        val vehicleId = serviceRequestsViewModel.uiState.vehicleId
        val origin = serviceRequestsViewModel.backFromCreate()
        if (origin == ServiceRequestFormOrigin.VEHICLE_DETAILS) {
            showVehicleDetails(vehicleId)
        } else {
            showServiceRequestsContent()
        }
    }

    private fun cancelServiceRequest(requestId: String) {
        val token = sessionStore.token ?: return showLoginScreen()
        if (!serviceRequestsViewModel.startCancel(requestId)) {
            return
        }
        showServiceRequestsContent()

        runAsync(
            task = { apiClient.cancelServiceRequest(token, requestId) },
            onSuccess = { request ->
                serviceRequestsViewModel.finishCancel(request)
                showServiceRequestsContent()
            },
            onError = { error ->
                handleAuthenticatedRequestError(error) { transientError ->
                    serviceRequestsViewModel.failCancel(transientError.userMessage())
                    showServiceRequestsContent()
                }
            },
        )
    }

    private fun loadServiceRequestsForVehicle(token: String, vehicleId: String): List<ServiceRequest> {
        return apiClient.listServiceRequests(token)
            .filter { request -> request.vehicleId == vehicleId }
    }

    private fun vehicleLabelFor(vehicleId: String): String {
        val vehicle = vehicleDetailsViewModel.uiState.data?.status?.vehicle?.takeIf { it.id == vehicleId }
            ?: vehicles.firstOrNull { it.id == vehicleId }
        return vehicle?.let { "${it.brand} ${it.model}".trim().ifBlank { getString(R.string.selected_vehicle) } } ?: getString(R.string.selected_vehicle)
    }

    private fun vehicleLabelMap(): Map<String, String> {
        return vehicles.associate { vehicle ->
            val label = "${vehicle.brand} ${vehicle.model}".trim().ifBlank { getString(R.string.connected_vehicle) }
            vehicle.id to label
        }
    }
    private fun showVehicleStatusScreen(
        status: VehicleStatus,
        thresholds: List<ThresholdRule>,
        alerts: List<Alert>,
        serviceRequests: List<ServiceRequest>,
    ) {
        val data = VehicleDetailsData(status, thresholds, alerts, serviceRequests)
        vehicleDetailsViewModel.showDetails(status.vehicle.id, data)
        showVehicleDetailsContent()
    }
    private fun <T> runAsync(task: () -> T, onSuccess: (T) -> Unit, onError: (Exception) -> Unit) {
        executor.execute {
            try {
                val result = task()
                mainHandler.post { onSuccess(result) }
            } catch (error: Exception) {
                mainHandler.post { onError(error) }
            }
        }
    }

    private fun Exception.userMessage(): String {
        return UserFacingErrorMapper.messageFor(this)
    }

}
