package specialistcompetency

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

var ErrSpecialistNotFound = errors.New("specialist not found")

type Repository interface {
	GetSpecialistByID(ctx context.Context, specialistID string) (auth.User, error)
	ListBySpecialist(ctx context.Context, specialistID string) ([]Competency, error)
	ListAll(ctx context.Context) ([]Competency, error)
	ReplaceForSpecialist(ctx context.Context, specialistID string, competencies []SupportedCompetency) ([]Competency, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) GetSpecialistByID(
	ctx context.Context,
	specialistID string,
) (auth.User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE users.id = $1
	`

	user, err := scanUser(r.db.QueryRowContext(ctx, query, specialistID))
	if errors.Is(err, sql.ErrNoRows) {
		return auth.User{}, ErrSpecialistNotFound
	}
	if err != nil {
		return auth.User{}, fmt.Errorf("query specialist by ID: %w", err)
	}

	return user, nil
}

func (r *PostgresRepository) ListBySpecialist(
	ctx context.Context,
	specialistID string,
) ([]Competency, error) {
	const query = `
		SELECT id, specialist_id, code, name, created_at
		FROM specialist_competencies
		WHERE specialist_id = $1
		ORDER BY code
	`

	rows, err := r.db.QueryContext(ctx, query, specialistID)
	if err != nil {
		return nil, fmt.Errorf("query specialist competencies: %w", err)
	}
	defer rows.Close()

	return scanCompetencies(rows)
}

func (r *PostgresRepository) ListAll(ctx context.Context) ([]Competency, error) {
	const query = `
		SELECT
			competencies.id,
			competencies.specialist_id,
			competencies.code,
			competencies.name,
			competencies.created_at
		FROM specialist_competencies competencies
		INNER JOIN users ON users.id = competencies.specialist_id
		INNER JOIN roles ON roles.id = users.role_id
		WHERE roles.code = $1
		  AND users.is_active = TRUE
		ORDER BY competencies.specialist_id, competencies.code
	`

	rows, err := r.db.QueryContext(ctx, query, auth.TechnicalSpecialistRoleCode)
	if err != nil {
		return nil, fmt.Errorf("query all specialist competencies: %w", err)
	}
	defer rows.Close()

	return scanCompetencies(rows)
}

func (r *PostgresRepository) ReplaceForSpecialist(
	ctx context.Context,
	specialistID string,
	competencies []SupportedCompetency,
) ([]Competency, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, fmt.Errorf("begin competency replace transaction: %w", err)
	}
	defer tx.Rollback()

	if _, err := tx.ExecContext(
		ctx,
		`DELETE FROM specialist_competencies WHERE specialist_id = $1`,
		specialistID,
	); err != nil {
		return nil, fmt.Errorf("delete specialist competencies: %w", err)
	}

	for _, competency := range competencies {
		if _, err := tx.ExecContext(
			ctx,
			`
				INSERT INTO specialist_competencies (specialist_id, code, name)
				VALUES ($1, $2, $3)
			`,
			specialistID,
			competency.Code,
			competency.Name,
		); err != nil {
			return nil, fmt.Errorf("insert specialist competency: %w", err)
		}
	}

	rows, err := tx.QueryContext(
		ctx,
		`
			SELECT id, specialist_id, code, name, created_at
			FROM specialist_competencies
			WHERE specialist_id = $1
			ORDER BY code
		`,
		specialistID,
	)
	if err != nil {
		return nil, fmt.Errorf("query replaced specialist competencies: %w", err)
	}

	items, err := scanCompetencies(rows)
	rows.Close()
	if err != nil {
		return nil, err
	}

	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit competency replace transaction: %w", err)
	}

	return items, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanUser(row scanner) (auth.User, error) {
	var user auth.User
	if err := row.Scan(
		&user.ID,
		&user.RoleID,
		&user.Role,
		&user.Email,
		&user.FullName,
		&user.IsActive,
		&user.CreatedAt,
		&user.UpdatedAt,
	); err != nil {
		return auth.User{}, err
	}

	return user, nil
}

func scanCompetencies(rows *sql.Rows) ([]Competency, error) {
	items := make([]Competency, 0)
	for rows.Next() {
		var item Competency
		if err := rows.Scan(
			&item.ID,
			&item.SpecialistID,
			&item.Code,
			&item.Name,
			&item.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan specialist competency: %w", err)
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate specialist competencies: %w", err)
	}

	return items, nil
}
