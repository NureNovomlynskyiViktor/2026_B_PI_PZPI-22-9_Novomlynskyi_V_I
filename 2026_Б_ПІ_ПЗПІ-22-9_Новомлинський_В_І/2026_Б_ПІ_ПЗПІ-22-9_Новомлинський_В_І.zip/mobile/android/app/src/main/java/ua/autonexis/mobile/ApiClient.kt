package ua.autonexis.mobile

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val statusCode: Int, message: String) : Exception(message)

class ApiClient(var baseUrl: String) {
    fun login(email: String, password: String): AuthResult {
        val body = JSONObject()
            .put("email", email)
            .put("password", password)

        val json = JSONObject(request("POST", "/api/v1/auth/login", null, body.toString()))
        return AuthResult(
            user = parseUser(json.getJSONObject("user")),
            accessToken = json.getString("access_token"),
        )
    }

    fun register(fullName: String, email: String, password: String): AuthResult {
        val body = JSONObject()
            .put("full_name", fullName)
            .put("email", email)
            .put("password", password)

        val json = JSONObject(request("POST", "/api/v1/auth/register", null, body.toString()))
        return AuthResult(
            user = parseUser(json.getJSONObject("user")),
            accessToken = json.getString("access_token"),
        )
    }

    fun googleLogin(idToken: String): AuthResult {
        val json = JSONObject(request("POST", "/api/v1/auth/google", null, googleLoginRequestBody(idToken)))
        return AuthResult(
            user = parseUser(json.getJSONObject("user")),
            accessToken = json.getString("access_token"),
        )
    }

    fun currentUser(token: String): User {
        return parseUser(JSONObject(request("GET", "/api/v1/auth/me", token)))
    }

    fun getAuthMethods(token: String): AuthMethods {
        return parseAuthMethods(JSONObject(request("GET", "/api/v1/auth/methods", token)))
    }

    fun linkGoogleAccount(token: String, idToken: String): AuthMethods {
        val payload = request("POST", "/api/v1/auth/google/link", token, googleLoginRequestBody(idToken))
        return parseAuthMethods(JSONObject(payload))
    }

    fun listOwnerVehicles(token: String): List<Vehicle> {
        return parseVehicleArray(JSONArray(request("GET", "/api/v1/me/vehicles", token)))
    }

    fun claimVehicleActivation(token: String, activationCode: String): Vehicle {
        val body = JSONObject()
            .put("activation_code", activationCode)

        val payload = request("POST", "/api/v1/me/vehicle-activations/claim", token, body.toString())
        return parseVehicle(JSONObject(payload))
    }

    fun getVehicleStatus(token: String, vehicleId: String): VehicleStatus {
        val json = JSONObject(request("GET", "/api/v1/me/vehicles/$vehicleId/status", token))
        val telemetryJson = json.optJSONObject("latest_telemetry")
        val deviceJson = json.optJSONObject("device")

        return VehicleStatus(
            vehicle = parseVehicle(json.getJSONObject("vehicle")),
            device = deviceJson?.let(::parseDevice),
            latestTelemetry = telemetryJson?.let(::parseTelemetry),
            activeAlerts = parseAlertArray(json.optJSONArray("active_alerts") ?: JSONArray()),
            overallStatus = json.optString("overall_status", "unknown"),
        )
    }

    fun listVehicleThresholds(token: String, vehicleId: String): List<ThresholdRule> {
        val payload = request("GET", "/api/v1/me/vehicles/$vehicleId/thresholds", token)
        val items = JSONArray(payload)
        return List(items.length()) { index -> parseThreshold(items.getJSONObject(index)) }
    }

    fun listVehicleTelemetry(token: String, vehicleId: String, limit: Int = 20): List<TelemetryRecord> {
        val payload = request("GET", "/api/v1/me/vehicles/$vehicleId/telemetry?limit=$limit", token)
        val items = JSONArray(payload)
        return List(items.length()) { index -> parseTelemetry(items.getJSONObject(index)) }
    }

    fun listVehicleAlerts(token: String, vehicleId: String, limit: Int = 50): List<Alert> {
        val payload = request("GET", "/api/v1/me/vehicles/$vehicleId/alerts?limit=$limit", token)
        val items = JSONArray(payload)
        return parseAlertArray(items)
    }

    fun listMaintenanceRecords(token: String, vehicleId: String): List<MaintenanceRecord> {
        val payload = request("GET", "/api/v1/me/vehicles/$vehicleId/maintenance-records", token)
        val items = JSONArray(payload)
        return List(items.length()) { index -> parseMaintenanceRecord(items.getJSONObject(index)) }
    }

    fun listServiceRequests(token: String): List<ServiceRequest> {
        val payload = request("GET", "/api/v1/me/service-requests", token)
        val items = JSONArray(payload)
        return List(items.length()) { index -> parseServiceRequest(items.getJSONObject(index)) }
    }

    fun createServiceRequest(
        token: String,
        vehicleId: String,
        draft: ServiceRequestDraft,
    ): ServiceRequest {
        val body = JSONObject()
            .put("title", draft.title)
            .put("description", draft.description)
            .put("priority", draft.priority)
        if (!draft.sourceAlertId.isNullOrBlank()) {
            body.put("source_alert_id", draft.sourceAlertId)
        }

        val payload = request(
            "POST",
            "/api/v1/me/vehicles/$vehicleId/service-requests",
            token,
            body.toString(),
        )
        return parseServiceRequest(JSONObject(payload))
    }

    fun cancelServiceRequest(token: String, requestId: String): ServiceRequest {
        val payload = request("PATCH", "/api/v1/me/service-requests/$requestId/cancel", token)
        return parseServiceRequest(JSONObject(payload))
    }

    fun listNotifications(token: String): List<OwnerNotification> {
        val payload = request("GET", "/api/v1/me/notifications", token)
        val items = JSONArray(payload)
        return List(items.length()) { index -> parseNotification(items.getJSONObject(index)) }
    }

    fun markNotificationRead(token: String, notificationId: String): OwnerNotification {
        val payload = request("PATCH", "/api/v1/me/notifications/$notificationId/read", token)
        return parseNotification(JSONObject(payload))
    }

    private fun request(method: String, path: String, token: String?, body: String? = null): String {
        val normalizedBaseUrl = baseUrl.trim().trimEnd('/')
        val connection = URL("$normalizedBaseUrl$path").openConnection() as HttpURLConnection
        connection.requestMethod = method
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        connection.setRequestProperty("Accept", "application/json")

        if (!token.isNullOrBlank()) {
            connection.setRequestProperty("Authorization", "Bearer $token")
        }

        if (body != null) {
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { stream ->
                stream.write(body.toByteArray(Charsets.UTF_8))
            }
        }

        val status = connection.responseCode
        val responseText = if (status in 200..299) {
            connection.inputStream.bufferedReader().use { it.readText() }
        } else {
            connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        }

        if (status !in 200..299) {
            throw ApiException(status, parseError(responseText, status))
        }

        return responseText
    }

    private fun parseError(responseText: String, status: Int): String {
        if (responseText.isBlank()) {
            return "Request failed with status $status"
        }

        return try {
            JSONObject(responseText).optString("error", "Request failed with status $status")
        } catch (_: Exception) {
            "Request failed with status $status"
        }
    }

    private fun parseVehicleArray(items: JSONArray): List<Vehicle> {
        return List(items.length()) { index -> parseVehicle(items.getJSONObject(index)) }
    }

    private fun parseAlertArray(items: JSONArray): List<Alert> {
        return List(items.length()) { index -> parseAlert(items.getJSONObject(index)) }
    }

    private fun parseUser(json: JSONObject): User {
        return User(
            id = json.getString("id"),
            email = json.getString("email"),
            role = json.optString("role", ""),
            fullName = json.optString("full_name", ""),
        )
    }

    private fun parseAuthMethods(json: JSONObject): AuthMethods {
        return AuthMethods(
            passwordEnabled = json.optBoolean("password_enabled", false),
            googleLinked = json.optBoolean("google_linked", false),
        )
    }

    private fun parseVehicle(json: JSONObject): Vehicle {
        return Vehicle(
            id = json.getString("id"),
            brand = json.optString("brand", ""),
            model = json.optString("model", ""),
            year = json.optionalInt("year"),
            licensePlate = json.optionalString("license_plate"),
        )
    }

    private fun parseDevice(json: JSONObject): Device {
        return Device(
            id = json.getString("id"),
            deviceUid = json.optString("device_uid", ""),
            name = json.optionalString("name"),
            status = json.optString("status", ""),
            lastSeenAt = json.optionalString("last_seen_at"),
        )
    }

    private fun parseTelemetry(json: JSONObject): TelemetryRecord {
        return TelemetryRecord(
            measuredAt = json.optString("measured_at", ""),
            engineTemperature = json.optDouble("engine_temperature", 0.0),
            batteryVoltage = json.optDouble("battery_voltage", 0.0),
            vibrationLevel = json.optDouble("vibration_level", 0.0),
            rpm = json.optInt("rpm", 0),
            speed = json.optInt("speed", 0),
            fuelLevel = json.optDouble("fuel_level", 0.0),
        )
    }

    private fun parseAlert(json: JSONObject): Alert {
        return Alert(
            id = json.getString("id"),
            type = json.optString("type", ""),
            severity = json.optString("severity", ""),
            currentSeverity = json.optionalString("current_severity"),
            status = json.optString("status", ""),
            occurrenceCount = json.optInt("occurrence_count", 1),
            recoveryStreak = json.optInt("recovery_streak", 0),
            lastTriggeredAt = json.optionalString("last_triggered_at"),
            message = json.optString("message", ""),
            recommendation = json.optionalString("recommendation"),
            createdAt = json.optString("created_at", ""),
            clearedAt = json.optionalString("cleared_at"),
            resolvedAt = json.optionalString("resolved_at"),
            resolvedByUserId = json.optionalString("resolved_by_user_id"),
            resolutionNote = json.optionalString("resolution_note"),
            resolutionServiceRequestId = json.optionalString("resolution_service_request_id"),
        )
    }

    private fun parseThreshold(json: JSONObject): ThresholdRule {
        return ThresholdRule(
            metric = json.optString("metric", json.optString("parameter", "")),
            severity = json.optString("severity", ""),
            value = json.optDouble("value", 0.0),
            unit = json.optString("unit", ""),
            description = json.optString("description", ""),
        )
    }

    private fun parseMaintenanceRecord(json: JSONObject): MaintenanceRecord {
        return MaintenanceRecord(
            id = json.getString("id"),
            title = json.optString("title", ""),
            description = json.optString("description", ""),
            serviceDate = json.optString("service_date", ""),
            createdAt = json.optString("created_at", ""),
        )
    }

    private fun parseServiceRequest(json: JSONObject): ServiceRequest {
        return ServiceRequest(
            id = json.getString("id"),
            vehicleId = json.optString("vehicle_id", ""),
            ownerId = json.optString("owner_id", ""),
            sourceAlertId = json.optionalString("source_alert_id"),
            assignedSpecialistId = json.optionalString("assigned_specialist_id"),
            assignedBy = json.optionalString("assigned_by"),
            title = json.optString("title", ""),
            description = json.optString("description", ""),
            priority = json.optString("priority", ""),
            status = json.optString("status", ""),
            resultSummary = json.optionalString("result_summary"),
            createdAt = json.optString("created_at", ""),
            updatedAt = json.optString("updated_at", ""),
            assignedAt = json.optionalString("assigned_at"),
            startedAt = json.optionalString("started_at"),
            completedAt = json.optionalString("completed_at"),
            cancelledAt = json.optionalString("cancelled_at"),
        )
    }

    private fun parseNotification(json: JSONObject): OwnerNotification {
        return OwnerNotification(
            id = json.getString("id"),
            alertId = json.optionalString("alert_id"),
            serviceRequestId = json.optionalString("service_request_id"),
            notificationType = json.optString("notification_type", "vehicle_alert"),
            title = json.optString("title", ""),
            message = json.optString("message", ""),
            isRead = json.optBoolean("is_read", false),
            createdAt = json.optString("created_at", ""),
        )
    }

    private fun JSONObject.optionalString(name: String): String? {
        return if (isNull(name)) null else optString(name)
    }

    private fun JSONObject.optionalInt(name: String): Int? {
        return if (isNull(name)) null else optInt(name)
    }
}
