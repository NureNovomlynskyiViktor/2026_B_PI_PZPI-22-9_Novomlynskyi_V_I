export type User = {
  id: string;
  role_id: string;
  role: string;
  email: string;
  full_name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  deactivated_at?: string | null;
};

export type AdminUserFilters = {
  role?: 'vehicle_owner' | 'technical_specialist' | 'administrator';
  is_active?: boolean;
  search?: string;
};

export type DeactivateUserRequest = {
  reason?: string;
};

export type CreateAdminSpecialistRequest = {
  email: string;
  password: string;
  name: string;
  competencies: string[];
};

export type CreateAdminSpecialistResponse = {
  user: User;
  competencies: SpecialistCompetency[];
};

export type AdminAuditActor = {
  id: string;
  email: string;
  full_name: string;
  role: string;
};

export type AdminAuditLog = {
  id: number;
  actor: AdminAuditActor | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
};

export type AdminAuditFilters = {
  action?: string;
  actor_id?: string;
  actor_search?: string;
  entity_type?: string;
  entity_id?: string;
  date_from?: string;
  date_to?: string;
  limit?: number;
  offset?: number;
};

export type AdminAuditPagination = {
  limit: number;
  offset: number;
  total: number;
  has_more: boolean;
};

export type AdminAuditListResponse = {
  items: AdminAuditLog[];
  pagination: AdminAuditPagination;
};

export type SpecialistAssignment = {
  id: string;
  vehicle_id: string;
  specialist_id: string;
  specialist: User;
  assigned_by: string | null;
  created_at: string;
};

export type SpecialistCompetency = {
  id: string;
  specialist_id: string;
  code: string;
  name: string;
  created_at: string;
};

export type SpecialistRecommendation = {
  specialist: User;
  competencies: SpecialistCompetency[];
  score: number;
  matched_competencies: string[];
  reasons: string[];
  active_assignment_count: number;
  already_assigned: boolean;
};

export type AuthResponse = {
  user: User;
  access_token: string;
  token_type: 'Bearer';
  expires_at: number;
};

export type Vehicle = {
  id: string;
  owner_id: string;
  vin: string | null;
  brand: string;
  model: string;
  year: number | null;
  license_plate: string | null;
  created_at: string;
  updated_at: string;
};

export type Device = {
  id: string;
  vehicle_id: string;
  device_uid: string;
  name: string | null;
  status: string;
  last_seen_at: string | null;
  created_at: string;
  updated_at: string;
};

export type TelemetryRecord = {
  id: number;
  vehicle_id: string;
  device_id: string;
  measured_at: string;
  received_at: string;
  engine_temperature: number;
  battery_voltage: number;
  vibration_level: number;
  rpm: number;
  speed: number;
  fuel_level: number;
};

export type Alert = {
  id: string;
  vehicle_id: string;
  telemetry_record_id: number | null;
  type: string;
  severity: string;
  current_severity: string | null;
  status: string;
  occurrence_count: number;
  recovery_streak: number;
  last_triggered_at: string | null;
  message: string;
  recommendation: string | null;
  created_at: string;
  cleared_at: string | null;
  resolved_at: string | null;
  resolved_by_user_id: string | null;
  resolution_note: string | null;
  resolution_service_request_id: string | null;
};

export type ThresholdRule = {
  id: string;
  vehicle_id: string;
  parameter: string;
  metric: string;
  severity: 'warning' | 'critical' | string;
  rule_type: string;
  value: number;
  unit: string;
  description: string;
  created_at: string;
  updated_at: string;
};

export type MaintenanceRecord = {
  id: string;
  vehicle_id: string;
  created_by: string | null;
  title: string;
  description: string;
  service_date: string;
  created_at: string;
};

export type ServiceRequestPriority = 'low' | 'normal' | 'high' | string;

export type ServiceRequestStatus =
  | 'pending'
  | 'assigned'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | string;

export type ServiceRequest = {
  id: string;
  vehicle_id: string;
  owner_id: string;
  source_alert_id?: string | null;
  assigned_specialist_id?: string | null;
  assigned_by?: string | null;
  title: string;
  description: string;
  priority: ServiceRequestPriority;
  status: ServiceRequestStatus;
  result_summary?: string | null;
  created_at: string;
  updated_at: string;
  assigned_at?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
  cancelled_at?: string | null;
};

export type VehicleStatus = {
  vehicle: Vehicle;
  device: Device | null;
  latest_telemetry: TelemetryRecord | null;
  active_alerts: Alert[];
  overall_status: 'unknown' | 'normal' | 'warning' | 'critical' | string;
};

export type RegisterRequest = {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
};

export type LoginRequest = {
  email: string;
  password: string;
};

export type GoogleLoginRequest = {
  id_token: string;
};

export type AuthenticationMethods = {
  password_enabled: boolean;
  google_linked: boolean;
};

export type GoogleLinkRequest = {
  id_token: string;
};

export type CreateVehicleRequest = {
  vin: string;
  brand: string;
  model: string;
  year: number;
  license_plate: string;
};

export type CreateVehicleActivationRequest = CreateVehicleRequest & {
  device_uid: string;
  device_name: string;
};

export type VehicleActivationResponse = {
  activation_code: string;
  activation_uri: string;
  expires_at: string;
  vehicle: Vehicle;
  device: Device;
};

export type CreateMaintenanceRecordRequest = {
  title: string;
  description: string;
  service_date: string;
};

export type CompleteServiceRequestRequest = {
  result_summary: string;
};

export type ResolveSpecialistAlertRequest = {
  resolution_note: string;
  service_request_id?: string | null;
};
