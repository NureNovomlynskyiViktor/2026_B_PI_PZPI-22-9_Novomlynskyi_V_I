package auth

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type serviceStub struct {
	response AuthResponse
	user     User
	register RegisterRequest
	google   GoogleLoginRequest
	link     GoogleLinkRequest
	status   AuthMethodStatus
	err      error
	token    string
}

func (s *serviceStub) Register(_ context.Context, request RegisterRequest) (AuthResponse, error) {
	s.register = request
	return s.response, s.err
}

func (s *serviceStub) Login(context.Context, LoginRequest) (AuthResponse, error) {
	return s.response, s.err
}
func (s *serviceStub) GoogleLogin(_ context.Context, request GoogleLoginRequest) (AuthResponse, error) {
	s.google = request
	return s.response, s.err
}

func (s *serviceStub) AuthMethods(context.Context, User) (AuthMethodStatus, error) {
	return s.status, s.err
}

func (s *serviceStub) LinkGoogle(_ context.Context, _ User, request GoogleLinkRequest) (AuthMethodStatus, error) {
	s.link = request
	return s.status, s.err
}

func (s *serviceStub) CurrentUser(_ context.Context, token string) (User, error) {
	s.token = token
	return s.user, s.err
}

func TestHandlerRegisterSuccess(t *testing.T) {
	service := &serviceStub{response: AuthResponse{AccessToken: "jwt"}}
	handler := NewHandler(
		service,
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/register",
		strings.NewReader(`{"full_name":"New Vehicle Owner","email":"user@example.com","password":"StrongPassword123!"}`),
	)
	recorder := httptest.NewRecorder()

	handler.Register(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if !strings.Contains(recorder.Body.String(), `"access_token":"jwt"`) {
		t.Fatalf("expected auth response, got %s", recorder.Body.String())
	}
	if service.register.FullName != "New Vehicle Owner" {
		t.Fatalf("expected full_name to be decoded, got %#v", service.register)
	}
}

func TestHandlerRegisterDuplicateEmail(t *testing.T) {
	handler := NewHandler(&serviceStub{err: ErrEmailAlreadyExists}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/register",
		strings.NewReader(`{"email":"user@example.com","password":"StrongPassword123!","first_name":"Viktor"}`),
	)
	recorder := httptest.NewRecorder()

	handler.Register(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func TestHandlerRegisterRejectsClientRole(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/register",
		strings.NewReader(`{
			"full_name":"New Vehicle Owner",
			"email":"user@example.com",
			"password":"StrongPassword123!",
			"role":"administrator"
		}`),
	)
	recorder := httptest.NewRecorder()

	handler.Register(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerLoginInvalidCredentials(t *testing.T) {
	handler := NewHandler(&serviceStub{err: ErrInvalidCredentials}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/login",
		strings.NewReader(`{"email":"user@example.com","password":"WrongPassword123!"}`),
	)
	recorder := httptest.NewRecorder()

	handler.Login(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestHandlerMe(t *testing.T) {
	service := &serviceStub{user: User{ID: testUserID, Email: "user@example.com"}}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/auth/me", nil)
	request.Header.Set("Authorization", "Bearer jwt")
	recorder := httptest.NewRecorder()

	handler.Me(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.token != "jwt" {
		t.Fatalf("expected token jwt, got %s", service.token)
	}
	if strings.Contains(recorder.Body.String(), "password_hash") {
		t.Fatal("response exposed password_hash")
	}
}

func TestHandlerMeRequiresToken(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/auth/me", nil)
	recorder := httptest.NewRecorder()

	handler.Me(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestHandlerDoesNotExposeInternalErrors(t *testing.T) {
	handler := NewHandler(&serviceStub{err: errors.New("database details")}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/login",
		strings.NewReader(`{"email":"user@example.com","password":"StrongPassword123!"}`),
	)
	recorder := httptest.NewRecorder()

	handler.Login(recorder, request)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, recorder.Code)
	}
	if strings.Contains(recorder.Body.String(), "database details") {
		t.Fatal("response exposed an internal error")
	}
}

func TestHandlerRejectsMalformedJSON(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/login",
		strings.NewReader(`{"email":`),
	)
	recorder := httptest.NewRecorder()

	handler.Login(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func TestHandlerGoogleSuccess(t *testing.T) {
	service := &serviceStub{response: AuthResponse{AccessToken: "jwt"}}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/google",
		strings.NewReader(`{"id_token":"google-id-token"}`),
	)
	recorder := httptest.NewRecorder()

	handler.Google(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.google.IDToken != "google-id-token" {
		t.Fatalf("expected id_token to be decoded, got %#v", service.google)
	}
	if !strings.Contains(recorder.Body.String(), `"access_token":"jwt"`) {
		t.Fatalf("expected auth response, got %s", recorder.Body.String())
	}
}

func TestHandlerGoogleErrorMapping(t *testing.T) {
	tests := []struct {
		name       string
		err        error
		wantStatus int
		wantBody   string
	}{
		{name: "invalid input", err: ErrInvalidInput, wantStatus: http.StatusBadRequest, wantBody: "invalid Google sign-in request"},
		{name: "invalid token", err: ErrInvalidGoogleToken, wantStatus: http.StatusUnauthorized, wantBody: "invalid Google identity token"},
		{name: "inactive", err: ErrInactiveUser, wantStatus: http.StatusForbidden, wantBody: "user account is inactive"},
		{name: "email conflict", err: ErrGoogleEmailRequiresLinking, wantStatus: http.StatusConflict, wantBody: "account with this email already exists"},
		{name: "unavailable", err: ErrGoogleAuthUnavailable, wantStatus: http.StatusServiceUnavailable, wantBody: "Google sign-in is not available"},
		{name: "verifier infrastructure failure", err: ErrGoogleVerificationUnavailable, wantStatus: http.StatusInternalServerError, wantBody: "internal server error"},
		{name: "internal", err: errors.New("google library details"), wantStatus: http.StatusInternalServerError, wantBody: "internal server error"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			handler := NewHandler(&serviceStub{err: tc.err}, testLogger())
			request := httptest.NewRequest(
				http.MethodPost,
				"/api/v1/auth/google",
				strings.NewReader(`{"id_token":"google-id-token"}`),
			)
			recorder := httptest.NewRecorder()

			handler.Google(recorder, request)

			if recorder.Code != tc.wantStatus {
				t.Fatalf("expected status %d, got %d", tc.wantStatus, recorder.Code)
			}
			if !strings.Contains(recorder.Body.String(), tc.wantBody) {
				t.Fatalf("expected response to contain %q, got %s", tc.wantBody, recorder.Body.String())
			}
			if strings.Contains(recorder.Body.String(), "google library details") {
				t.Fatal("response exposed internal verifier details")
			}
		})
	}
}

func TestHandlerGoogleRejectsMalformedJSON(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/google",
		strings.NewReader(`{"id_token":`),
	)
	recorder := httptest.NewRecorder()

	handler.Google(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerMethodsSuccess(t *testing.T) {
	service := &serviceStub{
		status: AuthMethodStatus{PasswordEnabled: true, GoogleLinked: false},
	}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/auth/methods", nil)
	request = request.WithContext(WithUser(request.Context(), User{ID: testUserID, Email: "user@example.com", IsActive: true}))
	recorder := httptest.NewRecorder()

	handler.Methods(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if !strings.Contains(recorder.Body.String(), `"password_enabled":true`) ||
		!strings.Contains(recorder.Body.String(), `"google_linked":false`) {
		t.Fatalf("unexpected status response: %s", recorder.Body.String())
	}
	if strings.Contains(recorder.Body.String(), "password_hash") || strings.Contains(recorder.Body.String(), "google-sub") {
		t.Fatalf("response exposed auth secrets: %s", recorder.Body.String())
	}
}

func TestHandlerLinkGoogleSuccess(t *testing.T) {
	service := &serviceStub{status: AuthMethodStatus{PasswordEnabled: true, GoogleLinked: true}}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/auth/google/link",
		strings.NewReader(`{"id_token":"google-id-token"}`),
	)
	request = request.WithContext(WithUser(request.Context(), User{ID: testUserID, Email: "user@example.com", IsActive: true}))
	recorder := httptest.NewRecorder()

	handler.LinkGoogle(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.link.IDToken != "google-id-token" {
		t.Fatalf("expected id token to be decoded, got %#v", service.link)
	}
	if !strings.Contains(recorder.Body.String(), `"google_linked":true`) {
		t.Fatalf("unexpected link response: %s", recorder.Body.String())
	}
}

func TestHandlerLinkGoogleErrorMapping(t *testing.T) {
	tests := []struct {
		name       string
		err        error
		wantStatus int
		wantBody   string
	}{
		{name: "invalid input", err: ErrInvalidInput, wantStatus: http.StatusBadRequest, wantBody: "invalid Google linking request"},
		{name: "invalid token", err: ErrInvalidGoogleToken, wantStatus: http.StatusUnauthorized, wantBody: "invalid Google identity token"},
		{name: "inactive", err: ErrInactiveUser, wantStatus: http.StatusForbidden, wantBody: "user account is inactive"},
		{name: "disabled", err: ErrGoogleAuthUnavailable, wantStatus: http.StatusServiceUnavailable, wantBody: "Google sign-in is not available"},
		{name: "email mismatch", err: ErrGoogleEmailMismatch, wantStatus: http.StatusConflict, wantBody: "email must match"},
		{name: "other user", err: ErrGoogleIdentityLinkedToOtherUser, wantStatus: http.StatusConflict, wantBody: "already linked to another"},
		{name: "different google", err: ErrUserLinkedToDifferentGoogle, wantStatus: http.StatusConflict, wantBody: "different Google account"},
		{name: "verifier infrastructure", err: ErrGoogleVerificationUnavailable, wantStatus: http.StatusInternalServerError, wantBody: "internal server error"},
		{name: "internal", err: errors.New("google-id-token raw details"), wantStatus: http.StatusInternalServerError, wantBody: "internal server error"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			handler := NewHandler(&serviceStub{err: tc.err}, testLogger())
			request := httptest.NewRequest(
				http.MethodPost,
				"/api/v1/auth/google/link",
				strings.NewReader(`{"id_token":"google-id-token"}`),
			)
			request = request.WithContext(WithUser(request.Context(), User{ID: testUserID, Email: "user@example.com", IsActive: true}))
			recorder := httptest.NewRecorder()

			handler.LinkGoogle(recorder, request)

			if recorder.Code != tc.wantStatus {
				t.Fatalf("expected status %d, got %d", tc.wantStatus, recorder.Code)
			}
			if !strings.Contains(recorder.Body.String(), tc.wantBody) {
				t.Fatalf("expected response to contain %q, got %s", tc.wantBody, recorder.Body.String())
			}
			if strings.Contains(recorder.Body.String(), "google-id-token") {
				t.Fatalf("response exposed raw token: %s", recorder.Body.String())
			}
		})
	}
}

func TestHandlerAuthenticatedMethodsRequireUserContext(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())

	for _, tc := range []struct {
		name   string
		method string
		path   string
		body   io.Reader
		run    func(http.ResponseWriter, *http.Request)
	}{
		{name: "methods", method: http.MethodGet, path: "/api/v1/auth/methods", run: handler.Methods},
		{name: "link", method: http.MethodPost, path: "/api/v1/auth/google/link", body: strings.NewReader(`{"id_token":"token"}`), run: handler.LinkGoogle},
	} {
		t.Run(tc.name, func(t *testing.T) {
			request := httptest.NewRequest(tc.method, tc.path, tc.body)
			recorder := httptest.NewRecorder()

			tc.run(recorder, request)

			if recorder.Code != http.StatusUnauthorized {
				t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
			}
		})
	}
}
