package ownermaintenance

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/maintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
)

type stubMaintenanceService struct {
	records       []maintenance.Record
	err           error
	called        bool
	calledVehicle string
}

func (s *stubMaintenanceService) ListByVehicle(
	_ context.Context,
	vehicleID string,
) ([]maintenance.Record, error) {
	s.called = true
	s.calledVehicle = vehicleID
	return s.records, s.err
}

type stubVehicleService struct {
	err           error
	calledOwner   string
	calledVehicle string
}

func (s *stubVehicleService) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) (vehicle.Vehicle, error) {
	s.calledOwner = ownerID
	s.calledVehicle = vehicleID
	if s.err != nil {
		return vehicle.Vehicle{}, s.err
	}
	return vehicle.Vehicle{ID: vehicleID, OwnerID: ownerID}, nil
}

func TestListByVehicleRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(
		&stubMaintenanceService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/maintenance-records",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestListByVehicleRejectsInvalidVehicleID(t *testing.T) {
	handler := NewHandler(
		&stubMaintenanceService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := requestWithUser("/api/v1/me/vehicles/not-a-uuid/maintenance-records")
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListByVehicleReturnsNotFoundForOtherUserVehicle(t *testing.T) {
	maintenanceService := &stubMaintenanceService{}
	handler := NewHandler(
		maintenanceService,
		&stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	request := requestWithUser(
		"/api/v1/me/vehicles/" + testVehicleID + "/maintenance-records",
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
	if maintenanceService.called {
		t.Fatal("expected maintenance service not to be called")
	}
}

func TestListByVehicleUsesOwnerAndReturnsRecords(t *testing.T) {
	serviceDate := time.Date(2026, 5, 20, 0, 0, 0, 0, time.UTC)
	maintenanceService := &stubMaintenanceService{
		records: []maintenance.Record{
			{
				ID:          "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
				VehicleID:   testVehicleID,
				Title:       "Oil and filter replacement",
				Description: "Changed engine oil and oil filter.",
				ServiceDate: serviceDate,
			},
		},
	}
	vehicleService := &stubVehicleService{}
	handler := NewHandler(
		maintenanceService,
		vehicleService,
		testLogger(),
	)
	request := requestWithUser(
		"/api/v1/me/vehicles/" + testVehicleID + "/maintenance-records",
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if vehicleService.calledOwner != testOwnerID {
		t.Fatalf("expected owner %q, got %q", testOwnerID, vehicleService.calledOwner)
	}
	if vehicleService.calledVehicle != testVehicleID {
		t.Fatalf("expected owner check vehicle %q, got %q", testVehicleID, vehicleService.calledVehicle)
	}
	if maintenanceService.calledVehicle != testVehicleID {
		t.Fatalf("expected maintenance vehicle %q, got %q", testVehicleID, maintenanceService.calledVehicle)
	}
}

func requestWithUser(target string) *http.Request {
	request := httptest.NewRequest(http.MethodGet, target, nil)
	ctx := auth.WithUser(
		request.Context(),
		auth.User{
			ID:    testOwnerID,
			Email: "owner@example.com",
			Role:  "vehicle_owner",
		},
	)
	return request.WithContext(ctx)
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
