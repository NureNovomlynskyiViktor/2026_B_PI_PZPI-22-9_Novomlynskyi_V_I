package telemetryingestion

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
)

type stubService struct {
	result Result
	err    error
}

func (s stubService) Ingest(context.Context, string, Input) (Result, error) {
	return s.result, s.err
}

func TestHandlerSuccess(t *testing.T) {
	handler := NewHandler(
		stubService{result: Result{
			Telemetry:      telemetry.Record{ID: 6, DeviceID: testDeviceID},
			CreatedAlerts:  nil,
			ExistingAlerts: nil,
			OverallResult:  "critical",
		}},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/devices/"+testDeviceUID+"/telemetry",
		strings.NewReader(`{
			"engine_temperature": 96.5,
			"battery_voltage": 13.6,
			"vibration_level": 2.1,
			"rpm": 2600,
			"speed": 72,
			"fuel_level": 63.5
		}`),
	)
	request.SetPathValue("device_uid", testDeviceUID)
	recorder := httptest.NewRecorder()

	handler.Ingest(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"overall_result":"critical"`) {
		t.Fatalf("expected ingestion JSON response, got %s", body)
	}
}

func TestHandlerRejectsMalformedJSON(t *testing.T) {
	handler := NewHandler(stubService{}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/devices/"+testDeviceUID+"/telemetry",
		strings.NewReader(`{"rpm":`),
	)
	request.SetPathValue("device_uid", testDeviceUID)
	recorder := httptest.NewRecorder()

	handler.Ingest(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerRejectsUnknownFields(t *testing.T) {
	handler := NewHandler(stubService{}, testLogger())
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/devices/"+testDeviceUID+"/telemetry",
		strings.NewReader(`{"unexpected":true}`),
	)
	request.SetPathValue("device_uid", testDeviceUID)
	recorder := httptest.NewRecorder()

	handler.Ingest(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerServiceErrors(t *testing.T) {
	tests := []struct {
		name       string
		err        error
		wantStatus int
	}{
		{name: "invalid UID", err: ErrInvalidDeviceUID, wantStatus: http.StatusBadRequest},
		{name: "device not found", err: ErrDeviceNotFound, wantStatus: http.StatusNotFound},
		{name: "invalid payload", err: ErrInvalidPayload, wantStatus: http.StatusBadRequest},
		{name: "internal error", err: errors.New("database details"), wantStatus: http.StatusInternalServerError},
	}

	body := `{
		"engine_temperature":96.5,
		"battery_voltage":13.6,
		"vibration_level":2.1,
		"rpm":2600,
		"speed":72,
		"fuel_level":63.5
	}`

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := NewHandler(stubService{err: tt.err}, testLogger())
			request := httptest.NewRequest(
				http.MethodPost,
				"/api/v1/devices/"+testDeviceUID+"/telemetry",
				strings.NewReader(body),
			)
			request.SetPathValue("device_uid", testDeviceUID)
			recorder := httptest.NewRecorder()

			handler.Ingest(recorder, request)

			if recorder.Code != tt.wantStatus {
				t.Fatalf("expected status %d, got %d", tt.wantStatus, recorder.Code)
			}
			if strings.Contains(recorder.Body.String(), "database details") {
				t.Fatal("response exposed an internal error")
			}
		})
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
