package threshold

import (
	"context"
	"database/sql"
	"fmt"
)

type Repository interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]Setting, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) ListByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Setting, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			parameter,
			warning_value,
			critical_value,
			recovery_margin,
			recovery_samples,
			created_at,
			updated_at
		FROM threshold_settings
		WHERE vehicle_id = $1
		ORDER BY parameter, id
	`

	rows, err := r.db.QueryContext(ctx, query, vehicleID)
	if err != nil {
		return nil, fmt.Errorf("query threshold settings: %w", err)
	}
	defer rows.Close()

	settings := make([]Setting, 0)
	for rows.Next() {
		var setting Setting
		if err := rows.Scan(
			&setting.ID,
			&setting.VehicleID,
			&setting.Parameter,
			&setting.WarningValue,
			&setting.CriticalValue,
			&setting.RecoveryMargin,
			&setting.RecoverySamples,
			&setting.CreatedAt,
			&setting.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan threshold setting: %w", err)
		}
		settings = append(settings, setting)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate threshold settings: %w", err)
	}

	return settings, nil
}
