package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.auth.AuthRoute
import ua.autonexis.mobile.ui.auth.AuthScreenMode
import ua.autonexis.mobile.ui.auth.AuthViewModel
import ua.autonexis.mobile.ui.auth.isStrongPassword
import ua.autonexis.mobile.ui.auth.loginValidationError
import ua.autonexis.mobile.ui.auth.passwordRequirements
import ua.autonexis.mobile.ui.auth.registrationValidationError

class ComposeAuthStateTest {
    @Test
    fun loginValidationRequiresUrlEmailAndPassword() {
        assertEquals(
            "Backend URL, email, and password are required.",
            loginValidationError("", "owner@example.com", "DemoPass123!"),
        )
        assertEquals(
            "Enter a valid email address.",
            loginValidationError("http://10.0.2.2:8080", "bad-email", "DemoPass123!"),
        )
        assertNull(loginValidationError("http://10.0.2.2:8080", "owner@example.com", "DemoPass123!"))
    }

    @Test
    fun registrationPasswordRulesMatchOwnerRegistrationRequirements() {
        val weakRequirements = passwordRequirements("short")
        assertFalse(isStrongPassword("short"))
        assertTrue(weakRequirements.any { !it.isSatisfied })

        assertTrue(isStrongPassword("SecurePass123!"))
        assertNull(
            registrationValidationError(
                "http://10.0.2.2:8080",
                "New Owner",
                "owner2@example.com",
                "SecurePass123!",
                "SecurePass123!",
            ),
        )
        assertEquals(
            "Password confirmation does not match.",
            registrationValidationError(
                "http://10.0.2.2:8080",
                "New Owner",
                "owner2@example.com",
                "SecurePass123!",
                "OtherPass123!",
            ),
        )
    }

    @Test
    fun sharedAuthLockBlocksDuplicatePasswordAndGoogleRequests() {
        val viewModel = AuthViewModel()
        viewModel.showLogin(baseUrl = "http://10.0.2.2:8080")

        assertTrue(viewModel.tryStartAuthentication("Logging in..."))
        assertFalse(viewModel.tryStartAuthentication("Signing in with Google..."))
        assertTrue(viewModel.uiState.isAuthInFlight)

        viewModel.finishAuthentication()
        assertTrue(viewModel.tryStartAuthentication("Signing in with Google..."))
    }

    @Test
    fun ownerAuthenticationRoutesToOwnerDashboard() {
        val route = AuthViewModel().routeAfterAuthentication(
            baseUrl = " http://10.0.2.2:8080/ ",
            result = AuthResult(
                user = user(role = "vehicle_owner"),
                accessToken = "owner-token",
            ),
        )

        assertEquals("owner-token", assertIs<AuthRoute.OwnerDashboard>(route).token)
    }

    @Test
    fun staffAuthenticationRoutesToUnsupportedRole() {
        val route = AuthViewModel().routeAfterAuthentication(
            baseUrl = "http://10.0.2.2:8080",
            result = AuthResult(
                user = user(role = "administrator"),
                accessToken = "admin-token",
            ),
        )

        assertEquals("administrator", assertIs<AuthRoute.UnsupportedRole>(route).user.role)
    }

    @Test
    fun invalidSessionReturnsToLoginState() {
        val viewModel = AuthViewModel()
        viewModel.showLoading("Restoring session...")
        viewModel.showLogin(message = "Session expired", baseUrl = "http://10.0.2.2:8080")

        assertEquals(AuthScreenMode.LOGIN, viewModel.uiState.screen)
        assertEquals("Session expired", viewModel.uiState.statusMessage)
        assertFalse(viewModel.uiState.isAuthInFlight)
    }

    @Test
    fun statusMessageCanBeClearedAfterItIsShown() {
        val viewModel = AuthViewModel()
        viewModel.showLogin(message = "Session expired", baseUrl = "http://10.0.2.2:8080")

        assertEquals("Session expired", viewModel.uiState.statusMessage)

        viewModel.clearStatusMessage()

        assertNull(viewModel.uiState.statusMessage)
        assertEquals(AuthScreenMode.LOGIN, viewModel.uiState.screen)
    }

    @Test
    fun googleUnavailableStateIsSafeAndCredentialFree() {
        val secret = "raw-google-id-token"
        val viewModel = AuthViewModel()
        viewModel.showLogin(baseUrl = "http://10.0.2.2:8080")
        viewModel.tryStartAuthentication("Opening Google sign-in...")
        viewModel.showError("Google sign-in is temporarily unavailable. You can still use email and password.")

        val error = assertNotNull(viewModel.uiState.errorMessage)
        assertFalse(error.contains(secret))
        assertFalse(viewModel.uiState.isAuthInFlight)
    }

    private fun user(role: String) = User(
        id = "user-$role",
        email = "$role@example.com",
        role = role,
        fullName = "Autonexis User",
    )
}
