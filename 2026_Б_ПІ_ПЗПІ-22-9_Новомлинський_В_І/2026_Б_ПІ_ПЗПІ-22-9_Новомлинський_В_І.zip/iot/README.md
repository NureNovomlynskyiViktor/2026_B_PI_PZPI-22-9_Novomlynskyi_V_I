# IoT

This directory is reserved for ESP32/Wokwi simulation files and MQTT-related configuration.

Device logic will be added in later steps.
