package notification

import (
	"database/sql"
	"testing"
	"time"
)

func TestScanNotificationSupportsVehicleAlertReference(t *testing.T) {
	alertID := "44444444-4444-4444-4444-444444444444"
	row := fakeScanner{
		values: []any{
			"33333333-3333-3333-3333-333333333333",
			"11111111-1111-1111-1111-111111111111",
			alertID,
			nil,
			TypeVehicleAlert,
			"WARNING alert: rpm",
			"RPM warning.",
			false,
			time.Date(2026, 6, 18, 10, 0, 0, 0, time.UTC),
		},
	}

	item, err := scanNotification(row)
	if err != nil {
		t.Fatalf("scanNotification returned error: %v", err)
	}
	if item.AlertID == nil || *item.AlertID != alertID {
		t.Fatalf("expected alert ID %q, got %#v", alertID, item.AlertID)
	}
	if item.ServiceRequestID != nil {
		t.Fatalf("expected nil service request ID, got %#v", item.ServiceRequestID)
	}
	if item.NotificationType != TypeVehicleAlert {
		t.Fatalf("expected type %q, got %q", TypeVehicleAlert, item.NotificationType)
	}
}

func TestScanNotificationSupportsServiceRequestReference(t *testing.T) {
	requestID := "55555555-5555-5555-5555-555555555555"
	row := fakeScanner{
		values: []any{
			"33333333-3333-3333-3333-333333333333",
			"11111111-1111-1111-1111-111111111111",
			nil,
			requestID,
			TypeServiceRequestCompleted,
			"Service request completed",
			"Result: inspected.",
			true,
			time.Date(2026, 6, 18, 10, 0, 0, 0, time.UTC),
		},
	}

	item, err := scanNotification(row)
	if err != nil {
		t.Fatalf("scanNotification returned error: %v", err)
	}
	if item.AlertID != nil {
		t.Fatalf("expected nil alert ID, got %#v", item.AlertID)
	}
	if item.ServiceRequestID == nil || *item.ServiceRequestID != requestID {
		t.Fatalf("expected service request ID %q, got %#v", requestID, item.ServiceRequestID)
	}
	if item.NotificationType != TypeServiceRequestCompleted {
		t.Fatalf("expected type %q, got %q", TypeServiceRequestCompleted, item.NotificationType)
	}
}

type fakeScanner struct {
	values []any
}

func (s fakeScanner) Scan(dest ...any) error {
	for index, value := range s.values {
		switch target := dest[index].(type) {
		case *string:
			*target = value.(string)
		case **string:
			panic("unexpected pointer")
		case *bool:
			*target = value.(bool)
		case *time.Time:
			*target = value.(time.Time)
		default:
			setNullValue(target, value)
		}
	}
	return nil
}

func setNullValue(target any, value any) {
	switch typed := target.(type) {
	case *sql.NullString:
		if value == nil {
			typed.Valid = false
			return
		}
		typed.String = value.(string)
		typed.Valid = true
	default:
		panic("unsupported scan target")
	}
}
