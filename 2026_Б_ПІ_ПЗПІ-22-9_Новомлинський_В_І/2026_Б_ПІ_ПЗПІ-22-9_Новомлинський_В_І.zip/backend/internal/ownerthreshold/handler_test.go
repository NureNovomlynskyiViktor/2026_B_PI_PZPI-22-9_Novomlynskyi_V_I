package ownerthreshold

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
)

type stubThresholdService struct {
	settings        []threshold.Setting
	err             error
	capturedVehicle string
}

func (s *stubThresholdService) ListByVehicle(
	_ context.Context,
	vehicleID string,
) ([]threshold.Setting, error) {
	s.capturedVehicle = vehicleID
	return s.settings, s.err
}

type stubVehicleService struct {
	err             error
	capturedOwner   string
	capturedVehicle string
}

func (s *stubVehicleService) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) (vehicle.Vehicle, error) {
	s.capturedOwner = ownerID
	s.capturedVehicle = vehicleID
	if s.err != nil {
		return vehicle.Vehicle{}, s.err
	}
	return vehicle.Vehicle{ID: vehicleID, OwnerID: ownerID}, nil
}

func TestListByVehicleRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(
		&stubThresholdService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/thresholds",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestListByVehicleRejectsInvalidUUID(t *testing.T) {
	handler := NewHandler(
		&stubThresholdService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := authenticatedRequest("/api/v1/me/vehicles/not-a-uuid/thresholds")
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListByVehicleReturnsNotFoundForOtherUsersVehicle(t *testing.T) {
	thresholdService := &stubThresholdService{}
	handler := NewHandler(
		thresholdService,
		&stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	request := authenticatedRequest("/api/v1/me/vehicles/" + testVehicleID + "/thresholds")
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
	if thresholdService.capturedVehicle != "" {
		t.Fatal("expected threshold service not to be called")
	}
}

func TestListByVehicleReturnsPresentationRules(t *testing.T) {
	thresholdService := &stubThresholdService{
		settings: []threshold.Setting{
			{
				ID:            "55555555-5555-5555-5555-555555555551",
				VehicleID:     testVehicleID,
				Parameter:     "engine_temperature",
				WarningValue:  90,
				CriticalValue: 105,
			},
		},
	}
	vehicleService := &stubVehicleService{}
	handler := NewHandler(thresholdService, vehicleService, testLogger())
	request := authenticatedRequest("/api/v1/me/vehicles/" + testVehicleID + "/thresholds")
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if vehicleService.capturedOwner != testOwnerID {
		t.Fatalf("expected owner %s, got %s", testOwnerID, vehicleService.capturedOwner)
	}
	if thresholdService.capturedVehicle != testVehicleID {
		t.Fatalf(
			"expected threshold vehicle %s, got %s",
			testVehicleID,
			thresholdService.capturedVehicle,
		)
	}
	body := recorder.Body.String()
	for _, expected := range []string{
		`"severity":"warning"`,
		`"severity":"critical"`,
		`"unit":"C"`,
		`"rule_type":"engine_temperature_warning"`,
	} {
		if !strings.Contains(body, expected) {
			t.Fatalf("expected response to contain %s, got %s", expected, body)
		}
	}
}

func authenticatedRequest(target string) *http.Request {
	request := httptest.NewRequest(http.MethodGet, target, nil)
	ctx := auth.WithUser(
		request.Context(),
		auth.User{
			ID:    testOwnerID,
			Email: "owner@example.com",
			Role:  auth.DefaultRoleCode,
		},
	)
	return request.WithContext(ctx)
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
