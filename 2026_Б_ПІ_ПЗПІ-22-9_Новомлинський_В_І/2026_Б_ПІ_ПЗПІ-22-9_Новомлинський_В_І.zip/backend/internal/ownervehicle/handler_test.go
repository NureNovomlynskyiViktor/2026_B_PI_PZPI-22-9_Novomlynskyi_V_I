package ownervehicle

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
)

type stubVehicleService struct {
	vehicles      []vehicle.Vehicle
	vehicle       vehicle.Vehicle
	err           error
	capturedOwner string
	capturedInput vehicle.CreateRequest
}

func (s *stubVehicleService) ListByOwner(
	_ context.Context,
	ownerID string,
) ([]vehicle.Vehicle, error) {
	s.capturedOwner = ownerID
	return s.vehicles, s.err
}

func (s *stubVehicleService) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	_ string,
) (vehicle.Vehicle, error) {
	s.capturedOwner = ownerID
	return s.vehicle, s.err
}

func (s *stubVehicleService) CreateForOwner(
	_ context.Context,
	ownerID string,
	request vehicle.CreateRequest,
) (vehicle.Vehicle, error) {
	s.capturedOwner = ownerID
	s.capturedInput = request
	return s.vehicle, s.err
}

type stubStatusService struct {
	status vehiclestatus.VehicleStatus
	err    error
}

func (s stubStatusService) GetByVehicleID(
	context.Context,
	string,
) (vehiclestatus.VehicleStatus, error) {
	return s.status, s.err
}

func TestListRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(&stubVehicleService{}, stubStatusService{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/me/vehicles", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestListReturnsOnlyCurrentUserVehicles(t *testing.T) {
	service := &stubVehicleService{
		vehicles: []vehicle.Vehicle{{
			ID:      testVehicleID,
			OwnerID: testOwnerID,
			Brand:   "Toyota",
		}},
	}
	handler := NewHandler(service, stubStatusService{}, testLogger())
	request := authenticatedRequest(http.MethodGet, "/api/v1/me/vehicles", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.capturedOwner != testOwnerID {
		t.Fatalf("expected owner %s, got %s", testOwnerID, service.capturedOwner)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"owner_id":"`+testOwnerID+`"`) {
		t.Fatalf("expected owned vehicle JSON, got %s", body)
	}
}

func TestListReturnsEmptyVehiclesForNewOwner(t *testing.T) {
	service := &stubVehicleService{vehicles: []vehicle.Vehicle{}}
	handler := NewHandler(service, stubStatusService{}, testLogger())
	request := authenticatedRequest(http.MethodGet, "/api/v1/me/vehicles", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.capturedOwner != testOwnerID {
		t.Fatalf("expected owner %s, got %s", testOwnerID, service.capturedOwner)
	}
	if body := strings.TrimSpace(recorder.Body.String()); body != "[]" {
		t.Fatalf("expected empty vehicle list, got %s", body)
	}
}

func TestGetByIDReturnsNotFoundForOtherUserVehicle(t *testing.T) {
	handler := NewHandler(
		&stubVehicleService{err: vehicle.ErrNotFound},
		stubStatusService{},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID,
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestCreateAssignsCurrentUserAsOwner(t *testing.T) {
	service := &stubVehicleService{
		vehicle: vehicle.Vehicle{
			ID:      testVehicleID,
			OwnerID: testOwnerID,
			Brand:   "Toyota",
		},
	}
	handler := NewHandler(service, stubStatusService{}, testLogger())
	body := strings.NewReader(`{
		"vin":"TESTVIN0000000001",
		"brand":"Toyota",
		"model":"Corolla",
		"year":2020,
		"license_plate":"AA1234BB"
	}`)
	request := authenticatedRequest(http.MethodPost, "/api/v1/me/vehicles", body)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if service.capturedOwner != testOwnerID {
		t.Fatalf("expected owner %s, got %s", testOwnerID, service.capturedOwner)
	}
	if service.capturedInput.VIN != "TESTVIN0000000001" {
		t.Fatalf("expected request body to be decoded, got %+v", service.capturedInput)
	}
}

func TestGetByIDRejectsInvalidUUID(t *testing.T) {
	handler := NewHandler(&stubVehicleService{}, stubStatusService{}, testLogger())
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/not-a-uuid",
		nil,
	)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestStatusVerifiesOwnershipBeforeReturningStatus(t *testing.T) {
	handler := NewHandler(
		&stubVehicleService{vehicle: vehicle.Vehicle{ID: testVehicleID, OwnerID: testOwnerID}},
		stubStatusService{
			status: vehiclestatus.VehicleStatus{
				Vehicle:       vehicle.Vehicle{ID: testVehicleID, OwnerID: testOwnerID},
				ActiveAlerts:  []alert.Alert{},
				OverallStatus: "normal",
			},
		},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/status",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Status(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"overall_status":"normal"`) {
		t.Fatalf("expected status JSON, got %s", body)
	}
}

func TestStatusHidesVehicleOwnedByAnotherUser(t *testing.T) {
	handler := NewHandler(
		&stubVehicleService{err: vehicle.ErrNotFound},
		stubStatusService{err: errors.New("status should not be called")},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/status",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Status(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func authenticatedRequest(method string, path string, body io.Reader) *http.Request {
	request := httptest.NewRequest(method, path, body)
	return request.WithContext(auth.WithUser(
		request.Context(),
		auth.User{ID: testOwnerID, Email: "owner@example.com", Role: auth.DefaultRoleCode},
	))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
