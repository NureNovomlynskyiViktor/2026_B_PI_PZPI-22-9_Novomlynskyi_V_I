# Mobile Client

This directory contains mobile client work for the basic functional version of Autonexis.

The initial Android vehicle owner app foundation is located in:

- `mobile/android`

See `mobile/android/README.md` for Android Studio setup, backend URL notes, and the current owner app flow.
