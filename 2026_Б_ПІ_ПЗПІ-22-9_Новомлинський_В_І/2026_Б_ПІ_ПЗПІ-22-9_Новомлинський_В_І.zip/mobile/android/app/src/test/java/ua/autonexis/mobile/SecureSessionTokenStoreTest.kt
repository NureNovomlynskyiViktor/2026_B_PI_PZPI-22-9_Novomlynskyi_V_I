package ua.autonexis.mobile

import java.util.Base64
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class SecureSessionTokenStoreTest {
    @Test
    fun encryptedEnvelopeRoundTripsUsingCipher() {
        val preferences = FakeSessionTokenPreferences()
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        store.token = " access-token "

        assertEquals("access-token", store.token)
        assertNull(preferences.legacyToken)
        assertEquals(1, preferences.secureEnvelope.formatVersion)
        assertNotNull(preferences.secureEnvelope.ciphertext)
        assertNotNull(preferences.secureEnvelope.iv)
        assertFalse(preferences.secureEnvelope.ciphertext.orEmpty().contains("access-token"))
    }

    @Test
    fun legacyPlaintextTokenMigratesAndRemovesPlaintextAfterSuccessfulPersistence() {
        val preferences = FakeSessionTokenPreferences(legacyToken = " legacy-token ")
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        assertEquals("legacy-token", store.token)
        assertNull(preferences.legacyToken)
        assertEquals("legacy-token", store.token)
    }

    @Test
    fun failedLegacyMigrationClearsPlaintextAndReturnsNoToken() {
        val preferences = FakeSessionTokenPreferences(legacyToken = "legacy-token")
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(failEncrypt = true),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        assertNull(store.token)
        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun missingIvClearsSecureAndLegacyState() {
        val preferences = FakeSessionTokenPreferences(
            legacyToken = "legacy-token",
            secureEnvelope = StoredTokenEnvelope(
                ciphertext = JvmBase64TokenEnvelopeCodec.encode("encrypted:token".toByteArray()),
                iv = null,
                formatVersion = 1,
            ),
        )
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        assertNull(store.token)
        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun malformedBase64ClearsSecureAndLegacyState() {
        val preferences = FakeSessionTokenPreferences(
            legacyToken = "legacy-token",
            secureEnvelope = StoredTokenEnvelope(
                ciphertext = "%%%",
                iv = JvmBase64TokenEnvelopeCodec.encode("iv".toByteArray()),
                formatVersion = 1,
            ),
        )
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        assertNull(store.token)
        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun unsupportedFormatVersionClearsSecureAndLegacyState() {
        val preferences = FakeSessionTokenPreferences(
            legacyToken = "legacy-token",
            secureEnvelope = StoredTokenEnvelope(
                ciphertext = JvmBase64TokenEnvelopeCodec.encode("encrypted:token".toByteArray()),
                iv = JvmBase64TokenEnvelopeCodec.encode("iv".toByteArray()),
                formatVersion = 99,
            ),
        )
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        assertNull(store.token)
        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun corruptedCiphertextClearsSecureAndLegacyState() {
        val preferences = FakeSessionTokenPreferences(
            legacyToken = "legacy-token",
            secureEnvelope = StoredTokenEnvelope(
                ciphertext = JvmBase64TokenEnvelopeCodec.encode("not-encrypted".toByteArray()),
                iv = JvmBase64TokenEnvelopeCodec.encode("iv".toByteArray()),
                formatVersion = 1,
            ),
        )
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        assertNull(store.token)
        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun clearTokenRemovesSecureEnvelopeAndLegacyPlaintext() {
        val preferences = FakeSessionTokenPreferences(legacyToken = "legacy-token")
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )
        store.token = "access-token"
        preferences.legacyToken = "legacy-token"

        store.clearToken()

        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun blankTokenClearsSessionInsteadOfPersistingPlaintext() {
        val preferences = FakeSessionTokenPreferences(legacyToken = "legacy-token")
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        store.token = "   "

        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }

    @Test
    fun safeCryptoErrorTextDoesNotIncludeTokenValue() {
        val token = "sensitive.jwt.value"
        val exception = SessionTokenCryptoException(
            message = "Unable to encrypt session token.",
            cause = RuntimeException(token),
        )

        assertFalse(exception.message.orEmpty().contains(token))
    }

    @Test
    fun writeFailureClearsPlaintextAndIncompleteEnvelope() {
        val preferences = FakeSessionTokenPreferences(legacyToken = "legacy-token")
        preferences.failWrites = true
        val store = SecureSessionTokenStore(
            preferences = preferences,
            cipher = FakeSessionTokenCipher(),
            codec = JvmBase64TokenEnvelopeCodec,
        )

        store.token = "access-token"

        assertNull(preferences.legacyToken)
        assertEquals(StoredTokenEnvelope(null, null, null), preferences.secureEnvelope)
    }
}

private class FakeSessionTokenPreferences(
    var legacyToken: String? = null,
    var secureEnvelope: StoredTokenEnvelope = StoredTokenEnvelope(null, null, null),
) : SessionTokenPreferences {
    var failWrites = false

    override fun readSecureEnvelope(): StoredTokenEnvelope = secureEnvelope

    override fun writeSecureEnvelope(envelope: StoredTokenEnvelope): Boolean {
        if (failWrites) {
            return false
        }
        secureEnvelope = envelope
        return true
    }

    override fun clearSecureEnvelope(): Boolean {
        secureEnvelope = StoredTokenEnvelope(null, null, null)
        return true
    }

    override fun readLegacyPlaintextToken(): String? = legacyToken

    override fun clearLegacyPlaintextToken(): Boolean {
        legacyToken = null
        return true
    }
}

private class FakeSessionTokenCipher(
    private val failEncrypt: Boolean = false,
) : SessionTokenCipherContract {
    override fun encrypt(plaintextToken: String): TokenCipherResult {
        if (failEncrypt) {
            throw SessionTokenCryptoException("Unable to encrypt session token.")
        }

        return TokenCipherResult(
            ciphertext = "encrypted:$plaintextToken".toByteArray(),
            iv = "fake-iv".toByteArray(),
        )
    }

    override fun decrypt(ciphertext: ByteArray, iv: ByteArray): String {
        assertTrue(iv.isNotEmpty())
        val encoded = ciphertext.toString(Charsets.UTF_8)
        if (!encoded.startsWith("encrypted:")) {
            throw SessionTokenCryptoException("Unable to decrypt session token.")
        }

        return encoded.removePrefix("encrypted:")
    }
}

private object JvmBase64TokenEnvelopeCodec : TokenEnvelopeCodec {
    override fun encode(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    override fun decode(encoded: String): ByteArray = Base64.getDecoder().decode(encoded)
}
