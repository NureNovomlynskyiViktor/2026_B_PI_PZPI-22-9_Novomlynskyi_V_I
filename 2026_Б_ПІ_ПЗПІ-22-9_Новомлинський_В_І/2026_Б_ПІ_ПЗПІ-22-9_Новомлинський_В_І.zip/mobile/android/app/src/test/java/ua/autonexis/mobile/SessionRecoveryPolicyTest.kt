package ua.autonexis.mobile

import java.io.File
import java.net.ConnectException
import java.net.SocketTimeoutException
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class SessionRecoveryPolicyTest {
    @Test
    fun restoredTokenRejectedWith401ExpiresSession() {
        assertTrue(
            SessionRecoveryPolicy.isExpiredSession(
                ApiException(401, "missing or invalid token"),
            ),
        )
    }

    @Test
    fun restoredTokenAcceptedDoesNotRequireRecovery() {
        assertFalse(SessionRecoveryPolicy.isExpiredSession(ApiException(200, "ok")))
    }

    @Test
    fun non401ApiErrorsAreTransientForAuthenticatedRecovery() {
        assertTrue(SessionRecoveryPolicy.isTransientAuthenticatedFailure(ApiException(400, "bad request")))
        assertTrue(SessionRecoveryPolicy.isTransientAuthenticatedFailure(ApiException(403, "forbidden")))
        assertTrue(SessionRecoveryPolicy.isTransientAuthenticatedFailure(ApiException(500, "server error")))
    }

    @Test
    fun networkFailuresAreTransientForAuthenticatedRecovery() {
        assertTrue(
            SessionRecoveryPolicy.isTransientAuthenticatedFailure(
                ConnectException("failed to connect to /10.0.2.2 (port 8080)"),
            ),
        )
        assertTrue(SessionRecoveryPolicy.isTransientAuthenticatedFailure(SocketTimeoutException("timeout")))
    }

    @Test
    fun expiredSessionPolicyDoesNotExposeRawBackendText() {
        val error = ApiException(401, "missing or invalid token")

        assertTrue(SessionRecoveryPolicy.isExpiredSession(error))
        assertFalse("Your session has expired. Please sign in again.".contains(error.message.orEmpty()))
    }

    @Test
    fun transientErrorsKeepExistingSafeRetryMessages() {
        assertEquals(
            "Cannot reach the Autonexis server. Check the backend connection and try again.",
            UserFacingErrorMapper.messageFor(ConnectException("failed to connect to /10.0.2.2 (port 8080)")),
        )
        assertEquals(
            "The server is taking too long to respond. Try again.",
            UserFacingErrorMapper.messageFor(SocketTimeoutException("timeout")),
        )
        assertEquals(
            "temporary server error",
            UserFacingErrorMapper.messageFor(ApiException(500, "temporary server error")),
        )
    }

    @Test
    fun expiredSessionCleanupClearsOnlyAutonexisJwtPreferences() {
        val tokenPreferences = PolicyFakeSessionTokenPreferences()
        val tokenStore = SecureSessionTokenStore(
            preferences = tokenPreferences,
            cipher = PolicyFakeSessionTokenCipher(),
            codec = PolicyPlainTokenEnvelopeCodec,
        )
        val appearanceStore = AppearanceStore(PolicyFakeAppearanceStorage())
        val languageStore = LanguageStore(PolicyFakeLanguageStorage())
        var backendUrl = "http://127.0.0.1:8080"

        tokenStore.token = "jwt-token"
        appearanceStore.mode = AppearanceMode.DARK
        languageStore.mode = LanguageMode.UKRAINIAN
        languageStore.restoreAccountAfterLanguageChange = true

        tokenStore.clearToken()

        assertNull(tokenStore.token)
        assertEquals("http://127.0.0.1:8080", backendUrl)
        assertEquals(AppearanceMode.DARK, appearanceStore.mode)
        assertEquals(LanguageMode.UKRAINIAN, languageStore.mode)
        assertTrue(languageStore.restoreAccountAfterLanguageChange)
        backendUrl = "http://10.0.2.2:8080"
        assertEquals("http://10.0.2.2:8080", backendUrl)
    }

    @Test
    fun localizedExpiredSessionResourceExistsInBothLocales() {
        val defaultStrings = stringResources(File("src/main/res/values/strings.xml"))
        val ukrainianStrings = stringResources(File("src/main/res/values-uk/strings.xml"))

        assertEquals(
            "Your session has expired. Please sign in again.",
            defaultStrings.getValue("session_expired_message"),
        )
        assertEquals(
            "\u0422\u0435\u0440\u043c\u0456\u043d \u0434\u0456\u0457 \u0441\u0435\u0430\u043d\u0441\u0443 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0432\u0441\u044f. \u0423\u0432\u0456\u0439\u0434\u0456\u0442\u044c \u0437\u043d\u043e\u0432\u0443.",
            ukrainianStrings.getValue("session_expired_message"),
        )
    }

    private fun stringResources(file: File): Map<String, String> {
        val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file)
        val nodes = document.getElementsByTagName("string")
        val values = linkedMapOf<String, String>()
        for (index in 0 until nodes.length) {
            val node = nodes.item(index)
            val name = node.attributes?.getNamedItem("name")?.nodeValue.orEmpty()
            if (name.isNotBlank()) {
                values[name] = node.textContent
            }
        }
        return values
    }
}

private class PolicyFakeSessionTokenPreferences : SessionTokenPreferences {
    var legacyToken: String? = null
    var secureEnvelope: StoredTokenEnvelope = StoredTokenEnvelope(null, null, null)

    override fun readSecureEnvelope(): StoredTokenEnvelope = secureEnvelope

    override fun writeSecureEnvelope(envelope: StoredTokenEnvelope): Boolean {
        secureEnvelope = envelope
        return true
    }

    override fun clearSecureEnvelope(): Boolean {
        secureEnvelope = StoredTokenEnvelope(null, null, null)
        return true
    }

    override fun readLegacyPlaintextToken(): String? = legacyToken

    override fun clearLegacyPlaintextToken(): Boolean {
        legacyToken = null
        return true
    }
}

private class PolicyFakeSessionTokenCipher : SessionTokenCipherContract {
    override fun encrypt(plaintextToken: String): TokenCipherResult {
        return TokenCipherResult(
            ciphertext = "encrypted:$plaintextToken".toByteArray(),
            iv = "policy-iv".toByteArray(),
        )
    }

    override fun decrypt(ciphertext: ByteArray, iv: ByteArray): String {
        val encoded = ciphertext.toString(Charsets.UTF_8)
        if (!encoded.startsWith("encrypted:")) {
            throw SessionTokenCryptoException("Unable to decrypt session token.")
        }
        return encoded.removePrefix("encrypted:")
    }
}

private object PolicyPlainTokenEnvelopeCodec : TokenEnvelopeCodec {
    override fun encode(bytes: ByteArray): String = bytes.toString(Charsets.UTF_8)

    override fun decode(encoded: String): ByteArray = encoded.toByteArray()
}

private class PolicyFakeAppearanceStorage : AppearancePreferenceStorage {
    override var rawAppearanceMode: String? = null
}

private class PolicyFakeLanguageStorage : LanguagePreferenceStorage {
    override var rawLanguageMode: String? = null
    override var restoreAccountAfterLanguageChange: Boolean = false
}
