package adminspecialist

import (
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

func TestTechnicalSpecialistCreatedAuditEntry(t *testing.T) {
	user := auth.User{
		ID:    "22222222-2222-2222-2222-222222222222",
		Role:  auth.TechnicalSpecialistRoleCode,
		Email: "specialist.new@example.com",
	}
	entry := technicalSpecialistCreatedAuditEntry(testAdminID, user, []specialistcompetency.SupportedCompetency{
		{Code: specialistcompetency.CodeEngineDiagnostics, Name: "Engine diagnostics"},
		{Code: specialistcompetency.CodeBatteryElectrical, Name: "Battery and electrical systems"},
	})

	if entry.ActorID != testAdminID || entry.Action != ActionTechnicalSpecialistCreated ||
		entry.EntityType != EntityTypeUser || entry.EntityID != user.ID {
		t.Fatalf("unexpected audit entry: %#v", entry)
	}
	metadata, ok := entry.Metadata.(map[string]any)
	if !ok {
		t.Fatalf("expected metadata map, got %#v", entry.Metadata)
	}
	if metadata["email"] != user.Email || metadata["role"] != auth.TechnicalSpecialistRoleCode ||
		metadata["competencies_count"] != 2 {
		t.Fatalf("unexpected audit metadata: %#v", metadata)
	}
	for _, forbidden := range []string{"password", "password_hash", "DemoPass123!", "hashed-password"} {
		if _, exists := metadata[forbidden]; exists {
			t.Fatalf("audit metadata exposed secret field %q: %#v", forbidden, metadata)
		}
	}
}
