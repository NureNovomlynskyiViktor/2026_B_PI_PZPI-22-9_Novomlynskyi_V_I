import { useId } from 'react';
import { useAppearance, type AppearanceMode } from '../../appearance';
import { useMessages } from '../../i18n';

type Props = {
  className?: string;
};

export function AppearanceSelector({ className = '' }: Props) {
  const selectID = useId();
  const { appearanceMode, setAppearanceMode } = useAppearance();
  const t = useMessages().appearance;

  return (
    <label
      className={className ? `language-selector appearance-selector ${className}` : 'language-selector appearance-selector'}
      htmlFor={selectID}
    >
      <span>{t.label}</span>
      <select
        id={selectID}
        value={appearanceMode}
        onChange={(event) => setAppearanceMode(event.target.value as AppearanceMode)}
      >
        <option value="system">{t.system}</option>
        <option value="light">{t.light}</option>
        <option value="dark">{t.dark}</option>
      </select>
    </label>
  );
}
