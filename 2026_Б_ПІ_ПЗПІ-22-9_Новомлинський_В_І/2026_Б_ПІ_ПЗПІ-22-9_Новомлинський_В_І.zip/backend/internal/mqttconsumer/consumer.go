package mqttconsumer

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/config"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetryingestion"
)

const (
	operationTimeout   = 10 * time.Second
	ingestionTimeout   = 15 * time.Second
	maximumPayloadSize = 1 << 20
	subscriptionQoS    = byte(1)
	disconnectQuiesce  = 250
)

var (
	ErrInvalidTopic   = errors.New("invalid MQTT telemetry topic")
	ErrInvalidPayload = errors.New("invalid MQTT telemetry payload")
)

type IngestionService interface {
	Ingest(
		ctx context.Context,
		deviceUID string,
		input telemetryingestion.Input,
	) (telemetryingestion.Result, error)
}

type Consumer struct {
	config    config.MQTTConfig
	ingestion IngestionService
	logger    *slog.Logger
	client    mqtt.Client
	ctx       context.Context
	cancel    context.CancelFunc

	mu         sync.Mutex
	workers    sync.WaitGroup
	closed     bool
	subscribed atomic.Bool
}

func New(
	cfg config.MQTTConfig,
	ingestion IngestionService,
	logger *slog.Logger,
) (*Consumer, error) {
	if _, err := wildcardIndex(cfg.TelemetryTopic); err != nil {
		return nil, err
	}

	return &Consumer{
		config:    cfg,
		ingestion: ingestion,
		logger:    logger,
	}, nil
}

func (c *Consumer) Start(ctx context.Context) error {
	if c.isClosed() {
		return context.Canceled
	}
	c.ctx, c.cancel = context.WithCancel(ctx)

	options := mqtt.NewClientOptions().
		AddBroker(c.config.BrokerURL()).
		SetClientID(c.config.ClientID).
		SetCleanSession(true).
		SetAutoReconnect(true).
		SetConnectRetry(false).
		SetOrderMatters(false).
		SetConnectionLostHandler(func(_ mqtt.Client, err error) {
			c.logger.Warn("MQTT connection lost", "error", err)
		})

	options.SetOnConnectHandler(func(client mqtt.Client) {
		if !c.subscribed.Load() || c.isClosed() {
			return
		}
		if err := c.subscribe(client); err != nil {
			c.logger.Error(
				"failed to restore MQTT telemetry subscription",
				"topic", c.config.TelemetryTopic,
				"error", err,
			)
			return
		}
		c.logger.Info(
			"MQTT telemetry subscription restored",
			"topic", c.config.TelemetryTopic,
		)
	})

	c.client = mqtt.NewClient(options)
	connectToken := c.client.Connect()
	if !connectToken.WaitTimeout(operationTimeout) {
		return errors.New("MQTT connection timed out")
	}
	if err := connectToken.Error(); err != nil {
		return fmt.Errorf("connect to MQTT broker: %w", err)
	}
	if c.isClosed() || c.ctx.Err() != nil {
		c.client.Disconnect(disconnectQuiesce)
		return context.Canceled
	}

	if err := c.subscribe(c.client); err != nil {
		c.client.Disconnect(disconnectQuiesce)
		return err
	}
	c.subscribed.Store(true)

	c.logger.Info(
		"MQTT telemetry consumer started",
		"broker", c.config.BrokerURL(),
		"client_id", c.config.ClientID,
		"topic", c.config.TelemetryTopic,
	)

	return nil
}

func (c *Consumer) Close() {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return
	}
	c.closed = true
	c.mu.Unlock()

	if c.cancel != nil {
		c.cancel()
	}
	if c.client != nil && c.client.IsConnected() {
		token := c.client.Unsubscribe(c.config.TelemetryTopic)
		_ = token.WaitTimeout(operationTimeout)
		c.client.Disconnect(disconnectQuiesce)
	}

	c.workers.Wait()
	c.logger.Info("MQTT telemetry consumer stopped")
}

func (c *Consumer) subscribe(client mqtt.Client) error {
	token := client.Subscribe(
		c.config.TelemetryTopic,
		subscriptionQoS,
		c.handleMessage,
	)
	if !token.WaitTimeout(operationTimeout) {
		return errors.New("MQTT subscription timed out")
	}
	if err := token.Error(); err != nil {
		return fmt.Errorf("subscribe to MQTT telemetry topic: %w", err)
	}

	return nil
}

func (c *Consumer) handleMessage(_ mqtt.Client, message mqtt.Message) {
	if !c.beginWork() {
		return
	}
	defer c.workers.Done()

	ctx, cancel := context.WithTimeout(c.ctx, ingestionTimeout)
	defer cancel()

	result, err := c.processMessage(ctx, message.Topic(), message.Payload())
	if err != nil {
		c.logger.Warn(
			"MQTT telemetry message rejected",
			"topic", message.Topic(),
			"error", err,
		)
		return
	}

	c.logger.Info(
		"MQTT telemetry ingested",
		"device_uid", result.deviceUID,
		"telemetry_id", result.ingestion.Telemetry.ID,
		"created_alerts", len(result.ingestion.CreatedAlerts),
		"updated_alerts", len(result.ingestion.UpdatedAlerts),
		"cleared_alerts", len(result.ingestion.ResolvedAlerts),
		"overall_result", result.ingestion.OverallResult,
	)
}

type processedMessage struct {
	deviceUID string
	ingestion telemetryingestion.Result
}

func (c *Consumer) processMessage(
	ctx context.Context,
	topic string,
	payload []byte,
) (processedMessage, error) {
	deviceUID, err := DeviceUIDFromTopic(c.config.TelemetryTopic, topic)
	if err != nil {
		return processedMessage{}, err
	}

	input, err := DecodePayload(payload)
	if err != nil {
		return processedMessage{}, err
	}

	result, err := c.ingestion.Ingest(ctx, deviceUID, input)
	if err != nil {
		return processedMessage{}, fmt.Errorf("ingest MQTT telemetry: %w", err)
	}

	return processedMessage{
		deviceUID: deviceUID,
		ingestion: result,
	}, nil
}

func (c *Consumer) beginWork() bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.closed {
		return false
	}
	c.workers.Add(1)
	return true
}

func (c *Consumer) isClosed() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.closed
}

func DeviceUIDFromTopic(filter, topic string) (string, error) {
	wildcard, err := wildcardIndex(filter)
	if err != nil {
		return "", err
	}

	filterParts := strings.Split(filter, "/")
	topicParts := strings.Split(topic, "/")
	if len(topicParts) != len(filterParts) {
		return "", ErrInvalidTopic
	}

	for index := range filterParts {
		if index == wildcard {
			continue
		}
		if filterParts[index] != topicParts[index] {
			return "", ErrInvalidTopic
		}
	}

	deviceUID := topicParts[wildcard]
	if !identifier.IsDeviceUID(deviceUID) {
		return "", ErrInvalidTopic
	}

	return deviceUID, nil
}

func DecodePayload(payload []byte) (telemetryingestion.Input, error) {
	if len(payload) == 0 || len(payload) > maximumPayloadSize {
		return telemetryingestion.Input{}, ErrInvalidPayload
	}

	var input telemetryingestion.Input
	decoder := json.NewDecoder(bytes.NewReader(payload))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&input); err != nil {
		return telemetryingestion.Input{}, fmt.Errorf("%w: %v", ErrInvalidPayload, err)
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return telemetryingestion.Input{}, ErrInvalidPayload
	}

	return input, nil
}

func wildcardIndex(filter string) (int, error) {
	parts := strings.Split(filter, "/")
	wildcard := -1

	for index, part := range parts {
		if part == "+" {
			if wildcard != -1 {
				return -1, ErrInvalidTopic
			}
			wildcard = index
			continue
		}
		if part == "" || strings.ContainsAny(part, "+#") {
			return -1, ErrInvalidTopic
		}
	}

	if wildcard == -1 {
		return -1, ErrInvalidTopic
	}

	return wildcard, nil
}
