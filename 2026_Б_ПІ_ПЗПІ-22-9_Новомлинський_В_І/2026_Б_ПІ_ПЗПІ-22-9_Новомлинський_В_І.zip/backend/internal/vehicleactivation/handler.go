package vehicleactivation

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumActivationRequestBodySize = 1 << 20

type ActivationService interface {
	Create(ctx context.Context, admin auth.User, request AdminCreateRequest) (AdminCreateResponse, error)
	Claim(ctx context.Context, owner auth.User, request ClaimRequest) (vehicle.Vehicle, error)
}

type Handler struct {
	service ActivationService
	logger  *slog.Logger
}

func NewHandler(service ActivationService, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) Create(w http.ResponseWriter, r *http.Request) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}
	if user.Role != auth.AdministratorRoleCode {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return
	}

	var request AdminCreateRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	result, err := h.service.Create(r.Context(), user, request)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle activation data")
		return
	}
	if errors.Is(err, ErrDuplicateVIN) {
		response.Error(w, http.StatusConflict, "vehicle VIN already exists")
		return
	}
	if errors.Is(err, ErrDuplicateDevice) {
		response.Error(w, http.StatusConflict, "device UID already exists")
		return
	}
	if errors.Is(err, auth.ErrUnauthorized) {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return
	}
	if err != nil {
		h.logger.Error("failed to create vehicle activation", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, result)
}

func (h *Handler) Claim(w http.ResponseWriter, r *http.Request) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}
	if user.Role != auth.DefaultRoleCode {
		response.Error(w, http.StatusForbidden, "vehicle owner role required")
		return
	}

	var request ClaimRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	item, err := h.service.Claim(r.Context(), user, request)
	if errors.Is(err, ErrInvalidInput) || errors.Is(err, ErrInvalidCode) {
		response.Error(w, http.StatusBadRequest, "invalid activation code")
		return
	}
	if errors.Is(err, ErrExpiredCode) {
		response.Error(w, http.StatusBadRequest, "activation code expired")
		return
	}
	if errors.Is(err, ErrAlreadyClaimed) || errors.Is(err, ErrVehicleClaimed) {
		response.Error(w, http.StatusConflict, "activation code already used")
		return
	}
	if errors.Is(err, auth.ErrUnauthorized) {
		response.Error(w, http.StatusForbidden, "vehicle owner role required")
		return
	}
	if err != nil {
		h.logger.Error("failed to claim vehicle activation", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumActivationRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
