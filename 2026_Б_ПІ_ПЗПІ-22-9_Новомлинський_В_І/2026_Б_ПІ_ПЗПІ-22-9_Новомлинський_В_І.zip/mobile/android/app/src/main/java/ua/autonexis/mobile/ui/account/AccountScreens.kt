package ua.autonexis.mobile.ui.account

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.AppearanceMode
import ua.autonexis.mobile.LanguageMode
import ua.autonexis.mobile.R
import ua.autonexis.mobile.ui.owner.OwnerNavigationBar
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets

@Composable
internal fun AccountRoot(
    state: AccountUiState,
    appearanceMode: AppearanceMode,
    languageMode: LanguageMode,
    notificationUnreadCount: Int,
    onVehicles: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onRefresh: () -> Unit,
    onRetry: () -> Unit,
    onConnectGoogle: () -> Unit,
    onAppearanceModeSelected: (AppearanceMode) -> Unit,
    onLanguageModeSelected: (LanguageMode) -> Unit,
    onLogout: () -> Unit,
) {
    BackHandler(onBack = onVehicles)

    Scaffold(
        topBar = {
            AccountTopBar(
                isBusy = state.isLoading || state.isRefreshing || state.isLinkingGoogle,
                onRefresh = onRefresh,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = OwnerNavigationTab.ACCOUNT,
                notificationUnreadCount = notificationUnreadCount,
                onVehicles = onVehicles,
                onRequests = onRequests,
                onNotifications = onNotifications,
                onAccount = {},
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.methods == null -> AccountLoadingState(state.message ?: stringResource(R.string.loading_account))
                state.isError && state.methods == null -> AccountInitialErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_account_message),
                    onRetry = onRetry,
                    onVehicles = onVehicles,
                )
                else -> AccountContent(
                    state = state,
                    appearanceMode = appearanceMode,
                    languageMode = languageMode,
                    onConnectGoogle = onConnectGoogle,
                    onAppearanceModeSelected = onAppearanceModeSelected,
                    onLanguageModeSelected = onLanguageModeSelected,
                    onLogout = onLogout,
                )
            }
        }
    }
}

@Composable
private fun AccountTopBar(isBusy: Boolean, onRefresh: () -> Unit) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.account_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.account_subtitle),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            TextButton(onClick = onRefresh, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
        }
    }
}

@Composable
private fun AccountContent(
    state: AccountUiState,
    appearanceMode: AppearanceMode,
    languageMode: LanguageMode,
    onConnectGoogle: () -> Unit,
    onAppearanceModeSelected: (AppearanceMode) -> Unit,
    onLanguageModeSelected: (LanguageMode) -> Unit,
    onLogout: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_account)) }
        }
        item { ProfileCard(state) }
        item { AuthenticationMethodsCard(state, onConnectGoogle) }
        item { AppearanceCard(appearanceMode, onAppearanceModeSelected) }
        item { LanguageCard(languageMode, onLanguageModeSelected) }
        item { SessionCard(onLogout) }
    }
}

@Composable
private fun ProfileCard(state: AccountUiState) {
    val fullName = state.user?.fullName?.takeIf { it.isNotBlank() } ?: stringResource(R.string.vehicle_owner)
    val initials = fullName
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifBlank { "A" }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(AutonexisSpacing.lg),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = initials,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
            ) {
                Text(fullName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    text = state.user?.email.orEmpty().ifBlank { stringResource(R.string.not_available) },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = AccountPresentation.roleLabel(state.user),
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), RoundedCornerShape(999.dp))
                        .padding(horizontal = AutonexisSpacing.sm, vertical = AutonexisSpacing.xs),
                )
            }
        }
    }
}

@Composable
private fun AuthenticationMethodsCard(state: AccountUiState, onConnectGoogle: () -> Unit) {
    InfoCard {
        SectionHeader(stringResource(R.string.sign_in_methods))
        MethodRow(stringResource(R.string.method_password), stringResource(AccountPresentation.passwordMethodLabelRes(state.methods)))
        MethodRow(stringResource(R.string.method_google), stringResource(AccountPresentation.googleMethodLabelRes(state.methods)))
        when {
            state.methods?.googleLinked == true -> InfoText(stringResource(R.string.google_connected))
            !state.googleConfigured -> InfoText(stringResource(R.string.google_link_not_configured))
            else -> {
                Button(
                    onClick = onConnectGoogle,
                    enabled = AccountPresentation.canConnectGoogle(state),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_owner_account),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(if (state.isLinkingGoogle) stringResource(R.string.google_connecting) else stringResource(R.string.connect_google_account))
                    }
                }
            }
        }
        if (!state.googleLinkMessage.isNullOrBlank()) {
            StateMessage(state.googleLinkMessage, state.googleLinkIsError)
        }
    }
}

@Composable
private fun AppearanceCard(selectedMode: AppearanceMode, onModeSelected: (AppearanceMode) -> Unit) {
    InfoCard {
        SectionHeader(stringResource(R.string.appearance))
        Text(
            text = stringResource(R.string.appearance_intro),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        AppearanceMode.entries.forEach { mode ->
            AppearanceOptionRow(
                mode = mode,
                selected = mode == selectedMode,
                onSelected = { onModeSelected(mode) },
            )
        }
    }
}

@Composable
private fun AppearanceOptionRow(mode: AppearanceMode, selected: Boolean, onSelected: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .selectable(
                selected = selected,
                onClick = onSelected,
                role = Role.RadioButton,
            )
            .padding(horizontal = AutonexisSpacing.md, vertical = AutonexisSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelected)
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(stringResource(AccountPresentation.appearanceModeLabelRes(mode)), fontWeight = FontWeight.Bold)
            Text(
                stringResource(AccountPresentation.appearanceModeDescriptionRes(mode)),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}
@Composable
private fun LanguageCard(selectedMode: LanguageMode, onModeSelected: (LanguageMode) -> Unit) {
    InfoCard {
        SectionHeader(stringResource(R.string.language))
        Text(
            text = stringResource(R.string.language_intro),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        LanguageMode.entries.forEach { mode ->
            LanguageOptionRow(
                mode = mode,
                selected = mode == selectedMode,
                onSelected = { onModeSelected(mode) },
            )
        }
    }
}

@Composable
private fun LanguageOptionRow(mode: LanguageMode, selected: Boolean, onSelected: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .selectable(
                selected = selected,
                onClick = onSelected,
                role = Role.RadioButton,
            )
            .padding(horizontal = AutonexisSpacing.md, vertical = AutonexisSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelected)
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(stringResource(AccountPresentation.languageModeLabelRes(mode)), fontWeight = FontWeight.Bold)
            Text(
                stringResource(AccountPresentation.languageModeDescriptionRes(mode)),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}
@Composable
private fun SessionCard(onLogout: () -> Unit) {
    InfoCard {
        SectionHeader(stringResource(R.string.session))
        Text(
            text = stringResource(R.string.session_hint),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
        ) {
            Text(stringResource(R.string.logout))
        }
    }
}

@Composable
private fun MethodRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AccountLoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AccountInitialErrorState(message: String, onRetry: () -> Unit, onVehicles: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(stringResource(R.string.could_not_load_account), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onVehicles) { Text(stringResource(R.string.back_to_vehicles)) }
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            content = content,
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable
private fun DetailBlock(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InfoText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
