package specialistalert

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

const (
	testAlertID      = "44444444-4444-4444-4444-444444444444"
	testSpecialistID = "55555555-5555-5555-5555-555555555555"
	testRequestID    = "66666666-6666-6666-6666-666666666666"
)

type stubAlertService struct {
	item    alert.Alert
	err     error
	request alert.SpecialistResolution
}

func (s *stubAlertService) ResolveBySpecialist(
	_ context.Context,
	request alert.SpecialistResolution,
) (alert.Alert, error) {
	s.request = request
	if s.err != nil {
		return alert.Alert{}, s.err
	}
	return s.item, nil
}

func TestResolveRequiresSpecialistRole(t *testing.T) {
	handler := NewHandler(&stubAlertService{}, testLogger())
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.DefaultRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestResolveRejectsInvalidBody(t *testing.T) {
	handler := NewHandler(&stubAlertService{err: alert.ErrInvalidResolutionNote}, testLogger())
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestResolveActiveAlertReturnsConflict(t *testing.T) {
	handler := NewHandler(&stubAlertService{err: alert.ErrActiveNotResolved}, testLogger())
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func TestResolveUnavailableAlertReturnsNotFound(t *testing.T) {
	handler := NewHandler(&stubAlertService{err: alert.ErrNotFound}, testLogger())
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestResolveRejectsInvalidLinkedServiceRequest(t *testing.T) {
	handler := NewHandler(
		&stubAlertService{err: alert.ErrInvalidResolutionServiceRequest},
		testLogger(),
	)
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestResolvePassesNoteAndServiceRequest(t *testing.T) {
	resolvedAt := time.Date(2026, 6, 19, 12, 0, 0, 0, time.UTC)
	service := &stubAlertService{
		item: alert.Alert{
			ID:         testAlertID,
			Status:     alert.StatusResolved,
			ResolvedAt: &resolvedAt,
		},
	}
	handler := NewHandler(service, testLogger())
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.request.AlertID != testAlertID ||
		service.request.SpecialistID != testSpecialistID ||
		service.request.ResolutionNote != "Cooling system repaired and verified." {
		t.Fatalf("unexpected request: %#v", service.request)
	}
	if service.request.ServiceRequestID == nil || *service.request.ServiceRequestID != testRequestID {
		t.Fatalf("expected service request ID %q, got %#v", testRequestID, service.request.ServiceRequestID)
	}
}

func TestResolveDoesNotExposeUnexpectedErrors(t *testing.T) {
	handler := NewHandler(&stubAlertService{err: errors.New("database details")}, testLogger())
	request := resolveRequestForUser(auth.User{
		ID:   testSpecialistID,
		Role: auth.TechnicalSpecialistRoleCode,
	})
	recorder := httptest.NewRecorder()

	handler.Resolve(recorder, request)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, recorder.Code)
	}
	if strings.Contains(recorder.Body.String(), "database details") {
		t.Fatal("response exposed internal error")
	}
}

func resolveRequestForUser(user auth.User) *http.Request {
	body := strings.NewReader(`{
		"resolution_note":"Cooling system repaired and verified.",
		"service_request_id":"` + testRequestID + `"
	}`)
	request := httptest.NewRequest(
		http.MethodPatch,
		"/api/v1/specialist/alerts/"+testAlertID+"/resolve",
		body,
	)
	request.SetPathValue("alert_id", testAlertID)
	return request.WithContext(auth.WithUser(request.Context(), user))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
