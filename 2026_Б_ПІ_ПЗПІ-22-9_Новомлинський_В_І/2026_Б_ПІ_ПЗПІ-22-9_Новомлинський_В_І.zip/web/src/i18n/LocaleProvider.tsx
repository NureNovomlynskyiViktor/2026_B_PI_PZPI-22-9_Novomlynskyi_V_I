import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { en } from './locales/en';
import { uk } from './locales/uk';
import type { LanguageMode, Locale, LocaleMessages } from './types';

const messages: Record<Locale, LocaleMessages> = { en, uk };

type LocaleContextValue = {
  locale: Locale;
  languageMode: LanguageMode;
  messages: LocaleMessages;
  setLanguageMode: (mode: LanguageMode) => void;
};

const LocaleContext = createContext<LocaleContextValue | null>(null);

function isLanguageMode(value: string | null): value is LanguageMode {
  return value === 'system' || value === 'en' || value === 'uk';
}

export function resolveLocale(mode: LanguageMode, language = navigator.language): Locale {
  if (mode === 'en' || mode === 'uk') {
    return mode;
  }

  return language.toLowerCase().startsWith('uk') ? 'uk' : 'en';
}

function readStoredLanguageMode(): LanguageMode {
  const storedMode = window.localStorage.getItem('autonexis_web_language_mode');
  return isLanguageMode(storedMode) ? storedMode : 'system';
}

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [languageMode, setLanguageModeState] = useState<LanguageMode>(readStoredLanguageMode);
  const [browserLanguage, setBrowserLanguage] = useState(() => navigator.language);

  useEffect(() => {
    function handleLanguageChange() {
      setBrowserLanguage(navigator.language);
    }

    window.addEventListener('languagechange', handleLanguageChange);
    return () => window.removeEventListener('languagechange', handleLanguageChange);
  }, []);

  function setLanguageMode(mode: LanguageMode) {
    setLanguageModeState(mode);
    window.localStorage.setItem('autonexis_web_language_mode', mode);
  }

  const locale = resolveLocale(languageMode, browserLanguage);
  const value = useMemo<LocaleContextValue>(
    () => ({
      locale,
      languageMode,
      messages: messages[locale],
      setLanguageMode,
    }),
    [languageMode, locale],
  );

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) {
    throw new Error('useLocale must be used inside LocaleProvider');
  }

  return context;
}

export function useMessages() {
  return useLocale().messages;
}
