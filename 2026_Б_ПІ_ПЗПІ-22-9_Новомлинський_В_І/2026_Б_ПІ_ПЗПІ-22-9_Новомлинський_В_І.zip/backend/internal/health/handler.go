package health

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"time"
)

const readinessTimeout = 2 * time.Second

type DatabasePinger interface {
	PingContext(ctx context.Context) error
}

type Handler struct {
	database DatabasePinger
	logger   *slog.Logger
}

type response struct {
	Status   string `json:"status"`
	Service  string `json:"service,omitempty"`
	Database string `json:"database,omitempty"`
}

func New(database DatabasePinger, logger *slog.Logger) *Handler {
	return &Handler{
		database: database,
		logger:   logger,
	}
}

func (h *Handler) Health(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, response{
		Status:  "ok",
		Service: "autonexis-backend",
	})
}

func (h *Handler) Ready(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), readinessTimeout)
	defer cancel()

	if err := h.database.PingContext(ctx); err != nil {
		h.logger.Warn("readiness check failed", "error", err)
		writeJSON(w, http.StatusServiceUnavailable, response{
			Status:   "not_ready",
			Database: "unavailable",
		})
		return
	}

	writeJSON(w, http.StatusOK, response{
		Status:   "ready",
		Database: "ok",
	})
}

func writeJSON(w http.ResponseWriter, status int, payload response) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)

	if err := json.NewEncoder(w).Encode(payload); err != nil {
		slog.Error("failed to write JSON response", "error", err)
	}
}
