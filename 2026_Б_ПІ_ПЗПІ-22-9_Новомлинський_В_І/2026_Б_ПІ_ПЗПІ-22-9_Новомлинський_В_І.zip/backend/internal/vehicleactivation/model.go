package vehicleactivation

import (
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type AdminCreateRequest struct {
	VIN          string `json:"vin"`
	Brand        string `json:"brand"`
	Model        string `json:"model"`
	Year         int    `json:"year"`
	LicensePlate string `json:"license_plate"`
	DeviceUID    string `json:"device_uid"`
	DeviceName   string `json:"device_name"`
}

type ClaimRequest struct {
	ActivationCode string `json:"activation_code"`
}

type Activation struct {
	ID        string     `json:"id"`
	VehicleID string     `json:"vehicle_id"`
	ExpiresAt time.Time  `json:"expires_at"`
	ClaimedAt *time.Time `json:"claimed_at"`
	ClaimedBy *string    `json:"claimed_by"`
	CreatedBy string     `json:"created_by"`
	CreatedAt time.Time  `json:"created_at"`
}

type AdminCreateResponse struct {
	Vehicle        vehicle.Vehicle `json:"vehicle"`
	Device         device.Device   `json:"device"`
	ActivationCode string          `json:"activation_code"`
	ActivationURI  string          `json:"activation_uri"`
	ExpiresAt      time.Time       `json:"expires_at"`
}

type CreateInput struct {
	Request      AdminCreateRequest
	CreatedBy    string
	CodeHash     string
	ExpiresAt    time.Time
	DefaultRules []DefaultThreshold
}

type DefaultThreshold struct {
	Parameter       string
	WarningValue    float64
	CriticalValue   float64
	RecoveryMargin  float64
	RecoverySamples int
}

type CreateResult struct {
	Vehicle    vehicle.Vehicle
	Device     device.Device
	Activation Activation
}
