﻿import emblemUrl from '../../assets/brand/autonexis-emblem-primary.svg';

type BrandMarkProps = {
  size?: number;
  mode?: 'icon' | 'full';
  label?: string;
  className?: string;
};

function Emblem({ size }: { size: number }) {
  return (
    <img
      src={emblemUrl}
      className="brand-mark__emblem"
      width={size}
      height={size}
      alt=""
      aria-hidden="true"
      decoding="async"
    />
  );
}

export function BrandMark({
  size = 40,
  mode = 'full',
  label = 'Autonexis',
  className = '',
}: BrandMarkProps) {
  const isIconOnly = mode === 'icon';

  return (
    <span
      className={`brand-mark brand-mark--${mode} ${className}`.trim()}
      aria-label={label}
      role="img"
    >
      <Emblem size={size} />
      {!isIconOnly && <span className="brand-mark__wordmark">Autonexis</span>}
    </span>
  );
}
