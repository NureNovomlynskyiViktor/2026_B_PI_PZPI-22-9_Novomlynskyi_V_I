package ownerdevice

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
	testDeviceID  = "33333333-3333-3333-3333-333333333333"
)

type stubDeviceService struct {
	devices         []device.Device
	device          device.Device
	err             error
	capturedOwner   string
	capturedVehicle string
	capturedDevice  string
	capturedInput   device.CreateRequest
}

func (s *stubDeviceService) ListByOwner(
	_ context.Context,
	ownerID string,
) ([]device.Device, error) {
	s.capturedOwner = ownerID
	return s.devices, s.err
}

func (s *stubDeviceService) ListByVehicleForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) ([]device.Device, error) {
	s.capturedOwner = ownerID
	s.capturedVehicle = vehicleID
	return s.devices, s.err
}

func (s *stubDeviceService) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	deviceID string,
) (device.Device, error) {
	s.capturedOwner = ownerID
	s.capturedDevice = deviceID
	return s.device, s.err
}

func (s *stubDeviceService) CreateForOwnedVehicle(
	_ context.Context,
	ownerID string,
	vehicleID string,
	request device.CreateRequest,
) (device.Device, error) {
	s.capturedOwner = ownerID
	s.capturedVehicle = vehicleID
	s.capturedInput = request
	return s.device, s.err
}

type stubVehicleService struct {
	err error
}

func (s stubVehicleService) GetByIDForOwner(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testVehicleID, OwnerID: testOwnerID}, s.err
}

func TestListRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(&stubDeviceService{}, stubVehicleService{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/me/devices", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestCreateForOwnedVehicle(t *testing.T) {
	service := &stubDeviceService{
		device: device.Device{
			ID:        testDeviceID,
			VehicleID: testVehicleID,
			DeviceUID: "esp32-user-001",
			Status:    "active",
		},
	}
	handler := NewHandler(service, stubVehicleService{}, testLogger())
	body := strings.NewReader(`{
		"device_uid":"esp32-user-001",
		"name":"My ESP32"
	}`)
	request := authenticatedRequest(
		http.MethodPost,
		"/api/v1/me/vehicles/"+testVehicleID+"/devices",
		body,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.CreateForVehicle(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if service.capturedOwner != testOwnerID {
		t.Fatalf("expected owner %s, got %s", testOwnerID, service.capturedOwner)
	}
	if service.capturedVehicle != testVehicleID {
		t.Fatalf("expected vehicle %s, got %s", testVehicleID, service.capturedVehicle)
	}
	if service.capturedInput.DeviceUID != "esp32-user-001" {
		t.Fatalf("expected decoded input, got %+v", service.capturedInput)
	}
}

func TestCreateForAnotherUsersVehicleReturnsNotFound(t *testing.T) {
	service := &stubDeviceService{}
	handler := NewHandler(
		service,
		stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	body := strings.NewReader(`{
		"device_uid":"esp32-user-001",
		"name":"My ESP32"
	}`)
	request := authenticatedRequest(
		http.MethodPost,
		"/api/v1/me/vehicles/"+testVehicleID+"/devices",
		body,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.CreateForVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
	if service.capturedOwner != "" {
		t.Fatal("expected device service not to be called")
	}
}

func TestListByVehicleForAnotherUsersVehicleReturnsNotFound(t *testing.T) {
	handler := NewHandler(
		&stubDeviceService{},
		stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/devices",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestDuplicateDeviceUIDReturnsConflict(t *testing.T) {
	handler := NewHandler(
		&stubDeviceService{err: device.ErrDuplicateUID},
		stubVehicleService{},
		testLogger(),
	)
	body := strings.NewReader(`{
		"device_uid":"esp32-user-001",
		"name":"My ESP32"
	}`)
	request := authenticatedRequest(
		http.MethodPost,
		"/api/v1/me/vehicles/"+testVehicleID+"/devices",
		body,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.CreateForVehicle(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func TestGetByIDRejectsInvalidUUID(t *testing.T) {
	handler := NewHandler(&stubDeviceService{}, stubVehicleService{}, testLogger())
	request := authenticatedRequest(http.MethodGet, "/api/v1/me/devices/not-a-uuid", nil)
	request.SetPathValue("device_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestGetAnotherUsersDeviceReturnsNotFound(t *testing.T) {
	handler := NewHandler(
		&stubDeviceService{err: device.ErrNotFound},
		stubVehicleService{},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/devices/"+testDeviceID,
		nil,
	)
	request.SetPathValue("device_id", testDeviceID)
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestListReturnsOnlyCurrentUserDevices(t *testing.T) {
	service := &stubDeviceService{
		devices: []device.Device{{
			ID:        testDeviceID,
			VehicleID: testVehicleID,
			DeviceUID: "esp32-user-001",
			Status:    "active",
		}},
	}
	handler := NewHandler(service, stubVehicleService{}, testLogger())
	request := authenticatedRequest(http.MethodGet, "/api/v1/me/devices", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.capturedOwner != testOwnerID {
		t.Fatalf("expected owner %s, got %s", testOwnerID, service.capturedOwner)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"device_uid":"esp32-user-001"`) {
		t.Fatalf("expected device JSON, got %s", body)
	}
}

func TestListByVehicleRejectsInvalidUUID(t *testing.T) {
	handler := NewHandler(&stubDeviceService{}, stubVehicleService{}, testLogger())
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/not-a-uuid/devices",
		nil,
	)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func authenticatedRequest(method string, path string, body io.Reader) *http.Request {
	request := httptest.NewRequest(method, path, body)
	return request.WithContext(auth.WithUser(
		request.Context(),
		auth.User{ID: testOwnerID, Email: "owner@example.com", Role: auth.DefaultRoleCode},
	))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
