package specialistrecommendation

import (
	"context"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

const (
	testVehicleID     = "11111111-1111-1111-1111-111111111111"
	engineSpecialist  = "22222222-2222-2222-2222-222222222222"
	generalSpecialist = "33333333-3333-3333-3333-333333333333"
)

type alertServiceStub struct {
	alerts []alert.Alert
}

func (s alertServiceStub) ListActiveByVehicle(
	context.Context,
	string,
) ([]alert.Alert, error) {
	return s.alerts, nil
}

type assignmentServiceStub struct {
	assignments []specialistassignment.Assignment
	counts      map[string]int
}

func (s assignmentServiceStub) ListByVehicle(
	context.Context,
	string,
) ([]specialistassignment.Assignment, error) {
	return s.assignments, nil
}

func (s assignmentServiceStub) ListSpecialists(context.Context) ([]auth.User, error) {
	return []auth.User{
		{ID: engineSpecialist, Email: "engine@example.com", Role: auth.TechnicalSpecialistRoleCode},
		{ID: generalSpecialist, Email: "general@example.com", Role: auth.TechnicalSpecialistRoleCode},
	}, nil
}

func (s assignmentServiceStub) CountBySpecialist(context.Context) (map[string]int, error) {
	return s.counts, nil
}

type competencyServiceStub struct {
	competencies []specialistcompetency.Competency
}

func (s competencyServiceStub) ListAll(
	context.Context,
) ([]specialistcompetency.Competency, error) {
	return s.competencies, nil
}

func TestRecommendRanksMatchingCompetenciesHigher(t *testing.T) {
	service := NewService(
		alertServiceStub{
			alerts: []alert.Alert{
				{VehicleID: testVehicleID, Type: "engine_temperature", Status: "active"},
			},
		},
		assignmentServiceStub{counts: map[string]int{}},
		competencyServiceStub{
			competencies: []specialistcompetency.Competency{
				{
					SpecialistID: engineSpecialist,
					Code:         specialistcompetency.CodeEngineDiagnostics,
					Name:         "Engine diagnostics",
				},
				{
					SpecialistID: generalSpecialist,
					Code:         specialistcompetency.CodeGeneralMaintenance,
					Name:         "General maintenance",
				},
			},
		},
	)

	result, err := service.Recommend(context.Background(), testVehicleID)
	if err != nil {
		t.Fatalf("recommend specialists: %v", err)
	}
	if len(result) != 2 {
		t.Fatalf("expected 2 recommendations, got %d", len(result))
	}
	if result[0].Specialist.ID != engineSpecialist {
		t.Fatalf("expected engine specialist first, got %s", result[0].Specialist.ID)
	}
	if result[0].Score <= result[1].Score {
		t.Fatalf("expected matching specialist to score higher")
	}
}

func TestRecommendMarksAlreadyAssignedSpecialist(t *testing.T) {
	service := NewService(
		alertServiceStub{
			alerts: []alert.Alert{
				{VehicleID: testVehicleID, Type: "vibration_level", Status: "active"},
			},
		},
		assignmentServiceStub{
			assignments: []specialistassignment.Assignment{
				{VehicleID: testVehicleID, SpecialistID: engineSpecialist},
			},
			counts: map[string]int{engineSpecialist: 2},
		},
		competencyServiceStub{
			competencies: []specialistcompetency.Competency{
				{
					SpecialistID: engineSpecialist,
					Code:         specialistcompetency.CodeVibrationAnalysis,
					Name:         "Vibration analysis",
				},
			},
		},
	)

	result, err := service.Recommend(context.Background(), testVehicleID)
	if err != nil {
		t.Fatalf("recommend specialists: %v", err)
	}

	var found bool
	for _, recommendation := range result {
		if recommendation.Specialist.ID == engineSpecialist {
			found = true
			if !recommendation.AlreadyAssigned {
				t.Fatal("expected specialist to be marked as already assigned")
			}
			if recommendation.ActiveAssignmentCount != 2 {
				t.Fatalf("expected assignment count 2, got %d", recommendation.ActiveAssignmentCount)
			}
		}
	}
	if !found {
		t.Fatal("expected engine specialist in recommendations")
	}
}

func TestRecommendUsesFallbackWhenNoActiveAlerts(t *testing.T) {
	service := NewService(
		alertServiceStub{},
		assignmentServiceStub{counts: map[string]int{}},
		competencyServiceStub{
			competencies: []specialistcompetency.Competency{
				{
					SpecialistID: generalSpecialist,
					Code:         specialistcompetency.CodeGeneralMaintenance,
					Name:         "General maintenance",
				},
			},
		},
	)

	result, err := service.Recommend(context.Background(), testVehicleID)
	if err != nil {
		t.Fatalf("recommend specialists: %v", err)
	}
	if len(result) == 0 || result[0].Specialist.ID != generalSpecialist {
		t.Fatal("expected general maintenance specialist first")
	}
	if result[0].Score == 0 {
		t.Fatal("expected fallback competency to receive a positive score")
	}
}
