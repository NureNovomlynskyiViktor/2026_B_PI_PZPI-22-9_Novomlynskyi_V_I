package notification

import (
	"context"
	"errors"
	"testing"
)

const (
	testUserID           = "11111111-1111-1111-1111-111111111111"
	testAlertID          = "22222222-2222-2222-2222-222222222222"
	testServiceRequestID = "33333333-3333-3333-3333-333333333333"
)

func TestCreateVehicleAlertNotification(t *testing.T) {
	repository := &fakeRepository{}
	service := NewService(repository)

	alertID := testAlertID
	item, err := service.Create(context.Background(), NewNotification{
		UserID:  testUserID,
		AlertID: &alertID,
		Title:   " WARNING alert ",
		Message: " Engine temperature warning. ",
	})
	if err != nil {
		t.Fatalf("Create returned error: %v", err)
	}
	if item.NotificationType != TypeVehicleAlert {
		t.Fatalf("expected default type %q, got %q", TypeVehicleAlert, item.NotificationType)
	}
	if repository.input.Title != "WARNING alert" {
		t.Fatalf("expected trimmed title, got %q", repository.input.Title)
	}
}

func TestCreateServiceRequestNotification(t *testing.T) {
	repository := &fakeRepository{}
	service := NewService(repository)

	requestID := testServiceRequestID
	item, err := service.Create(context.Background(), NewNotification{
		UserID:           testUserID,
		ServiceRequestID: &requestID,
		NotificationType: TypeServiceRequestCompleted,
		Title:            "Service request completed",
		Message:          "Result summary.",
	})
	if err != nil {
		t.Fatalf("Create returned error: %v", err)
	}
	if item.ServiceRequestID == nil || *item.ServiceRequestID != requestID {
		t.Fatalf("expected service request ID %q, got %#v", requestID, item.ServiceRequestID)
	}
}

func TestCreateRejectsInvalidNotification(t *testing.T) {
	service := NewService(&fakeRepository{})

	_, err := service.Create(context.Background(), NewNotification{
		UserID:           testUserID,
		NotificationType: TypeServiceRequestStarted,
		Title:            "Started",
		Message:          "Work started.",
	})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for missing references, got %v", err)
	}

	requestID := testServiceRequestID
	_, err = service.Create(context.Background(), NewNotification{
		UserID:           testUserID,
		ServiceRequestID: &requestID,
		NotificationType: "future_provider_specific_type",
		Title:            "Started",
		Message:          "Work started.",
	})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for invalid type, got %v", err)
	}

	alertID := testAlertID
	_, err = service.Create(context.Background(), NewNotification{
		UserID:           testUserID,
		AlertID:          &alertID,
		NotificationType: TypeServiceRequestAssigned,
		Title:            "Specialist assigned",
		Message:          "A technical specialist was assigned.",
	})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for mismatched reference type, got %v", err)
	}
}

type fakeRepository struct {
	input NewNotification
}

func (r *fakeRepository) Create(
	_ context.Context,
	input NewNotification,
) (Notification, error) {
	r.input = input
	return Notification{
		ID:               "44444444-4444-4444-4444-444444444444",
		UserID:           input.UserID,
		AlertID:          input.AlertID,
		ServiceRequestID: input.ServiceRequestID,
		NotificationType: input.NotificationType,
		Title:            input.Title,
		Message:          input.Message,
	}, nil
}

func (r *fakeRepository) ListByUser(context.Context, string) ([]Notification, error) {
	return nil, nil
}

func (r *fakeRepository) MarkReadForUser(
	context.Context,
	string,
	string,
) (Notification, error) {
	return Notification{}, nil
}
