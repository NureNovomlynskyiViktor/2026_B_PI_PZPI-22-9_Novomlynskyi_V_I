BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(128) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id UUID NOT NULL REFERENCES roles(id),
    email VARCHAR(320) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    full_name VARCHAR(255) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE oauth_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider VARCHAR(64) NOT NULL,
    provider_account_id VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT oauth_accounts_provider_account_unique
        UNIQUE (provider, provider_account_id)
);

CREATE TABLE vehicles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES users(id),
    vin VARCHAR(17) UNIQUE,
    brand VARCHAR(128) NOT NULL,
    model VARCHAR(128) NOT NULL,
    year SMALLINT,
    license_plate VARCHAR(32),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT vehicles_year_check
        CHECK (year IS NULL OR year BETWEEN 1886 AND 2100)
);

CREATE TABLE devices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id),
    device_uid VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(128),
    status VARCHAR(32) NOT NULL DEFAULT 'active',
    last_seen_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT devices_uid_format_check
        CHECK (device_uid ~ '^[A-Za-z0-9_-]{3,64}$'),
    CONSTRAINT devices_status_check
        CHECK (status IN ('active', 'inactive', 'lost', 'maintenance'))
);

CREATE TABLE telemetry_records (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    vehicle_id UUID NOT NULL REFERENCES vehicles(id),
    device_id UUID NOT NULL REFERENCES devices(id),
    measured_at TIMESTAMPTZ NOT NULL,
    received_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    engine_temperature NUMERIC(6, 2) NOT NULL,
    battery_voltage NUMERIC(6, 2) NOT NULL,
    vibration_level NUMERIC(7, 3) NOT NULL,
    rpm INTEGER NOT NULL,
    speed NUMERIC(6, 2) NOT NULL,
    fuel_level NUMERIC(5, 2) NOT NULL,
    CONSTRAINT telemetry_engine_temperature_check
        CHECK (engine_temperature BETWEEN -40 AND 150),
    CONSTRAINT telemetry_battery_voltage_check
        CHECK (battery_voltage BETWEEN 0 AND 24),
    CONSTRAINT telemetry_vibration_level_check
        CHECK (vibration_level BETWEEN 0 AND 100),
    CONSTRAINT telemetry_rpm_check
        CHECK (rpm BETWEEN 0 AND 10000),
    CONSTRAINT telemetry_speed_check
        CHECK (speed BETWEEN 0 AND 300),
    CONSTRAINT telemetry_fuel_level_check
        CHECK (fuel_level BETWEEN 0 AND 100)
);

CREATE TABLE threshold_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID REFERENCES vehicles(id),
    parameter VARCHAR(64) NOT NULL,
    warning_value NUMERIC(10, 3) NOT NULL,
    critical_value NUMERIC(10, 3) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT threshold_settings_parameter_check
        CHECK (
            parameter IN (
                'engine_temperature',
                'battery_voltage',
                'vibration_level',
                'rpm',
                'speed',
                'fuel_level'
            )
        ),
    CONSTRAINT threshold_settings_warning_value_check
        CHECK (
            CASE parameter
                WHEN 'engine_temperature' THEN warning_value BETWEEN -40 AND 150
                WHEN 'battery_voltage' THEN warning_value BETWEEN 0 AND 24
                WHEN 'vibration_level' THEN warning_value BETWEEN 0 AND 100
                WHEN 'rpm' THEN warning_value BETWEEN 0 AND 10000
                WHEN 'speed' THEN warning_value BETWEEN 0 AND 300
                WHEN 'fuel_level' THEN warning_value BETWEEN 0 AND 100
                ELSE FALSE
            END
        ),
    CONSTRAINT threshold_settings_critical_value_check
        CHECK (
            CASE parameter
                WHEN 'engine_temperature' THEN critical_value BETWEEN -40 AND 150
                WHEN 'battery_voltage' THEN critical_value BETWEEN 0 AND 24
                WHEN 'vibration_level' THEN critical_value BETWEEN 0 AND 100
                WHEN 'rpm' THEN critical_value BETWEEN 0 AND 10000
                WHEN 'speed' THEN critical_value BETWEEN 0 AND 300
                WHEN 'fuel_level' THEN critical_value BETWEEN 0 AND 100
                ELSE FALSE
            END
        )
);

CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id),
    telemetry_record_id BIGINT NOT NULL REFERENCES telemetry_records(id),
    type VARCHAR(64) NOT NULL,
    severity VARCHAR(32) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'active',
    message TEXT NOT NULL,
    recommendation TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMPTZ,
    CONSTRAINT alerts_severity_check
        CHECK (severity IN ('info', 'warning', 'critical')),
    CONSTRAINT alerts_status_check
        CHECK (status IN ('active', 'resolved'))
);

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    alert_id UUID NOT NULL REFERENCES alerts(id),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(128) NOT NULL,
    entity_type VARCHAR(128) NOT NULL,
    entity_id VARCHAR(255),
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maintenance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id),
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    service_date DATE NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX telemetry_records_vehicle_measured_at_idx
    ON telemetry_records (vehicle_id, measured_at DESC);

CREATE INDEX telemetry_records_device_measured_at_idx
    ON telemetry_records (device_id, measured_at DESC);

CREATE INDEX threshold_settings_vehicle_parameter_idx
    ON threshold_settings (vehicle_id, parameter);

CREATE INDEX alerts_vehicle_status_idx
    ON alerts (vehicle_id, status);

CREATE INDEX notifications_user_is_read_idx
    ON notifications (user_id, is_read);

INSERT INTO roles (id, code, name, description)
VALUES
    (
        '00000000-0000-0000-0000-000000000001',
        'vehicle_owner',
        'Власник автомобіля',
        'Користувач, який контролює технічний стан власного автомобіля'
    ),
    (
        '00000000-0000-0000-0000-000000000002',
        'technical_specialist',
        'Технічний спеціаліст',
        'Користувач, який аналізує телеметрію та попередження'
    ),
    (
        '00000000-0000-0000-0000-000000000003',
        'administrator',
        'Адміністратор',
        'Користувач, який виконує базове адміністрування системи'
    );

COMMIT;
