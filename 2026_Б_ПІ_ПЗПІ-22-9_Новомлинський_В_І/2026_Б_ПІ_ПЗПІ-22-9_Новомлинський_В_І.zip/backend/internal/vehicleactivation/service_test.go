package vehicleactivation

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testAdminID   = "33333333-3333-3333-3333-333333333333"
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
	testDeviceID  = "44444444-4444-4444-4444-444444444444"
)

type repositoryStub struct {
	createInput CreateInput
	claimOwner  string
	claimCodeOK bool
	errCreate   error
	errClaim    error
}

func (r *repositoryStub) CreateUnclaimed(
	_ context.Context,
	input CreateInput,
) (CreateResult, error) {
	r.createInput = input
	if r.errCreate != nil {
		return CreateResult{}, r.errCreate
	}

	return CreateResult{
		Vehicle: vehicle.Vehicle{
			ID:      testVehicleID,
			Brand:   input.Request.Brand,
			Model:   input.Request.Model,
			OwnerID: "",
		},
		Device: device.Device{
			ID:        testDeviceID,
			VehicleID: testVehicleID,
			DeviceUID: input.Request.DeviceUID,
			Status:    "inactive",
		},
		Activation: Activation{
			ID:        "55555555-5555-5555-5555-555555555555",
			VehicleID: testVehicleID,
			ExpiresAt: input.ExpiresAt,
			CreatedBy: input.CreatedBy,
		},
	}, nil
}

func (r *repositoryStub) Claim(
	_ context.Context,
	ownerID string,
	_ string,
	verify func(hash string) bool,
	_ time.Time,
) (vehicle.Vehicle, error) {
	r.claimOwner = ownerID
	r.claimCodeOK = verify("hashed-code")
	if r.errClaim != nil {
		return vehicle.Vehicle{}, r.errClaim
	}

	return vehicle.Vehicle{ID: testVehicleID, OwnerID: ownerID}, nil
}

type hasherStub struct {
	raw    string
	hash   string
	verify bool
	err    error
}

func (h *hasherStub) Hash(value string) (string, error) {
	h.raw = value
	if h.err != nil {
		return "", h.err
	}
	return h.hash, nil
}

func (h *hasherStub) Verify(hash string, value string) bool {
	h.raw = value
	return hash == "hashed-code" && h.verify
}

func TestServiceCreateSuccessfulAdminOnboarding(t *testing.T) {
	repository := &repositoryStub{}
	hasher := &hasherStub{hash: "hashed-code"}
	service := &service{
		repository: repository,
		hasher:     hasher,
		now:        func() time.Time { return time.Date(2026, 6, 17, 12, 0, 0, 0, time.UTC) },
		generate:   func() (string, error) { return "ax7k29qp", nil },
	}

	result, err := service.Create(
		context.Background(),
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
		AdminCreateRequest{
			VIN:          " autonexisdemo0002 ",
			Brand:        "Toyota",
			Model:        "Corolla",
			Year:         2022,
			LicensePlate: " ax-0002 ",
			DeviceUID:    "esp32-demo-002",
			DeviceName:   "Owner ESP32",
		},
	)
	if err != nil {
		t.Fatalf("Create() returned an error: %v", err)
	}
	if result.ActivationCode != "AX7K-29QP" {
		t.Fatalf("expected normalized activation code, got %s", result.ActivationCode)
	}
	if result.ActivationURI != "autonexis://vehicle-activation?code=AX7K-29QP" {
		t.Fatalf("expected activation URI for normalized code, got %s", result.ActivationURI)
	}
	if result.Device.Status != "inactive" {
		t.Fatalf("expected inactive device, got %s", result.Device.Status)
	}
	if repository.createInput.Request.VIN != "AUTONEXISDEMO0002" {
		t.Fatalf("expected normalized VIN, got %s", repository.createInput.Request.VIN)
	}
	if repository.createInput.CodeHash != "hashed-code" {
		t.Fatalf("expected hashed code to be stored, got %s", repository.createInput.CodeHash)
	}
	if repository.createInput.CodeHash == result.ActivationCode {
		t.Fatal("activation code plaintext was stored")
	}
	if hasher.raw != "AX7K-29QP" {
		t.Fatalf("expected normalized code passed to hasher, got %s", hasher.raw)
	}
	if len(repository.createInput.DefaultRules) != 4 {
		t.Fatalf("expected four default thresholds, got %d", len(repository.createInput.DefaultRules))
	}
	if repository.createInput.DefaultRules[0].Parameter != "engine_temperature" ||
		repository.createInput.DefaultRules[1].Parameter != "battery_voltage" ||
		repository.createInput.DefaultRules[2].Parameter != "vibration_level" ||
		repository.createInput.DefaultRules[3].Parameter != "rpm" {
		t.Fatalf("unexpected default thresholds: %#v", repository.createInput.DefaultRules)
	}
}

func TestServiceCreateRejectsInvalidNonAdminAndDuplicates(t *testing.T) {
	service := &service{
		repository: &repositoryStub{},
		hasher:     &hasherStub{hash: "hashed-code"},
		now:        time.Now,
		generate:   func() (string, error) { return "AX7K-29QP", nil },
	}

	_, err := service.Create(context.Background(), auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode}, AdminCreateRequest{})
	if !errors.Is(err, auth.ErrUnauthorized) {
		t.Fatalf("expected ErrUnauthorized for non-admin, got %v", err)
	}

	_, err = service.Create(
		context.Background(),
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
		AdminCreateRequest{VIN: "", Year: 2022},
	)
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}

	service.repository = &repositoryStub{errCreate: ErrDuplicateVIN}
	_, err = service.Create(
		context.Background(),
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
		validCreateRequest(),
	)
	if !errors.Is(err, ErrDuplicateVIN) {
		t.Fatalf("expected ErrDuplicateVIN, got %v", err)
	}

	service.repository = &repositoryStub{errCreate: ErrDuplicateDevice}
	_, err = service.Create(
		context.Background(),
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
		validCreateRequest(),
	)
	if !errors.Is(err, ErrDuplicateDevice) {
		t.Fatalf("expected ErrDuplicateDevice, got %v", err)
	}
}

func TestServiceClaim(t *testing.T) {
	repository := &repositoryStub{}
	service := &service{
		repository: repository,
		hasher:     &hasherStub{verify: true},
		now:        func() time.Time { return time.Date(2026, 6, 17, 12, 0, 0, 0, time.UTC) },
		generate:   func() (string, error) { return "AX7K-29QP", nil },
	}

	item, err := service.Claim(
		context.Background(),
		auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode},
		ClaimRequest{ActivationCode: " ax7k 29qp "},
	)
	if err != nil {
		t.Fatalf("Claim() returned an error: %v", err)
	}
	if item.OwnerID != testOwnerID {
		t.Fatalf("expected vehicle owner %s, got %s", testOwnerID, item.OwnerID)
	}
	if repository.claimOwner != testOwnerID {
		t.Fatalf("expected claim owner %s, got %s", testOwnerID, repository.claimOwner)
	}
	if !repository.claimCodeOK {
		t.Fatal("expected normalized activation code to verify")
	}
}

func TestServiceClaimRejectsInvalidExpiredUsedAndConcurrentClaims(t *testing.T) {
	service := &service{
		repository: &repositoryStub{},
		hasher:     &hasherStub{verify: true},
		now:        time.Now,
		generate:   func() (string, error) { return "AX7K-29QP", nil },
	}

	_, err := service.Claim(context.Background(), auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode}, ClaimRequest{ActivationCode: "AX7K-29QP"})
	if !errors.Is(err, auth.ErrUnauthorized) {
		t.Fatalf("expected ErrUnauthorized for non-owner, got %v", err)
	}

	_, err = service.Claim(context.Background(), auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode}, ClaimRequest{ActivationCode: "bad"})
	if !errors.Is(err, ErrInvalidCode) {
		t.Fatalf("expected ErrInvalidCode, got %v", err)
	}

	for _, expected := range []error{ErrInvalidCode, ErrExpiredCode, ErrAlreadyClaimed, ErrVehicleClaimed} {
		service.repository = &repositoryStub{errClaim: expected}
		_, err = service.Claim(
			context.Background(),
			auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode},
			ClaimRequest{ActivationCode: "AX7K-29QP"},
		)
		if !errors.Is(err, expected) {
			t.Fatalf("expected %v, got %v", expected, err)
		}
	}
}

func validCreateRequest() AdminCreateRequest {
	return AdminCreateRequest{
		VIN:          "AUTONEXISDEMO0002",
		Brand:        "Toyota",
		Model:        "Corolla",
		Year:         2022,
		LicensePlate: "AX-0002",
		DeviceUID:    "esp32-demo-002",
		DeviceName:   "Owner ESP32",
	}
}
