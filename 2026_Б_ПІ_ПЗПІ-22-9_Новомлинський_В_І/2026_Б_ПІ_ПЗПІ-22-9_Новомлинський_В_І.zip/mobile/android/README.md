# Autonexis Android Owner App

This directory contains the initial native Android Kotlin foundation for the Autonexis vehicle owner mobile app.

The app is intentionally simple at this stage. It is meant to demonstrate the owner-facing flow of the basic functional version while the web dashboard remains focused on technical specialist and administrator workflows.

## Compose Application Foundation

The application shell, authentication flow, owner vehicle list, vehicle activation entry, vehicle details overview, latest telemetry summary, alert lifecycle presentation, owner service-request flow, global Requests tab, notification center, Account Center, telemetry history, and maintenance history now use Jetpack Compose with a focused Autonexis Material 3 theme. The migrated Compose screens are:

- session restoration/loading;
- Login;
- Register;
- unsupported-role notice for authenticated staff accounts;
- Owner Vehicles;
- Connect Vehicle with manual activation-code entry and QR scanner bridge;
- Vehicle Details overview;
- alert lifecycle presentation;
- latest telemetry summary;
- Resolved incident history screen;
- Service Requests list;
- Service Request details;
- Service Request creation form.
- Notifications center.
- Recent Telemetry history.
- Maintenance History.

After a vehicle owner authenticates successfully, the app stays in the Compose owner shell for the vehicle list, Connect Vehicle flow, Vehicle Details overview, Service Requests flow, global Requests tab, Notifications flow, Account Center, Recent Telemetry history, and Maintenance History. The owner bottom navigation exposes four working destinations: Vehicles, Requests, Notifications, and Account. It uses local vector icons and Autonexis blue selected-state styling.

Compose uses the canonical Autonexis emblem as an Android vector asset and a Material 3 theme based on deep navy, electric blue, emerald green, amber, critical red, light gray, and white. The app supports persistent System default, Light, and Dark appearance modes plus persistent System default, English, and Ukrainian language modes.

## Implemented Screens

- Compose Login screen.
- Compose Register screen.
- Compose session-restoration loading screen.
- Compose unsupported-role screen for staff accounts.
- Compose Owner Vehicles screen with branded loading, refresh, empty, and error states.
- Compose Connect Vehicle screen with manual activation-code entry and the existing QR scanner bridge.
- Compose Notifications screen for in-app vehicle alerts and service-request updates.
- Compose Account Center with profile, sign-in methods, logout, and Google account linking.
- Compose vehicle status/details overview.
- Compose service request screens for creating and tracking owner diagnostic requests.
- Compose Recent Telemetry dashboard with real-data summaries and native trend visualization.
- Compose Maintenance History timeline screen.

The Compose vehicle details overview shows:

- current user-owned vehicle data;
- assigned device information if available;
- overall vehicle status;
- latest telemetry summary;
- alert incidents grouped by active, cleared, and resolved lifecycle state;
- owner service requests, including requests linked to active warning/critical alerts;
- read-only technical thresholds.

Threshold editing is not available in the owner mobile app.

## Backend API Integration

The app uses the existing backend endpoints:

- `POST /api/v1/auth/login`
- `POST /api/v1/auth/google`
- `GET /api/v1/auth/me`
- `GET /api/v1/auth/methods`
- `POST /api/v1/auth/google/link`
- `GET /api/v1/me/vehicles`
- `POST /api/v1/me/vehicle-activations/claim`
- `GET /api/v1/me/vehicles/{vehicle_id}/status`
- `GET /api/v1/me/vehicles/{vehicle_id}/alerts?limit=50`
- `GET /api/v1/me/vehicles/{vehicle_id}/telemetry?limit=20`
- `GET /api/v1/me/vehicles/{vehicle_id}/maintenance-records`
- `GET /api/v1/me/vehicles/{vehicle_id}/thresholds`
- `GET /api/v1/me/service-requests`
- `POST /api/v1/me/vehicles/{vehicle_id}/service-requests`
- `PATCH /api/v1/me/service-requests/{request_id}/cancel`
- `GET /api/v1/me/notifications`
- `PATCH /api/v1/me/notifications/{notification_id}/read`

The JWT access token is encrypted at rest as described in Session Storage Security below. The backend URL remains normal local configuration and is not treated as a secret.


## Appearance Settings

The owner app supports three appearance modes:

- `System default`: follows the device light/dark setting.
- `Light`: always uses the branded light Autonexis theme.
- `Dark`: always uses the branded dark Autonexis theme.

The setting is available in `Account` under the `Appearance` section. It applies immediately without a Save button, app restart, or navigation reset. The selected mode is stored in ordinary app preferences because it is non-sensitive configuration; it is separate from encrypted JWT storage and remains unchanged after login, logout, process death, and emulator restart. Malformed stored values safely fall back to `System default`.

The dark theme keeps the Autonexis brand direction with deep navy backgrounds, elevated dark-blue surfaces, electric/light-blue primary accents, readable foreground text, visible outlines, and adapted success, warning, critical, and neutral status colors. The app does not use Android dynamic colors so the brand remains consistent across devices.

## Language Settings

The owner app supports three language modes in `Account` under the `Language` section:

- `System default`: follows Android per-app/system locale settings. Unsupported locales fall back to the default English resources.
- `English`: forces English resources for this app.
- `Ukrainian`: forces Ukrainian resources for this app.

Language selection uses Android's official per-app locale mechanism through AppCompat so it works across the supported minSdk 26 through target SDK 35 range. The selected language is non-sensitive device preference data stored separately from appearance settings and encrypted JWT session storage. It applies immediately without a Save button, preserves the authenticated session, and returns the user to Account after the locale-triggered Activity recreation.

New owner-facing Compose screens should render user-visible static text through `res/values/strings.xml` and `res/values-uk/strings.xml` with `stringResource` or `pluralStringResource`. Backend-provided data such as vehicle names, alert messages, maintenance titles, service-request descriptions, and API error details remain server/user content and are displayed as received after safe error mapping where applicable.
## Session Storage Security

The owner app encrypts the persisted Autonexis JWT with an Android Keystore-managed AES-GCM key:

- Keystore provider: `AndroidKeyStore`;
- cipher: `AES/GCM/NoPadding`;
- key alias: `autonexis_session_token_key_v1`;
- associated authenticated data: `ua.autonexis.mobile:session-token:v1`.

The secure session file stores only the ciphertext, IV, and token format version. The plaintext token exists only temporarily while encrypting, decrypting for session restoration, or sending authenticated API requests. The app does not log the token, IV, ciphertext, or key material.

The backend URL remains in the existing ordinary preferences because it is local configuration, not a secret.

Upgrades from the previous plaintext `access_token` are migrated automatically on first token read. If migration succeeds, the plaintext value is removed. If migration fails, or if the encrypted envelope is incomplete, malformed, corrupted, tied to a missing/invalidated Keystore key, or otherwise unreadable, the app clears token state and safely returns to Login instead of crashing.

The secure-session SharedPreferences file is excluded from Android cloud backup and device transfer through both `dataExtractionRules` and legacy `fullBackupContent`. This protects the encrypted token envelope from being restored onto a device where the Keystore key is unavailable.

This protects the token at rest for normal device and backup scenarios. It does not claim protection against a fully compromised running application, a rooted device, memory inspection, or malware with control of the user session.
## Service Requests

On the vehicle status screen, owners can open the Compose `Service Requests` flow to view diagnostic/service requests for the selected vehicle. They can create a manual request for vehicles in any state, including `NORMAL`, `UNKNOWN`, `WARNING`, and `CRITICAL`. The top-level `Requests` tab loads all owner requests through `GET /api/v1/me/service-requests`, sorts them newest-first, shows the related vehicle label when known, and opens the same Compose request detail UI. Global request creation is intentionally hidden because creation requires a selected vehicle context.

Each warning or critical alert incident in the active or cleared lifecycle sections also offers `Create service request`. The app opens an editable form prefilled from the alert type, message, and recommendation. Critical alerts default to `high` priority; warning alerts default to `normal` priority. The request is linked to the alert through `source_alert_id`, but creating the request does not resolve the alert.

Requests are sorted newest-first by creation time, with updated time used as a fallback. The list uses an inline full-width create button only when the vehicle has no requests; otherwise it uses a bottom-reachable create action. Details hide raw internal IDs, show whether a technical specialist has been assigned, and display lifecycle timestamps and result summaries when available.

Only pending service requests can be cancelled from the owner app. Cancellation uses a confirmation dialog and updates the local request state with the backend response. Completed requests display the specialist result summary when available.

## Alert Lifecycle

Vehicle details load the current status and a separate all-alert list from:

```http
GET /api/v1/me/vehicles/{vehicle_id}/alerts?limit=50
```

The Compose vehicle details overview groups incidents into:

- `Active conditions`: ongoing warning or critical conditions. The owner can create a service request, but cannot manually resolve the incident while it is active.
- `Cleared - awaiting inspection`: telemetry has stabilized, but the root cause is not confirmed repaired. Technical specialist confirmation is required. The owner can still create a service request unless an open linked request already exists.
- `Resolved incidents`: specialist-confirmed incident history and read-only in the app. Older resolved incidents without specialist metadata remain visible as legacy/manual incident history.

The backend `severity` field is the maximum severity reached during an incident. `current_severity` is shown only for active incidents. The app also displays occurrence count, recovery progress, last-triggered time, cleared time, and resolved time when available.

Resolved incidents may include `resolved_by_user_id`, `resolution_note`, and `resolution_service_request_id`. The Vehicle Details overview shows a compact resolved-incident preview, while `View all resolved incidents` opens a dedicated Compose history screen using the already loaded data. When the linked service request is present in the owner's request list, the full history screen displays its title, status, and result summary.

If current telemetry is `NORMAL`, no active condition exists, and a cleared critical incident remains, the app shows:

```text
Current telemetry is normal, but inspection is still recommended.
```

Unknown future alert statuses are shown in a neutral historical section rather than crashing the UI.

## Recent Telemetry Dashboard

The Recent Telemetry screen is a Compose dashboard backed only by records returned from:

```http
GET /api/v1/me/vehicles/{vehicle_id}/telemetry?limit=20
```

It shows the latest telemetry snapshot, factual data overview, a local metric selector, native Compose Canvas trend visualization, selected-metric current/minimum/average/maximum statistics, and a compact recent-measurements history. The chart uses equal sample spacing and does not infer real-time sampling intervals, vehicle health, threshold status, predictions, recommendations, or online/offline state.
## In-app Notifications

The Notifications screen reads provider-neutral in-app notification records from PostgreSQL through the backend. It supports vehicle-alert notifications and service-request lifecycle updates:

- `vehicle_alert`
- `service_request_assigned`
- `service_request_started`
- `service_request_completed`

Vehicle-alert notifications can include `alert_id` and show severity when it is available from the notification title or message. Service-request notifications can include `service_request_id`; the app shows `View service request`, loads the owner's service requests, and opens the existing Compose service-request detail view with title, description, priority, status, assigned specialist state, timestamps, and result summary. Back from a request opened through Notifications returns to the Notifications screen.

The unread count is synced best-effort when the owner dashboard is entered, refreshed, or updated after connecting a vehicle. The Notifications screen includes a local `Hide read notifications` filter; when unread-only mode is active, marking a notification as read removes it from the visible list immediately while preserving the backend state update. The app does not use Firebase Cloud Messaging, background polling, or Android system push notifications in this step. Notifications remain an authenticated in-app screen, and `Mark as read` uses the existing backend endpoint.

## Vehicle Activation QR Codes

Administrators register unclaimed vehicles in the web dashboard. The dashboard displays a one-time plaintext activation code and a QR code only immediately after registration. The canonical QR payload format is:

```text
autonexis://vehicle-activation?code={ACTIVATION_CODE}
```

Example:

```text
autonexis://vehicle-activation?code=RNF6-CQSD
```

The QR code contains the same sensitive one-time activation credential as the displayed code. The owner app also supports manual code entry. Scanning a QR code only extracts and fills the activation-code field; the owner must review it and press `Connect`. The final claim still uses the existing authenticated endpoint:

```http
POST /api/v1/me/vehicle-activations/claim
```

The Connect Vehicle screen is Compose-based, but QR scanning itself remains the existing Activity-managed bridge. Compose triggers scanning through a callback; MainActivity keeps responsibility for camera permission, `IntentIntegrator`, QR parsing through `ActivationCodeParser`, and returning the scanned code or safe error message to Compose state. Activation codes are never persisted to disk.

## Compose Owner Flow

All owner-facing screens are now Compose-based:

```text
- Auth
- Session restoration
- Unsupported role
- Owner Vehicles
- Connect Vehicle
- Vehicle Details overview
- Alert lifecycle presentation
- Latest telemetry summary
- Resolved incident history
- Service Requests
- Notifications
- Recent Telemetry history
- Maintenance History
```

The Owner Vehicles bottom navigation exposes only working destinations: `Vehicles`, `Requests`, `Notifications`, and `Account`. All destinations stay in Compose, use icon-based navigation items, preserve the notification unread count, and keep the selected state aligned with the Autonexis deep navy/electric blue palette. Opening a notification-linked service request uses the same Compose service-request detail UI as the normal owner request flow, with an explicit return path back to Notifications. Opening a vehicle card transitions to the Compose Vehicle Details overview. From there, Recent Telemetry, Maintenance History, Service Requests, and Service Request creation stay in Compose. Navigation back to vehicle details reloads the Compose Vehicle Details overview through `showVehicleDetails(...)`, while `showVehiclesScreen(...)` returns to the Compose Owner Vehicles screen.

## Google Sign-In
The Compose Login screen supports explicit Sign in with Google through Android Credential Manager and the backend endpoint:

```http
POST /api/v1/auth/google
```

Google determines the user's identity. Autonexis still owns account roles: new Google accounts are created as `vehicle_owner` accounts, while technical specialists and administrators should use administrator-provided credentials.

Configure the public Web OAuth Client ID locally in `mobile/android/local.properties`:

```properties
autonexis.googleWebClientId=your-web-client-id.apps.googleusercontent.com
```

This value is a public Web Client ID, not a secret. Do not commit `local.properties`. The backend must allow the same Web Client ID in its Google authentication configuration. The Android OAuth client remains configured in Google Cloud by package name and SHA-1 fingerprint.

If `autonexis.googleWebClientId` is blank, the app hides the Google button and keeps email/password Login and Register working normally. Emulators and physical devices need current Google Play Services for Credential Manager Google sign-in.

Google sign-in stores only the Autonexis JWT access token returned by the backend. The Google ID token is exchanged immediately and is not persisted by the app.

Authenticated owners can open `Account` to view profile data and sign-in methods from `GET /api/v1/auth/methods`. If Google is not connected and `autonexis.googleWebClientId` is configured, `Connect Google account` uses Credential Manager to obtain a Google ID token and sends it only to `POST /api/v1/auth/google/link`. Linking does not replace the current Autonexis JWT, role, vehicles, or owner data. Google unlinking is not available because the backend does not support it yet.

## Demo Account

Use the development seed account:

- Email: `owner@example.com`
- Password: `DemoPass123!`

Seeded accounts are for local development and demonstration only.

## Backend Base URL

Default Android Emulator URL:

```text
http://10.0.2.2:8080
```

Use `10.0.2.2` because Android Emulator maps that address to the host machine running the Go backend.

For a USB-connected physical phone with adb reverse enabled:

```text
http://127.0.0.1:8080
```

Set up adb reverse from PowerShell:

```powershell
$adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
& $adb reverse tcp:8080 tcp:8080
```

The default API URL is generated into `BuildConfig.API_BASE_URL`. To override it locally, create or edit `mobile/android/local.properties`:

```properties
autonexis.apiBaseUrl=http://127.0.0.1:8080
```

Do not commit `local.properties`. The app still preserves any URL saved from the login screen in `SharedPreferences`.

## Run Backend Locally

From the repository root:

```powershell
docker compose up -d
```

Apply migrations and the development seed as described in `backend/README.md`, then start the backend:

```powershell
cd backend
go run ./cmd/server
```

## Open in Android Studio

1. Open Android Studio.
2. Select `Open`.
3. Choose `mobile/android`.
4. Let Android Studio sync Gradle. Compose dependencies are part of the app module and should resolve during sync.
5. Start an Android Emulator.
6. Run the `app` configuration.

On the login screen, keep the default backend URL for the emulator:

```text
http://10.0.2.2:8080
```

Then log in as `owner@example.com` with password `DemoPass123!`.

## Planned Next Steps

- Add advanced Recent Telemetry visualization polish, such as charts, after the backend data contract and demo needs justify it.
- Keep authentication and session flows covered by focused unit tests as the UI evolves.
- Add push-notification foundation for critical alerts.
- Add better offline/error states.
- Add vehicle and device creation flows only if they are needed in the mobile client.
