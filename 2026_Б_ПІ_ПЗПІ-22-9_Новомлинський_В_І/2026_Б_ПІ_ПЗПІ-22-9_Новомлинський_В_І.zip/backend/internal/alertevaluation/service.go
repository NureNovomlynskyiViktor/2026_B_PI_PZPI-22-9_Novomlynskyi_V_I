package alertevaluation

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

var (
	ErrInvalidVehicleID  = errors.New("invalid vehicle ID")
	ErrVehicleNotFound   = errors.New("vehicle not found")
	ErrTelemetryNotFound = errors.New("telemetry not found")
)

type VehicleService interface {
	GetByID(ctx context.Context, id string) (vehicle.Vehicle, error)
}

type TelemetryService interface {
	LatestByVehicle(ctx context.Context, vehicleID string) (telemetry.Record, error)
}

type ThresholdService interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]threshold.Setting, error)
}

type AlertWriter interface {
	ApplyEvaluation(
		ctx context.Context,
		input alert.NewAlert,
	) (alert.Alert, alert.LifecycleAction, error)
	ApplyRecovery(
		ctx context.Context,
		input alert.RecoveryInput,
	) (alert.Alert, alert.LifecycleAction, error)
}

type NotificationWriter interface {
	Create(
		ctx context.Context,
		input notification.NewNotification,
	) (notification.Notification, error)
}

type Service interface {
	Evaluate(ctx context.Context, vehicleID string) (Result, error)
	EvaluateRecord(ctx context.Context, record telemetry.Record) (Result, error)
}

type service struct {
	vehicles      VehicleService
	telemetry     TelemetryService
	thresholds    ThresholdService
	alerts        AlertWriter
	notifications NotificationWriter
}

func NewService(
	vehicles VehicleService,
	telemetryService TelemetryService,
	thresholds ThresholdService,
	alerts AlertWriter,
	notifications NotificationWriter,
) Service {
	return &service{
		vehicles:      vehicles,
		telemetry:     telemetryService,
		thresholds:    thresholds,
		alerts:        alerts,
		notifications: notifications,
	}
}

func (s *service) Evaluate(ctx context.Context, vehicleID string) (Result, error) {
	if !identifier.IsUUID(vehicleID) {
		return Result{}, ErrInvalidVehicleID
	}

	item, err := s.vehicles.GetByID(ctx, vehicleID)
	if errors.Is(err, vehicle.ErrNotFound) {
		return Result{}, ErrVehicleNotFound
	} else if err != nil {
		return Result{}, err
	}

	record, err := s.telemetry.LatestByVehicle(ctx, vehicleID)
	if errors.Is(err, telemetry.ErrNotFound) {
		return Result{}, ErrTelemetryNotFound
	}
	if err != nil {
		return Result{}, err
	}

	return s.evaluateRecord(ctx, item, record)
}

func (s *service) EvaluateRecord(
	ctx context.Context,
	record telemetry.Record,
) (Result, error) {
	if !identifier.IsUUID(record.VehicleID) {
		return Result{}, ErrInvalidVehicleID
	}

	item, err := s.vehicles.GetByID(ctx, record.VehicleID)
	if errors.Is(err, vehicle.ErrNotFound) {
		return Result{}, ErrVehicleNotFound
	}
	if err != nil {
		return Result{}, err
	}

	return s.evaluateRecord(ctx, item, record)
}

func (s *service) evaluateRecord(
	ctx context.Context,
	vehicleItem vehicle.Vehicle,
	record telemetry.Record,
) (Result, error) {
	settings, err := s.thresholds.ListByVehicle(ctx, record.VehicleID)
	if err != nil {
		return Result{}, err
	}

	result := Result{
		VehicleID:         record.VehicleID,
		TelemetryRecordID: record.ID,
		EvaluatedRules:    len(settings),
		CreatedAlerts:     make([]alert.Alert, 0),
		ExistingAlerts:    make([]alert.Alert, 0),
		UpdatedAlerts:     make([]alert.Alert, 0),
		ResolvedAlerts:    make([]alert.Alert, 0),
		OverallResult:     "normal",
	}
	processed := make(map[string]struct{})

	for _, setting := range settings {
		if _, _, ok := telemetryValue(record, setting.Parameter); !ok {
			continue
		}
		if _, exists := processed[setting.Parameter]; exists {
			continue
		}
		processed[setting.Parameter] = struct{}{}

		value, severity, exceeded := evaluate(record, setting)
		if !exceeded {
			item, action, err := s.alerts.ApplyRecovery(
				ctx,
				alert.RecoveryInput{
					VehicleID:         record.VehicleID,
					TelemetryRecordID: record.ID,
					Type:              setting.Parameter,
					Recovered:         isRecovered(record, setting),
					RequiredSamples:   recoverySamples(setting),
				},
			)
			if err != nil {
				return Result{}, err
			}
			if action == alert.LifecycleCleared {
				if err := s.createNotification(ctx, vehicleItem, item, action); err != nil {
					return Result{}, err
				}
				result.ResolvedAlerts = append(result.ResolvedAlerts, item)
			} else if item.ID != "" && item.Status == alert.StatusActive {
				result.ExistingAlerts = append(result.ExistingAlerts, item)
				result.OverallResult = higherSeverity(
					result.OverallResult,
					effectiveCurrentSeverity(item),
				)
			}
			continue
		}

		item, action, err := s.alerts.ApplyEvaluation(
			ctx,
			alert.NewAlert{
				VehicleID:         record.VehicleID,
				TelemetryRecordID: record.ID,
				Type:              setting.Parameter,
				Severity:          severity,
				Message:           alertMessage(setting.Parameter, severity, value),
				Recommendation:    recommendation(setting.Parameter, severity),
			},
		)
		if err != nil {
			return Result{}, err
		}

		switch action {
		case alert.LifecycleCreated:
			if err := s.createNotification(ctx, vehicleItem, item, action); err != nil {
				return Result{}, err
			}
			result.CreatedAlerts = append(result.CreatedAlerts, item)
		case alert.LifecycleEscalated:
			if err := s.createNotification(ctx, vehicleItem, item, action); err != nil {
				return Result{}, err
			}
			result.UpdatedAlerts = append(result.UpdatedAlerts, item)
		case alert.LifecycleReopened:
			if err := s.createNotification(ctx, vehicleItem, item, action); err != nil {
				return Result{}, err
			}
			result.UpdatedAlerts = append(result.UpdatedAlerts, item)
		case alert.LifecycleUpdated:
			result.UpdatedAlerts = append(result.UpdatedAlerts, item)
		default:
			result.ExistingAlerts = append(result.ExistingAlerts, item)
		}
		result.OverallResult = higherSeverity(
			result.OverallResult,
			effectiveCurrentSeverity(item),
		)
	}

	return result, nil
}

func (s *service) createNotification(
	ctx context.Context,
	vehicleItem vehicle.Vehicle,
	item alert.Alert,
	action alert.LifecycleAction,
) error {
	if s.notifications == nil {
		return nil
	}

	severity := effectiveCurrentSeverity(item)
	title := fmt.Sprintf("%s alert: %s", strings.ToUpper(severity), item.Type)
	messagePrefix := strings.ToUpper(severity)
	switch action {
	case alert.LifecycleEscalated:
		title = fmt.Sprintf(
			"%s escalation: %s",
			strings.ToUpper(item.Severity),
			item.Type,
		)
		messagePrefix = "Escalated to " + strings.ToUpper(item.Severity)
	case alert.LifecycleReopened:
		title = fmt.Sprintf("Reopened alert: %s", item.Type)
		messagePrefix = "Reopened " + strings.ToUpper(severity)
	case alert.LifecycleCleared:
		title = fmt.Sprintf("Alert cleared: %s", item.Type)
		messagePrefix = "Cleared"
	}

	_, err := s.notifications.Create(
		ctx,
		notification.NewNotification{
			UserID:           vehicleItem.OwnerID,
			AlertID:          &item.ID,
			NotificationType: notification.TypeVehicleAlert,
			Title:            title,
			Message: fmt.Sprintf(
				"%s for %s: %s",
				messagePrefix,
				vehicleContext(vehicleItem),
				item.Message,
			),
		},
	)
	return err
}

func evaluate(
	record telemetry.Record,
	setting threshold.Setting,
) (float64, string, bool) {
	value, lowerIsWorse, ok := telemetryValue(record, setting.Parameter)
	if !ok {
		return 0, "", false
	}

	if lowerIsWorse {
		if value <= setting.CriticalValue {
			return value, "critical", true
		}
		if value <= setting.WarningValue {
			return value, "warning", true
		}
		return value, "", false
	}

	if value >= setting.CriticalValue {
		return value, "critical", true
	}
	if value >= setting.WarningValue {
		return value, "warning", true
	}

	return value, "", false
}

func isRecovered(record telemetry.Record, setting threshold.Setting) bool {
	value, lowerIsWorse, ok := telemetryValue(record, setting.Parameter)
	if !ok {
		return false
	}

	if lowerIsWorse {
		return value >= setting.WarningValue+setting.RecoveryMargin
	}

	return value <= setting.WarningValue-setting.RecoveryMargin
}

func recoverySamples(setting threshold.Setting) int {
	if setting.RecoverySamples < 1 {
		return 3
	}
	if setting.RecoverySamples > 10 {
		return 10
	}
	return setting.RecoverySamples
}

func telemetryValue(record telemetry.Record, parameter string) (float64, bool, bool) {
	switch parameter {
	case "engine_temperature":
		return record.EngineTemperature, false, true
	case "battery_voltage":
		return record.BatteryVoltage, true, true
	case "vibration_level":
		return record.VibrationLevel, false, true
	case "rpm":
		return float64(record.RPM), false, true
	case "speed":
		return record.Speed, false, true
	case "fuel_level":
		return record.FuelLevel, true, true
	default:
		return 0, false, false
	}
}

func alertMessage(parameter, severity string, value float64) string {
	return fmt.Sprintf(
		"%s reached %s level (measured value: %.3f).",
		parameter,
		severity,
		value,
	)
}

func recommendation(parameter, severity string) string {
	if severity == "critical" {
		return "Stop the vehicle safely and arrange an immediate technical inspection for " + parameter + "."
	}

	return "Reduce vehicle load and monitor " + parameter + "; schedule an inspection if the condition persists."
}

func vehicleContext(vehicleItem vehicle.Vehicle) string {
	name := strings.TrimSpace(vehicleItem.Brand + " " + vehicleItem.Model)
	if name != "" {
		if vehicleItem.LicensePlate != nil && strings.TrimSpace(*vehicleItem.LicensePlate) != "" {
			return fmt.Sprintf("%s (%s)", name, strings.TrimSpace(*vehicleItem.LicensePlate))
		}
		return name
	}

	return "vehicle " + vehicleItem.ID
}

func higherSeverity(current, candidate string) string {
	if candidate == "critical" {
		return "critical"
	}
	if candidate == "warning" && current == "normal" {
		return "warning"
	}
	return current
}

func effectiveCurrentSeverity(item alert.Alert) string {
	if item.CurrentSeverity != nil {
		return *item.CurrentSeverity
	}
	if item.Status == alert.StatusActive {
		return item.Severity
	}
	return ""
}
