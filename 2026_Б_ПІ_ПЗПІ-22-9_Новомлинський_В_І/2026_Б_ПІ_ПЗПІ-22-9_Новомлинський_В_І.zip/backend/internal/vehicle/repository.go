package vehicle

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
)

var ErrNotFound = errors.New("vehicle not found")
var ErrDuplicateVIN = errors.New("vehicle VIN already exists")

type Repository interface {
	List(ctx context.Context) ([]Vehicle, error)
	GetByID(ctx context.Context, id string) (Vehicle, error)
	ListByOwner(ctx context.Context, ownerID string) ([]Vehicle, error)
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (Vehicle, error)
	CreateForOwner(
		ctx context.Context,
		ownerID string,
		request CreateRequest,
	) (Vehicle, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) List(ctx context.Context) ([]Vehicle, error) {
	const query = `
		SELECT
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
		FROM vehicles
		ORDER BY created_at DESC, id
	`

	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("query vehicles: %w", err)
	}
	defer rows.Close()

	vehicles := make([]Vehicle, 0)
	for rows.Next() {
		item, err := scanVehicle(rows)
		if err != nil {
			return nil, fmt.Errorf("scan vehicle: %w", err)
		}
		vehicles = append(vehicles, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate vehicles: %w", err)
	}

	return vehicles, nil
}

func (r *PostgresRepository) GetByID(ctx context.Context, id string) (Vehicle, error) {
	const query = `
		SELECT
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
		FROM vehicles
		WHERE id = $1
	`

	item, err := scanVehicle(r.db.QueryRowContext(ctx, query, id))
	if errors.Is(err, sql.ErrNoRows) {
		return Vehicle{}, ErrNotFound
	}
	if err != nil {
		return Vehicle{}, fmt.Errorf("query vehicle by ID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ListByOwner(
	ctx context.Context,
	ownerID string,
) ([]Vehicle, error) {
	const query = `
		SELECT
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
		FROM vehicles
		WHERE owner_id = $1
		ORDER BY created_at DESC, id
	`

	rows, err := r.db.QueryContext(ctx, query, ownerID)
	if err != nil {
		return nil, fmt.Errorf("query owner vehicles: %w", err)
	}
	defer rows.Close()

	vehicles := make([]Vehicle, 0)
	for rows.Next() {
		item, err := scanVehicle(rows)
		if err != nil {
			return nil, fmt.Errorf("scan owner vehicle: %w", err)
		}
		vehicles = append(vehicles, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate owner vehicles: %w", err)
	}

	return vehicles, nil
}

func (r *PostgresRepository) GetByIDForOwner(
	ctx context.Context,
	ownerID string,
	vehicleID string,
) (Vehicle, error) {
	const query = `
		SELECT
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
		FROM vehicles
		WHERE id = $1 AND owner_id = $2
	`

	item, err := scanVehicle(r.db.QueryRowContext(ctx, query, vehicleID, ownerID))
	if errors.Is(err, sql.ErrNoRows) {
		return Vehicle{}, ErrNotFound
	}
	if err != nil {
		return Vehicle{}, fmt.Errorf("query owner vehicle by ID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) CreateForOwner(
	ctx context.Context,
	ownerID string,
	request CreateRequest,
) (Vehicle, error) {
	const query = `
		INSERT INTO vehicles (
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate
		)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
	`

	item, err := scanVehicle(r.db.QueryRowContext(
		ctx,
		query,
		ownerID,
		request.VIN,
		request.Brand,
		request.Model,
		request.Year,
		request.LicensePlate,
	))
	if isUniqueViolation(err, "vehicles_vin_key") {
		return Vehicle{}, ErrDuplicateVIN
	}
	if err != nil {
		return Vehicle{}, fmt.Errorf("create owner vehicle: %w", err)
	}

	return item, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanVehicle(row scanner) (Vehicle, error) {
	var (
		item         Vehicle
		ownerID      sql.NullString
		vin          sql.NullString
		year         sql.NullInt16
		licensePlate sql.NullString
	)

	if err := row.Scan(
		&item.ID,
		&ownerID,
		&vin,
		&item.Brand,
		&item.Model,
		&year,
		&licensePlate,
		&item.CreatedAt,
		&item.UpdatedAt,
	); err != nil {
		return Vehicle{}, err
	}

	if ownerID.Valid {
		item.OwnerID = ownerID.String
	}
	if vin.Valid {
		item.VIN = &vin.String
	}
	if year.Valid {
		value := year.Int16
		item.Year = &value
	}
	if licensePlate.Valid {
		item.LicensePlate = &licensePlate.String
	}

	return item, nil
}

func isUniqueViolation(err error, constraint string) bool {
	if err == nil {
		return false
	}

	message := err.Error()
	return strings.Contains(message, constraint) ||
		strings.Contains(message, "duplicate key")
}
