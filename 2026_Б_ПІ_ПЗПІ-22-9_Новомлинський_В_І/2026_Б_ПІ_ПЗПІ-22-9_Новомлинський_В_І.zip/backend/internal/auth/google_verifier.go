package auth

import (
	"context"
	"errors"
	"fmt"
	"net"
	"strings"

	"google.golang.org/api/idtoken"
)

var (
	ErrInvalidGoogleToken            = errors.New("invalid google token")
	ErrGoogleVerificationUnavailable = errors.New("google verification unavailable")
)

type GoogleTokenVerifier interface {
	Verify(ctx context.Context, idToken string) (GoogleIdentity, error)
}

type googlePayloadValidator func(
	ctx context.Context,
	rawIDToken string,
	audience string,
) (*idtoken.Payload, error)

type GoogleIDTokenVerifier struct {
	clientIDs []string
	validate  googlePayloadValidator
}

func NewGoogleIDTokenVerifier(clientIDs []string) *GoogleIDTokenVerifier {
	return newGoogleIDTokenVerifier(clientIDs, idtoken.Validate)
}

func newGoogleIDTokenVerifier(
	clientIDs []string,
	validate googlePayloadValidator,
) *GoogleIDTokenVerifier {
	return &GoogleIDTokenVerifier{
		clientIDs: append([]string(nil), clientIDs...),
		validate:  validate,
	}
}

func (v *GoogleIDTokenVerifier) Verify(ctx context.Context, rawIDToken string) (GoogleIdentity, error) {
	idToken := strings.TrimSpace(rawIDToken)
	if idToken == "" || len(v.clientIDs) == 0 {
		return GoogleIdentity{}, ErrInvalidGoogleToken
	}
	if v.validate == nil {
		return GoogleIdentity{}, ErrGoogleVerificationUnavailable
	}

	var lastErr error
	var unavailableErr error
	for _, audience := range v.clientIDs {
		payload, err := v.validate(ctx, idToken, audience)
		if err != nil {
			if isGoogleVerifierInfrastructureError(err) {
				unavailableErr = err
			}
			lastErr = err
			continue
		}

		if payload.Issuer != "accounts.google.com" && payload.Issuer != "https://accounts.google.com" {
			return GoogleIdentity{}, ErrInvalidGoogleToken
		}
		if strings.TrimSpace(payload.Subject) == "" {
			return GoogleIdentity{}, ErrInvalidGoogleToken
		}

		email, _ := payload.Claims["email"].(string)
		name, _ := payload.Claims["name"].(string)
		emailVerified, ok := payload.Claims["email_verified"].(bool)
		if !ok || strings.TrimSpace(email) == "" || !emailVerified {
			return GoogleIdentity{}, ErrInvalidGoogleToken
		}

		return GoogleIdentity{
			Subject:       strings.TrimSpace(payload.Subject),
			Email:         strings.TrimSpace(email),
			FullName:      strings.TrimSpace(name),
			EmailVerified: true,
		}, nil
	}

	if unavailableErr != nil {
		return GoogleIdentity{}, fmt.Errorf("google ID token verifier unavailable: %w", ErrGoogleVerificationUnavailable)
	}
	if lastErr != nil {
		return GoogleIdentity{}, fmt.Errorf("validate google ID token: %w", ErrInvalidGoogleToken)
	}
	return GoogleIdentity{}, ErrInvalidGoogleToken
}

func isGoogleVerifierInfrastructureError(err error) bool {
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return true
	}

	var netErr net.Error
	return errors.As(err, &netErr)
}
