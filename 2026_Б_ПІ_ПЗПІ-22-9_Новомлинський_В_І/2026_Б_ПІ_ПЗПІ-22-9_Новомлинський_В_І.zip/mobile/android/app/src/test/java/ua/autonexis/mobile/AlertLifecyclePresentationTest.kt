package ua.autonexis.mobile

import java.time.ZoneId
import java.util.Locale
import kotlin.test.Test
import ua.autonexis.mobile.ui.UiStringResources
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals
import kotlin.test.assertNull

class AlertLifecyclePresentationTest {
    @Test
    fun groupsAlertsByLifecycleStatusAndKeepsUnknownStatuses() {
        val groups = AlertLifecyclePresentation.group(
            listOf(
                alert("active-1", "active"),
                alert("cleared-1", "cleared"),
                alert("resolved-1", "resolved"),
                alert("future-1", "archived"),
            ),
        )

        assertEquals(listOf("active-1"), groups.active.map { it.id })
        assertEquals(listOf("cleared-1"), groups.cleared.map { it.id })
        assertEquals(listOf("resolved-1"), groups.resolved.map { it.id })
        assertEquals(listOf("future-1"), groups.historicalOther.map { it.id })
    }

    @Test
    fun recommendsInspectionForNormalTelemetryWithClearedCriticalIncident() {
        val older = alert(
            id = "older",
            status = "cleared",
            severity = "critical",
            clearedAt = "2026-06-18T10:00:00Z",
        )
        val newer = alert(
            id = "newer",
            status = "cleared",
            severity = "critical",
            clearedAt = "2026-06-18T11:00:00Z",
        )

        val selected = AlertLifecyclePresentation
            .latestClearedCriticalWhenInspectionRecommended("normal", listOf(older, newer))

        assertEquals("newer", selected?.id)
    }

    @Test
    fun doesNotRecommendInspectionWhenAnActiveConditionExists() {
        val selected = AlertLifecyclePresentation
            .latestClearedCriticalWhenInspectionRecommended(
                "normal",
                listOf(
                    alert("active-1", "active", severity = "warning"),
                    alert("cleared-1", "cleared", severity = "critical"),
                ),
            )

        assertNull(selected)
    }

    @Test
    fun formatsReadableParameterAndTimestamp() {
        assertEquals(R.string.metric_engine_temperature, UiStringResources.metricLabelRes("engine_temperature"))
        assertEquals(
            "Jun 18, 2026, 1:15 PM",
            AlertLifecyclePresentation.displayTimestamp(
                value = "2026-06-18T10:15:30Z",
                fallback = "n/a",
                locale = Locale.US,
                zoneId = ZoneId.of("Europe/Kyiv"),
            ),
        )
        assertEquals(
            "Jun 18, 2026, 1:15 PM",
            AlertLifecyclePresentation.displayTimestamp(
                value = "2026-06-18T12:15:30+02:00",
                fallback = "n/a",
                locale = Locale.US,
                zoneId = ZoneId.of("Europe/Kyiv"),
            ),
        )
        assertEquals(
            "Jun 18, 2026, 10:15 AM",
            AlertLifecyclePresentation.displayTimestamp(
                value = "2026-06-18T10:15:30",
                fallback = "n/a",
                locale = Locale.US,
                zoneId = ZoneId.of("Europe/Kyiv"),
            ),
        )
        assertEquals("n/a", AlertLifecyclePresentation.displayTimestamp("not-a-timestamp"))
        assertEquals("n/a", AlertLifecyclePresentation.displayTimestamp(null))
    }

    @Test
    fun formatsIsoOffsetTimestampWithoutRawTechnicalParts() {
        val formatted = AlertLifecyclePresentation.displayTimestamp(
            value = "2026-06-19T13:37:15.799977+03:00",
            fallback = "n/a",
            locale = Locale.US,
            zoneId = ZoneId.of("Europe/Kyiv"),
        )

        assertEquals("Jun 19, 2026, 1:37 PM", formatted)
        assertFalse(formatted.contains("2026-06-19T"))
        assertFalse(formatted.contains("799977"))
        assertFalse(formatted.contains("+03:00"))
    }

    @Test
    fun invalidAndBlankTimestampsUseFallback() {
        assertEquals(
            "fallback",
            AlertLifecyclePresentation.displayTimestamp(
                value = "",
                fallback = "fallback",
                locale = Locale("uk", "UA"),
                zoneId = ZoneId.of("Europe/Kyiv"),
            ),
        )
        assertEquals(
            "fallback",
            AlertLifecyclePresentation.displayTimestamp(
                value = "not-a-timestamp",
                fallback = "fallback",
                locale = Locale("uk", "UA"),
                zoneId = ZoneId.of("Europe/Kyiv"),
            ),
        )
    }

    @Test
    fun timestampFormattingIsLocaleAware() {
        val value = "2026-06-19T13:37:15.799977+03:00"
        val zone = ZoneId.of("Europe/Kyiv")
        val english = AlertLifecyclePresentation.displayTimestamp(value, "n/a", Locale.US, zone)
        val ukrainian = AlertLifecyclePresentation.displayTimestamp(value, "fallback", Locale("uk", "UA"), zone)

        assertNotEquals(english, ukrainian)
        assertFalse(ukrainian.contains("2026-06-19T"))
    }
    @Test
    fun warningOrCriticalUsesMaximumOrCurrentSeverity() {
        assertEquals(
            true,
            AlertLifecyclePresentation.isWarningOrCritical(
                alert("cleared-critical", "cleared", severity = "critical", currentSeverity = null),
            ),
        )
        assertEquals(
            true,
            AlertLifecyclePresentation.isWarningOrCritical(
                alert("active-warning", "active", severity = "critical", currentSeverity = "warning"),
            ),
        )
        assertEquals(
            false,
            AlertLifecyclePresentation.isWarningOrCritical(
                alert("other", "resolved", severity = "info", currentSeverity = null),
            ),
        )
    }

    @Test
    fun ownerResolutionActionIsNeverAvailable() {
        listOf("active", "cleared", "resolved", "archived").forEach { status ->
            assertEquals(
                false,
                AlertLifecyclePresentation.ownerCanResolveAlert(alert(status, status)),
            )
        }
    }

    @Test
    fun detectsOpenLinkedServiceRequestForAlert() {
        val alert = alert("alert-1", "cleared")
        val request = serviceRequest(
            id = "request-1",
            sourceAlertId = "alert-1",
            status = "in_progress",
        )

        assertEquals(
            request,
            AlertLifecyclePresentation.openLinkedServiceRequest(alert, listOf(request)),
        )
    }

    @Test
    fun cancelledLinkedRequestDoesNotBlockCreation() {
        val alert = alert("alert-1", "cleared")
        val request = serviceRequest(
            id = "request-1",
            sourceAlertId = "alert-1",
            status = "cancelled",
        )

        assertNull(AlertLifecyclePresentation.openLinkedServiceRequest(alert, listOf(request)))
    }

    @Test
    fun presentsSpecialistResolutionMetadataAndLinkedCompletedRequest() {
        val alert = alert(
            id = "alert-1",
            status = "resolved",
            resolvedByUserId = "specialist-1",
            resolutionNote = "Cooling system repaired and verified.",
            resolutionServiceRequestId = "request-1",
        )
        val request = serviceRequest(
            id = "request-1",
            sourceAlertId = "alert-1",
            status = "completed",
            resultSummary = "Replaced thermostat.",
        )

        assertEquals(
            R.string.resolved_by_technical_specialist,
            AlertLifecyclePresentation.resolvedHistoryLabelRes(alert),
        )
        assertEquals(
            request,
            AlertLifecyclePresentation.linkedResolutionServiceRequest(alert, listOf(request)),
        )
        assertEquals("Cooling system repaired and verified.", alert.resolutionNote)
        assertEquals("Replaced thermostat.", request.resultSummary)
    }

    @Test
    fun legacyResolvedIncidentFallbackIsReadable() {
        val alert = alert("legacy", "resolved")

        assertEquals(
            R.string.legacy_manual_incident_history,
            AlertLifecyclePresentation.resolvedHistoryLabelRes(alert),
        )
        assertNull(AlertLifecyclePresentation.linkedResolutionServiceRequest(alert, emptyList()))
    }

    private fun alert(
        id: String,
        status: String,
        severity: String = "warning",
        currentSeverity: String? = severity,
        clearedAt: String? = null,
        resolvedByUserId: String? = null,
        resolutionNote: String? = null,
        resolutionServiceRequestId: String? = null,
    ): Alert {
        return Alert(
            id = id,
            type = "engine_temperature",
            severity = severity,
            currentSeverity = currentSeverity,
            status = status,
            occurrenceCount = 2,
            recoveryStreak = 0,
            lastTriggeredAt = "2026-06-18T09:00:00Z",
            message = "Engine temperature exceeded a threshold.",
            recommendation = "Inspect the cooling system.",
            createdAt = "2026-06-18T08:00:00Z",
            clearedAt = clearedAt,
            resolvedAt = null,
            resolvedByUserId = resolvedByUserId,
            resolutionNote = resolutionNote,
            resolutionServiceRequestId = resolutionServiceRequestId,
        )
    }

    private fun serviceRequest(
        id: String,
        sourceAlertId: String?,
        status: String,
        resultSummary: String? = null,
    ): ServiceRequest {
        return ServiceRequest(
            id = id,
            vehicleId = "vehicle-1",
            ownerId = "owner-1",
            sourceAlertId = sourceAlertId,
            assignedSpecialistId = "specialist-1",
            assignedBy = "admin-1",
            title = "Cooling inspection",
            description = "Inspect the cooling system.",
            priority = "normal",
            status = status,
            resultSummary = resultSummary,
            createdAt = "2026-06-18T08:00:00Z",
            updatedAt = "2026-06-18T09:00:00Z",
            assignedAt = "2026-06-18T09:10:00Z",
            startedAt = "2026-06-18T09:20:00Z",
            completedAt = if (status == "completed") "2026-06-18T10:00:00Z" else null,
            cancelledAt = if (status == "cancelled") "2026-06-18T10:00:00Z" else null,
        )
    }
}
