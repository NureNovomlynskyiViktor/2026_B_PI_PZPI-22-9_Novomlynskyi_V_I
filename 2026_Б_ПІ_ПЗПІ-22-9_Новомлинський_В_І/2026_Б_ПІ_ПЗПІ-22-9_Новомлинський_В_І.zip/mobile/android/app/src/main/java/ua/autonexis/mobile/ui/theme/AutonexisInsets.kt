﻿package ua.autonexis.mobile.ui.theme

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
internal fun Modifier.autonexisTopBarInsets(): Modifier {
    return windowInsetsPadding(WindowInsets.statusBars)
}

