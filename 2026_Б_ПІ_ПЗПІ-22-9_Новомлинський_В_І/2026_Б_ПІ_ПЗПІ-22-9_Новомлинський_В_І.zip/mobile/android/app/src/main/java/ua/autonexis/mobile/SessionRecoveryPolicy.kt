package ua.autonexis.mobile

internal object SessionRecoveryPolicy {
    const val EXPIRED_SESSION_STATUS_CODE = 401

    fun isExpiredSession(error: Exception): Boolean {
        return error is ApiException && error.statusCode == EXPIRED_SESSION_STATUS_CODE
    }

    fun isTransientAuthenticatedFailure(error: Exception): Boolean {
        return !isExpiredSession(error)
    }
}
