package ua.autonexis.mobile.ui.telemetry

import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.util.Locale
import kotlin.math.abs
import ua.autonexis.mobile.AlertLifecyclePresentation
import ua.autonexis.mobile.TelemetryRecord
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsPresentation

internal data class TelemetryMetricSpec(
    val key: String,
    val label: String,
    val unit: String,
    val value: (TelemetryRecord) -> Double,
    val formatValue: (Double) -> String,
    val formatAverage: (Double) -> String = formatValue,
)

internal data class TelemetryOverview(
    val readingCount: Int,
    val oldestTimestamp: String,
    val newestTimestamp: String,
)

internal data class TelemetryMetricStatistics(
    val current: String,
    val minimum: String,
    val average: String,
    val maximum: String,
)

internal data class TelemetryChartPoint(
    val timestamp: String,
    val value: Double,
)

internal object RecentTelemetryPresentation {
    const val DEFAULT_HISTORY_LIMIT = 5
    const val DEFAULT_METRIC_KEY = "engine_temperature"

    val metrics: List<TelemetryMetricSpec> = listOf(
        TelemetryMetricSpec(
            key = "engine_temperature",
            label = "Engine temperature",
            unit = "\u00B0C",
            value = { it.engineTemperature },
            formatValue = { formatOneDecimal(it, "\u00B0C") },
        ),
        TelemetryMetricSpec(
            key = "battery_voltage",
            label = "Battery voltage",
            unit = "V",
            value = { it.batteryVoltage },
            formatValue = { formatOneDecimal(it, "V") },
        ),
        TelemetryMetricSpec(
            key = "vibration_level",
            label = "Vibration",
            unit = "level",
            value = { it.vibrationLevel },
            formatValue = { formatOneDecimal(it, null) },
        ),
        TelemetryMetricSpec(
            key = "rpm",
            label = "RPM",
            unit = "rpm",
            value = { it.rpm.toDouble() },
            formatValue = { formatWhole(it, "rpm") },
            formatAverage = { formatWholeOrOneDecimal(it, "rpm") },
        ),
        TelemetryMetricSpec(
            key = "speed",
            label = "Speed",
            unit = "km/h",
            value = { it.speed.toDouble() },
            formatValue = { formatWhole(it, "km/h") },
            formatAverage = { formatWholeOrOneDecimal(it, "km/h") },
        ),
        TelemetryMetricSpec(
            key = "fuel_level",
            label = "Fuel level",
            unit = "%",
            value = { it.fuelLevel },
            formatValue = { formatOneDecimal(it, "%") },
        ),
    )

    fun metricFor(key: String): TelemetryMetricSpec {
        return metrics.firstOrNull { it.key == key } ?: metrics.first()
    }

    fun isKnownMetricKey(key: String): Boolean {
        return metrics.any { it.key == key }
    }

    fun newestFirst(records: List<TelemetryRecord>): List<TelemetryRecord> {
        return indexedRecords(records).sortedWith { left, right ->
            compareTimestampDescending(left, right).takeIf { it != 0 } ?: left.index.compareTo(right.index)
        }.map { it.record }
    }

    fun chronological(records: List<TelemetryRecord>): List<TelemetryRecord> {
        return indexedRecords(records).sortedWith { left, right ->
            compareTimestampAscending(left, right).takeIf { it != 0 } ?: left.index.compareTo(right.index)
        }.map { it.record }
    }

    fun latestRecord(records: List<TelemetryRecord>): TelemetryRecord? {
        return newestFirst(records).firstOrNull()
    }

    fun oldestRecord(records: List<TelemetryRecord>): TelemetryRecord? {
        return chronological(records).firstOrNull()
    }

    fun measuredAtLabel(record: TelemetryRecord): String {
        return AlertLifecyclePresentation.displayTimestamp(record.measuredAt)
    }

    fun metrics(record: TelemetryRecord): List<Pair<String, String>> {
        return VehicleDetailsPresentation.telemetryMetrics(record)
    }

    fun overview(records: List<TelemetryRecord>): TelemetryOverview? {
        if (records.isEmpty()) {
            return null
        }
        val oldest = oldestRecord(records)
        val newest = latestRecord(records)
        return TelemetryOverview(
            readingCount = records.size,
            oldestTimestamp = oldest?.let(::measuredAtLabel) ?: "n/a",
            newestTimestamp = newest?.let(::measuredAtLabel) ?: "n/a",
        )
    }

    fun chartSeries(records: List<TelemetryRecord>, metricKey: String): List<TelemetryChartPoint> {
        val metric = metricFor(metricKey)
        return chronological(records).map { record ->
            TelemetryChartPoint(
                timestamp = measuredAtLabel(record),
                value = metric.value(record),
            )
        }
    }

    fun statistics(records: List<TelemetryRecord>, metricKey: String): TelemetryMetricStatistics? {
        if (records.isEmpty()) {
            return null
        }
        val metric = metricFor(metricKey)
        val values = newestFirst(records).map(metric.value)
        val current = values.first()
        val min = values.minOrNull() ?: return null
        val max = values.maxOrNull() ?: return null
        val average = values.average()

        return TelemetryMetricStatistics(
            current = metric.formatValue(current),
            minimum = metric.formatValue(min),
            average = metric.formatAverage(average),
            maximum = metric.formatValue(max),
        )
    }

    fun historyRecords(records: List<TelemetryRecord>, expanded: Boolean): List<TelemetryRecord> {
        val ordered = newestFirst(records)
        return if (expanded) ordered else ordered.take(DEFAULT_HISTORY_LIMIT)
    }

    fun canToggleHistory(records: List<TelemetryRecord>): Boolean {
        return records.size > DEFAULT_HISTORY_LIMIT
    }

    private data class IndexedTelemetryRecord(
        val record: TelemetryRecord,
        val index: Int,
        val timestampMillis: Long?,
    )

    private fun indexedRecords(records: List<TelemetryRecord>): List<IndexedTelemetryRecord> {
        return records.mapIndexed { index, record ->
            IndexedTelemetryRecord(
                record = record,
                index = index,
                timestampMillis = parseTimestampMillis(record.measuredAt),
            )
        }
    }

    private fun compareTimestampDescending(left: IndexedTelemetryRecord, right: IndexedTelemetryRecord): Int {
        return when {
            left.timestampMillis != null && right.timestampMillis != null ->
                right.timestampMillis.compareTo(left.timestampMillis)
            left.timestampMillis != null -> -1
            right.timestampMillis != null -> 1
            else -> 0
        }
    }

    private fun compareTimestampAscending(left: IndexedTelemetryRecord, right: IndexedTelemetryRecord): Int {
        return when {
            left.timestampMillis != null && right.timestampMillis != null ->
                left.timestampMillis.compareTo(right.timestampMillis)
            left.timestampMillis != null -> -1
            right.timestampMillis != null -> 1
            else -> 0
        }
    }

    private fun parseTimestampMillis(value: String): Long? {
        val trimmed = value.trim()
        if (trimmed.isBlank()) {
            return null
        }

        return runCatching { Instant.parse(trimmed).toEpochMilli() }.getOrNull()
            ?: runCatching { OffsetDateTime.parse(trimmed).toInstant().toEpochMilli() }.getOrNull()
            ?: runCatching { LocalDateTime.parse(trimmed).toInstant(ZoneOffset.UTC).toEpochMilli() }.getOrNull()
    }

    private fun formatOneDecimal(value: Double, unit: String?): String {
        val formatted = String.format(Locale.US, "%.1f", value)
        return if (unit == null) formatted else "$formatted $unit"
    }

    private fun formatWhole(value: Double, unit: String): String {
        return "${String.format(Locale.US, "%.0f", value)} $unit"
    }

    private fun formatWholeOrOneDecimal(value: Double, unit: String): String {
        val formatted = if (abs(value - value.toInt()) < 0.05) {
            String.format(Locale.US, "%.0f", value)
        } else {
            String.format(Locale.US, "%.1f", value)
        }
        return "$formatted $unit"
    }
}