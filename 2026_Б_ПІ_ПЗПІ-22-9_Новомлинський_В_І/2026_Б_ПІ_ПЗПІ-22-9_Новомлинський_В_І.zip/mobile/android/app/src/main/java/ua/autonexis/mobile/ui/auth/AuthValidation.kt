package ua.autonexis.mobile.ui.auth

import ua.autonexis.mobile.R

internal data class PasswordRequirement(
    val label: String,
    val labelRes: Int,
    val isSatisfied: Boolean,
)

internal fun loginValidationError(
    baseUrl: String,
    email: String,
    password: String,
): String? {
    if (baseUrl.isBlank() || email.isBlank() || password.isBlank()) {
        return "Backend URL, email, and password are required."
    }
    if (!looksLikeEmail(email)) {
        return "Enter a valid email address."
    }
    return null
}

internal fun registrationValidationError(
    baseUrl: String,
    fullName: String,
    email: String,
    password: String,
    confirmPassword: String,
): String? {
    if (baseUrl.isBlank() || fullName.isBlank() || email.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
        return "Backend URL, full name, email, password, and confirmation are required."
    }
    if (!looksLikeEmail(email)) {
        return "Enter a valid email address."
    }
    if (!isStrongPassword(password)) {
        return "Password must be at least 8 characters and include uppercase, lowercase, number, and symbol."
    }
    if (password != confirmPassword) {
        return "Password confirmation does not match."
    }
    return null
}

internal fun passwordRequirements(password: String): List<PasswordRequirement> = listOf(
    PasswordRequirement("At least 8 characters", R.string.password_req_min_length, password.length >= 8),
    PasswordRequirement("Uppercase letter", R.string.password_req_uppercase, password.any { it.isUpperCase() }),
    PasswordRequirement("Lowercase letter", R.string.password_req_lowercase, password.any { it.isLowerCase() }),
    PasswordRequirement("Digit", R.string.password_req_digit, password.any { it.isDigit() }),
    PasswordRequirement("Special character", R.string.password_req_special, password.any { !it.isLetterOrDigit() && !it.isWhitespace() }),
)

internal fun isStrongPassword(value: String): Boolean = passwordRequirements(value).all { it.isSatisfied }

internal fun looksLikeEmail(value: String): Boolean {
    val trimmed = value.trim()
    val atIndex = trimmed.indexOf('@')
    val dotIndex = trimmed.lastIndexOf('.')
    return atIndex > 0 && dotIndex > atIndex + 1 && dotIndex < trimmed.length - 1
}
