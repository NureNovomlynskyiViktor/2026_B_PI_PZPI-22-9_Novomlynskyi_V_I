package telemetryingestion

import (
	"context"
	"errors"
	"math"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alertevaluation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
)

const maximumFutureTime = 5 * time.Minute

var (
	ErrInvalidDeviceUID = errors.New("invalid device UID")
	ErrDeviceNotFound   = errors.New("device not found")
	ErrInvalidPayload   = errors.New("invalid telemetry payload")
)

type DeviceService interface {
	GetByUID(ctx context.Context, deviceUID string) (device.Device, error)
}

type TelemetryWriter interface {
	Create(ctx context.Context, input telemetry.NewRecord) (telemetry.Record, error)
}

type AlertEvaluator interface {
	EvaluateRecord(
		ctx context.Context,
		record telemetry.Record,
	) (alertevaluation.Result, error)
}

type Service interface {
	Ingest(ctx context.Context, deviceUID string, input Input) (Result, error)
}

type service struct {
	devices   DeviceService
	telemetry TelemetryWriter
	evaluator AlertEvaluator
	now       func() time.Time
}

func NewService(
	devices DeviceService,
	telemetryWriter TelemetryWriter,
	evaluator AlertEvaluator,
) Service {
	return &service{
		devices:   devices,
		telemetry: telemetryWriter,
		evaluator: evaluator,
		now:       time.Now,
	}
}

func (s *service) Ingest(
	ctx context.Context,
	deviceUID string,
	input Input,
) (Result, error) {
	if !identifier.IsDeviceUID(deviceUID) {
		return Result{}, ErrInvalidDeviceUID
	}

	deviceItem, err := s.devices.GetByUID(ctx, deviceUID)
	if errors.Is(err, device.ErrNotFound) {
		return Result{}, ErrDeviceNotFound
	}
	if err != nil {
		return Result{}, err
	}

	receivedAt := s.now().UTC()
	if err := validateInput(input, receivedAt); err != nil {
		return Result{}, err
	}

	measuredAt := receivedAt
	if input.MeasuredAt != nil {
		measuredAt = input.MeasuredAt.UTC()
	}

	record, err := s.telemetry.Create(
		ctx,
		telemetry.NewRecord{
			VehicleID:         deviceItem.VehicleID,
			DeviceID:          deviceItem.ID,
			MeasuredAt:        measuredAt,
			ReceivedAt:        receivedAt,
			EngineTemperature: *input.EngineTemperature,
			BatteryVoltage:    *input.BatteryVoltage,
			VibrationLevel:    *input.VibrationLevel,
			RPM:               *input.RPM,
			Speed:             *input.Speed,
			FuelLevel:         *input.FuelLevel,
		},
	)
	if err != nil {
		return Result{}, err
	}

	evaluation, err := s.evaluator.EvaluateRecord(ctx, record)
	if err != nil {
		return Result{}, err
	}

	return Result{
		Telemetry:      record,
		CreatedAlerts:  evaluation.CreatedAlerts,
		ExistingAlerts: evaluation.ExistingAlerts,
		UpdatedAlerts:  evaluation.UpdatedAlerts,
		ResolvedAlerts: evaluation.ResolvedAlerts,
		OverallResult:  evaluation.OverallResult,
	}, nil
}

func validateInput(input Input, receivedAt time.Time) error {
	if input.EngineTemperature == nil ||
		input.BatteryVoltage == nil ||
		input.VibrationLevel == nil ||
		input.RPM == nil ||
		input.Speed == nil ||
		input.FuelLevel == nil {
		return ErrInvalidPayload
	}

	if input.MeasuredAt != nil {
		if input.MeasuredAt.IsZero() ||
			input.MeasuredAt.After(receivedAt.Add(maximumFutureTime)) {
			return ErrInvalidPayload
		}
	}

	if !inRange(*input.EngineTemperature, -40, 150) ||
		!inRange(*input.BatteryVoltage, 0, 24) ||
		!inRange(*input.VibrationLevel, 0, 100) ||
		*input.RPM < 0 ||
		*input.RPM > 10000 ||
		!inRange(*input.Speed, 0, 300) ||
		!inRange(*input.FuelLevel, 0, 100) {
		return ErrInvalidPayload
	}

	return nil
}

func inRange(value, minimum, maximum float64) bool {
	return !math.IsNaN(value) &&
		!math.IsInf(value, 0) &&
		value >= minimum &&
		value <= maximum
}
