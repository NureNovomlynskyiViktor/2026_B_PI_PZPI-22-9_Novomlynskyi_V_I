package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.notification.NotificationsPresentation
import ua.autonexis.mobile.ui.notification.NotificationsViewModel

class NotificationsStateTest {
    @Test
    fun initialLoadingSuccessAndErrorStatesAreExplicit() {
        val viewModel = NotificationsViewModel()

        viewModel.showInitialLoading()
        assertTrue(viewModel.uiState.isLoading)
        assertEquals("Loading notifications...", viewModel.uiState.message)
        assertTrue(viewModel.uiState.items.isEmpty())

        viewModel.showNotifications(listOf(notification(id = "n1", isRead = false)))
        assertFalse(viewModel.uiState.isLoading)
        assertFalse(viewModel.uiState.isError)
        assertEquals(1, viewModel.uiState.unreadCount)

        viewModel.failInitialLoad("Could not load notifications.")
        assertFalse(viewModel.uiState.isLoading)
        assertTrue(viewModel.uiState.isError)
        assertEquals("Could not load notifications.", viewModel.uiState.message)
        assertTrue(viewModel.uiState.items.isEmpty())
    }

    @Test
    fun notificationsAreSortedNewestFirst() {
        val ordered = NotificationsPresentation.newestFirst(
            listOf(
                notification(id = "older", createdAt = "2026-06-18T09:00:00Z"),
                notification(id = "newer", createdAt = "2026-06-18T11:00:00Z"),
                notification(id = "tie-b", createdAt = "2026-06-18T10:00:00Z"),
                notification(id = "tie-a", createdAt = "2026-06-18T10:00:00Z"),
            ),
        )

        assertEquals(listOf("newer", "tie-b", "tie-a", "older"), ordered.map { it.id })
    }

    @Test
    fun refreshLocksAndFailurePreservesExistingItems() {
        val viewModel = NotificationsViewModel()
        val existing = notification(id = "n1", isRead = false)
        viewModel.showNotifications(listOf(existing))

        assertTrue(viewModel.startRefresh())
        assertFalse(viewModel.startRefresh())
        assertTrue(viewModel.uiState.isRefreshing)

        viewModel.failRefresh("Network unavailable.")
        assertFalse(viewModel.uiState.isRefreshing)
        assertTrue(viewModel.uiState.isError)
        assertEquals("Network unavailable.", viewModel.uiState.message)
        assertEquals(listOf(existing), viewModel.uiState.items)
        assertEquals(1, viewModel.uiState.unreadCount)
    }

    @Test
    fun refreshSuccessReplacesItemsAndUpdatesUnreadCount() {
        val viewModel = NotificationsViewModel()
        viewModel.showNotifications(listOf(notification(id = "old", isRead = false)))

        assertTrue(viewModel.startRefresh())
        viewModel.finishRefresh(
            listOf(
                notification(id = "read", isRead = true, createdAt = "2026-06-18T12:00:00Z"),
                notification(id = "unread", isRead = false, createdAt = "2026-06-18T13:00:00Z"),
            ),
        )

        assertFalse(viewModel.uiState.isRefreshing)
        assertEquals(listOf("unread", "read"), viewModel.uiState.items.map { it.id })
        assertEquals(1, viewModel.uiState.unreadCount)
    }

    @Test
    fun markReadLocksDuplicateAndIgnoresAlreadyReadItems() {
        val viewModel = NotificationsViewModel()
        viewModel.showNotifications(
            listOf(
                notification(id = "unread", isRead = false),
                notification(id = "read", isRead = true),
            ),
        )

        assertTrue(viewModel.startMarkRead("unread"))
        assertFalse(viewModel.startMarkRead("unread"))
        assertFalse(viewModel.startMarkRead("read"))
        assertEquals(setOf("unread"), viewModel.uiState.markingReadIds)
    }

    @Test
    fun markReadSuccessReplacesOnlyTargetAndDecreasesUnreadCount() {
        val viewModel = NotificationsViewModel()
        val other = notification(id = "other", isRead = false, title = "Keep me")
        val target = notification(id = "target", isRead = false, title = "Old title")
        viewModel.showNotifications(listOf(other, target))

        assertTrue(viewModel.startMarkRead("target"))
        viewModel.finishMarkRead(target.copy(isRead = true, title = "Updated title"))

        val updatedTarget = viewModel.uiState.items.first { it.id == "target" }
        val untouchedOther = viewModel.uiState.items.first { it.id == "other" }
        assertTrue(updatedTarget.isRead)
        assertEquals("Updated title", updatedTarget.title)
        assertEquals("Keep me", untouchedOther.title)
        assertEquals(1, viewModel.uiState.unreadCount)
        assertTrue(viewModel.uiState.markingReadIds.isEmpty())
    }

    @Test
    fun markReadFailurePreservesUnreadState() {
        val viewModel = NotificationsViewModel()
        viewModel.showNotifications(listOf(notification(id = "target", isRead = false)))

        assertTrue(viewModel.startMarkRead("target"))
        viewModel.failMarkRead("target", "Could not update notification.")

        assertFalse(viewModel.uiState.items.first().isRead)
        assertEquals(1, viewModel.uiState.unreadCount)
        assertTrue(viewModel.uiState.isError)
        assertEquals("Could not update notification.", viewModel.uiState.message)
        assertTrue(viewModel.uiState.markingReadIds.isEmpty())
    }

    @Test
    fun unreadOnlyFilterHidesReadItemsAndUpdatesAfterMarkRead() {
        val viewModel = NotificationsViewModel()
        val unread = notification(id = "unread", isRead = false)
        val read = notification(id = "read", isRead = true)
        viewModel.showNotifications(listOf(unread, read))

        assertEquals(listOf("unread", "read"), viewModel.uiState.visibleItems.map { it.id })

        viewModel.toggleUnreadOnly()
        assertTrue(viewModel.uiState.showUnreadOnly)
        assertEquals(listOf("unread"), viewModel.uiState.visibleItems.map { it.id })

        assertTrue(viewModel.startMarkRead("unread"))
        viewModel.finishMarkRead(unread.copy(isRead = true))

        assertEquals(0, viewModel.uiState.unreadCount)
        assertTrue(viewModel.uiState.visibleItems.isEmpty())

        viewModel.toggleUnreadOnly()
        assertFalse(viewModel.uiState.showUnreadOnly)
        assertEquals(listOf("unread", "read"), viewModel.uiState.visibleItems.map { it.id })
    }

    @Test
    fun nullableReferencesAndUnknownTypesRemainReadable() {
        val unknown = notification(
            id = "unknown",
            alertId = null,
            serviceRequestId = null,
            notificationType = "future_domain_event",
        )

        assertNull(unknown.alertId)
        assertNull(unknown.serviceRequestId)
        assertEquals("Future domain event", NotificationPresentation.typeLabel(unknown.notificationType))
        assertFalse(NotificationPresentation.shouldShowSeverity(unknown))
        assertNull(NotificationPresentation.severityLabel(unknown))
        assertFalse(NotificationPresentation.canViewServiceRequest(unknown))
    }

    private fun notification(
        id: String,
        alertId: String? = null,
        serviceRequestId: String? = null,
        notificationType: String = NotificationPresentation.TYPE_VEHICLE_ALERT,
        title: String = "Notification title",
        message: String = "Notification message",
        isRead: Boolean = false,
        createdAt: String = "2026-06-18T10:00:00Z",
    ): OwnerNotification {
        return OwnerNotification(
            id = id,
            alertId = alertId,
            serviceRequestId = serviceRequestId,
            notificationType = notificationType,
            title = title,
            message = message,
            isRead = isRead,
            createdAt = createdAt,
        )
    }
}
