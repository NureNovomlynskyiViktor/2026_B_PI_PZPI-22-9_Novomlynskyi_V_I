package auth

import "time"

const (
	DefaultRoleCode             = "vehicle_owner"
	TechnicalSpecialistRoleCode = "technical_specialist"
	AdministratorRoleCode       = "administrator"
	GoogleProvider              = "google"
)

type User struct {
	ID        string    `json:"id"`
	RoleID    string    `json:"role_id"`
	Role      string    `json:"role"`
	Email     string    `json:"email"`
	FullName  string    `json:"full_name"`
	IsActive  bool      `json:"is_active"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type UserWithPassword struct {
	User
	PasswordHash *string
}

type Role struct {
	ID   string
	Code string
}

type RegisterRequest struct {
	Email     string `json:"email"`
	Password  string `json:"password"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	FullName  string `json:"full_name"`
}

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type GoogleLoginRequest struct {
	IDToken string `json:"id_token"`
}

type GoogleLinkRequest struct {
	IDToken string `json:"id_token"`
}

type AuthMethodStatus struct {
	PasswordEnabled bool `json:"password_enabled"`
	GoogleLinked    bool `json:"google_linked"`
}

type OAuthAccount struct {
	UserID            string
	Provider          string
	ProviderAccountID string
}

type GoogleIdentity struct {
	Subject       string
	Email         string
	FullName      string
	EmailVerified bool
}

type contextKey string

const userContextKey contextKey = "auth_user"

type AuthResponse struct {
	User        User   `json:"user"`
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresAt   int64  `json:"expires_at"`
}

type TokenClaims struct {
	Subject   string
	Email     string
	Role      string
	IssuedAt  time.Time
	ExpiresAt time.Time
}
