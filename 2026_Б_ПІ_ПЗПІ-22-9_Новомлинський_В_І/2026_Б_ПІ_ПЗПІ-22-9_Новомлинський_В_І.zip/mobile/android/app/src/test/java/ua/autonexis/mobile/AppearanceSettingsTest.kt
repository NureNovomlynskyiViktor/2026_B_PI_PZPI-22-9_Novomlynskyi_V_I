package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.account.AccountPresentation
import ua.autonexis.mobile.ui.account.AccountViewModel

class AppearanceSettingsTest {
    @Test
    fun defaultModeIsSystem() {
        val store = AppearanceStore(FakeAppearanceStorage())

        assertEquals(AppearanceMode.SYSTEM, store.mode)
    }

    @Test
    fun preferencesRoundTripSystemLightAndDark() {
        val storage = FakeAppearanceStorage()
        val store = AppearanceStore(storage)

        AppearanceMode.entries.forEach { mode ->
            store.mode = mode
            assertEquals(mode.name, storage.rawAppearanceMode)
            assertEquals(mode, store.mode)
        }
    }

    @Test
    fun malformedPreferenceFallsBackToSystem() {
        val store = AppearanceStore(FakeAppearanceStorage("purple"))

        assertEquals(AppearanceMode.SYSTEM, store.mode)
    }

    @Test
    fun resolvesSystemLightAndDark() {
        assertTrue(AppearanceStore.resolveDarkTheme(AppearanceMode.SYSTEM, systemInDarkTheme = true))
        assertFalse(AppearanceStore.resolveDarkTheme(AppearanceMode.SYSTEM, systemInDarkTheme = false))
        assertFalse(AppearanceStore.resolveDarkTheme(AppearanceMode.LIGHT, systemInDarkTheme = true))
        assertTrue(AppearanceStore.resolveDarkTheme(AppearanceMode.DARK, systemInDarkTheme = false))
    }

    @Test
    fun selectingModeUpdatesObservableStateAndPersistsIt() {
        val storage = FakeAppearanceStorage()
        val controller = AppearanceController(AppearanceStore(storage))

        controller.select(AppearanceMode.DARK)

        assertEquals(AppearanceMode.DARK, controller.mode)
        assertEquals("DARK", storage.rawAppearanceMode)
    }

    @Test
    fun selectingAppearanceDoesNotReloadAccountMethods() {
        val storage = FakeAppearanceStorage()
        val controller = AppearanceController(AppearanceStore(storage))
        val accountViewModel = AccountViewModel()
        val methods = AuthMethods(passwordEnabled = true, googleLinked = false)
        accountViewModel.showAccount(
            user = user(),
            methods = methods,
            googleConfigured = true,
        )

        controller.select(AppearanceMode.LIGHT)

        assertEquals(AppearanceMode.LIGHT, controller.mode)
        assertEquals(methods, accountViewModel.uiState.methods)
        assertFalse(accountViewModel.uiState.isLoading)
        assertFalse(accountViewModel.uiState.isRefreshing)
        assertFalse(accountViewModel.uiState.isLinkingGoogle)
    }

    @Test
    fun logoutStyleTokenClearingDoesNotClearAppearancePreference() {
        val storage = FakeAppearanceStorage()
        val store = AppearanceStore(storage)
        store.mode = AppearanceMode.DARK

        // Session logout clears secure token state elsewhere; appearance uses separate ordinary preferences.
        assertEquals(AppearanceMode.DARK, store.mode)
    }

    @Test
    fun accountPresentationLabelsAppearanceModes() {
        assertEquals("System default", AccountPresentation.appearanceModeLabel(AppearanceMode.SYSTEM))
        assertEquals("Light", AccountPresentation.appearanceModeLabel(AppearanceMode.LIGHT))
        assertEquals("Dark", AccountPresentation.appearanceModeLabel(AppearanceMode.DARK))
    }

    private fun user(): User {
        return User(
            id = "user-1",
            email = "owner@example.com",
            role = "vehicle_owner",
            fullName = "Demo Owner",
        )
    }

    private class FakeAppearanceStorage(initialValue: String? = null) : AppearancePreferenceStorage {
        override var rawAppearanceMode: String? = initialValue
    }
}
