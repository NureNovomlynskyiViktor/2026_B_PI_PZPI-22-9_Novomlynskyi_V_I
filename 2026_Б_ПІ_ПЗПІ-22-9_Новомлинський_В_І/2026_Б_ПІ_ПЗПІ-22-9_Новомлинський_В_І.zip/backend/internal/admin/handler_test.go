package admin

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistrecommendation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const testUUID = "11111111-1111-1111-1111-111111111111"

type vehicleServiceStub struct {
	getErr error
}

func (s vehicleServiceStub) List(context.Context) ([]vehicle.Vehicle, error) {
	return []vehicle.Vehicle{{ID: testUUID}}, nil
}

func (s vehicleServiceStub) GetByID(context.Context, string) (vehicle.Vehicle, error) {
	if s.getErr != nil {
		return vehicle.Vehicle{}, s.getErr
	}

	return vehicle.Vehicle{ID: testUUID}, nil
}

type assignmentServiceStub struct {
	assignErr error
	removeErr error
}

func (s assignmentServiceStub) AssignByEmail(
	context.Context,
	string,
	string,
	string,
) (specialistassignment.Assignment, error) {
	if s.assignErr != nil {
		return specialistassignment.Assignment{}, s.assignErr
	}

	return testAssignment(), nil
}

func (s assignmentServiceStub) AssignByID(
	context.Context,
	string,
	string,
	string,
) (specialistassignment.Assignment, error) {
	if s.assignErr != nil {
		return specialistassignment.Assignment{}, s.assignErr
	}

	return testAssignment(), nil
}

func (s assignmentServiceStub) ListByVehicle(
	context.Context,
	string,
) ([]specialistassignment.Assignment, error) {
	return []specialistassignment.Assignment{testAssignment()}, nil
}

func (s assignmentServiceStub) ListSpecialists(context.Context) ([]auth.User, error) {
	return []auth.User{testSpecialist()}, nil
}

func (s assignmentServiceStub) CountBySpecialist(context.Context) (map[string]int, error) {
	return map[string]int{testUUID: 1}, nil
}

func (s assignmentServiceStub) Remove(context.Context, string, string) error {
	return s.removeErr
}

type competencyServiceStub struct {
	replaceErr error
}

func (s competencyServiceStub) List(
	context.Context,
	string,
) ([]specialistcompetency.Competency, error) {
	return []specialistcompetency.Competency{
		{
			SpecialistID: testUUID,
			Code:         specialistcompetency.CodeEngineDiagnostics,
			Name:         "Engine diagnostics",
		},
	}, nil
}

func (s competencyServiceStub) Replace(
	context.Context,
	string,
	[]string,
) ([]specialistcompetency.Competency, error) {
	if s.replaceErr != nil {
		return nil, s.replaceErr
	}

	return []specialistcompetency.Competency{
		{
			SpecialistID: testUUID,
			Code:         specialistcompetency.CodeEngineDiagnostics,
			Name:         "Engine diagnostics",
		},
	}, nil
}

type recommendationServiceStub struct {
	err error
}

func (s recommendationServiceStub) Recommend(
	context.Context,
	string,
) ([]specialistrecommendation.Recommendation, error) {
	if s.err != nil {
		return nil, s.err
	}

	return []specialistrecommendation.Recommendation{
		{
			Specialist: testSpecialist(),
			Score:      50,
		},
	}, nil
}

func TestListVehiclesRequiresAdministrator(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := httptest.NewRequest(http.MethodGet, "/api/v1/admin/vehicles", nil)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:   testUUID,
		Role: auth.TechnicalSpecialistRoleCode,
	}))
	recorder := httptest.NewRecorder()

	handler.ListVehicles(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestListVehicleSpecialistsRejectsInvalidVehicleID(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(http.MethodGet, "/api/v1/admin/vehicles/not-a-uuid/specialists", nil)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListVehicleSpecialists(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListVehicleSpecialistsReturnsNotFoundForMissingVehicle(t *testing.T) {
	handler := newTestHandler(
		vehicleServiceStub{getErr: vehicle.ErrNotFound},
		assignmentServiceStub{},
	)
	request := adminRequest(http.MethodGet, "/api/v1/admin/vehicles/"+testUUID+"/specialists", nil)
	request.SetPathValue("vehicle_id", testUUID)
	recorder := httptest.NewRecorder()

	handler.ListVehicleSpecialists(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestListRecommendedSpecialists(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(
		http.MethodGet,
		"/api/v1/admin/vehicles/"+testUUID+"/recommended-specialists",
		nil,
	)
	request.SetPathValue("vehicle_id", testUUID)
	recorder := httptest.NewRecorder()

	handler.ListRecommendedSpecialists(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
}

func TestListRecommendedSpecialistsRejectsInvalidVehicleID(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(
		http.MethodGet,
		"/api/v1/admin/vehicles/not-a-uuid/recommended-specialists",
		nil,
	)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListRecommendedSpecialists(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestAssignVehicleSpecialistReturnsConflictForDuplicate(t *testing.T) {
	handler := newTestHandler(
		vehicleServiceStub{},
		assignmentServiceStub{assignErr: specialistassignment.ErrDuplicate},
	)
	request := adminRequest(
		http.MethodPost,
		"/api/v1/admin/vehicles/"+testUUID+"/specialists",
		strings.NewReader(`{"specialist_id":"`+testUUID+`"}`),
	)
	request.SetPathValue("vehicle_id", testUUID)
	recorder := httptest.NewRecorder()

	handler.AssignVehicleSpecialist(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func TestAssignVehicleSpecialistByID(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(
		http.MethodPost,
		"/api/v1/admin/vehicles/"+testUUID+"/specialists",
		strings.NewReader(`{"specialist_id":"`+testUUID+`"}`),
	)
	request.SetPathValue("vehicle_id", testUUID)
	recorder := httptest.NewRecorder()

	handler.AssignVehicleSpecialist(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
}

func TestRemoveVehicleSpecialistRejectsInvalidSpecialistID(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(
		http.MethodDelete,
		"/api/v1/admin/vehicles/"+testUUID+"/specialists/not-a-uuid",
		nil,
	)
	request.SetPathValue("vehicle_id", testUUID)
	request.SetPathValue("specialist_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.RemoveVehicleSpecialist(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListSpecialistCompetenciesRejectsInvalidSpecialistID(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(
		http.MethodGet,
		"/api/v1/admin/specialists/not-a-uuid/competencies",
		nil,
	)
	request.SetPathValue("specialist_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListSpecialistCompetencies(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestReplaceSpecialistCompetenciesRejectsInvalidCode(t *testing.T) {
	handler := newTestHandlerWithCompetencies(
		vehicleServiceStub{},
		assignmentServiceStub{},
		competencyServiceStub{replaceErr: specialistcompetency.ErrInvalidCompetencyCode},
		recommendationServiceStub{},
	)
	request := adminRequest(
		http.MethodPut,
		"/api/v1/admin/specialists/"+testUUID+"/competencies",
		strings.NewReader(`{"codes":["unsafe_code"]}`),
	)
	request.SetPathValue("specialist_id", testUUID)
	recorder := httptest.NewRecorder()

	handler.ReplaceSpecialistCompetencies(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestReplaceSpecialistCompetencies(t *testing.T) {
	handler := newTestHandler(vehicleServiceStub{}, assignmentServiceStub{})
	request := adminRequest(
		http.MethodPut,
		"/api/v1/admin/specialists/"+testUUID+"/competencies",
		strings.NewReader(`{"codes":["engine_diagnostics","vibration_analysis"]}`),
	)
	request.SetPathValue("specialist_id", testUUID)
	recorder := httptest.NewRecorder()

	handler.ReplaceSpecialistCompetencies(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
}

func newTestHandler(
	vehicles VehicleService,
	assignments AssignmentService,
) *Handler {
	return newTestHandlerWithCompetencies(
		vehicles,
		assignments,
		competencyServiceStub{},
		recommendationServiceStub{},
	)
}

func newTestHandlerWithCompetencies(
	vehicles VehicleService,
	assignments AssignmentService,
	competencies CompetencyService,
	recommendations RecommendationService,
) *Handler {
	return NewHandler(
		vehicles,
		assignments,
		competencies,
		recommendations,
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
}

func adminRequest(method string, target string, body io.Reader) *http.Request {
	request := httptest.NewRequest(method, target, body)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:    testUUID,
		Email: "admin@example.com",
		Role:  auth.AdministratorRoleCode,
	}))

	return request
}

func testAssignment() specialistassignment.Assignment {
	return specialistassignment.Assignment{
		ID:           testUUID,
		VehicleID:    testUUID,
		SpecialistID: testUUID,
		Specialist:   testSpecialist(),
	}
}

func testSpecialist() auth.User {
	return auth.User{
		ID:    testUUID,
		Email: "specialist@example.com",
		Role:  auth.TechnicalSpecialistRoleCode,
	}
}
