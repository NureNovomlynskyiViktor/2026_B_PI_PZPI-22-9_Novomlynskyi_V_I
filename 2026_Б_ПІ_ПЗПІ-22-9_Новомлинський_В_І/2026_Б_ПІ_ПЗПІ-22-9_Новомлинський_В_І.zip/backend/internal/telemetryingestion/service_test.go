package telemetryingestion

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alertevaluation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
)

const (
	testDeviceUID = "esp32-demo-001"
	testDeviceID  = "33333333-3333-3333-3333-333333333333"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
)

var testNow = time.Date(2026, 6, 15, 12, 0, 0, 0, time.UTC)

type deviceService struct {
	item device.Device
	err  error
}

func (s deviceService) GetByUID(context.Context, string) (device.Device, error) {
	return s.item, s.err
}

type telemetryWriter struct {
	input  telemetry.NewRecord
	record telemetry.Record
	err    error
}

func (w *telemetryWriter) Create(
	_ context.Context,
	input telemetry.NewRecord,
) (telemetry.Record, error) {
	w.input = input
	if w.err != nil {
		return telemetry.Record{}, w.err
	}
	if w.record.ID == 0 {
		w.record = telemetry.Record{
			ID:                6,
			VehicleID:         input.VehicleID,
			DeviceID:          input.DeviceID,
			MeasuredAt:        input.MeasuredAt,
			ReceivedAt:        input.ReceivedAt,
			EngineTemperature: input.EngineTemperature,
			BatteryVoltage:    input.BatteryVoltage,
			VibrationLevel:    input.VibrationLevel,
			RPM:               input.RPM,
			Speed:             input.Speed,
			FuelLevel:         input.FuelLevel,
		}
	}
	return w.record, nil
}

type alertEvaluator struct {
	record telemetry.Record
	result alertevaluation.Result
	err    error
}

func (e *alertEvaluator) EvaluateRecord(
	_ context.Context,
	record telemetry.Record,
) (alertevaluation.Result, error) {
	e.record = record
	return e.result, e.err
}

func TestServiceIngest(t *testing.T) {
	writer := &telemetryWriter{}
	evaluator := &alertEvaluator{
		result: alertevaluation.Result{
			CreatedAlerts: []alert.Alert{{Type: "rpm", Severity: "warning"}},
			ExistingAlerts: []alert.Alert{{
				Type:     "vibration_level",
				Severity: "critical",
			}},
			OverallResult: "critical",
		},
	}
	svc := &service{
		devices: deviceService{item: device.Device{
			ID:        testDeviceID,
			VehicleID: testVehicleID,
			DeviceUID: testDeviceUID,
		}},
		telemetry: writer,
		evaluator: evaluator,
		now:       func() time.Time { return testNow },
	}

	result, err := svc.Ingest(context.Background(), testDeviceUID, validInput())
	if err != nil {
		t.Fatalf("Ingest() returned an error: %v", err)
	}
	if result.Telemetry.ID != 6 {
		t.Fatalf("expected telemetry ID 6, got %d", result.Telemetry.ID)
	}
	if writer.input.VehicleID != testVehicleID || writer.input.DeviceID != testDeviceID {
		t.Fatalf("telemetry was not linked to the resolved device: %#v", writer.input)
	}
	if !writer.input.MeasuredAt.Equal(testNow) || !writer.input.ReceivedAt.Equal(testNow) {
		t.Fatal("expected omitted measured_at and received_at to use the current time")
	}
	if evaluator.record.ID != result.Telemetry.ID {
		t.Fatal("evaluator did not receive the exact saved telemetry record")
	}
	if len(result.CreatedAlerts) != 1 ||
		len(result.ExistingAlerts) != 1 ||
		result.OverallResult != "critical" {
		t.Fatalf("unexpected ingestion result: %#v", result)
	}
}

func TestServiceUsesProvidedMeasuredAt(t *testing.T) {
	measuredAt := testNow.Add(-time.Minute)
	input := validInput()
	input.MeasuredAt = &measuredAt
	writer := &telemetryWriter{}
	svc := &service{
		devices: deviceService{item: device.Device{
			ID:        testDeviceID,
			VehicleID: testVehicleID,
		}},
		telemetry: writer,
		evaluator: &alertEvaluator{
			result: alertevaluation.Result{OverallResult: "normal"},
		},
		now: func() time.Time { return testNow },
	}

	if _, err := svc.Ingest(context.Background(), testDeviceUID, input); err != nil {
		t.Fatalf("Ingest() returned an error: %v", err)
	}
	if !writer.input.MeasuredAt.Equal(measuredAt) {
		t.Fatalf("expected measured_at %s, got %s", measuredAt, writer.input.MeasuredAt)
	}
}

func TestServiceValidation(t *testing.T) {
	svc := &service{
		devices: deviceService{item: device.Device{
			ID:        testDeviceID,
			VehicleID: testVehicleID,
		}},
		telemetry: &telemetryWriter{},
		evaluator: &alertEvaluator{},
		now:       func() time.Time { return testNow },
	}

	if _, err := svc.Ingest(context.Background(), "bad uid", validInput()); !errors.Is(err, ErrInvalidDeviceUID) {
		t.Fatalf("expected ErrInvalidDeviceUID, got %v", err)
	}

	notFoundService := &service{
		devices: deviceService{err: device.ErrNotFound},
		now:     func() time.Time { return testNow },
	}
	if _, err := notFoundService.Ingest(context.Background(), "unknown-device", validInput()); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatalf("expected ErrDeviceNotFound, got %v", err)
	}

	missingField := validInput()
	missingField.Speed = nil
	if _, err := svc.Ingest(context.Background(), testDeviceUID, missingField); !errors.Is(err, ErrInvalidPayload) {
		t.Fatalf("expected ErrInvalidPayload for missing field, got %v", err)
	}

	outOfRange := validInput()
	invalidSpeed := 301.0
	outOfRange.Speed = &invalidSpeed
	if _, err := svc.Ingest(context.Background(), testDeviceUID, outOfRange); !errors.Is(err, ErrInvalidPayload) {
		t.Fatalf("expected ErrInvalidPayload for invalid speed, got %v", err)
	}

	futureTime := testNow.Add(maximumFutureTime + time.Second)
	future := validInput()
	future.MeasuredAt = &futureTime
	if _, err := svc.Ingest(context.Background(), testDeviceUID, future); !errors.Is(err, ErrInvalidPayload) {
		t.Fatalf("expected ErrInvalidPayload for future measured_at, got %v", err)
	}
}

func validInput() Input {
	engineTemperature := 96.5
	batteryVoltage := 13.6
	vibrationLevel := 2.1
	rpm := 2600
	speed := 72.0
	fuelLevel := 63.5

	return Input{
		EngineTemperature: &engineTemperature,
		BatteryVoltage:    &batteryVoltage,
		VibrationLevel:    &vibrationLevel,
		RPM:               &rpm,
		Speed:             &speed,
		FuelLevel:         &fuelLevel,
	}
}
