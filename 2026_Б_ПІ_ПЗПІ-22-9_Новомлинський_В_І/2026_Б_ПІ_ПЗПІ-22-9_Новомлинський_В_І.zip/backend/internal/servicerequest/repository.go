package servicerequest

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
)

const (
	ActionServiceRequestAssigned   = "service_request.assigned"
	ActionServiceRequestReassigned = "service_request.reassigned"
	ActionServiceRequestCancelled  = "service_request.cancelled"
	EntityTypeServiceRequest       = "service_request"
)

var (
	ErrNotFound                  = errors.New("service request not found")
	ErrDuplicateOpenAlertRequest = errors.New("open service request already exists for alert")
)

type Repository interface {
	Create(ctx context.Context, request CreateRequest) (Request, error)
	ListForOwner(ctx context.Context, ownerID string) ([]Request, error)
	GetForOwner(ctx context.Context, ownerID string, requestID string) (Request, error)
	ListForAdmin(ctx context.Context, status string) ([]Request, error)
	GetByID(ctx context.Context, requestID string) (Request, error)
	Assign(ctx context.Context, requestID string, specialistID string, adminID string) (Request, error)
	CancelByOwner(ctx context.Context, ownerID string, requestID string) (Request, error)
	CancelByAdmin(ctx context.Context, adminID string, requestID string) (Request, error)
	ListForSpecialist(ctx context.Context, specialistID string) ([]Request, error)
	GetForSpecialist(ctx context.Context, specialistID string, requestID string) (Request, error)
	Start(ctx context.Context, specialistID string, requestID string) (Request, error)
	Complete(ctx context.Context, specialistID string, requestID string, resultSummary string) (Request, error)
}

type PostgresRepository struct {
	db            *sql.DB
	notifications notification.Writer
	audits        auditlog.Writer
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{
		db:            db,
		notifications: notification.NewPostgresWriter(),
		audits:        auditlog.NewPostgresWriter(),
	}
}

func (r *PostgresRepository) Create(ctx context.Context, request CreateRequest) (Request, error) {
	const query = `
		INSERT INTO vehicle_service_requests (
			vehicle_id,
			owner_id,
			source_alert_id,
			title,
			description,
			priority
		)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
	`

	item, err := scanRequest(r.db.QueryRowContext(
		ctx,
		query,
		request.VehicleID,
		request.OwnerID,
		request.SourceAlertID,
		request.Title,
		request.Description,
		request.Priority,
	))
	if isDuplicateOpenAlertRequest(err) {
		return Request{}, ErrDuplicateOpenAlertRequest
	}
	if err != nil {
		return Request{}, fmt.Errorf("create service request: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ListForOwner(ctx context.Context, ownerID string) ([]Request, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
		WHERE owner_id = $1
		ORDER BY created_at DESC, id DESC
	`

	return queryRequests(ctx, r.db, query, ownerID)
}

func (r *PostgresRepository) GetForOwner(
	ctx context.Context,
	ownerID string,
	requestID string,
) (Request, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
		WHERE id = $1 AND owner_id = $2
	`

	return getRequest(ctx, r.db, query, requestID, ownerID)
}

func (r *PostgresRepository) ListForAdmin(ctx context.Context, status string) ([]Request, error) {
	const baseQuery = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
	`
	if status != "" {
		return queryRequests(
			ctx,
			r.db,
			baseQuery+" WHERE status = $1 ORDER BY created_at DESC, id DESC",
			status,
		)
	}

	return queryRequests(ctx, r.db, baseQuery+" ORDER BY created_at DESC, id DESC")
}

func (r *PostgresRepository) GetByID(ctx context.Context, requestID string) (Request, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
		WHERE id = $1
	`

	return getRequest(ctx, r.db, query, requestID)
}

func (r *PostgresRepository) Assign(
	ctx context.Context,
	requestID string,
	specialistID string,
	adminID string,
) (Request, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Request{}, fmt.Errorf("begin service request assignment transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	previous, err := r.getByIDForUpdate(ctx, tx, requestID)
	if err != nil {
		return Request{}, err
	}
	if previous.Status != StatusPending && previous.Status != StatusAssigned {
		return Request{}, ErrInvalidTransition
	}

	const query = `
		UPDATE vehicle_service_requests
		SET
			assigned_specialist_id = $2,
			assigned_by = $3,
			status = 'assigned',
			assigned_at = CURRENT_TIMESTAMP,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1
		RETURNING
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
	`

	item, err := getRequest(ctx, tx, query, requestID, specialistID, adminID)
	if err != nil {
		return Request{}, err
	}
	if err := r.createLifecycleNotification(
		ctx,
		tx,
		assignmentNotification(item),
	); err != nil {
		return Request{}, err
	}
	if err := r.writeLifecycleAudit(
		ctx,
		tx,
		adminID,
		assignmentAuditAction(previous),
		previous,
		item,
	); err != nil {
		return Request{}, err
	}
	if err := tx.Commit(); err != nil {
		return Request{}, fmt.Errorf("commit service request assignment transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) CancelByOwner(
	ctx context.Context,
	ownerID string,
	requestID string,
) (Request, error) {
	const query = `
		UPDATE vehicle_service_requests
		SET
			status = 'cancelled',
			cancelled_at = CURRENT_TIMESTAMP,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1 AND owner_id = $2
		RETURNING
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
	`

	return getRequest(ctx, r.db, query, requestID, ownerID)
}

func (r *PostgresRepository) CancelByAdmin(
	ctx context.Context,
	adminID string,
	requestID string,
) (Request, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Request{}, fmt.Errorf("begin service request admin cancellation transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	previous, err := r.getByIDForUpdate(ctx, tx, requestID)
	if err != nil {
		return Request{}, err
	}
	if previous.Status != StatusPending && previous.Status != StatusAssigned {
		return Request{}, ErrInvalidTransition
	}

	const query = `
		UPDATE vehicle_service_requests
		SET
			status = 'cancelled',
			cancelled_at = CURRENT_TIMESTAMP,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1
		RETURNING
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
	`

	item, err := getRequest(ctx, tx, query, requestID)
	if err != nil {
		return Request{}, err
	}
	if err := r.writeLifecycleAudit(
		ctx,
		tx,
		adminID,
		ActionServiceRequestCancelled,
		previous,
		item,
	); err != nil {
		return Request{}, err
	}
	if err := tx.Commit(); err != nil {
		return Request{}, fmt.Errorf("commit service request admin cancellation transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ListForSpecialist(
	ctx context.Context,
	specialistID string,
) ([]Request, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
		WHERE assigned_specialist_id = $1
		ORDER BY created_at DESC, id DESC
	`

	return queryRequests(ctx, r.db, query, specialistID)
}

func (r *PostgresRepository) GetForSpecialist(
	ctx context.Context,
	specialistID string,
	requestID string,
) (Request, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
		WHERE id = $1 AND assigned_specialist_id = $2
	`

	return getRequest(ctx, r.db, query, requestID, specialistID)
}

func (r *PostgresRepository) Start(
	ctx context.Context,
	specialistID string,
	requestID string,
) (Request, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Request{}, fmt.Errorf("begin service request start transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	const query = `
		UPDATE vehicle_service_requests
		SET
			status = 'in_progress',
			started_at = CURRENT_TIMESTAMP,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1 AND assigned_specialist_id = $2
		  AND status = 'assigned'
		RETURNING
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
	`

	item, err := getRequest(ctx, tx, query, requestID, specialistID)
	if err != nil {
		return Request{}, err
	}
	if err := r.createLifecycleNotification(
		ctx,
		tx,
		startedNotification(item),
	); err != nil {
		return Request{}, err
	}
	if err := tx.Commit(); err != nil {
		return Request{}, fmt.Errorf("commit service request start transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) Complete(
	ctx context.Context,
	specialistID string,
	requestID string,
	resultSummary string,
) (Request, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Request{}, fmt.Errorf("begin service request completion transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	const query = `
		UPDATE vehicle_service_requests
		SET
			status = 'completed',
			result_summary = $3,
			completed_at = CURRENT_TIMESTAMP,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1 AND assigned_specialist_id = $2
		  AND status = 'in_progress'
		RETURNING
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
	`

	item, err := getRequest(ctx, tx, query, requestID, specialistID, resultSummary)
	if err != nil {
		return Request{}, err
	}
	if err := r.createLifecycleNotification(
		ctx,
		tx,
		completedNotification(item, resultSummary),
	); err != nil {
		return Request{}, err
	}
	if err := tx.Commit(); err != nil {
		return Request{}, fmt.Errorf("commit service request completion transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) createLifecycleNotification(
	ctx context.Context,
	tx notification.Executor,
	input notification.NewNotification,
) error {
	if r.notifications == nil {
		return nil
	}

	_, err := r.notifications.Create(
		ctx,
		tx,
		input,
	)
	if err != nil {
		return fmt.Errorf("create service request lifecycle notification: %w", err)
	}

	return nil
}

func (r *PostgresRepository) writeLifecycleAudit(
	ctx context.Context,
	tx auditlog.Executor,
	actorID string,
	action string,
	previous Request,
	next Request,
) error {
	if r.audits == nil {
		return nil
	}

	err := r.audits.Write(ctx, tx, auditlog.Entry{
		ActorID:    actorID,
		Action:     action,
		EntityType: EntityTypeServiceRequest,
		EntityID:   next.ID,
		Metadata:   lifecycleAuditMetadata(previous, next),
	})
	if err != nil {
		return fmt.Errorf("write service request lifecycle audit: %w", err)
	}

	return nil
}

func (r *PostgresRepository) getByIDForUpdate(
	ctx context.Context,
	tx *sql.Tx,
	requestID string,
) (Request, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			owner_id,
			source_alert_id,
			assigned_specialist_id,
			assigned_by,
			title,
			description,
			priority,
			status,
			result_summary,
			created_at,
			updated_at,
			assigned_at,
			started_at,
			completed_at,
			cancelled_at
		FROM vehicle_service_requests
		WHERE id = $1
		FOR UPDATE
	`

	return getRequest(ctx, tx, query, requestID)
}

func assignmentAuditAction(previous Request) string {
	if previous.Status == StatusAssigned {
		return ActionServiceRequestReassigned
	}

	return ActionServiceRequestAssigned
}

func lifecycleAuditMetadata(previous Request, next Request) map[string]any {
	return map[string]any{
		"vehicle_id":             next.VehicleID,
		"owner_id":               next.OwnerID,
		"title":                  next.Title,
		"priority":               next.Priority,
		"previous_status":        previous.Status,
		"new_status":             next.Status,
		"previous_specialist_id": previous.AssignedSpecialistID,
		"new_specialist_id":      next.AssignedSpecialistID,
	}
}

func assignmentNotification(item Request) notification.NewNotification {
	return notification.NewNotification{
		UserID:           item.OwnerID,
		ServiceRequestID: &item.ID,
		NotificationType: notification.TypeServiceRequestAssigned,
		Title:            "Specialist assigned",
		Message:          fmt.Sprintf("A technical specialist was assigned to service request %q.", item.Title),
	}
}

func startedNotification(item Request) notification.NewNotification {
	return notification.NewNotification{
		UserID:           item.OwnerID,
		ServiceRequestID: &item.ID,
		NotificationType: notification.TypeServiceRequestStarted,
		Title:            "Service work started",
		Message:          fmt.Sprintf("Work started on service request %q.", item.Title),
	}
}

func completedNotification(item Request, resultSummary string) notification.NewNotification {
	return notification.NewNotification{
		UserID:           item.OwnerID,
		ServiceRequestID: &item.ID,
		NotificationType: notification.TypeServiceRequestCompleted,
		Title:            "Service request completed",
		Message: fmt.Sprintf(
			"Service request %q was completed. Result: %s",
			item.Title,
			resultSummary,
		),
	}
}

type queryer interface {
	QueryContext(ctx context.Context, query string, args ...any) (*sql.Rows, error)
}

type rowQueryer interface {
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

type scanner interface {
	Scan(dest ...any) error
}

func queryRequests(
	ctx context.Context,
	db queryer,
	query string,
	args ...any,
) ([]Request, error) {
	rows, err := db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query service requests: %w", err)
	}
	defer rows.Close()

	requests := make([]Request, 0)
	for rows.Next() {
		item, err := scanRequest(rows)
		if err != nil {
			return nil, fmt.Errorf("scan service request: %w", err)
		}
		requests = append(requests, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate service requests: %w", err)
	}

	return requests, nil
}

func getRequest(
	ctx context.Context,
	db rowQueryer,
	query string,
	args ...any,
) (Request, error) {
	item, err := scanRequest(db.QueryRowContext(ctx, query, args...))
	if errors.Is(err, sql.ErrNoRows) {
		return Request{}, ErrNotFound
	}
	if err != nil {
		return Request{}, fmt.Errorf("query service request: %w", err)
	}

	return item, nil
}

func scanRequest(row scanner) (Request, error) {
	var (
		item                 Request
		sourceAlertID        sql.NullString
		assignedSpecialistID sql.NullString
		assignedBy           sql.NullString
		resultSummary        sql.NullString
		assignedAt           sql.NullTime
		startedAt            sql.NullTime
		completedAt          sql.NullTime
		cancelledAt          sql.NullTime
	)

	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.OwnerID,
		&sourceAlertID,
		&assignedSpecialistID,
		&assignedBy,
		&item.Title,
		&item.Description,
		&item.Priority,
		&item.Status,
		&resultSummary,
		&item.CreatedAt,
		&item.UpdatedAt,
		&assignedAt,
		&startedAt,
		&completedAt,
		&cancelledAt,
	); err != nil {
		return Request{}, err
	}

	if sourceAlertID.Valid {
		item.SourceAlertID = &sourceAlertID.String
	}
	if assignedSpecialistID.Valid {
		item.AssignedSpecialistID = &assignedSpecialistID.String
	}
	if assignedBy.Valid {
		item.AssignedBy = &assignedBy.String
	}
	if resultSummary.Valid {
		item.ResultSummary = &resultSummary.String
	}
	if assignedAt.Valid {
		item.AssignedAt = &assignedAt.Time
	}
	if startedAt.Valid {
		item.StartedAt = &startedAt.Time
	}
	if completedAt.Valid {
		item.CompletedAt = &completedAt.Time
	}
	if cancelledAt.Valid {
		item.CancelledAt = &cancelledAt.Time
	}

	return item, nil
}

func isDuplicateOpenAlertRequest(err error) bool {
	if err == nil {
		return false
	}

	message := err.Error()
	return strings.Contains(message, "vehicle_service_requests_open_source_alert_unique") ||
		strings.Contains(message, "duplicate key")
}
