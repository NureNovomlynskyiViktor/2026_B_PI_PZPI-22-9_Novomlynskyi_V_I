import { useLocale, useMessages } from '../i18n';
import { formatStructuredLabel, formatTelemetryMetricValue, formatTimestamp } from '../utils/presentation';
import type { TelemetryRecord, VehicleStatus } from '../api/types';

type Props = {
  status: VehicleStatus | null;
  isLoading: boolean;
};

export function StatusPanel({ status, isLoading }: Props) {
  const { common, specialist, structuredLabels } = useMessages();
  const diagnosticsMessages = specialist.diagnostics;

  if (isLoading && !status) {
    return (
      <section className="panel">
        <h2>{diagnosticsMessages.vehicleStatus}</h2>
        <p className="muted">{common.loadingStatus}</p>
      </section>
    );
  }

  if (!status) {
    return (
      <section className="panel">
        <h2>{diagnosticsMessages.vehicleStatus}</h2>
        <p className="empty-state">{diagnosticsMessages.selectVehicleStatus}</p>
      </section>
    );
  }

  return (
    <section className="panel status-panel">
      <div className="panel-header">
        <div>
          <h2>{diagnosticsMessages.vehicleStatus}</h2>
          <p className="muted">
            {status.vehicle.brand} {status.vehicle.model} /{' '}
            {status.vehicle.license_plate ?? common.notAvailable}
          </p>
        </div>
        <span className={`status-pill ${status.overall_status}`}>
          {formatStructuredLabel(status.overall_status, common.notAvailable, structuredLabels)}
        </span>
      </div>

      <TelemetryGrid telemetry={status.latest_telemetry} />
    </section>
  );
}

function TelemetryGrid({ telemetry }: { telemetry: TelemetryRecord | null }) {
  const { common, specialist, structuredLabels } = useMessages();
  const { locale } = useLocale();
  const diagnosticsMessages = specialist.diagnostics;

  if (!telemetry) {
    return (
      <p className="empty-state">{diagnosticsMessages.waitingForTelemetry}</p>
    );
  }

  const items = [
    [structuredLabels.engine_temperature, formatTelemetryMetricValue('engine_temperature', telemetry.engine_temperature, locale)],
    [structuredLabels.battery_voltage, formatTelemetryMetricValue('battery_voltage', telemetry.battery_voltage, locale)],
    [structuredLabels.vibration_level, formatTelemetryMetricValue('vibration_level', telemetry.vibration_level, locale)],
    [structuredLabels.rpm, formatTelemetryMetricValue('rpm', telemetry.rpm, locale)],
    [structuredLabels.speed, formatTelemetryMetricValue('speed', telemetry.speed, locale)],
    [structuredLabels.fuel_level, formatTelemetryMetricValue('fuel_level', telemetry.fuel_level, locale)],
  ];

  return (
    <div>
      <p className="muted">
        {common.measuredAt} {formatTimestamp(telemetry.measured_at, common.notAvailable)}
      </p>
      <div className="metric-grid">
        {items.map(([label, value]) => (
          <div className="metric-card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
