# Autonexis Web

React + TypeScript + Vite web application for Autonexis.

The web product is role-aware:

- public visitors see the landing page and mobile onboarding guidance;
- vehicle owners see Android app download and vehicle-activation guidance after sign-in;
- administrators use the web administrator workspace;
- technical specialists use the web specialist workspace.

Vehicle-owner daily monitoring is intentionally handled by the Android app, not by a duplicated owner web dashboard.

## Features

- public landing page with product and onboarding guidance;
- email/password registration and login;
- optional Google Sign-In and authenticated Google account linking;
- account panel with sign-in methods, language selection, and appearance mode;
- English and Ukrainian localization foundation;
- light, dark, and system appearance modes;
- owner mobile onboarding with optional demo APK QR/link;
- administrator workspace for vehicle activation, specialist assignment, competencies, user lifecycle, service requests, and audit logs;
- technical specialist workspace for assigned vehicles, diagnostics, telemetry trends, service requests, maintenance records, and specialist-confirmed incident resolution.

## Requirements

- Node.js 22 or compatible current LTS;
- running Autonexis backend on `http://localhost:8080`;
- PostgreSQL and Mosquitto through the repository Docker Compose setup.

## Configuration

The API base URL is configured through Vite environment variables.

Create a local `.env` file only if you need to override the default:

```powershell
Copy-Item .env.example .env
```

Default:

```text
VITE_API_BASE_URL=http://localhost:8080
```

Optional public/support and authentication configuration:

```env
VITE_SUPPORT_EMAIL=
VITE_GOOGLE_CLIENT_ID=your-web-client-id.apps.googleusercontent.com
```

`VITE_GOOGLE_CLIENT_ID` is a public OAuth client identifier, not a secret. Do not put a Google client secret in the web application. Store real local values in `.env.local`, restart Vite after changing them, and configure the backend separately with Google auth enabled and the same client ID in its allowed audience list.

Optional owner mobile onboarding APK link:

```env
VITE_ANDROID_APK_URL=https://example.com/autonexis-demo.apk
```

`VITE_ANDROID_APK_URL` enables the authenticated owner onboarding page to render a QR code and `Download APK` link for a demo Android APK distribution channel. Do not commit APK files to the repository.

Local `.env` files should not be committed.

## Owner Web Experience

Authenticated `vehicle_owner` users always see the mobile onboarding page in the web app. That page explains how to:

1. download and install the Android app;
2. sign in with the owner account;
3. get a vehicle activation QR from an administrator or service center;
4. scan the activation QR in Android;
5. start monitoring the connected vehicle.

The APK download QR and the vehicle activation QR are different:

- APK QR downloads the Android application;
- vehicle activation QR connects one registered vehicle to the owner account.

Vehicle owners use Android for vehicles, telemetry, alerts, service requests, notifications, and maintenance history.

## Account Sign-In Methods

Authenticated users can open `Account / Sign-in methods` from the owner onboarding page or from the administrator and technical specialist workspace headers. The panel shows whether password sign-in is enabled and whether a Google account is connected.

Google linking requires an authenticated Autonexis account and the same Google Web Client ID configuration used by public Google Sign-In. Users must connect a Google account that uses the same email address as the current Autonexis account. Linking adds another sign-in method only: it does not replace the current JWT, change the account role, change account data, or sign the user out.

Unlinking Google, creating a password for Google-only accounts, password reset, and password change are intentionally unsupported in this step.

## Install

From the `web` directory:

```powershell
npm install
```

## Run

Start the backend first. Then run:

```powershell
npm run dev
```

Open:

```text
http://localhost:5173
```

The backend must allow the frontend origin. The repository root `.env.example` includes:

```text
CORS_ALLOWED_ORIGINS=http://localhost:5173
```

## Build

```powershell
npm run build
```

## Demo Accounts

Development-only seeded accounts:

| Email | Role | Password |
|---|---|---|
| `owner@example.com` | `vehicle_owner` | `DemoPass123!` |
| `specialist@example.com` | `technical_specialist` | `DemoPass123!` |
| `specialist.engine@example.com` | `technical_specialist` | `DemoPass123!` |
| `specialist.electrical@example.com` | `technical_specialist` | `DemoPass123!` |
| `admin@example.com` | `administrator` | `DemoPass123!` |

These accounts are only for local demonstration. Do not reuse the seeded password outside development.

## Demo Flow

1. Start Docker services from the repository root.
2. Apply backend migrations and `backend/seeds/dev_seed.sql`.
3. Start the backend from `backend`.
4. Start the web app from `web`.
5. Open the public landing page and sign in.
6. Login as `owner@example.com` and verify the Android onboarding/download/activation guidance.
7. Login as `admin@example.com` and verify vehicle onboarding, activation QR generation, specialist assignments, competencies, users, service requests, and audit logs.
8. Login as `specialist@example.com` and verify assigned vehicles, diagnostics, telemetry trends, service requests, maintenance records, and incident resolution.

## Role-Aware Behavior

- `vehicle_owner`: sees Android onboarding and APK/activation guidance. Daily monitoring is in Android.
- `technical_specialist`: sees the specialist workspace with assigned vehicles, diagnostics, telemetry history/trends, thresholds, alerts, service requests, maintenance records, and incident resolution.
- `administrator`: sees the administrator workspace for vehicle activation, specialist assignment/recommendations, competencies, users, service requests, and audit logs.

## Vehicle Onboarding

Administrators register unclaimed vehicles through:

```http
POST /api/v1/admin/vehicle-activations
```

A successful response displays the one-time plaintext activation code and a QR code only in the result panel. The QR payload format is:

```text
autonexis://vehicle-activation?code={ACTIVATION_CODE}
```

Example:

```text
autonexis://vehicle-activation?code=RNF6-CQSD
```

The QR contains the same sensitive one-time activation credential as the plaintext code. The web app does not store the plaintext code, activation URI, or QR image in local storage; after refresh, they cannot be recovered from the page. Owners can still enter the code manually in the Android app. QR scanning only extracts the code; the final vehicle claim still uses the authenticated owner endpoint:

```http
POST /api/v1/me/vehicle-activations/claim
```

## Administrator Workspace

Administrator workflows include:

- vehicle activation and QR/code handoff;
- specialist assignment and reassignment;
- specialist competency management;
- recommended specialists based on active vehicle context;
- service request triage, assignment, reassignment, and cancellation;
- user deactivation/reactivation;
- administrative audit log review.

Duplicate assignments and unsupported competency codes are reported by the backend. Recommendations are advisory and rule-based; the administrator still makes the final assignment decision.

## Technical Specialist Workspace

Technical specialist workflows include:

- assigned vehicle selection;
- diagnostic status and telemetry history/trends;
- active, cleared, and resolved incident review;
- service request start/completion;
- maintenance record creation for owners to view in Android;
- specialist-confirmed resolution for cleared incidents.

The specialist workspace does not expose owner-only Android actions such as vehicle activation claiming or notification-center management.

## MQTT Telemetry Context

Telemetry for registered devices can be sent through MQTT.

MQTT topic format:

```text
autonexis/devices/{device_uid}/telemetry
```

Example:

```text
autonexis/devices/esp32-demo-002/telemetry
```
