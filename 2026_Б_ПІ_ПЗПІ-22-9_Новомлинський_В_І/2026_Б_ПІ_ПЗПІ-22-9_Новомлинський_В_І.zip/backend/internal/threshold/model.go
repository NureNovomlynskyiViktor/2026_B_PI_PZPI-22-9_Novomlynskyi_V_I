package threshold

import "time"

type Setting struct {
	ID              string    `json:"id"`
	VehicleID       string    `json:"vehicle_id"`
	Parameter       string    `json:"parameter"`
	WarningValue    float64   `json:"warning_value"`
	CriticalValue   float64   `json:"critical_value"`
	RecoveryMargin  float64   `json:"recovery_margin"`
	RecoverySamples int       `json:"recovery_samples"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}
