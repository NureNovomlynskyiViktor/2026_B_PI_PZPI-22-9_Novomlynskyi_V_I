package device

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type stubService struct {
	devices []Device
	device  Device
	err     error
}

func (s stubService) List(context.Context) ([]Device, error) {
	return s.devices, s.err
}

func (s stubService) GetByID(context.Context, string) (Device, error) {
	return s.device, s.err
}

func (s stubService) GetByUID(context.Context, string) (Device, error) {
	return s.device, s.err
}

func (s stubService) GetByVehicleID(context.Context, string) (Device, error) {
	return s.device, s.err
}

func (s stubService) ListByOwner(context.Context, string) ([]Device, error) {
	return s.devices, s.err
}

func (s stubService) ListByVehicleForOwner(context.Context, string, string) ([]Device, error) {
	return s.devices, s.err
}

func (s stubService) GetByIDForOwner(context.Context, string, string) (Device, error) {
	return s.device, s.err
}

func (s stubService) CreateForOwnedVehicle(
	context.Context,
	string,
	string,
	CreateRequest,
) (Device, error) {
	return s.device, s.err
}

func TestHandlerList(t *testing.T) {
	handler := NewHandler(stubService{
		devices: []Device{{
			ID:        "11111111-1111-1111-1111-111111111111",
			DeviceUID: "esp32-vehicle-001",
			Status:    "active",
		}},
	}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/devices", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"device_uid":"esp32-vehicle-001"`) {
		t.Fatalf("expected device JSON, got %s", body)
	}
}

func TestHandlerGetByIDNotFound(t *testing.T) {
	handler := NewHandler(stubService{err: ErrNotFound}, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/devices/11111111-1111-1111-1111-111111111111",
		nil,
	)
	request.SetPathValue("id", "11111111-1111-1111-1111-111111111111")
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestHandlerListInternalError(t *testing.T) {
	handler := NewHandler(stubService{err: errors.New("database error")}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/devices", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, recorder.Code)
	}
	if strings.Contains(recorder.Body.String(), "database error") {
		t.Fatal("response exposed an internal error")
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
