package specialistassignment

import (
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

type Assignment struct {
	ID           string    `json:"id"`
	VehicleID    string    `json:"vehicle_id"`
	SpecialistID string    `json:"specialist_id"`
	Specialist   auth.User `json:"specialist"`
	AssignedBy   *string   `json:"assigned_by"`
	CreatedAt    time.Time `json:"created_at"`
}

type AssignRequest struct {
	Email string `json:"email"`
}

type AdminAssignRequest struct {
	SpecialistID string `json:"specialist_id"`
	Email        string `json:"email"`
}
