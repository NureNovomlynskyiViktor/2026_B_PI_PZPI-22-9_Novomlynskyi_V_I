BEGIN;

DROP TABLE IF EXISTS specialist_competencies;

COMMIT;
