package adminuser

import (
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strconv"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

const maximumAdminUserRequestBodySize = 1 << 20

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := adminUser(w, r)
	if !ok {
		return
	}

	filters, ok := queryFilters(w, r)
	if !ok {
		return
	}

	items, err := h.service.List(r.Context(), filters)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid user filters")
		return
	}
	if err != nil {
		h.logger.Error("failed to list admin users", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, items)
}

func (h *Handler) Get(w http.ResponseWriter, r *http.Request) {
	user, targetID, ok := adminTargetID(w, r)
	if !ok {
		return
	}

	item, err := h.service.Get(r.Context(), targetID)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid user_id")
		return
	}
	if errors.Is(err, ErrNotFound) {
		response.Error(w, http.StatusNotFound, "user not found")
		return
	}
	if err != nil {
		h.logger.Error("failed to get admin user", "user_id", user.ID, "target_user_id", targetID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Deactivate(w http.ResponseWriter, r *http.Request) {
	user, targetID, ok := adminTargetID(w, r)
	if !ok {
		return
	}

	var request DeactivateRequest
	if !decodeOptionalJSON(w, r, &request) {
		return
	}

	item, err := h.service.Deactivate(r.Context(), user, targetID, request)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid user deactivation request")
		return
	}
	if errors.Is(err, ErrSelfDeactivation) {
		response.Error(w, http.StatusConflict, "administrator cannot deactivate own account")
		return
	}
	if errors.Is(err, ErrNotFound) {
		response.Error(w, http.StatusNotFound, "user not found")
		return
	}
	if isConflict(err) {
		response.Error(w, http.StatusConflict, "user cannot be deactivated")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to deactivate user",
			"user_id", user.ID,
			"target_user_id", targetID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Reactivate(w http.ResponseWriter, r *http.Request) {
	user, targetID, ok := adminTargetID(w, r)
	if !ok {
		return
	}

	item, err := h.service.Reactivate(r.Context(), user, targetID)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid user_id")
		return
	}
	if errors.Is(err, ErrNotFound) {
		response.Error(w, http.StatusNotFound, "user not found")
		return
	}
	if isConflict(err) {
		response.Error(w, http.StatusConflict, "user cannot be reactivated")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to reactivate user",
			"user_id", user.ID,
			"target_user_id", targetID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func queryFilters(w http.ResponseWriter, r *http.Request) (ListFilters, bool) {
	query := r.URL.Query()
	filters := ListFilters{
		Role:   query.Get("role"),
		Search: query.Get("search"),
	}
	if raw := query.Get("is_active"); raw != "" {
		value, err := strconv.ParseBool(raw)
		if err != nil {
			response.Error(w, http.StatusBadRequest, "invalid is_active")
			return ListFilters{}, false
		}
		filters.IsActive = &value
	}

	return filters, true
}

func adminTargetID(w http.ResponseWriter, r *http.Request) (auth.User, string, bool) {
	user, ok := adminUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	return user, r.PathValue("user_id"), true
}

func adminUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.AdministratorRoleCode {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeOptionalJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumAdminUserRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(target)
	if errors.Is(err, io.EOF) {
		return true
	}
	if err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}

func isConflict(err error) bool {
	return errors.Is(err, ErrAlreadyInactive) ||
		errors.Is(err, ErrAlreadyActive) ||
		errors.Is(err, ErrLastAdministrator) ||
		errors.Is(err, ErrSpecialistActiveWork)
}
