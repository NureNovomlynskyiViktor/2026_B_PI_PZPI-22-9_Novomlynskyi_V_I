package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/admin"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminaudit"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminuser"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alertevaluation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/config"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/database"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/health"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/httpserver"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/logger"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/maintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/mqttconsumer"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/owneralert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerdevice"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownermaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownernotification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownertelemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerthreshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownervehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistalert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistmaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistrecommendation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistvehicle"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetryingestion"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicleactivation"
)

const (
	databasePingTimeout = 5 * time.Second
	shutdownTimeout     = 10 * time.Second
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		slog.Error("failed to load configuration", "error", err)
		os.Exit(1)
	}

	log := logger.New(cfg.AppEnv)
	slog.SetDefault(log)

	db, err := database.Open(cfg.Database)
	if err != nil {
		log.Error("failed to initialize database pool", "error", err)
		os.Exit(1)
	}
	defer db.Close()

	pingCtx, cancelPing := context.WithTimeout(context.Background(), databasePingTimeout)
	if err := db.PingContext(pingCtx); err != nil {
		log.Warn("database is not ready at startup", "error", err)
	} else {
		log.Info("database connection established")
	}
	cancelPing()

	healthHandler := health.New(db, log)
	vehicleRepository := vehicle.NewPostgresRepository(db)
	vehicleService := vehicle.NewService(vehicleRepository)
	vehicleHandler := vehicle.NewHandler(vehicleService, log)

	deviceRepository := device.NewPostgresRepository(db)
	deviceService := device.NewService(deviceRepository)
	deviceHandler := device.NewHandler(deviceService, log)

	telemetryRepository := telemetry.NewPostgresRepository(db)
	telemetryService := telemetry.NewService(telemetryRepository)
	telemetryHandler := telemetry.NewHandler(telemetryService, log)

	alertRepository := alert.NewPostgresRepository(db)
	alertService := alert.NewService(alertRepository)
	alertHandler := alert.NewHandler(alertService, log)

	statusService := vehiclestatus.NewService(
		vehicleService,
		deviceService,
		telemetryService,
		alertService,
	)
	statusHandler := vehiclestatus.NewHandler(statusService, log)

	thresholdRepository := threshold.NewPostgresRepository(db)
	thresholdService := threshold.NewService(thresholdRepository)
	maintenanceRepository := maintenance.NewPostgresRepository(db)
	maintenanceService := maintenance.NewService(maintenanceRepository)
	notificationRepository := notification.NewPostgresRepository(db)
	notificationService := notification.NewService(notificationRepository)
	vehicleActivationRepository := vehicleactivation.NewPostgresRepository(db)
	vehicleActivationService := vehicleactivation.NewService(
		vehicleActivationRepository,
		auth.BcryptHasher{},
	)
	specialistAssignmentRepository := specialistassignment.NewPostgresRepository(db)
	specialistAssignmentService := specialistassignment.NewService(
		specialistAssignmentRepository,
	)
	serviceRequestRepository := servicerequest.NewPostgresRepository(db)
	serviceRequestService := servicerequest.NewService(
		serviceRequestRepository,
		specialistAssignmentService,
	)
	specialistCompetencyRepository := specialistcompetency.NewPostgresRepository(db)
	specialistCompetencyService := specialistcompetency.NewService(
		specialistCompetencyRepository,
	)
	specialistRecommendationService := specialistrecommendation.NewService(
		alertService,
		specialistAssignmentService,
		specialistCompetencyService,
	)
	alertEvaluationService := alertevaluation.NewService(
		vehicleService,
		telemetryService,
		thresholdService,
		alertRepository,
		notificationService,
	)
	alertEvaluationHandler := alertevaluation.NewHandler(
		alertEvaluationService,
		log,
	)
	telemetryIngestionService := telemetryingestion.NewService(
		deviceService,
		telemetryRepository,
		alertEvaluationService,
	)
	telemetryIngestionHandler := telemetryingestion.NewHandler(
		telemetryIngestionService,
		log,
	)
	authRepository := auth.NewPostgresRepository(db)
	var googleVerifier auth.GoogleTokenVerifier
	if cfg.GoogleAuth.Enabled {
		googleVerifier = auth.NewGoogleIDTokenVerifier(cfg.GoogleAuth.ClientIDs)
	}
	authService := auth.NewServiceWithGoogle(
		authRepository,
		auth.BcryptHasher{},
		auth.NewJWTManager(cfg.JWT.Secret, cfg.JWT.AccessTokenTTL),
		googleVerifier,
		cfg.GoogleAuth.Enabled,
	)
	authHandler := auth.NewHandler(authService, log)
	vehicleActivationHandler := vehicleactivation.NewHandler(
		vehicleActivationService,
		log,
	)
	ownerVehicleHandler := ownervehicle.NewHandler(
		vehicleService,
		statusService,
		log,
	)
	ownerDeviceHandler := ownerdevice.NewHandler(
		deviceService,
		vehicleService,
		log,
	)
	ownerTelemetryHandler := ownertelemetry.NewHandler(
		telemetryService,
		vehicleService,
		log,
	)
	ownerAlertHandler := owneralert.NewHandler(
		alertService,
		vehicleService,
		log,
	)
	ownerThresholdHandler := ownerthreshold.NewHandler(
		thresholdService,
		vehicleService,
		log,
	)
	ownerMaintenanceHandler := ownermaintenance.NewHandler(
		maintenanceService,
		vehicleService,
		log,
	)
	ownerNotificationHandler := ownernotification.NewHandler(
		notificationService,
		log,
	)
	ownerServiceRequestHandler := ownerservicerequest.NewHandler(
		serviceRequestService,
		vehicleService,
		alertService,
		log,
	)
	ownerSpecialistHandler := ownerspecialist.NewHandler(
		specialistAssignmentService,
		vehicleService,
		log,
	)
	specialistAlertHandler := specialistalert.NewHandler(
		alertService,
		log,
	)
	specialistMaintenanceHandler := specialistmaintenance.NewHandler(
		maintenanceService,
		specialistAssignmentService,
		vehicleService,
		log,
	)
	specialistServiceRequestHandler := specialistservicerequest.NewHandler(
		serviceRequestService,
		log,
	)
	specialistVehicleHandler := specialistvehicle.NewHandler(
		specialistAssignmentService,
		statusService,
		thresholdService,
		telemetryService,
		alertService,
		log,
	)
	adminServiceRequestHandler := adminservicerequest.NewHandler(
		serviceRequestService,
		log,
	)
	adminSpecialistRepository := adminspecialist.NewPostgresRepository(db)
	adminSpecialistService := adminspecialist.NewService(
		adminSpecialistRepository,
		auth.BcryptHasher{},
	)
	adminSpecialistHandler := adminspecialist.NewHandler(adminSpecialistService, log)
	adminUserRepository := adminuser.NewPostgresRepository(db)
	adminUserService := adminuser.NewService(adminUserRepository)
	adminUserHandler := adminuser.NewHandler(adminUserService, log)
	adminAuditRepository := adminaudit.NewPostgresRepository(db)
	adminAuditService := adminaudit.NewService(adminAuditRepository)
	adminAuditHandler := adminaudit.NewHandler(adminAuditService, log)
	adminHandler := admin.NewHandler(
		vehicleService,
		specialistAssignmentService,
		specialistCompetencyService,
		specialistRecommendationService,
		log,
	)

	signalCtx, stop := signal.NotifyContext(
		context.Background(),
		os.Interrupt,
		syscall.SIGTERM,
	)
	defer stop()

	var mqttTelemetrySupervisor *mqttconsumer.Supervisor
	if cfg.MQTT.Enabled {
		mqttTelemetryConsumer, err := mqttconsumer.New(
			cfg.MQTT,
			telemetryIngestionService,
			log,
		)
		if err != nil {
			log.Error("failed to configure MQTT consumer", "error", err)
			os.Exit(1)
		}

		mqttTelemetrySupervisor = mqttconsumer.NewSupervisor(
			mqttTelemetryConsumer,
			cfg.MQTT,
			log,
		)
		mqttTelemetrySupervisor.Start(signalCtx)
	}

	router := httpserver.NewRouter(
		healthHandler,
		vehicleHandler,
		deviceHandler,
		telemetryHandler,
		alertHandler,
		statusHandler,
		alertEvaluationHandler,
		telemetryIngestionHandler,
		authHandler,
		vehicleActivationHandler,
		ownerVehicleHandler,
		ownerDeviceHandler,
		ownerTelemetryHandler,
		ownerAlertHandler,
		ownerThresholdHandler,
		ownerMaintenanceHandler,
		ownerNotificationHandler,
		ownerServiceRequestHandler,
		ownerSpecialistHandler,
		specialistAlertHandler,
		specialistMaintenanceHandler,
		specialistServiceRequestHandler,
		specialistVehicleHandler,
		adminServiceRequestHandler,
		adminSpecialistHandler,
		adminUserHandler,
		adminAuditHandler,
		adminHandler,
		authService,
		cfg.CORS,
		log,
	)
	server := httpserver.New(cfg.HTTP, router)

	serverErrors := make(chan error, 1)
	go func() {
		log.Info(
			"HTTP server starting",
			"address", server.Addr,
			"environment", cfg.AppEnv,
		)
		serverErrors <- server.ListenAndServe()
	}()

	select {
	case <-signalCtx.Done():
		log.Info("shutdown signal received")
	case err := <-serverErrors:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Error("HTTP server stopped unexpectedly", "error", err)
		}
	}

	if mqttTelemetrySupervisor != nil {
		mqttTelemetrySupervisor.Close()
	}

	shutdownCtx, cancelShutdown := context.WithTimeout(context.Background(), shutdownTimeout)
	defer cancelShutdown()

	if err := server.Shutdown(shutdownCtx); err != nil {
		log.Error("graceful HTTP shutdown failed", "error", err)
		if closeErr := server.Close(); closeErr != nil {
			log.Error("forced HTTP shutdown failed", "error", closeErr)
		}
		os.Exit(1)
	}

	log.Info("HTTP server stopped")
}
