package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.VehiclePresentation

class VehiclePresentationTest {
    @Test
    fun formatsYearAndPlateWithEncodingSafeSeparator() {
        val metadata = VehiclePresentation.metadata(2024, "DEMO-001")

        assertEquals("2024 \u2022 DEMO-001", metadata)
        assertTrue(metadata!!.contains('\u2022'))
        assertFalse(metadata.contains('\uFFFD'))
    }

    @Test
    fun formatsDifferentVehiclesWithoutDemoAssumptions() {
        assertEquals("2020 \u2022 AA1234BB", VehiclePresentation.metadata(2020, "AA1234BB"))
        assertEquals("2022 \u2022 AX-0002", VehiclePresentation.metadata(2022, " AX-0002 "))
    }

    @Test
    fun formatsPartialMetadataOnlyWhenAvailable() {
        assertEquals("2024", VehiclePresentation.metadata(2024, null))
        assertEquals("2024", VehiclePresentation.metadata(2024, "   "))
        assertEquals("AA1234BB", VehiclePresentation.metadata(null, "AA1234BB"))
        assertEquals("AA1234BB", VehiclePresentation.metadata(0, "AA1234BB"))
        assertNull(VehiclePresentation.metadata(null, null))
        assertNull(VehiclePresentation.metadata(-1, " "))
    }

    @Test
    fun neverReturnsNullLiteralOrOrphanSeparator() {
        listOf(
            VehiclePresentation.metadata(2024, null),
            VehiclePresentation.metadata(null, "AA1234BB"),
            VehiclePresentation.metadata(0, "AA1234BB"),
        ).forEach { metadata ->
            assertFalse(metadata!!.contains("null"))
            assertFalse(metadata.trim() == "\u2022")
            assertFalse(metadata.startsWith("\u2022"))
            assertFalse(metadata.endsWith("\u2022"))
            assertFalse(metadata.contains('\uFFFD'))
        }
    }

    @Test
    fun formattingDoesNotDependOnOwnerOrVehicleIdentity() {
        val firstOwnerVehicle = VehiclePresentation.metadata(2021, "OWNER-A")
        val secondOwnerVehicle = VehiclePresentation.metadata(2023, "OWNER-B")

        assertEquals("2021 \u2022 OWNER-A", firstOwnerVehicle)
        assertEquals("2023 \u2022 OWNER-B", secondOwnerVehicle)
    }
}
