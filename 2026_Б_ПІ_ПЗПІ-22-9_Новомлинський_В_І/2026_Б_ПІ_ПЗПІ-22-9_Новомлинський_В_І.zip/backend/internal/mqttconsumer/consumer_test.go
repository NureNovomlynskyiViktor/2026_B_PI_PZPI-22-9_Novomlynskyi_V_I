package mqttconsumer

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/config"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetryingestion"
)

const testTopicFilter = "autonexis/devices/+/telemetry"

type ingestionService struct {
	deviceUID string
	input     telemetryingestion.Input
	result    telemetryingestion.Result
	err       error
}

func (s *ingestionService) Ingest(
	_ context.Context,
	deviceUID string,
	input telemetryingestion.Input,
) (telemetryingestion.Result, error) {
	s.deviceUID = deviceUID
	s.input = input
	return s.result, s.err
}

func TestDeviceUIDFromTopic(t *testing.T) {
	deviceUID, err := DeviceUIDFromTopic(
		testTopicFilter,
		"autonexis/devices/esp32-demo-001/telemetry",
	)
	if err != nil {
		t.Fatalf("DeviceUIDFromTopic() returned an error: %v", err)
	}
	if deviceUID != "esp32-demo-001" {
		t.Fatalf("unexpected device UID: %s", deviceUID)
	}
}

func TestDeviceUIDFromTopicRejectsInvalidTopics(t *testing.T) {
	topics := []string{
		"autonexis/devices/telemetry",
		"autonexis/vehicles/esp32-demo-001/telemetry",
		"autonexis/devices/bad.uid/telemetry",
		"autonexis/devices/esp32-demo-001/status",
	}

	for _, topic := range topics {
		t.Run(topic, func(t *testing.T) {
			if _, err := DeviceUIDFromTopic(testTopicFilter, topic); !errors.Is(err, ErrInvalidTopic) {
				t.Fatalf("expected ErrInvalidTopic, got %v", err)
			}
		})
	}
}

func TestDecodePayload(t *testing.T) {
	input, err := DecodePayload([]byte(`{
		"measured_at":"2026-06-15T14:30:00+03:00",
		"engine_temperature":98.2,
		"battery_voltage":13.5,
		"vibration_level":2.3,
		"rpm":2700,
		"speed":75,
		"fuel_level":62.1
	}`))
	if err != nil {
		t.Fatalf("DecodePayload() returned an error: %v", err)
	}
	if input.RPM == nil || *input.RPM != 2700 {
		t.Fatalf("unexpected decoded RPM: %#v", input.RPM)
	}
	if input.MeasuredAt == nil {
		t.Fatal("expected measured_at to be decoded")
	}
}

func TestDecodePayloadRejectsMalformedAndUnknownFields(t *testing.T) {
	payloads := [][]byte{
		[]byte(`{"rpm":`),
		[]byte(`{"unexpected":true}`),
		[]byte(`{}` + `{}`),
	}

	for _, payload := range payloads {
		if _, err := DecodePayload(payload); !errors.Is(err, ErrInvalidPayload) {
			t.Fatalf("expected ErrInvalidPayload, got %v", err)
		}
	}
}

func TestProcessMessageUsesIngestionService(t *testing.T) {
	service := &ingestionService{
		result: telemetryingestion.Result{
			Telemetry:     telemetry.Record{ID: 6},
			OverallResult: "critical",
		},
	}
	consumer, err := New(
		config.MQTTConfig{TelemetryTopic: testTopicFilter},
		service,
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
	if err != nil {
		t.Fatalf("New() returned an error: %v", err)
	}

	result, err := consumer.processMessage(
		context.Background(),
		"autonexis/devices/esp32-demo-001/telemetry",
		[]byte(`{
			"engine_temperature":98.2,
			"battery_voltage":13.5,
			"vibration_level":2.3,
			"rpm":2700,
			"speed":75,
			"fuel_level":62.1
		}`),
	)
	if err != nil {
		t.Fatalf("processMessage() returned an error: %v", err)
	}
	if service.deviceUID != "esp32-demo-001" {
		t.Fatalf("unexpected device UID passed to ingestion: %s", service.deviceUID)
	}
	if result.ingestion.Telemetry.ID != 6 {
		t.Fatalf("unexpected telemetry ID: %d", result.ingestion.Telemetry.ID)
	}
}

func TestProcessMessagePreservesLifecycleAlertBuckets(t *testing.T) {
	service := &ingestionService{
		result: telemetryingestion.Result{
			Telemetry: telemetry.Record{ID: 7},
			CreatedAlerts: []alert.Alert{
				{ID: "created-alert", Status: alert.StatusActive},
			},
			UpdatedAlerts: []alert.Alert{
				{ID: "reopened-alert", Status: alert.StatusActive},
			},
			ResolvedAlerts: []alert.Alert{
				{ID: "cleared-alert", Status: alert.StatusCleared},
			},
			OverallResult: "warning",
		},
	}
	consumer, err := New(
		config.MQTTConfig{TelemetryTopic: testTopicFilter},
		service,
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
	if err != nil {
		t.Fatalf("New() returned an error: %v", err)
	}

	result, err := consumer.processMessage(
		context.Background(),
		"autonexis/devices/esp32-demo-001/telemetry",
		[]byte(`{
			"engine_temperature":98.2,
			"battery_voltage":13.5,
			"vibration_level":2.3,
			"rpm":2700,
			"speed":75,
			"fuel_level":62.1
		}`),
	)
	if err != nil {
		t.Fatalf("processMessage() returned an error: %v", err)
	}
	if len(result.ingestion.CreatedAlerts) != 1 ||
		len(result.ingestion.UpdatedAlerts) != 1 ||
		len(result.ingestion.ResolvedAlerts) != 1 ||
		result.ingestion.ResolvedAlerts[0].Status != alert.StatusCleared {
		t.Fatalf("unexpected lifecycle buckets: %#v", result.ingestion)
	}
}

func TestNewRejectsInvalidTopicFilter(t *testing.T) {
	if _, err := New(
		config.MQTTConfig{TelemetryTopic: "autonexis/devices/telemetry"},
		&ingestionService{},
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	); !errors.Is(err, ErrInvalidTopic) {
		t.Fatalf("expected ErrInvalidTopic, got %v", err)
	}
}
