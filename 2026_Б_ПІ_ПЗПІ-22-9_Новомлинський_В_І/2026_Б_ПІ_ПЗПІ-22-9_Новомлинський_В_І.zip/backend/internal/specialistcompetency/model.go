package specialistcompetency

import "time"

const (
	CodeEngineDiagnostics  = "engine_diagnostics"
	CodeBatteryElectrical  = "battery_and_electrical"
	CodeVibrationAnalysis  = "vibration_analysis"
	CodeFuelSystem         = "fuel_system"
	CodeGeneralMaintenance = "general_maintenance"
	CodeIoTDeviceSetup     = "iot_device_setup"
)

type Competency struct {
	ID           string    `json:"id"`
	SpecialistID string    `json:"specialist_id"`
	Code         string    `json:"code"`
	Name         string    `json:"name"`
	CreatedAt    time.Time `json:"created_at"`
}

type ReplaceRequest struct {
	Codes []string `json:"codes"`
}

type SupportedCompetency struct {
	Code string `json:"code"`
	Name string `json:"name"`
}

var supportedCompetencies = []SupportedCompetency{
	{Code: CodeEngineDiagnostics, Name: "Engine diagnostics"},
	{Code: CodeBatteryElectrical, Name: "Battery and electrical systems"},
	{Code: CodeVibrationAnalysis, Name: "Vibration analysis"},
	{Code: CodeFuelSystem, Name: "Fuel system"},
	{Code: CodeGeneralMaintenance, Name: "General maintenance"},
	{Code: CodeIoTDeviceSetup, Name: "IoT device setup"},
}

func SupportedCompetencies() []SupportedCompetency {
	items := make([]SupportedCompetency, len(supportedCompetencies))
	copy(items, supportedCompetencies)

	return items
}

func competencyNameByCode(code string) (string, bool) {
	for _, competency := range supportedCompetencies {
		if competency.Code == code {
			return competency.Name, true
		}
	}

	return "", false
}
