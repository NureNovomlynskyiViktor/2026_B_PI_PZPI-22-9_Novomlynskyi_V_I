package specialistmaintenance

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/maintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumMaintenanceRequestBodySize = 1 << 20

type MaintenanceService interface {
	Create(ctx context.Context, request maintenance.CreateRequest) (maintenance.Record, error)
}

type AssignmentService interface {
	GetAssignedVehicle(ctx context.Context, specialistID string, vehicleID string) (vehicle.Vehicle, error)
}

type VehicleService interface {
	GetByID(ctx context.Context, id string) (vehicle.Vehicle, error)
}

type Handler struct {
	maintenance MaintenanceService
	assignments AssignmentService
	vehicles    VehicleService
	logger      *slog.Logger
}

func NewHandler(
	maintenanceService MaintenanceService,
	assignments AssignmentService,
	vehicles VehicleService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		maintenance: maintenanceService,
		assignments: assignments,
		vehicles:    vehicles,
		logger:      logger,
	}
}

func (h *Handler) Create(w http.ResponseWriter, r *http.Request) {
	user, ok := specialistUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	request, ok := decodeCreateRequest(w, r)
	if !ok {
		return
	}

	if _, err := h.vehicles.GetByID(r.Context(), vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return
		}
		h.logger.Error(
			"failed to verify maintenance vehicle exists",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	if _, err := h.assignments.GetAssignedVehicle(r.Context(), user.ID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) ||
			errors.Is(err, specialistassignment.ErrNotFound) {
			response.Error(w, http.StatusForbidden, "specialist is not assigned to vehicle")
			return
		}
		if errors.Is(err, specialistassignment.ErrInvalidSpecialistID) ||
			errors.Is(err, specialistassignment.ErrInvalidVehicleID) {
			response.Error(w, http.StatusBadRequest, "invalid specialist vehicle request")
			return
		}
		h.logger.Error(
			"failed to verify specialist maintenance assignment",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	record, err := h.maintenance.Create(
		r.Context(),
		maintenance.CreateRequest{
			VehicleID:   vehicleID,
			CreatedBy:   user.ID,
			Title:       request.Title,
			Description: request.Description,
			ServiceDate: request.ServiceDate,
		},
	)
	if errors.Is(err, maintenance.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid maintenance record data")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to create specialist maintenance record",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, record)
}

type createRequest struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	ServiceDate string `json:"service_date"`
}

type parsedCreateRequest struct {
	Title       string
	Description string
	ServiceDate time.Time
}

func decodeCreateRequest(w http.ResponseWriter, r *http.Request) (parsedCreateRequest, bool) {
	r.Body = http.MaxBytesReader(w, r.Body, maximumMaintenanceRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	var request createRequest
	if err := decoder.Decode(&request); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return parsedCreateRequest{}, false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return parsedCreateRequest{}, false
	}

	title := strings.TrimSpace(request.Title)
	description := strings.TrimSpace(request.Description)
	serviceDate, err := time.Parse("2006-01-02", strings.TrimSpace(request.ServiceDate))
	if title == "" || description == "" || err != nil {
		response.Error(w, http.StatusBadRequest, "invalid maintenance record data")
		return parsedCreateRequest{}, false
	}

	return parsedCreateRequest{
		Title:       title,
		Description: description,
		ServiceDate: serviceDate,
	}, true
}

func specialistUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.TechnicalSpecialistRoleCode {
		response.Error(w, http.StatusForbidden, "technical specialist role required")
		return auth.User{}, false
	}

	return user, true
}
