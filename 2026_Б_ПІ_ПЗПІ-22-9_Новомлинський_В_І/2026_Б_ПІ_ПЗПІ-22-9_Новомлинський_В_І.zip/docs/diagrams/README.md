# Autonexis Diagrams

This directory contains lightweight Mermaid source diagrams for diploma documentation, presentation slides, and demo preparation.

Mermaid files are committed as editable sources. Export them to SVG or PNG only when preparing the final diploma or presentation assets.

## Architecture

- `architecture/01-system-context.mmd` - high-level product context showing ESP32/Wokwi telemetry, MQTT, Go backend, PostgreSQL, web workspaces, and Android owner app.
- `architecture/02-local-demo-deployment.mmd` - local demo deployment view with laptop services, physical Android phone, optional APK download server, and MQTT broker.

## Flows

- `flows/01-vehicle-activation-flow.mmd` - administrator-created vehicle activation and Android owner claim flow.
- `flows/02-service-request-lifecycle.mmd` - owner request, administrator assignment, specialist work, completion, and owner visibility.
- `flows/03-alert-lifecycle.mmd` - stabilized alert incident lifecycle from active condition through cleared and specialist-confirmed resolved states.

## Database

- `database/01-autonexis-erd-notes.md` - concise notes for creating the final ERD from migrations, seed data, and schema documentation.

## Export Guidance

Use committed Mermaid sources as the single source of truth. Generated SVG/PNG exports may be committed when they are curated, small, and suitable for documentation. Raw screenshots, videos, APKs, local logs, and environment-specific files should remain outside the repository.

