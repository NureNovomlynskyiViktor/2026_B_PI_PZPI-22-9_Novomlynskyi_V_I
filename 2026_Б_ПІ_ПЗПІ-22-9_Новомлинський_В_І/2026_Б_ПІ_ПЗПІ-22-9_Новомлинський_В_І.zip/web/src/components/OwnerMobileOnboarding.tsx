﻿import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import type { User } from '../api/types';
import { useMessages } from '../i18n';
import { BrandMark } from './brand';

const androidApkUrl = (import.meta.env.VITE_ANDROID_APK_URL ?? '').trim();

type Props = {
  user: User;
  onLogout: () => void;
  onOpenAccount: () => void;
};

export function OwnerMobileOnboarding({ user, onLogout, onOpenAccount }: Props) {
  const t = useMessages().ownerOnboarding;
  const [apkQrDataUrl, setApkQrDataUrl] = useState<string | null>(null);
  const [qrError, setQrError] = useState<string | null>(null);

  useEffect(() => {
    let isCurrent = true;
    setApkQrDataUrl(null);
    setQrError(null);

    if (!androidApkUrl) {
      return () => {
        isCurrent = false;
      };
    }

    QRCode.toDataURL(androidApkUrl, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 220,
    })
      .then((dataUrl) => {
        if (isCurrent) {
          setApkQrDataUrl(dataUrl);
        }
      })
      .catch(() => {
        if (isCurrent) {
          setQrError(t.qrError);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [t.qrError]);

  return (
    <div className="owner-onboarding-page">
      <header className="workspace-header owner-onboarding-header">
        <BrandMark mode="full" size={46} label="Autonexis" />
        <div className="workspace-actions">
          <button className="secondary-button" type="button" onClick={onOpenAccount}>
            {t.account}
          </button>
          <button className="secondary-button" type="button" onClick={onLogout}>
            {t.logout}
          </button>
        </div>
      </header>

      <main className="owner-onboarding-main">
        <section className="owner-onboarding-hero" aria-labelledby="owner-onboarding-title">
          <div className="owner-onboarding-copy">
            <p className="eyebrow">{t.eyebrow}</p>
            <h1 id="owner-onboarding-title">{t.heading}</h1>
            <p>{t.body}</p>
            <p className="owner-onboarding-signed-in">
              {t.signedInAs} <strong>{user.email}</strong>
            </p>
          </div>

          <aside className="owner-apk-card" aria-labelledby="apk-download-title">
            <p className="eyebrow">{t.downloadKicker}</p>
            <h2 id="apk-download-title">{t.downloadHeading}</h2>
            {androidApkUrl ? (
              <>
                <div className="owner-qr-frame">
                  {apkQrDataUrl ? (
                    <img src={apkQrDataUrl} alt={t.qrAlt} />
                  ) : (
                    <div className="owner-qr-placeholder">{t.qrPreparing}</div>
                  )}
                </div>
                {qrError && <p className="error-box">{qrError}</p>}
                <a className="primary-button link-button" href={androidApkUrl} rel="noreferrer" target="_blank">
                  {t.downloadAction}
                </a>
                <p className="muted">{t.downloadNote}</p>
              </>
            ) : (
              <div className="info-box">{t.apkNotConfigured}</div>
            )}
          </aside>
        </section>

        <section className="owner-onboarding-section" aria-labelledby="qr-distinction-title">
          <div className="section-heading compact-heading">
            <p className="eyebrow">{t.distinctionKicker}</p>
            <h2 id="qr-distinction-title">{t.distinctionHeading}</h2>
          </div>
          <div className="owner-distinction-grid">
            <article className="owner-info-card">
              <h3>{t.apkQrTitle}</h3>
              <p>{t.apkQrBody}</p>
            </article>
            <article className="owner-info-card">
              <h3>{t.activationQrTitle}</h3>
              <p>{t.activationQrBody}</p>
            </article>
          </div>
        </section>

        <section className="owner-onboarding-section" aria-labelledby="owner-steps-title">
          <div className="section-heading compact-heading">
            <p className="eyebrow">{t.setupKicker}</p>
            <h2 id="owner-steps-title">{t.setupHeading}</h2>
          </div>
          <ol className="owner-step-list">
            {t.steps.map((step, index) => (
              <li key={step.title}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="owner-onboarding-section owner-demo-note" aria-labelledby="demo-iot-title">
          <div>
            <p className="eyebrow">{t.iotKicker}</p>
            <h2 id="demo-iot-title">{t.iotHeading}</h2>
            <p>{t.iotBody}</p>
          </div>
        </section>
      </main>
    </div>
  );
}
