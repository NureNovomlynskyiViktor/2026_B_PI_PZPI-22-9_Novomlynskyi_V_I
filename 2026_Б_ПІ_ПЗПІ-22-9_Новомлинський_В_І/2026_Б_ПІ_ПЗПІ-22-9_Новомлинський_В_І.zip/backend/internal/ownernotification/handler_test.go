package ownernotification

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
)

const (
	testOwnerID        = "11111111-1111-1111-1111-111111111111"
	testNotificationID = "33333333-3333-3333-3333-333333333333"
	testAlertID        = "44444444-4444-4444-4444-444444444444"
)

type stubNotificationService struct {
	items                []notification.Notification
	listErr              error
	markErr              error
	calledListUser       string
	calledMarkUser       string
	calledNotificationID string
}

func (s *stubNotificationService) ListByUser(
	_ context.Context,
	userID string,
) ([]notification.Notification, error) {
	s.calledListUser = userID
	return s.items, s.listErr
}

func (s *stubNotificationService) MarkReadForUser(
	_ context.Context,
	userID string,
	notificationID string,
) (notification.Notification, error) {
	s.calledMarkUser = userID
	s.calledNotificationID = notificationID
	if s.markErr != nil {
		return notification.Notification{}, s.markErr
	}

	return notification.Notification{
		ID:               notificationID,
		UserID:           userID,
		AlertID:          stringPtr(testAlertID),
		NotificationType: notification.TypeVehicleAlert,
		Title:            "WARNING alert: rpm",
		Message:          "WARNING for Toyota Corolla: rpm reached warning level.",
		IsRead:           true,
		CreatedAt:        time.Date(2026, 6, 17, 12, 0, 0, 0, time.UTC),
	}, nil
}

func TestListRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(&stubNotificationService{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/me/notifications", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestOwnerCanListOwnNotifications(t *testing.T) {
	service := &stubNotificationService{
		items: []notification.Notification{
			{
				ID:               testNotificationID,
				UserID:           testOwnerID,
				AlertID:          stringPtr(testAlertID),
				NotificationType: notification.TypeVehicleAlert,
				Title:            "CRITICAL alert: vibration_level",
				Message:          "CRITICAL for Toyota Corolla: vibration_level reached critical level.",
				IsRead:           false,
				CreatedAt:        time.Date(2026, 6, 17, 12, 0, 0, 0, time.UTC),
			},
		},
	}
	handler := NewHandler(service, testLogger())
	recorder := httptest.NewRecorder()

	handler.List(recorder, requestWithUser(http.MethodGet, "/api/v1/me/notifications"))

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.calledListUser != testOwnerID {
		t.Fatalf("expected list for owner %q, got %q", testOwnerID, service.calledListUser)
	}
}

func TestOwnerCanMarkNotificationRead(t *testing.T) {
	service := &stubNotificationService{}
	handler := NewHandler(service, testLogger())
	request := requestWithUser(
		http.MethodPatch,
		"/api/v1/me/notifications/"+testNotificationID+"/read",
	)
	request.SetPathValue("notification_id", testNotificationID)
	recorder := httptest.NewRecorder()

	handler.MarkRead(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.calledMarkUser != testOwnerID {
		t.Fatalf("expected mark-read owner %q, got %q", testOwnerID, service.calledMarkUser)
	}
	if service.calledNotificationID != testNotificationID {
		t.Fatalf("expected notification %q, got %q", testNotificationID, service.calledNotificationID)
	}
}

func TestMarkReadReturnsNotFoundForOtherOwnerNotification(t *testing.T) {
	service := &stubNotificationService{markErr: notification.ErrNotFound}
	handler := NewHandler(service, testLogger())
	request := requestWithUser(
		http.MethodPatch,
		"/api/v1/me/notifications/"+testNotificationID+"/read",
	)
	request.SetPathValue("notification_id", testNotificationID)
	recorder := httptest.NewRecorder()

	handler.MarkRead(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestMarkReadReturnsNotFoundForNonexistentNotification(t *testing.T) {
	service := &stubNotificationService{markErr: notification.ErrNotFound}
	handler := NewHandler(service, testLogger())
	request := requestWithUser(
		http.MethodPatch,
		"/api/v1/me/notifications/99999999-9999-9999-9999-999999999999/read",
	)
	request.SetPathValue("notification_id", "99999999-9999-9999-9999-999999999999")
	recorder := httptest.NewRecorder()

	handler.MarkRead(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func requestWithUser(method string, target string) *http.Request {
	request := httptest.NewRequest(method, target, nil)
	ctx := auth.WithUser(
		request.Context(),
		auth.User{
			ID:    testOwnerID,
			Email: "owner@example.com",
			Role:  "vehicle_owner",
		},
	)
	return request.WithContext(ctx)
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func stringPtr(value string) *string {
	return &value
}
