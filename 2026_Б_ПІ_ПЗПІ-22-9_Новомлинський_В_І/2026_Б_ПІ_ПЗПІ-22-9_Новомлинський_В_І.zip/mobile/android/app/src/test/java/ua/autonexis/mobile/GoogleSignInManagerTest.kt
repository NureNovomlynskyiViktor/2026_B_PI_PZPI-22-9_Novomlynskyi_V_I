package ua.autonexis.mobile

import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse

class GoogleSignInManagerTest {
    @Test
    fun blankWebClientIdIsRejectedSafely() {
        val error = assertFailsWith<MissingGoogleClientIdException> {
            normalizeGoogleWebClientId("  ")
        }

        assertEquals("Google sign-in is not configured.", error.message)
    }

    @Test
    fun unexpectedCredentialTypeIsRejected() {
        assertFailsWith<InvalidGoogleCredentialException> {
            extractGoogleIdToken("unexpected.credential") { "fake-token" }
        }
    }

    @Test
    fun malformedCredentialDataReturnsSafeError() {
        val error = assertFailsWith<InvalidGoogleCredentialException> {
            extractGoogleIdToken(GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                throw IllegalArgumentException("fake-token-that-must-not-leak")
            }
        }

        assertEquals("Google did not return a valid sign-in credential. Please try again.", error.message)
        assertFalse(error.message.orEmpty().contains("fake-token"))
    }

    @Test
    fun returnedIdTokenIsTrimmed() {
        val idToken = extractGoogleIdToken(GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            "  header.payload.signature  "
        }

        assertEquals("header.payload.signature", idToken)
    }
}