import { FormEvent, useCallback, useRef, useState } from 'react';
import { api } from '../api/client';
import type { AuthResponse } from '../api/types';
import { useMessages } from '../i18n';
import { navigatePublic } from '../navigation/publicNavigation';
import { AppearanceSelector } from './appearance/AppearanceSelector';
import { GoogleSignInButton } from './auth/GoogleSignInButton';
import { BrandMark } from './brand';
import { LanguageSelector } from './i18n/LanguageSelector';

type Props = {
  onAuthenticated: (response: AuthResponse) => void;
  sessionMessage?: string | null;
};

const googleClientID = (import.meta.env.VITE_GOOGLE_CLIENT_ID ?? '').trim();

export function AuthScreen({ onAuthenticated, sessionMessage = null }: Props) {
  const authMessages = useMessages().auth;
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGoogleExchangeInProgress, setIsGoogleExchangeInProgress] =
    useState(false);
  const authInFlightRef = useRef(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (authInFlightRef.current) {
      return;
    }

    authInFlightRef.current = true;
    setIsSubmitting(true);
    setError(null);

    try {
      const response =
        mode === 'login'
          ? await api.login({ email, password })
          : await api.register({
              email,
              password,
              first_name: firstName,
              last_name: lastName,
            });

      onAuthenticated(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : authMessages.failed);
    } finally {
      authInFlightRef.current = false;
      setIsSubmitting(false);
    }
  }

  const handleGoogleCredential = useCallback(
    async (credential: string) => {
      if (authInFlightRef.current) {
        return;
      }

      if (!credential.trim()) {
        setError(authMessages.googleInvalidCredential);
        return;
      }

      authInFlightRef.current = true;
      setIsGoogleExchangeInProgress(true);
      setError(null);

      try {
        const response = await api.googleLogin({ id_token: credential });
        onAuthenticated(response);
      } catch (err) {
        setError(err instanceof Error ? err.message : authMessages.failed);
      } finally {
        authInFlightRef.current = false;
        setIsGoogleExchangeInProgress(false);
      }
    },
    [authMessages.failed, authMessages.googleInvalidCredential, onAuthenticated],
  );

  return (
    <main className="auth-layout">
      <section className="auth-card">
        <button
          className="secondary-button auth-home-link"
          type="button"
          onClick={() => navigatePublic('/')}
        >
          {authMessages.backToHome}
        </button>

        <div className="brand-block">
          <BrandMark size={48} />
          <h1>{authMessages.brandHeading}</h1>
          <p>{authMessages.brandBody}</p>
        </div>

        {googleClientID ? (
          <>
            <GoogleSignInButton
              clientID={googleClientID}
              disabled={isSubmitting}
              exchangeInProgress={isGoogleExchangeInProgress}
              labels={{
                regionLabel: authMessages.googleRegionLabel,
                loading: authMessages.googleLoading,
                exchangeInProgress: authMessages.googleExchangeInProgress,
                unavailable: authMessages.googleUnavailable,
              }}
              onCredential={handleGoogleCredential}
            />
            <p className="auth-support-message role-policy">
              {authMessages.googleRolePolicy}
            </p>
            <div className="auth-divider" role="separator">
              <span>{authMessages.emailDivider}</span>
            </div>
          </>
        ) : import.meta.env.DEV ? (
          <p className="auth-support-message">{authMessages.googleNotConfigured}</p>
        ) : null}

        {sessionMessage && <p className="info-box">{sessionMessage}</p>}

        <div className="auth-preference-grid">
          <LanguageSelector className="auth-language-selector" />
          <AppearanceSelector className="auth-language-selector" />
        </div>

        <div className="tab-row" role="tablist" aria-label={authMessages.modeLabel}>
          <button
            className={mode === 'login' ? 'tab active' : 'tab'}
            type="button"
            onClick={() => setMode('login')}
          >
            {authMessages.loginTab}
          </button>
          <button
            className={mode === 'register' ? 'tab active' : 'tab'}
            type="button"
            onClick={() => setMode('register')}
          >
            {authMessages.registerTab}
          </button>
        </div>

        <form className="form-grid" onSubmit={handleSubmit}>
          <label>
            {authMessages.emailLabel}
            <input
              autoComplete="email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
          </label>

          <label>
            {authMessages.passwordLabel}
            <input
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
            />
          </label>

          {mode === 'register' && (
            <div className="two-column">
              <label>
                {authMessages.firstNameLabel}
                <input
                  value={firstName}
                  onChange={(event) => setFirstName(event.target.value)}
                  required
                />
              </label>
              <label>
                {authMessages.lastNameLabel}
                <input
                  value={lastName}
                  onChange={(event) => setLastName(event.target.value)}
                  required
                />
              </label>
            </div>
          )}

          {error && <div className="error-box">{error}</div>}

          <button
            className="primary-button"
            type="submit"
            disabled={isSubmitting || isGoogleExchangeInProgress}
          >
            {isSubmitting
              ? authMessages.submitting
              : mode === 'login'
                ? authMessages.submitLogin
                : authMessages.submitRegister}
          </button>
        </form>
      </section>
    </main>
  );
}
