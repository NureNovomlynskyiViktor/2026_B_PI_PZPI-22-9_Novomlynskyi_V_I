package adminuser

import "time"

const (
	ActionUserDeactivated                        = "user.deactivated"
	ActionUserReactivated                        = "user.reactivated"
	ActionTechnicalSpecialistDeactivationCleanup = "technical_specialist.deactivation_cleanup"
	EntityTypeUser                               = "user"
)

type User struct {
	ID            string     `json:"id"`
	RoleID        string     `json:"role_id"`
	Role          string     `json:"role"`
	Email         string     `json:"email"`
	FullName      string     `json:"full_name"`
	IsActive      bool       `json:"is_active"`
	CreatedAt     time.Time  `json:"created_at"`
	UpdatedAt     time.Time  `json:"updated_at"`
	DeactivatedAt *time.Time `json:"deactivated_at"`
}

type ListFilters struct {
	Role     string
	IsActive *bool
	Search   string
}

type DeactivateRequest struct {
	Reason string `json:"reason"`
}
