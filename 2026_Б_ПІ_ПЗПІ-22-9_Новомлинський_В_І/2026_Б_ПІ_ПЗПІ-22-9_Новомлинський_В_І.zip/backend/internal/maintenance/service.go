package maintenance

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var ErrInvalidInput = errors.New("invalid maintenance record input")

type Service interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]Record, error)
	Create(ctx context.Context, request CreateRequest) (Record, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) ListByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Record, error) {
	return s.repository.ListByVehicle(ctx, vehicleID)
}

func (s *service) Create(
	ctx context.Context,
	request CreateRequest,
) (Record, error) {
	request.Title = strings.TrimSpace(request.Title)
	request.Description = strings.TrimSpace(request.Description)

	if !identifier.IsUUID(request.VehicleID) ||
		!identifier.IsUUID(request.CreatedBy) ||
		request.Title == "" ||
		request.Description == "" ||
		request.ServiceDate.IsZero() {
		return Record{}, ErrInvalidInput
	}

	return s.repository.Create(ctx, request)
}
