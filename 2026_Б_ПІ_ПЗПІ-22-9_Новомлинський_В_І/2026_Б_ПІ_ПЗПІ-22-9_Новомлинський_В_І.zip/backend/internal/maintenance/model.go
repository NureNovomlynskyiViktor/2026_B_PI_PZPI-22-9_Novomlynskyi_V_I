package maintenance

import "time"

type Record struct {
	ID          string    `json:"id"`
	VehicleID   string    `json:"vehicle_id"`
	CreatedBy   *string   `json:"created_by"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	ServiceDate time.Time `json:"service_date"`
	CreatedAt   time.Time `json:"created_at"`
}

type CreateRequest struct {
	VehicleID   string
	CreatedBy   string
	Title       string
	Description string
	ServiceDate time.Time
}
