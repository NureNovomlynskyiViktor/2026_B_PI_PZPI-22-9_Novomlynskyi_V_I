package status

import (
	"context"
	"errors"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const testVehicleID = "22222222-2222-2222-2222-222222222222"

type vehicleService struct {
	item vehicle.Vehicle
	err  error
}

func (s vehicleService) GetByID(context.Context, string) (vehicle.Vehicle, error) {
	return s.item, s.err
}

type deviceService struct {
	item device.Device
	err  error
}

func (s deviceService) GetByVehicleID(context.Context, string) (device.Device, error) {
	return s.item, s.err
}

type telemetryService struct {
	item telemetry.Record
	err  error
}

func (s telemetryService) LatestByVehicle(context.Context, string) (telemetry.Record, error) {
	return s.item, s.err
}

type alertService struct {
	items []alert.Alert
	err   error
}

func (s alertService) ListActiveByVehicle(context.Context, string) ([]alert.Alert, error) {
	return s.items, s.err
}

func TestServiceVehicleWithoutTelemetryReturnsUnknown(t *testing.T) {
	service := NewService(
		vehicleService{item: vehicle.Vehicle{ID: testVehicleID}},
		deviceService{err: device.ErrNotFound},
		telemetryService{err: telemetry.ErrNotFound},
		alertService{items: []alert.Alert{}},
	)

	result, err := service.GetByVehicleID(context.Background(), testVehicleID)
	if err != nil {
		t.Fatalf("GetByVehicleID() returned an error: %v", err)
	}
	if result.OverallStatus != "unknown" {
		t.Fatalf("expected overall status unknown, got %s", result.OverallStatus)
	}
	if result.LatestTelemetry != nil {
		t.Fatal("expected missing telemetry to be represented as nil")
	}
	if len(result.ActiveAlerts) != 0 {
		t.Fatalf("expected no active alerts, got %#v", result.ActiveAlerts)
	}
}

func TestServiceOverallStatusWithTelemetry(t *testing.T) {
	warning := "warning"
	tests := []struct {
		name       string
		alerts     []alert.Alert
		wantStatus string
	}{
		{name: "normal", alerts: []alert.Alert{}, wantStatus: "normal"},
		{
			name:       "warning",
			alerts:     []alert.Alert{{Severity: "warning"}},
			wantStatus: "warning",
		},
		{
			name: "critical takes priority",
			alerts: []alert.Alert{
				{Severity: "warning"},
				{Severity: "critical"},
			},
			wantStatus: "critical",
		},
		{
			name: "current severity overrides incident maximum",
			alerts: []alert.Alert{
				{Severity: "critical", CurrentSeverity: &warning},
			},
			wantStatus: "warning",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := NewService(
				vehicleService{item: vehicle.Vehicle{ID: testVehicleID}},
				deviceService{err: device.ErrNotFound},
				telemetryService{item: telemetry.Record{ID: 1, VehicleID: testVehicleID}},
				alertService{items: tt.alerts},
			)

			result, err := service.GetByVehicleID(context.Background(), testVehicleID)
			if err != nil {
				t.Fatalf("GetByVehicleID() returned an error: %v", err)
			}
			if result.OverallStatus != tt.wantStatus {
				t.Fatalf(
					"expected overall status %s, got %s",
					tt.wantStatus,
					result.OverallStatus,
				)
			}
			if result.Device != nil {
				t.Fatal("expected missing device to be represented as nil")
			}
			if result.LatestTelemetry == nil {
				t.Fatal("expected latest telemetry to be present")
			}
		})
	}
}

func TestServiceValidationAndVehicleNotFound(t *testing.T) {
	service := NewService(
		vehicleService{},
		deviceService{},
		telemetryService{},
		alertService{},
	)

	if _, err := service.GetByVehicleID(context.Background(), "invalid"); !errors.Is(err, ErrInvalidVehicleID) {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}

	service = NewService(
		vehicleService{err: vehicle.ErrNotFound},
		deviceService{},
		telemetryService{},
		alertService{},
	)
	if _, err := service.GetByVehicleID(context.Background(), testVehicleID); !errors.Is(err, ErrVehicleNotFound) {
		t.Fatalf("expected ErrVehicleNotFound, got %v", err)
	}
}
