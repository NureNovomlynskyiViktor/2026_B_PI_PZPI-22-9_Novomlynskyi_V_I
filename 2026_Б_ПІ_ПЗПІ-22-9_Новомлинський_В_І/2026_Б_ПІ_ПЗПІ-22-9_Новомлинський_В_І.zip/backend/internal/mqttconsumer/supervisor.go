package mqttconsumer

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/config"
)

const (
	mqttStartupBackoffInitial = 2 * time.Second
	mqttStartupBackoffSecond  = 5 * time.Second
	mqttStartupBackoffThird   = 10 * time.Second
	mqttStartupBackoffMaximum = 30 * time.Second
)

var defaultStartupBackoff = []time.Duration{
	mqttStartupBackoffInitial,
	mqttStartupBackoffSecond,
	mqttStartupBackoffThird,
	mqttStartupBackoffMaximum,
}

type starter interface {
	Start(context.Context) error
	Close()
}

type Supervisor struct {
	starter starter
	config  config.MQTTConfig
	logger  *slog.Logger
	backoff []time.Duration

	startOnce sync.Once
	closeOnce sync.Once
	cancel    context.CancelFunc
	done      chan struct{}
}

func NewSupervisor(starter starter, cfg config.MQTTConfig, logger *slog.Logger) *Supervisor {
	return newSupervisorWithBackoff(starter, cfg, logger, defaultStartupBackoff)
}

func newSupervisorWithBackoff(
	starter starter,
	cfg config.MQTTConfig,
	logger *slog.Logger,
	backoff []time.Duration,
) *Supervisor {
	if logger == nil {
		logger = slog.Default()
	}
	if len(backoff) == 0 {
		backoff = defaultStartupBackoff
	}

	return &Supervisor{
		starter: starter,
		config:  cfg,
		logger:  logger,
		backoff: append([]time.Duration(nil), backoff...),
		done:    make(chan struct{}),
	}
}

func (s *Supervisor) Start(ctx context.Context) {
	s.startOnce.Do(func() {
		startupCtx, cancel := context.WithCancel(ctx)
		s.cancel = cancel
		s.logger.Info(
			"MQTT telemetry consumer background startup begins",
			"broker", s.config.BrokerURL(),
			"client_id", s.config.ClientID,
			"topic", s.config.TelemetryTopic,
		)
		go s.run(startupCtx)
	})
}

func (s *Supervisor) Close() {
	s.closeOnce.Do(func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.starter.Close()
		<-s.done
	})
}

func (s *Supervisor) run(ctx context.Context) {
	defer close(s.done)

	for attempt := 0; ; attempt++ {
		if ctx.Err() != nil {
			s.logger.Info("MQTT telemetry consumer startup stopped", "error", ctx.Err())
			return
		}

		err := s.starter.Start(ctx)
		if err == nil {
			s.logger.Info(
				"MQTT telemetry consumer started by background supervisor",
				"broker", s.config.BrokerURL(),
				"client_id", s.config.ClientID,
				"topic", s.config.TelemetryTopic,
			)
			return
		}
		if ctx.Err() != nil {
			s.logger.Info("MQTT telemetry consumer startup stopped", "error", ctx.Err())
			return
		}

		if attempt == 0 {
			s.logger.Warn(
				"MQTT telemetry consumer unavailable at startup; HTTP server continues",
				"broker", s.config.BrokerURL(),
				"client_id", s.config.ClientID,
				"topic", s.config.TelemetryTopic,
				"error", err,
			)
		} else {
			s.logger.Warn(
				"MQTT telemetry consumer retry failed",
				"broker", s.config.BrokerURL(),
				"client_id", s.config.ClientID,
				"topic", s.config.TelemetryTopic,
				"attempt", attempt+1,
				"error", err,
			)
		}

		delay := s.backoffForAttempt(attempt)
		s.logger.Info(
			"MQTT telemetry consumer retry scheduled",
			"broker", s.config.BrokerURL(),
			"client_id", s.config.ClientID,
			"topic", s.config.TelemetryTopic,
			"backoff", delay.String(),
		)
		if !waitBackoff(ctx, delay) {
			s.logger.Info("MQTT telemetry consumer startup stopped", "error", ctx.Err())
			return
		}
	}
}

func (s *Supervisor) backoffForAttempt(attempt int) time.Duration {
	if attempt < 0 {
		attempt = 0
	}
	if attempt >= len(s.backoff) {
		return s.backoff[len(s.backoff)-1]
	}
	return s.backoff[attempt]
}

func waitBackoff(ctx context.Context, delay time.Duration) bool {
	if delay <= 0 {
		return ctx.Err() == nil
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()

	select {
	case <-ctx.Done():
		return false
	case <-timer.C:
		return true
	}
}
