import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { api, errorMessage, isUnauthorizedError } from '../api/client';
import { useMessages } from '../i18n';
import { formatStructuredLabel, formatTimestamp } from '../utils/presentation';
import type {
  Alert,
  MaintenanceRecord,
  ServiceRequest,
  TelemetryRecord,
  ThresholdRule,
  User,
  Vehicle,
  VehicleStatus,
} from '../api/types';
import {
  AlertIncidentPanel,
  formatAlertParameter,
  formatAlertTimestamp,
  splitAlertsByLifecycle,
} from './AlertIncidentPanel';
import { StatusPanel } from './StatusPanel';
import { TelemetryHistory } from './TelemetryHistory';
import { TelemetryTrendsPanel } from './TelemetryTrendsPanel';
import { ThresholdsPanel } from './ThresholdsPanel';
import { VehicleList } from './VehicleList';
import { WorkspaceSection, WorkspaceShell } from './WorkspaceShell';

const diagnosticRefreshMs = 5000;

type Props = {
  token: string;
  user: User;
  onLogout: () => void;
  onOpenAccount: () => void;
  onSessionExpired: () => void;
};

const specialistWorkspaceSectionIDs = [
  'overview',
  'assigned-vehicles',
  'diagnostics',
  'service-requests',
  'maintenance',
  'incident-resolution',
] as const;
const requestStatusOrder: Record<string, number> = {
  in_progress: 0,
  assigned: 1,
  completed: 2,
  cancelled: 3,
};

function previewText(value: string, maxLength = 170) {
  const trimmed = value.trim();
  if (trimmed.length <= maxLength) {
    return trimmed;
  }

  return `${trimmed.slice(0, maxLength - 1).trimEnd()}...`;
}

function sortServiceRequests(requests: ServiceRequest[]) {
  return [...requests].sort((left, right) => {
    const leftRank = requestStatusOrder[left.status] ?? 9;
    const rightRank = requestStatusOrder[right.status] ?? 9;
    if (leftRank !== rightRank) {
      return leftRank - rightRank;
    }

    return new Date(right.created_at).getTime() - new Date(left.created_at).getTime();
  });
}

export function SpecialistDashboard({
  token,
  user,
  onLogout,
  onOpenAccount,
  onSessionExpired,
}: Props) {
  const localeMessages = useMessages();
  const accountMessages = localeMessages.account;
  const commonMessages = localeMessages.common;
  const specialistMessages = localeMessages.specialist;
  const workspaceMessages = localeMessages.workspace.specialist;
  const sharedWorkspaceMessages = localeMessages.workspace;
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  const [selectedVehicleID, setSelectedVehicleID] = useState<string | null>(null);
  const [status, setStatus] = useState<VehicleStatus | null>(null);
  const [thresholds, setThresholds] = useState<ThresholdRule[]>([]);
  const [telemetryHistory, setTelemetryHistory] = useState<TelemetryRecord[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingVehicle, setIsLoadingVehicle] = useState(false);
  const [isLoadingDiagnostics, setIsLoadingDiagnostics] = useState(false);
  const [isPollingDiagnostics, setIsPollingDiagnostics] = useState(false);
  const [isLoadingServiceRequests, setIsLoadingServiceRequests] = useState(false);
  const [actingServiceRequestID, setActingServiceRequestID] = useState<string | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);
  const [serviceRequestMessage, setServiceRequestMessage] = useState<string | null>(
    null,
  );
  const [serviceRequestError, setServiceRequestError] = useState<string | null>(
    null,
  );
  const [resultSummaries, setResultSummaries] = useState<Record<string, string>>({});
  const [maintenanceTitle, setMaintenanceTitle] = useState('');
  const [maintenanceDescription, setMaintenanceDescription] = useState('');
  const [maintenanceServiceDate, setMaintenanceServiceDate] = useState('');
  const [maintenanceMessage, setMaintenanceMessage] = useState<string | null>(null);
  const [maintenanceError, setMaintenanceError] = useState<string | null>(null);
  const [isCreatingMaintenance, setIsCreatingMaintenance] = useState(false);
  const [latestMaintenanceRecord, setLatestMaintenanceRecord] =
    useState<MaintenanceRecord | null>(null);
  const [diagnosticError, setDiagnosticError] = useState<string | null>(null);
  const [resolutionAlertID, setResolutionAlertID] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState('');
  const [resolutionServiceRequestID, setResolutionServiceRequestID] = useState('');
  const [isResolvingAlert, setIsResolvingAlert] = useState(false);
  const [resolutionMessage, setResolutionMessage] = useState<string | null>(null);
  const [resolutionError, setResolutionError] = useState<string | null>(null);
  const [activeWorkspaceSection, setActiveWorkspaceSection] = useState('overview');
  const diagnosticRequestRef = useRef(0);

  const specialistWorkspaceSections = useMemo(
    () =>
      specialistWorkspaceSectionIDs.map((id) => ({
        id,
        label:
          id === 'assigned-vehicles'
            ? workspaceMessages.sections.assignedVehicles
            : id === 'service-requests'
              ? workspaceMessages.sections.serviceRequests
              : id === 'incident-resolution'
                ? workspaceMessages.sections.incidentResolution
                : workspaceMessages.sections[id],
      })),
    [workspaceMessages],
  );
  const selectedVehicle = useMemo(
    () => vehicles.find((vehicle) => vehicle.id === selectedVehicleID) ?? null,
    [vehicles, selectedVehicleID],
  );
  const vehiclesByID = useMemo(
    () => new Map(vehicles.map((vehicle) => [vehicle.id, vehicle])),
    [vehicles],
  );
  const activeAlerts = useMemo(
    () => splitAlertsByLifecycle(alerts).activeAlerts,
    [alerts],
  );
  const { clearedAlerts, resolvedAlerts, otherAlerts } = useMemo(
    () => splitAlertsByLifecycle(alerts),
    [alerts],
  );
  const clearedCriticalAlerts = useMemo(
    () => clearedAlerts.filter((alert) => alert.severity === 'critical'),
    [clearedAlerts],
  );
  const shouldShowInspectionBanner =
    status?.overall_status === 'normal' &&
    activeAlerts.length === 0 &&
    clearedCriticalAlerts.length > 0;
  const latestTelemetryTimestamp = useMemo(
    () => telemetryHistory[0]?.measured_at ?? status?.latest_telemetry?.measured_at ?? null,
    [status?.latest_telemetry?.measured_at, telemetryHistory],
  );
  const serviceRequestQueues = useMemo(() => {
    const sorted = sortServiceRequests(serviceRequests);
    return {
      needsAction: sorted.filter((request) => request.status === 'assigned' || request.status === 'in_progress'),
      completed: sorted.filter((request) => request.status === 'completed'),
      archived: sorted.filter((request) => request.status !== 'assigned' && request.status !== 'in_progress' && request.status !== 'completed'),
    };
  }, [serviceRequests]);

  function handleUnauthorizedError(err: unknown) {
    if (!isUnauthorizedError(err)) {
      return false;
    }

    onSessionExpired();
    return true;
  }

  function handleSpecialistError(
    err: unknown,
    fallback: string,
    setter: (message: string) => void = setError,
  ) {
    if (handleUnauthorizedError(err)) {
      return;
    }

    setter(errorMessage(err, fallback));
  }

  function vehicleLabel(vehicleID: string) {
    const vehicle = vehiclesByID.get(vehicleID);
    if (!vehicle) {
      return vehicleID;
    }

    return `${vehicle.brand} ${vehicle.model} - ${vehicle.license_plate ?? vehicle.vin ?? vehicle.id}`;
  }

  const loadSelectedVehicle = useCallback(
    async (
      vehicleID: string,
      options: { background?: boolean; includeThresholds?: boolean } = {},
    ) => {
      const { background = false, includeThresholds = true } = options;
      const requestID = diagnosticRequestRef.current + 1;
      diagnosticRequestRef.current = requestID;

      if (background) {
        setIsPollingDiagnostics(true);
      } else {
        setIsLoadingVehicle(true);
        setIsLoadingDiagnostics(true);
      }
      setError(null);
      setDiagnosticError(null);

      try {
        const [nextStatus, nextThresholds, nextTelemetry, nextAlerts] =
          await Promise.all([
            api.getSpecialistVehicleStatus(token, vehicleID),
            includeThresholds
              ? api.listSpecialistVehicleThresholds(token, vehicleID)
              : Promise.resolve<ThresholdRule[] | null>(null),
            api.listSpecialistVehicleTelemetry(token, vehicleID, 50),
            api.listSpecialistVehicleAlerts(token, vehicleID, 'all', 50),
          ]);

        if (diagnosticRequestRef.current !== requestID) {
          return;
        }

        setStatus(nextStatus);
        if (nextThresholds) {
          setThresholds(nextThresholds);
        }
        setTelemetryHistory(nextTelemetry);
        setAlerts(nextAlerts);
      } catch (err) {
        if (diagnosticRequestRef.current !== requestID) {
          return;
        }

        if (handleUnauthorizedError(err)) {
          return;
        }

        const message = errorMessage(err, specialistMessages.diagnostics.diagnosticsLoadError);
        setDiagnosticError(message);
        if (!background) {
          setError(message);
        }
      } finally {
        if (diagnosticRequestRef.current === requestID) {
          if (background) {
            setIsPollingDiagnostics(false);
          } else {
            setIsLoadingVehicle(false);
            setIsLoadingDiagnostics(false);
          }
        }
      }
    },
    [specialistMessages.diagnostics, token],
  );

  const loadDashboard = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setServiceRequestError(null);

    try {
      const [assignedVehicles, assignedRequests] = await Promise.all([
        api.listSpecialistVehicles(token),
        api.listSpecialistServiceRequests(token),
      ]);
      setVehicles(assignedVehicles);
      setServiceRequests(assignedRequests);
      const nextVehicleID = selectedVehicleID ?? assignedVehicles[0]?.id ?? null;
      setSelectedVehicleID(nextVehicleID);
      if (nextVehicleID) {
        await loadSelectedVehicle(nextVehicleID);
      } else {
        setStatus(null);
        setThresholds([]);
        setTelemetryHistory([]);
        setAlerts([]);
        setDiagnosticError(null);
      }
    } catch (err) {
      handleSpecialistError(err, specialistMessages.overview.dashboardLoadError);
    } finally {
      setIsLoading(false);
    }
  }, [loadSelectedVehicle, selectedVehicleID, specialistMessages.overview, token]);

  useEffect(() => {
    if (!selectedVehicleID) {
      return undefined;
    }

    const intervalID = window.setInterval(() => {
      void loadSelectedVehicle(selectedVehicleID, {
        background: true,
        includeThresholds: false,
      });
    }, diagnosticRefreshMs);

    return () => window.clearInterval(intervalID);
  }, [loadSelectedVehicle, selectedVehicleID]);

  const loadServiceRequests = useCallback(async () => {
    setIsLoadingServiceRequests(true);
    setServiceRequestError(null);

    try {
      const assignedRequests = await api.listSpecialistServiceRequests(token);
      setServiceRequests(assignedRequests);
    } catch (err) {
      handleSpecialistError(err, specialistMessages.serviceRequests.loadError, setServiceRequestError);
    } finally {
      setIsLoadingServiceRequests(false);
    }
  }, [specialistMessages.serviceRequests, token]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  function handleSelectVehicle(vehicleID: string) {
    diagnosticRequestRef.current += 1;
    setSelectedVehicleID(vehicleID);
    setStatus(null);
    setThresholds([]);
    setTelemetryHistory([]);
    setAlerts([]);
    setDiagnosticError(null);
    setMaintenanceMessage(null);
    setMaintenanceError(null);
    setServiceRequestMessage(null);
    setServiceRequestError(null);
    resetResolutionForm();
    setLatestMaintenanceRecord(null);
    void loadSelectedVehicle(vehicleID);
  }

  function resetResolutionForm() {
    setResolutionAlertID(null);
    setResolutionNote('');
    setResolutionServiceRequestID('');
    setResolutionError(null);
  }

  async function handleStartServiceRequest(requestID: string) {
    setActingServiceRequestID(requestID);
    setServiceRequestMessage(null);
    setServiceRequestError(null);

    try {
      await api.startSpecialistServiceRequest(token, requestID);
      await loadServiceRequests();
      setServiceRequestMessage(specialistMessages.serviceRequests.movedInProgress);
    } catch (err) {
      handleSpecialistError(err, specialistMessages.serviceRequests.startError, setServiceRequestError);
    } finally {
      setActingServiceRequestID(null);
    }
  }

  async function handleCompleteServiceRequest(requestID: string) {
    const resultSummary = (resultSummaries[requestID] ?? '').trim();
    if (!resultSummary) {
      setServiceRequestError(specialistMessages.serviceRequests.resultRequired);
      return;
    }

    setActingServiceRequestID(requestID);
    setServiceRequestMessage(null);
    setServiceRequestError(null);

    try {
      await api.completeSpecialistServiceRequest(token, requestID, {
        result_summary: resultSummary,
      });
      await loadServiceRequests();
      setResultSummaries((current) => ({ ...current, [requestID]: '' }));
      setServiceRequestMessage(specialistMessages.serviceRequests.completedMessage);
    } catch (err) {
      handleSpecialistError(err, specialistMessages.serviceRequests.completeError, setServiceRequestError);
    } finally {
      setActingServiceRequestID(null);
    }
  }

  async function handleCreateMaintenanceRecord(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMaintenanceMessage(null);
    setMaintenanceError(null);

    if (!selectedVehicleID) {
      setMaintenanceError(specialistMessages.maintenance.selectVehicle);
      return;
    }

    const title = maintenanceTitle.trim();
    const description = maintenanceDescription.trim();
    if (!title || !description || !maintenanceServiceDate) {
      setMaintenanceError(specialistMessages.maintenance.requiredFields);
      return;
    }

    setIsCreatingMaintenance(true);
    try {
      const record = await api.createSpecialistMaintenanceRecord(
        token,
        selectedVehicleID,
        {
          title,
          description,
          service_date: maintenanceServiceDate,
        },
      );
      setLatestMaintenanceRecord(record);
      setMaintenanceTitle('');
      setMaintenanceDescription('');
      setMaintenanceServiceDate('');
      setMaintenanceMessage(specialistMessages.maintenance.success);
    } catch (err) {
      handleSpecialistError(err, specialistMessages.maintenance.error, setMaintenanceError);
    } finally {
      setIsCreatingMaintenance(false);
    }
  }

  function linkedCompletedRequestsForAlert(alert: Alert) {
    return serviceRequests.filter(
      (request) =>
        request.vehicle_id === alert.vehicle_id &&
        request.source_alert_id === alert.id &&
        request.assigned_specialist_id === user.id &&
        request.status === 'completed',
    );
  }

  function linkedServiceRequestForAlert(alert: Alert) {
    if (!alert.resolution_service_request_id) {
      return null;
    }

    return (
      serviceRequests.find(
        (request) => request.id === alert.resolution_service_request_id,
      ) ?? null
    );
  }

  async function handleResolveIncident(
    event: FormEvent<HTMLFormElement>,
    alert: Alert,
  ) {
    event.preventDefault();
    const trimmedNote = resolutionNote.trim();
    setResolutionMessage(null);
    setResolutionError(null);

    if (trimmedNote.length < 10 || trimmedNote.length > 2000) {
      setResolutionError(specialistMessages.incidents.noteValidation);
      return;
    }

    setIsResolvingAlert(true);
    try {
      await api.resolveSpecialistAlert(token, alert.id, {
        resolution_note: trimmedNote,
        service_request_id: resolutionServiceRequestID || undefined,
      });

      if (selectedVehicleID) {
        await Promise.all([
          loadSelectedVehicle(selectedVehicleID),
          loadServiceRequests(),
        ]);
      } else {
        await loadServiceRequests();
      }

      resetResolutionForm();
      setResolutionMessage(specialistMessages.incidents.success);
    } catch (err) {
      handleSpecialistError(err, specialistMessages.incidents.error, setResolutionError);
    } finally {
      setIsResolvingAlert(false);
    }
  }


  function renderServiceRequestCard(request: ServiceRequest) {
    const isActing = actingServiceRequestID === request.id;
    const canStart = request.status === 'assigned';
    const canComplete = request.status === 'in_progress';
    const hasAction = canStart || canComplete;

    return (
      <article className={`service-request-card specialist-request-card ${hasAction ? 'actionable' : 'readonly'}`} key={request.id}>
        <div className="service-request-main">
          <div className="specialist-request-heading">
            <div>
              <h3>{request.title}</h3>
              <p className="muted">{vehicleLabel(request.vehicle_id)}</p>
            </div>
            <div className="specialist-request-badges">
              <span className={`priority-pill ${request.priority}`}>{formatStructuredLabel(request.priority, commonMessages.notAvailable, localeMessages.structuredLabels)}</span>
              <span className={`status-pill ${request.status}`}>{formatStructuredLabel(request.status, commonMessages.notAvailable, localeMessages.structuredLabels)}</span>
            </div>
          </div>

          <div className="specialist-request-time-row">
            <span>{commonMessages.created} {formatTimestamp(request.created_at, commonMessages.notAvailable)}</span>
            {request.assigned_at && <span>{commonMessages.assignedAt} {formatTimestamp(request.assigned_at, commonMessages.notAvailable)}</span>}
          </div>

          <p className="specialist-request-description">{previewText(request.description)}</p>

          {request.result_summary && (
            <div className="specialist-result-summary">
              <strong>{specialistMessages.serviceRequests.result}</strong>
              <span>{request.result_summary}</span>
            </div>
          )}
        </div>

        {hasAction && (
          <div className="service-request-actions specialist-request-actions">
            {canStart && (
              <button
                className="primary-button"
                disabled={isActing}
                type="button"
                onClick={() => void handleStartServiceRequest(request.id)}
              >
                {isActing ? specialistMessages.serviceRequests.starting : specialistMessages.serviceRequests.startWork}
              </button>
            )}

            {canComplete && (
              <>
                <label>
                  {specialistMessages.serviceRequests.resultSummary}
                  <textarea
                    disabled={isActing}
                    onChange={(event) =>
                      setResultSummaries((current) => ({
                        ...current,
                        [request.id]: event.target.value,
                      }))
                    }
                    placeholder={specialistMessages.serviceRequests.resultPlaceholder}
                    rows={3}
                    value={resultSummaries[request.id] ?? ''}
                  />
                </label>
                <button
                  className="primary-button"
                  disabled={isActing}
                  type="button"
                  onClick={() => void handleCompleteServiceRequest(request.id)}
                >
                  {isActing ? specialistMessages.serviceRequests.completing : specialistMessages.serviceRequests.complete}
                </button>
              </>
            )}
          </div>
        )}
      </article>
    );
  }
  function renderResolutionForm(alert: Alert) {
    if (resolutionAlertID !== alert.id) {
      return (
        <button
          className="secondary-button"
          type="button"
          onClick={() => {
            setResolutionAlertID(alert.id);
            setResolutionNote('');
            setResolutionServiceRequestID('');
            setResolutionError(null);
            setResolutionMessage(null);
          }}
        >
          {specialistMessages.incidents.resolveIncident}
        </button>
      );
    }

    const linkedRequests = linkedCompletedRequestsForAlert(alert);

    return (
      <form
        className="alert-resolution-form"
        onSubmit={(event) => void handleResolveIncident(event, alert)}
      >
        <label>
          {specialistMessages.incidents.resolutionNote}
          <textarea
            disabled={isResolvingAlert}
            maxLength={2000}
            onChange={(event) => setResolutionNote(event.target.value)}
            placeholder={specialistMessages.incidents.resolutionPlaceholder}
            rows={4}
            value={resolutionNote}
          />
        </label>
        <small>{specialistMessages.incidents.noteLength.replace('{count}', String(resolutionNote.trim().length))}</small>

        <label>
          {specialistMessages.incidents.linkedCompletedRequest}
          <select
            disabled={isResolvingAlert}
            onChange={(event) => setResolutionServiceRequestID(event.target.value)}
            value={resolutionServiceRequestID}
          >
            <option value="">{specialistMessages.incidents.noLinkedRequest}</option>
            {linkedRequests.map((request) => (
              <option key={request.id} value={request.id}>
                {request.title}
              </option>
            ))}
          </select>
        </label>
        {linkedRequests.length === 0 && (
          <small>
            {specialistMessages.incidents.noCompletedLinked}
          </small>
        )}

        <div className="alert-resolution-actions">
          <button
            className="secondary-button"
            disabled={isResolvingAlert}
            type="button"
            onClick={resetResolutionForm}
          >
            {specialistMessages.incidents.cancel}
          </button>
          <button
            className="primary-button"
            disabled={isResolvingAlert}
            type="submit"
          >
            {isResolvingAlert ? specialistMessages.incidents.confirming : specialistMessages.incidents.confirm}
          </button>
        </div>
      </form>
    );
  }

  function renderResolvedIncidentDetails(alert: Alert) {
    const request = linkedServiceRequestForAlert(alert);

    if (!alert.resolution_service_request_id) {
      return null;
    }

    return (
      <div className="alert-linked-service-request">
        {request ? (
          <>
            <strong>{specialistMessages.incidents.linkedServiceRequest}</strong> {request.title}
            {request.result_summary && (
              <span>
                <strong>{specialistMessages.incidents.result}</strong> {request.result_summary}
              </span>
            )}
          </>
        ) : (
          <span>{specialistMessages.incidents.linkedUnavailable}</span>
        )}
      </div>
    );
  }

  return (
    <WorkspaceShell
      eyebrow={workspaceMessages.kicker}
      title={workspaceMessages.title}
      description={workspaceMessages.description}
      userEmail={user.email}
      userRole={formatStructuredLabel(user.role, commonMessages.notAvailable, localeMessages.structuredLabels)}
      sections={specialistWorkspaceSections}
      activeSection={activeWorkspaceSection}
      onSectionChange={setActiveWorkspaceSection}
      onOpenAccount={onOpenAccount}
      onLogout={onLogout}
      accountLabel={accountMessages.button}
      logoutLabel={commonMessages.logout}
      navigationLabel={sharedWorkspaceMessages.navigationLabel}
      sectionsLabel={sharedWorkspaceMessages.sectionsLabel}
      metricsLabel={sharedWorkspaceMessages.metricsLabel}
      metrics={[
        { label: workspaceMessages.metrics.assignedVehicles, value: vehicles.length },
        { label: workspaceMessages.metrics.assignedRequests, value: serviceRequests.length },
        { label: workspaceMessages.metrics.activeConditions, value: activeAlerts.length },
        { label: workspaceMessages.metrics.clearedIncidents, value: clearedAlerts.length },
      ]}
    >
      {error && <div className="error-box">{error}</div>}
      {isLoading && <div className="info-box">{commonMessages.loadingAssignedVehicles}</div>}

      <div className="panel selected-vehicle workspace-context-panel">
        <div>
          <h2>{specialistMessages.overview.selectedVehicle}</h2>
          {selectedVehicle ? (
            <p>
              {selectedVehicle.brand} {selectedVehicle.model} -{' '}
              {selectedVehicle.vin ?? specialistMessages.assignedVehicles.vinNotSet}
            </p>
          ) : (
            <p className="muted">
              {specialistMessages.overview.noVehicleSelected}
            </p>
          )}
        </div>
      </div>

      <WorkspaceSection active={activeWorkspaceSection === 'overview'}>
        <section className="panel">
          <h2>{specialistMessages.overview.title}</h2>
          <p className="muted">
            {specialistMessages.overview.description}
          </p>
          <div className="metric-grid">
            <div className="metric-card">
              <span>{specialistMessages.overview.selectedVehicle}</span>
              <strong>{selectedVehicle ? `${selectedVehicle.brand} ${selectedVehicle.model}` : specialistMessages.overview.none}</strong>
            </div>
            <div className="metric-card">
              <span>{specialistMessages.overview.telemetryRecordsLoaded}</span>
              <strong>{telemetryHistory.length}</strong>
            </div>
            <div className="metric-card">
              <span>{specialistMessages.overview.thresholds}</span>
              <strong>{thresholds.length}</strong>
            </div>
            <div className="metric-card">
              <span>{specialistMessages.overview.openRequests}</span>
              <strong>{serviceRequests.filter((request) => ['assigned', 'in_progress'].includes(request.status)).length}</strong>
            </div>
          </div>
        </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'assigned-vehicles'}>
        <section className="dashboard-grid workspace-dashboard-grid">
          <aside className="side-column">
            <section className="panel">
              <h2>{specialistMessages.assignedVehicles.specialistAccess}</h2>
              <p className="muted">
                {specialistMessages.assignedVehicles.accessExplanation}
              </p>
            </section>
            <VehicleList
              vehicles={vehicles}
              selectedVehicleID={selectedVehicleID}
              onSelect={handleSelectVehicle}
              labels={{
                title: specialistMessages.assignedVehicles.myVehicles,
                empty: specialistMessages.assignedVehicles.noVehicles,
                vinNotSet: specialistMessages.assignedVehicles.vinNotSet,
                noPlate: specialistMessages.assignedVehicles.noPlate,
              }}
            />
          </aside>
        </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'service-requests'}>
        <section className="panel">
          <div className="panel-header">
            <div>
              <h2>{specialistMessages.serviceRequests.title}</h2>
              <p className="muted">
                {specialistMessages.serviceRequests.description}
              </p>
            </div>
            <button
              className="secondary-button"
              disabled={isLoadingServiceRequests}
              type="button"
              onClick={() => void loadServiceRequests()}
            >
              {isLoadingServiceRequests ? commonMessages.refreshing : commonMessages.refreshRequests}
            </button>
          </div>

          {serviceRequestMessage && <div className="success-box">{serviceRequestMessage}</div>}
          {serviceRequestError && <div className="error-box inline">{serviceRequestError}</div>}

          {isLoadingServiceRequests ? (
            <p className="info-box">{commonMessages.loadingServiceRequests}</p>
          ) : serviceRequests.length === 0 ? (
            <p className="empty-state">{specialistMessages.serviceRequests.noAssigned}</p>
          ) : (
            <div className="specialist-request-queues">
              <RequestQueue
                title={specialistMessages.serviceRequests.needsAction}
                description={specialistMessages.serviceRequests.needsActionDescription}
                emptyMessage={specialistMessages.serviceRequests.needsActionEmpty}
                requests={serviceRequestQueues.needsAction}
                renderRequest={renderServiceRequestCard}
              />
              <RequestQueue
                title={specialistMessages.serviceRequests.completed}
                description={specialistMessages.serviceRequests.completedDescription}
                emptyMessage={specialistMessages.serviceRequests.completedEmpty}
                requests={serviceRequestQueues.completed}
                renderRequest={renderServiceRequestCard}
              />
              <RequestQueue
                title={specialistMessages.serviceRequests.archived}
                description={specialistMessages.serviceRequests.archivedDescription}
                emptyMessage={specialistMessages.serviceRequests.archivedEmpty}
                requests={serviceRequestQueues.archived}
                renderRequest={renderServiceRequestCard}
              />
            </div>
          )}
        </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'diagnostics'}>
        <section className="panel specialist-diagnostic-summary">
          <div className="panel-header">
            <div>
              <h2>{specialistMessages.diagnostics.summaryTitle}</h2>
              <p className="muted">{specialistMessages.diagnostics.summaryDescription}</p>
            </div>
            <div className="button-row compact">
              {(isPollingDiagnostics || isLoadingDiagnostics) && (
                <span className="badge">{isPollingDiagnostics ? commonMessages.polling : commonMessages.loading}</span>
              )}
              <button
                className="secondary-button"
                disabled={!selectedVehicleID || isLoadingDiagnostics}
                type="button"
                onClick={() => {
                  if (selectedVehicleID) {
                    void loadSelectedVehicle(selectedVehicleID);
                  }
                }}
              >
                {isLoadingDiagnostics ? commonMessages.refreshing : specialistMessages.diagnostics.refreshDiagnostics}
              </button>
            </div>
          </div>
          <div className="metric-grid compact diagnostic-summary-grid">
            <div className="metric-card">
              <span>{specialistMessages.diagnostics.vehicle}</span>
              <strong>{selectedVehicle ? `${selectedVehicle.brand} ${selectedVehicle.model}` : specialistMessages.assignedVehicles.noneSelected}</strong>
            </div>
            <div className="metric-card">
              <span>{specialistMessages.diagnostics.overallStatus}</span>
              <strong>{formatStructuredLabel(status?.overall_status, commonMessages.notAvailable, localeMessages.structuredLabels)}</strong>
            </div>
            <div className="metric-card">
              <span>{specialistMessages.diagnostics.activeConditions}</span>
              <strong>{activeAlerts.length}</strong>
            </div>
            <div className="metric-card">
              <span>{specialistMessages.diagnostics.latestTelemetry}</span>
              <strong>{formatTimestamp(latestTelemetryTimestamp, commonMessages.notAvailable)}</strong>
            </div>
          </div>
        </section>
        <StatusPanel status={status} isLoading={isLoadingVehicle} />
        {shouldShowInspectionBanner && (
          <ClearedCriticalAttentionBanner
            alerts={clearedCriticalAlerts}
            labels={localeMessages.structuredLabels}
            messages={specialistMessages.incidents}
            timestampFallback={commonMessages.notAvailable}
          />
        )}
        <ThresholdsPanel thresholds={thresholds} isLoading={isLoadingVehicle} audience="specialist" />
        {diagnosticError && <div className="error-box inline">{diagnosticError}</div>}
        <TelemetryTrendsPanel records={telemetryHistory} isLoading={isLoadingDiagnostics} />
        <TelemetryHistory
          records={telemetryHistory}
          isLoading={isLoadingDiagnostics}
          title={specialistMessages.diagnostics.telemetryTitle}
          description={specialistMessages.diagnostics.telemetryDescription}
          emptyMessage={specialistMessages.diagnostics.telemetryEmpty}
          loadingMessage={commonMessages.loadingDiagnosticTelemetry}
        />
        <AlertIncidentPanel
          title={specialistMessages.diagnostics.activeConditions}
          description={specialistMessages.diagnostics.activeDescription}
          alerts={activeAlerts}
          emptyMessage={specialistMessages.diagnostics.activeEmpty}
          isLoading={isLoadingDiagnostics}
          isRefreshing={isPollingDiagnostics}
        />
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'maintenance'}>
        <section className="panel">
          <h2>{specialistMessages.maintenance.title}</h2>
          <p className="muted">{specialistMessages.maintenance.helper}</p>

          {maintenanceMessage && <div className="success-box">{maintenanceMessage}</div>}
          {maintenanceError && <div className="error-box inline">{maintenanceError}</div>}

          <form className="form-grid specialist-maintenance-form" onSubmit={handleCreateMaintenanceRecord}>
            <label>
              {specialistMessages.maintenance.fieldTitle}
              <input
                disabled={!selectedVehicleID || isCreatingMaintenance}
                maxLength={255}
                onChange={(event) => setMaintenanceTitle(event.target.value)}
                placeholder={specialistMessages.maintenance.titlePlaceholder}
                value={maintenanceTitle}
              />
            </label>

            <label>
              {specialistMessages.maintenance.serviceDate}
              <input
                disabled={!selectedVehicleID || isCreatingMaintenance}
                onChange={(event) => setMaintenanceServiceDate(event.target.value)}
                type="date"
                value={maintenanceServiceDate}
              />
            </label>

            <label>
              {specialistMessages.maintenance.description}
              <textarea
                disabled={!selectedVehicleID || isCreatingMaintenance}
                onChange={(event) => setMaintenanceDescription(event.target.value)}
                placeholder={specialistMessages.maintenance.descriptionPlaceholder}
                rows={4}
                value={maintenanceDescription}
              />
            </label>

            <button className="primary-button full-width-action" disabled={!selectedVehicleID || isCreatingMaintenance} type="submit">
              {isCreatingMaintenance ? specialistMessages.maintenance.creating : specialistMessages.maintenance.create}
            </button>
          </form>

          {latestMaintenanceRecord && (
            <div className="info-box">
              {specialistMessages.maintenance.latestCreated
                .replace('{title}', latestMaintenanceRecord.title)
                .replace('{date}', formatTimestamp(latestMaintenanceRecord.service_date, commonMessages.notAvailable))}
            </div>
          )}
        </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'incident-resolution'}>
        {resolutionMessage && <div className="success-box">{resolutionMessage}</div>}
        {resolutionError && <div className="error-box inline">{resolutionError}</div>}
        <AlertIncidentPanel
          title={specialistMessages.incidents.clearedTitle}
          description={specialistMessages.incidents.clearedDescription}
          alerts={clearedAlerts}
          emptyMessage={specialistMessages.incidents.clearedEmpty}
          isLoading={isLoadingDiagnostics}
          isRefreshing={isPollingDiagnostics}
          clearedNote={specialistMessages.incidents.clearedNote}
          renderAction={renderResolutionForm}
        />
        <AlertIncidentPanel
          title={specialistMessages.incidents.resolvedTitle}
          description={specialistMessages.incidents.resolvedDescription}
          alerts={resolvedAlerts}
          emptyMessage={specialistMessages.incidents.resolvedEmpty}
          isLoading={isLoadingDiagnostics}
          isRefreshing={isPollingDiagnostics}
          renderExtra={renderResolvedIncidentDetails}
        />
        {otherAlerts.length > 0 && (
          <AlertIncidentPanel
            title={specialistMessages.incidents.otherTitle}
            description={specialistMessages.incidents.otherDescription}
            alerts={otherAlerts}
            emptyMessage={specialistMessages.incidents.otherEmpty}
            isLoading={isLoadingDiagnostics}
            isRefreshing={isPollingDiagnostics}
          />
        )}
      </WorkspaceSection>
    </WorkspaceShell>
  );
}

function RequestQueue({
  title,
  description,
  emptyMessage,
  requests,
  renderRequest,
}: {
  title: string;
  description: string;
  emptyMessage: string;
  requests: ServiceRequest[];
  renderRequest: (request: ServiceRequest) => JSX.Element;
}) {
  return (
    <section className="specialist-request-queue">
      <div className="specialist-request-queue-header">
        <div>
          <h3>{title}</h3>
          <p className="muted">{description}</p>
        </div>
        <span className="badge">{requests.length}</span>
      </div>
      {requests.length === 0 ? (
        <p className="empty-state compact-empty">{emptyMessage}</p>
      ) : (
        <div className="list-stack">{requests.map(renderRequest)}</div>
      )}
    </section>
  );
}
function ClearedCriticalAttentionBanner({
  alerts,
  labels,
  messages,
  timestampFallback,
}: {
  alerts: Alert[];
  labels: Record<string, string>;
  messages: Record<string, string>;
  timestampFallback: string;
}) {
  return (
    <section className="attention-banner">
      <div>
        <h2>{messages.attentionTitle}</h2>
        <p className="muted">
          {messages.attentionDescription}
        </p>
      </div>
      <div className="attention-list">
        {alerts.map((alert) => (
          <article key={alert.id}>
            <strong>{formatAlertParameter(alert.type, labels)}</strong>
            <span>{messages.attentionOccurrences}: {alert.occurrence_count}</span>
            <span>
              {messages.attentionLastTriggered}: {formatAlertTimestamp(alert.last_triggered_at, timestampFallback)}
            </span>
            <span>{messages.attentionCleared}: {formatAlertTimestamp(alert.cleared_at, timestampFallback)}</span>
          </article>
        ))}
      </div>
    </section>
  );
}
