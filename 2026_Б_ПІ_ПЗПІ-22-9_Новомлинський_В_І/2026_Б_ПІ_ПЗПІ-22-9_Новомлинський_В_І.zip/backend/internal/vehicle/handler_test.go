package vehicle

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type stubService struct {
	vehicles []Vehicle
	vehicle  Vehicle
	err      error
}

func (s stubService) List(context.Context) ([]Vehicle, error) {
	return s.vehicles, s.err
}

func (s stubService) GetByID(context.Context, string) (Vehicle, error) {
	return s.vehicle, s.err
}

func (s stubService) ListByOwner(context.Context, string) ([]Vehicle, error) {
	return s.vehicles, s.err
}

func (s stubService) GetByIDForOwner(context.Context, string, string) (Vehicle, error) {
	return s.vehicle, s.err
}

func (s stubService) CreateForOwner(context.Context, string, CreateRequest) (Vehicle, error) {
	return s.vehicle, s.err
}

func TestHandlerList(t *testing.T) {
	handler := NewHandler(stubService{
		vehicles: []Vehicle{{ID: "11111111-1111-1111-1111-111111111111", Brand: "Toyota"}},
	}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/vehicles", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"brand":"Toyota"`) {
		t.Fatalf("expected vehicle JSON, got %s", body)
	}
}

func TestHandlerGetByIDNotFound(t *testing.T) {
	handler := NewHandler(stubService{err: ErrNotFound}, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/11111111-1111-1111-1111-111111111111",
		nil,
	)
	request.SetPathValue("id", "11111111-1111-1111-1111-111111111111")
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestHandlerListInternalError(t *testing.T) {
	handler := NewHandler(stubService{err: errors.New("database error")}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/vehicles", nil)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, recorder.Code)
	}
	if strings.Contains(recorder.Body.String(), "database error") {
		t.Fatal("response exposed an internal error")
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
