import type { Vehicle } from '../api/types';

type VehicleListLabels = {
  title?: string;
  empty?: string;
  vinNotSet?: string;
  noPlate?: string;
};

type Props = {
  vehicles: Vehicle[];
  selectedVehicleID: string | null;
  onSelect: (vehicleID: string) => void;
  labels?: VehicleListLabels;
};

export function VehicleList({ vehicles, selectedVehicleID, onSelect, labels }: Props) {
  const title = labels?.title ?? 'My vehicles';
  const empty = labels?.empty ?? 'No vehicles yet. Create the first one.';
  const vinNotSet = labels?.vinNotSet ?? 'VIN not set';
  const noPlate = labels?.noPlate ?? 'No plate';
  return (
    <section className="panel">
      <h2>{title}</h2>
      {vehicles.length === 0 ? (
        <p className="empty-state">{empty}</p>
      ) : (
        <div className="list-stack">
          {vehicles.map((vehicle) => (
            <button
              className={
                selectedVehicleID === vehicle.id
                  ? 'list-item selected'
                  : 'list-item'
              }
              key={vehicle.id}
              type="button"
              onClick={() => onSelect(vehicle.id)}
            >
              <span>
                <strong>
                  {vehicle.brand} {vehicle.model}
                </strong>
                <small>{vehicle.vin ?? vinNotSet}</small>
              </span>
              <span className="badge">{vehicle.license_plate ?? noPlate}</span>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}
