package adminuser

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

var (
	ErrNotFound             = errors.New("user not found")
	ErrAlreadyInactive      = errors.New("user already inactive")
	ErrAlreadyActive        = errors.New("user already active")
	ErrLastAdministrator    = errors.New("last active administrator cannot be deactivated")
	ErrSpecialistActiveWork = errors.New("technical specialist has active service requests")
	ErrAuditInsertFailed    = auditlog.ErrWriteFailed
)

type Repository interface {
	List(ctx context.Context, filters ListFilters) ([]User, error)
	GetByID(ctx context.Context, userID string) (User, error)
	Deactivate(ctx context.Context, actorID string, targetID string, reason *string) (User, error)
	Reactivate(ctx context.Context, actorID string, targetID string) (User, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) List(ctx context.Context, filters ListFilters) ([]User, error) {
	query := `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at,
			users.deactivated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
	`
	clauses := make([]string, 0, 3)
	args := make([]any, 0, 3)
	if filters.Role != "" {
		args = append(args, filters.Role)
		clauses = append(clauses, fmt.Sprintf("roles.code = $%d", len(args)))
	}
	if filters.IsActive != nil {
		args = append(args, *filters.IsActive)
		clauses = append(clauses, fmt.Sprintf("users.is_active = $%d", len(args)))
	}
	if filters.Search != "" {
		args = append(args, "%"+strings.ToLower(filters.Search)+"%")
		clauses = append(
			clauses,
			fmt.Sprintf(
				"(lower(users.email) LIKE $%d OR lower(users.full_name) LIKE $%d)",
				len(args),
				len(args),
			),
		)
	}
	if len(clauses) > 0 {
		query += " WHERE " + strings.Join(clauses, " AND ")
	}
	query += " ORDER BY users.created_at DESC, users.id DESC"

	return queryUsers(ctx, r.db, query, args...)
}

func (r *PostgresRepository) GetByID(ctx context.Context, userID string) (User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at,
			users.deactivated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE users.id = $1
	`

	return getUser(ctx, r.db, query, userID)
}

func (r *PostgresRepository) Deactivate(
	ctx context.Context,
	actorID string,
	targetID string,
	reason *string,
) (User, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return User{}, fmt.Errorf("begin user deactivation transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	current, err := r.getByIDForUpdate(ctx, tx, targetID)
	if err != nil {
		return User{}, err
	}
	if !current.IsActive {
		return User{}, ErrAlreadyInactive
	}
	if current.Role == auth.AdministratorRoleCode {
		count, err := r.countActiveAdministrators(ctx, tx)
		if err != nil {
			return User{}, err
		}
		if count <= 1 {
			return User{}, ErrLastAdministrator
		}
	}
	removedVehicleAssignments := 0
	if current.Role == auth.TechnicalSpecialistRoleCode {
		hasWork, err := r.hasActiveSpecialistWork(ctx, tx, targetID)
		if err != nil {
			return User{}, err
		}
		if hasWork {
			return User{}, ErrSpecialistActiveWork
		}

		removedVehicleAssignments, err = cleanupActiveVehicleAssignments(ctx, tx, targetID)
		if err != nil {
			return User{}, err
		}
	}

	const query = `
		UPDATE users
		SET
			is_active = FALSE,
			deactivated_at = CURRENT_TIMESTAMP,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1
		RETURNING
			id,
			role_id,
			$2::varchar,
			email,
			full_name,
			is_active,
			created_at,
			updated_at,
			deactivated_at
	`

	item, err := getUser(ctx, tx, query, targetID, current.Role)
	if err != nil {
		return User{}, err
	}
	if err := insertAuditLog(
		ctx,
		tx,
		actorID,
		ActionUserDeactivated,
		targetID,
		auditMetadata(current, item, reason),
	); err != nil {
		return User{}, err
	}
	if current.Role == auth.TechnicalSpecialistRoleCode {
		if err := insertAuditLog(
			ctx,
			tx,
			actorID,
			ActionTechnicalSpecialistDeactivationCleanup,
			targetID,
			specialistDeactivationCleanupMetadata(item, removedVehicleAssignments),
		); err != nil {
			return User{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return User{}, fmt.Errorf("commit user deactivation transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) Reactivate(
	ctx context.Context,
	actorID string,
	targetID string,
) (User, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return User{}, fmt.Errorf("begin user reactivation transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	current, err := r.getByIDForUpdate(ctx, tx, targetID)
	if err != nil {
		return User{}, err
	}
	if current.IsActive {
		return User{}, ErrAlreadyActive
	}

	const query = `
		UPDATE users
		SET
			is_active = TRUE,
			deactivated_at = NULL,
			updated_at = CURRENT_TIMESTAMP
		WHERE id = $1
		RETURNING
			id,
			role_id,
			$2::varchar,
			email,
			full_name,
			is_active,
			created_at,
			updated_at,
			deactivated_at
	`

	item, err := getUser(ctx, tx, query, targetID, current.Role)
	if err != nil {
		return User{}, err
	}
	if err := insertAuditLog(
		ctx,
		tx,
		actorID,
		ActionUserReactivated,
		targetID,
		auditMetadata(current, item, nil),
	); err != nil {
		return User{}, err
	}
	if err := tx.Commit(); err != nil {
		return User{}, fmt.Errorf("commit user reactivation transaction: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) getByIDForUpdate(
	ctx context.Context,
	tx *sql.Tx,
	userID string,
) (User, error) {
	const query = `
		SELECT
			users.id,
			users.role_id,
			roles.code,
			users.email,
			users.full_name,
			users.is_active,
			users.created_at,
			users.updated_at,
			users.deactivated_at
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE users.id = $1
		FOR UPDATE
	`

	return getUser(ctx, tx, query, userID)
}

func (r *PostgresRepository) countActiveAdministrators(
	ctx context.Context,
	tx *sql.Tx,
) (int, error) {
	const query = `
		SELECT users.id
		FROM users
		INNER JOIN roles ON roles.id = users.role_id
		WHERE roles.code = 'administrator'
		  AND users.is_active = TRUE
		FOR UPDATE
	`

	rows, err := tx.QueryContext(ctx, query)
	if err != nil {
		return 0, fmt.Errorf("count active administrators: %w", err)
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return 0, fmt.Errorf("scan active administrator: %w", err)
		}
		count++
	}
	if err := rows.Err(); err != nil {
		return 0, fmt.Errorf("iterate active administrators: %w", err)
	}

	return count, nil
}

func (r *PostgresRepository) hasActiveSpecialistWork(
	ctx context.Context,
	tx *sql.Tx,
	specialistID string,
) (bool, error) {
	const query = `
		SELECT EXISTS (
			SELECT 1
			FROM vehicle_service_requests
			WHERE assigned_specialist_id = $1
			  AND status IN ('assigned', 'in_progress')
		)
	`

	var exists bool
	if err := tx.QueryRowContext(ctx, query, specialistID).Scan(&exists); err != nil {
		return false, fmt.Errorf("check active specialist service requests: %w", err)
	}

	return exists, nil
}

func cleanupActiveVehicleAssignments(
	ctx context.Context,
	executor auditlog.Executor,
	specialistID string,
) (int, error) {
	result, err := executor.ExecContext(
		ctx,
		`
			DELETE FROM vehicle_specialist_assignments
			WHERE specialist_id = $1
		`,
		specialistID,
	)
	if err != nil {
		return 0, fmt.Errorf("delete active specialist vehicle assignments: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("read removed specialist vehicle assignment count: %w", err)
	}

	return int(rowsAffected), nil
}

func insertAuditLog(
	ctx context.Context,
	tx *sql.Tx,
	actorID string,
	action string,
	targetID string,
	metadata map[string]any,
) error {
	return auditlog.NewPostgresWriter().Write(
		ctx,
		tx,
		auditlog.Entry{
			ActorID:    actorID,
			Action:     action,
			EntityType: EntityTypeUser,
			EntityID:   targetID,
			Metadata:   metadata,
		},
	)
}

func auditMetadata(previous User, next User, reason *string) map[string]any {
	metadata := map[string]any{
		"target_email":            next.Email,
		"target_role":             next.Role,
		"previous_active_state":   previous.IsActive,
		"new_active_state":        next.IsActive,
		"previous_deactivated_at": previous.DeactivatedAt,
		"new_deactivated_at":      next.DeactivatedAt,
	}
	if reason != nil {
		metadata["reason"] = *reason
	}

	return metadata
}

func specialistDeactivationCleanupMetadata(specialist User, removedVehicleAssignments int) map[string]any {
	return map[string]any{
		"specialist_id":               specialist.ID,
		"email":                       specialist.Email,
		"removed_vehicle_assignments": removedVehicleAssignments,
	}
}

type queryer interface {
	QueryContext(ctx context.Context, query string, args ...any) (*sql.Rows, error)
}

type rowQueryer interface {
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

type scanner interface {
	Scan(dest ...any) error
}

func queryUsers(
	ctx context.Context,
	db queryer,
	query string,
	args ...any,
) ([]User, error) {
	rows, err := db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("query admin users: %w", err)
	}
	defer rows.Close()

	users := make([]User, 0)
	for rows.Next() {
		item, err := scanUser(rows)
		if err != nil {
			return nil, fmt.Errorf("scan admin user: %w", err)
		}
		users = append(users, item)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate admin users: %w", err)
	}

	return users, nil
}

func getUser(
	ctx context.Context,
	db rowQueryer,
	query string,
	args ...any,
) (User, error) {
	item, err := scanUser(db.QueryRowContext(ctx, query, args...))
	if errors.Is(err, sql.ErrNoRows) {
		return User{}, ErrNotFound
	}
	if err != nil {
		return User{}, fmt.Errorf("query admin user: %w", err)
	}

	return item, nil
}

func scanUser(row scanner) (User, error) {
	var (
		item          User
		deactivatedAt sql.NullTime
	)
	if err := row.Scan(
		&item.ID,
		&item.RoleID,
		&item.Role,
		&item.Email,
		&item.FullName,
		&item.IsActive,
		&item.CreatedAt,
		&item.UpdatedAt,
		&deactivatedAt,
	); err != nil {
		return User{}, err
	}
	if deactivatedAt.Valid {
		item.DeactivatedAt = &deactivatedAt.Time
	}

	return item, nil
}
