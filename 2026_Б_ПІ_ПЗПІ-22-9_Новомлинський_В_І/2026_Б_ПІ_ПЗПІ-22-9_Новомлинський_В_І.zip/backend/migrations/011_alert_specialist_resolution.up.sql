BEGIN;

ALTER TABLE alerts
	ADD COLUMN resolved_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
	ADD COLUMN resolution_note TEXT,
	ADD COLUMN resolution_service_request_id UUID REFERENCES vehicle_service_requests(id) ON DELETE SET NULL,
	ADD CONSTRAINT alerts_resolution_note_length_check
	CHECK (
		resolution_note IS NULL
		OR char_length(btrim(resolution_note)) BETWEEN 10 AND 2000
	);

CREATE INDEX alerts_resolved_by_user_idx
	ON alerts(resolved_by_user_id, resolved_at DESC, id DESC);

CREATE INDEX alerts_resolution_service_request_idx
	ON alerts(resolution_service_request_id, resolved_at DESC, id DESC);

COMMIT;
