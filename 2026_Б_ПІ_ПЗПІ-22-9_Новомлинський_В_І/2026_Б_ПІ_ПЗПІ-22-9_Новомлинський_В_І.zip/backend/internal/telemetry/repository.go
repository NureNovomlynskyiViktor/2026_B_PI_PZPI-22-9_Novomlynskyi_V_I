package telemetry

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
)

var ErrNotFound = errors.New("telemetry record not found")

type Repository interface {
	ListByVehicle(ctx context.Context, vehicleID string, limit int) ([]Record, error)
	LatestByVehicle(ctx context.Context, vehicleID string) (Record, error)
	Create(ctx context.Context, input NewRecord) (Record, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) ListByVehicle(
	ctx context.Context,
	vehicleID string,
	limit int,
) ([]Record, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			device_id,
			measured_at,
			received_at,
			engine_temperature,
			battery_voltage,
			vibration_level,
			rpm,
			speed,
			fuel_level
		FROM telemetry_records
		WHERE vehicle_id = $1
		ORDER BY measured_at DESC, id DESC
		LIMIT $2
	`

	rows, err := r.db.QueryContext(ctx, query, vehicleID, limit)
	if err != nil {
		return nil, fmt.Errorf("query telemetry records: %w", err)
	}
	defer rows.Close()

	records := make([]Record, 0)
	for rows.Next() {
		record, err := scanRecord(rows)
		if err != nil {
			return nil, fmt.Errorf("scan telemetry record: %w", err)
		}
		records = append(records, record)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate telemetry records: %w", err)
	}

	return records, nil
}

func (r *PostgresRepository) LatestByVehicle(
	ctx context.Context,
	vehicleID string,
) (Record, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			device_id,
			measured_at,
			received_at,
			engine_temperature,
			battery_voltage,
			vibration_level,
			rpm,
			speed,
			fuel_level
		FROM telemetry_records
		WHERE vehicle_id = $1
		ORDER BY measured_at DESC, id DESC
		LIMIT 1
	`

	record, err := scanRecord(r.db.QueryRowContext(ctx, query, vehicleID))
	if errors.Is(err, sql.ErrNoRows) {
		return Record{}, ErrNotFound
	}
	if err != nil {
		return Record{}, fmt.Errorf("query latest telemetry record: %w", err)
	}

	return record, nil
}

func (r *PostgresRepository) Create(
	ctx context.Context,
	input NewRecord,
) (Record, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return Record{}, fmt.Errorf("begin telemetry transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	const insertQuery = `
		INSERT INTO telemetry_records (
			vehicle_id,
			device_id,
			measured_at,
			received_at,
			engine_temperature,
			battery_voltage,
			vibration_level,
			rpm,
			speed,
			fuel_level
		)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
		RETURNING
			id,
			vehicle_id,
			device_id,
			measured_at,
			received_at,
			engine_temperature,
			battery_voltage,
			vibration_level,
			rpm,
			speed,
			fuel_level
	`

	record, err := scanRecord(
		tx.QueryRowContext(
			ctx,
			insertQuery,
			input.VehicleID,
			input.DeviceID,
			input.MeasuredAt,
			input.ReceivedAt,
			input.EngineTemperature,
			input.BatteryVoltage,
			input.VibrationLevel,
			input.RPM,
			input.Speed,
			input.FuelLevel,
		),
	)
	if err != nil {
		return Record{}, fmt.Errorf("insert telemetry record: %w", err)
	}

	result, err := tx.ExecContext(
		ctx,
		`
			UPDATE devices
			SET last_seen_at = $1,
			    updated_at = $1
			WHERE id = $2
		`,
		input.ReceivedAt,
		input.DeviceID,
	)
	if err != nil {
		return Record{}, fmt.Errorf("update device last seen time: %w", err)
	}
	if affected, err := result.RowsAffected(); err != nil {
		return Record{}, fmt.Errorf("read updated device count: %w", err)
	} else if affected != 1 {
		return Record{}, fmt.Errorf("update device last seen time: device not found")
	}

	if err := tx.Commit(); err != nil {
		return Record{}, fmt.Errorf("commit telemetry transaction: %w", err)
	}

	return record, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanRecord(row scanner) (Record, error) {
	var record Record

	if err := row.Scan(
		&record.ID,
		&record.VehicleID,
		&record.DeviceID,
		&record.MeasuredAt,
		&record.ReceivedAt,
		&record.EngineTemperature,
		&record.BatteryVoltage,
		&record.VibrationLevel,
		&record.RPM,
		&record.Speed,
		&record.FuelLevel,
	); err != nil {
		return Record{}, err
	}

	return record, nil
}
