package specialistvehicle

import (
	"context"
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerthreshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type AssignmentService interface {
	ListVehiclesForSpecialist(ctx context.Context, specialistID string) ([]vehicle.Vehicle, error)
	GetAssignedVehicle(ctx context.Context, specialistID string, vehicleID string) (vehicle.Vehicle, error)
}

type StatusService interface {
	GetByVehicleID(ctx context.Context, vehicleID string) (vehiclestatus.VehicleStatus, error)
}

type ThresholdService interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]threshold.Setting, error)
}

type TelemetryService interface {
	ListByVehicle(ctx context.Context, vehicleID string, limit int) ([]telemetry.Record, error)
}

type AlertService interface {
	ListByVehicleStatus(ctx context.Context, vehicleID string, status string, limit int) ([]alert.Alert, error)
}

type Handler struct {
	assignments AssignmentService
	statuses    StatusService
	thresholds  ThresholdService
	telemetry   TelemetryService
	alerts      AlertService
	logger      *slog.Logger
}

func NewHandler(
	assignments AssignmentService,
	statuses StatusService,
	thresholds ThresholdService,
	telemetry TelemetryService,
	alerts AlertService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		assignments: assignments,
		statuses:    statuses,
		thresholds:  thresholds,
		telemetry:   telemetry,
		alerts:      alerts,
		logger:      logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := specialistUser(w, r)
	if !ok {
		return
	}

	vehicles, err := h.assignments.ListVehiclesForSpecialist(r.Context(), user.ID)
	if errors.Is(err, specialistassignment.ErrInvalidSpecialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist_id")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list specialist vehicles",
			"specialist_id", user.ID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, vehicles)
}

func (h *Handler) Status(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.assignedVehicle(w, r)
	if !ok {
		return
	}

	currentStatus, err := h.statuses.GetByVehicleID(r.Context(), vehicleID)
	if errors.Is(err, vehiclestatus.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, vehiclestatus.ErrVehicleNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get specialist vehicle status",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, currentStatus)
}

func (h *Handler) Thresholds(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.assignedVehicle(w, r)
	if !ok {
		return
	}

	settings, err := h.thresholds.ListByVehicle(r.Context(), vehicleID)
	if err != nil {
		h.logger.Error(
			"failed to list specialist vehicle thresholds",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, ownerthreshold.BuildRules(settings))
}

func (h *Handler) Telemetry(w http.ResponseWriter, r *http.Request) {
	user, ok := specialistUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	limit, err := telemetry.ParseLimit(r.URL.Query().Get("limit"))
	if err != nil {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}

	if !h.verifyAssignedVehicle(w, r, user.ID, vehicleID) {
		return
	}

	records, err := h.telemetry.ListByVehicle(r.Context(), vehicleID, limit)
	if errors.Is(err, telemetry.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, telemetry.ErrInvalidLimit) {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list specialist vehicle telemetry",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, records)
}

func (h *Handler) Alerts(w http.ResponseWriter, r *http.Request) {
	user, ok := specialistUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	status, err := alert.ParseStatus(r.URL.Query().Get("status"))
	if err != nil {
		response.Error(w, http.StatusBadRequest, "status must be active, resolved, or all")
		return
	}
	limit, err := alert.ParseLimit(r.URL.Query().Get("limit"))
	if err != nil {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}

	if !h.verifyAssignedVehicle(w, r, user.ID, vehicleID) {
		return
	}

	alerts, err := h.alerts.ListByVehicleStatus(r.Context(), vehicleID, status, limit)
	if errors.Is(err, alert.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, alert.ErrInvalidStatus) {
		response.Error(w, http.StatusBadRequest, "status must be active, resolved, or all")
		return
	}
	if errors.Is(err, alert.ErrInvalidLimit) {
		response.Error(w, http.StatusBadRequest, "limit must be between 1 and 200")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list specialist vehicle alerts",
			"specialist_id", user.ID,
			"vehicle_id", vehicleID,
			"status", status,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, alerts)
}

func (h *Handler) assignedVehicle(
	w http.ResponseWriter,
	r *http.Request,
) (auth.User, string, bool) {
	user, ok := specialistUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return auth.User{}, "", false
	}

	if _, err := h.assignments.GetAssignedVehicle(r.Context(), user.ID, vehicleID); err != nil {
		if !h.handleAssignmentVerificationError(w, user.ID, vehicleID, err) {
			return auth.User{}, "", false
		}
	}

	return user, vehicleID, true
}

func (h *Handler) verifyAssignedVehicle(
	w http.ResponseWriter,
	r *http.Request,
	specialistID string,
	vehicleID string,
) bool {
	if _, err := h.assignments.GetAssignedVehicle(r.Context(), specialistID, vehicleID); err != nil {
		return h.handleAssignmentVerificationError(w, specialistID, vehicleID, err)
	}

	return true
}

func (h *Handler) handleAssignmentVerificationError(
	w http.ResponseWriter,
	specialistID string,
	vehicleID string,
	err error,
) bool {
	if errors.Is(err, vehicle.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return false
	}
	if errors.Is(err, specialistassignment.ErrInvalidSpecialistID) ||
		errors.Is(err, specialistassignment.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist vehicle request")
		return false
	}
	h.logger.Error(
		"failed to verify specialist vehicle assignment",
		"specialist_id", specialistID,
		"vehicle_id", vehicleID,
		"error", err,
	)
	response.Error(w, http.StatusInternalServerError, "internal server error")
	return false
}

func specialistUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.TechnicalSpecialistRoleCode {
		response.Error(w, http.StatusForbidden, "technical specialist role required")
		return auth.User{}, false
	}

	return user, true
}
