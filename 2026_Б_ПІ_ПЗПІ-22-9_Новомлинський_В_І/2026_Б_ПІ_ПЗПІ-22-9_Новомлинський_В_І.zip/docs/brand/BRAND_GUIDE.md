# Autonexis Brand Guide

Autonexis is a software system for vehicle technical condition monitoring using IoT telemetry. The brand should feel trustworthy, technical, and calm: protective enough for vehicle safety data, but modern enough for connected diagnostics.

## Brand Purpose

Autonexis helps vehicle owners, technical specialists, and administrators understand vehicle condition from telemetry, alerts, service requests, and maintenance history. The visual language should communicate protection, mobility, diagnostics, and clear operational decisions without promising features the product does not yet provide.

## Logo Symbolism

The emblem combines three fixed ideas:

- Shield: trust, protection, data integrity, and responsible monitoring.
- Perspective road: vehicle movement, mobility, and real-world operating context.
- Five connected telemetry nodes: IoT readings, diagnostic relationships, and structured data processing.

The mark must remain simple at small sizes. Do not add text, vehicle silhouettes, fictional dashboard data, decorative stars, or extra details inside the emblem.

## Logo Assets

Primary assets live in `web/src/assets/brand/`:

- `autonexis-emblem-primary.svg`
- `autonexis-emblem-light.svg`
- `autonexis-emblem-dark.svg`
- `autonexis-emblem-monochrome.svg`
- `favicon.svg`

The primary mark is the shield emblem. The full brand lockup pairs the emblem with the HTML wordmark `Autonexis`; the wordmark should not be converted into SVG text or embedded as a font dependency.

## Usage

Use the full lockup in application headers, authentication surfaces, documentation covers, and presentation title slides when horizontal space allows. Use the compact icon-only mark for favicons, small navigation spaces, app launch surfaces, and square avatars.

Minimum practical sizes:

- 24 px: favicon or dense UI icon only.
- 32 px: compact navigation or list branding.
- 64 px and above: product headers and documentation.
- 128 px and above: presentation, export, or high-resolution preview.

Keep clear space around the mark equal to at least one telemetry node diameter. Do not place the emblem on busy imagery.

## Light, Dark, and Monochrome

Use `autonexis-emblem-light.svg` on light backgrounds and `autonexis-emblem-dark.svg` on dark navy backgrounds. Use the monochrome version for stamps, single-color printing, and constrained icon systems. In monochrome contexts, prefer deep navy on light surfaces and white on dark surfaces.

## Color Palette

Core colors:

- Deep navy: `#0B132B`
- Electric blue: `#2563EB`
- Telemetry accent: `#38BDF8`

The Web implementation exposes these through semantic CSS tokens, not direct component-level palette usage.

## Semantic Status Colors

Use semantic tokens for product state:

- Normal: stable vehicle condition.
- Warning: threshold issue needing attention.
- Critical: urgent issue or high severity incident.
- Offline: missing, inactive, unavailable, unknown, or disabled state.
- Cleared: telemetry has stabilized but repair is not confirmed.

Status colors must not be used as decoration. They should always communicate state.

## Typography

Use the existing system UI stack with Inter first when available. Product UI should favor compact, readable text, clear hierarchy, and no negative letter spacing. Use strong weights for labels, status pills, and the wordmark; use regular body text for descriptions.

## Spacing and Radius

Use the shared spacing scale in `web/src/styles/tokens.css`. Prefer steady 4 px increments, compact dashboards, and predictable grouping. Cards and panels should use moderate radii; avoid oversized rounded shapes in dense operational UI.

## Iconography

Icons should be outline-based, simple, and readable at 16-24 px. Use icons to clarify tools and statuses rather than decorate the page. The telemetry-node motif should remain unique to the brand mark and should not be scattered as background ornament.

## Theme Architecture

The Web app supports token definitions for `[data-theme="light"]` and `[data-theme="dark"]`. The application remains visually light by default. Future dark-mode activation should set `data-theme="dark"` on a root element without rewriting dashboard components.

## Localization

The intended Web localization foundation is:

```text
web/src/i18n/
  index.ts
  types.ts
  locales/
    en.ts
    uk.ts
```

Do not translate the whole existing application in this foundation step. New public and product-facing screens should use typed translation keys rather than hardcoded UI strings. Keep technical identifiers, API fields, and log-oriented values in English unless the UI context requires a localized label.

## Accessibility

Maintain WCAG-conscious contrast for text, controls, and status indicators. Do not rely on color alone: pair severity colors with readable labels such as `warning`, `critical`, `cleared`, or `resolved`. SVG marks must include accessible names when used as standalone images and should be hidden from assistive technology when paired with a visible wordmark.

## Do Not

- Do not copy or trace generated concept-board pixels.
- Do not embed raster logo images in production.
- Do not add claims such as AI-powered insights, fleet mapping, or cloud-native infrastructure unless the product actually implements them.
- Do not place tiny text or decorative micro-details inside the emblem.
- Do not change business workflows to accommodate branding.
