package specialistcompetency

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var (
	ErrInvalidSpecialistID   = errors.New("invalid specialist ID")
	ErrInvalidCompetencyCode = errors.New("invalid competency code")
	ErrInvalidSpecialistRole = errors.New("user is not a technical specialist")
)

type Service interface {
	List(ctx context.Context, specialistID string) ([]Competency, error)
	ListAll(ctx context.Context) ([]Competency, error)
	Replace(ctx context.Context, specialistID string, codes []string) ([]Competency, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) List(
	ctx context.Context,
	specialistID string,
) ([]Competency, error) {
	if !identifier.IsUUID(specialistID) {
		return nil, ErrInvalidSpecialistID
	}

	if err := s.ensureTechnicalSpecialist(ctx, specialistID); err != nil {
		return nil, err
	}

	return s.repository.ListBySpecialist(ctx, specialistID)
}

func (s *service) ListAll(ctx context.Context) ([]Competency, error) {
	return s.repository.ListAll(ctx)
}

func (s *service) Replace(
	ctx context.Context,
	specialistID string,
	codes []string,
) ([]Competency, error) {
	if !identifier.IsUUID(specialistID) {
		return nil, ErrInvalidSpecialistID
	}

	if err := s.ensureTechnicalSpecialist(ctx, specialistID); err != nil {
		return nil, err
	}

	competencies, err := NormalizeCompetencyCodes(codes)
	if err != nil {
		return nil, err
	}

	return s.repository.ReplaceForSpecialist(ctx, specialistID, competencies)
}

func (s *service) ensureTechnicalSpecialist(
	ctx context.Context,
	specialistID string,
) error {
	specialist, err := s.repository.GetSpecialistByID(ctx, specialistID)
	if err != nil {
		return err
	}
	if specialist.Role != auth.TechnicalSpecialistRoleCode {
		return ErrInvalidSpecialistRole
	}

	return nil
}

func NormalizeCompetencyCodes(codes []string) ([]SupportedCompetency, error) {
	seen := make(map[string]struct{}, len(codes))
	competencies := make([]SupportedCompetency, 0, len(codes))

	for _, code := range codes {
		normalizedCode := strings.TrimSpace(code)
		name, ok := competencyNameByCode(normalizedCode)
		if !ok {
			return nil, ErrInvalidCompetencyCode
		}
		if _, exists := seen[normalizedCode]; exists {
			continue
		}

		seen[normalizedCode] = struct{}{}
		competencies = append(competencies, SupportedCompetency{
			Code: normalizedCode,
			Name: name,
		})
	}

	return competencies, nil
}
