package ua.autonexis.mobile.ui.owner

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.R
import ua.autonexis.mobile.Vehicle
import ua.autonexis.mobile.ui.VehiclePresentation
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets

@Composable
internal fun OwnerRoot(
    state: OwnerUiState,
    onRefresh: () -> Unit,
    onVehicleSelected: (String) -> Unit,
    onConnectVehicle: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
    onLogout: () -> Unit,
    onBackToVehicles: () -> Unit,
    onActivationCodeChange: (String) -> Unit,
    onScanQr: () -> Unit,
    onClaimVehicle: () -> Unit,
) {
    when (state.destination) {
        OwnerDestination.VEHICLES -> OwnerVehiclesScreen(
            state = state,
            onRefresh = onRefresh,
            onVehicleSelected = onVehicleSelected,
            onConnectVehicle = onConnectVehicle,
            onRequests = onRequests,
            onNotifications = onNotifications,
            onAccount = onAccount,
            onLogout = onLogout,
        )
        OwnerDestination.CONNECT_VEHICLE -> ConnectVehicleScreen(
            state = state,
            onBackToVehicles = onBackToVehicles,
            onRequests = onRequests,
            onNotifications = onNotifications,
            onAccount = onAccount,
            onActivationCodeChange = onActivationCodeChange,
            onScanQr = onScanQr,
            onClaimVehicle = onClaimVehicle,
        )
    }
}

@Composable
private fun OwnerVehiclesScreen(
    state: OwnerUiState,
    onRefresh: () -> Unit,
    onVehicleSelected: (String) -> Unit,
    onConnectVehicle: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
    onLogout: () -> Unit,
) {
    Scaffold(
        topBar = {
            OwnerTopBar(
                title = stringResource(R.string.my_vehicles),
                subtitle = state.user?.email.orEmpty(),
                isBusy = state.isLoading || state.isRefreshing,
                onRefresh = onRefresh,
                onLogout = onLogout,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = OwnerNavigationTab.VEHICLES,
                notificationUnreadCount = state.notificationUnreadCount,
                onVehicles = {},
                onRequests = onRequests,
                onNotifications = onNotifications,
            onAccount = onAccount,
            )
        },
        floatingActionButton = {
            if (state.vehicles.isNotEmpty()) {
                val connectVehicleDescription = stringResource(R.string.connect_vehicle_cd)
                ExtendedFloatingActionButton(
                    onClick = onConnectVehicle,
                    containerColor = AutonexisColors.ElectricBlue,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.semantics { contentDescription = connectVehicleDescription },
                ) {
                    ConnectVehicleButtonContent()
                }
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.vehicles.isEmpty() -> BrandedLoadingState(
                    message = state.message ?: stringResource(R.string.loading_owner_dashboard),
                )
                state.isError && state.vehicles.isEmpty() -> FullErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_vehicles_message),
                    onRetry = onRefresh,
                    onLogout = onLogout,
                )
                else -> VehicleListContent(
                    state = state,
                    onVehicleSelected = onVehicleSelected,
                    onConnectVehicle = onConnectVehicle,
                )
            }
        }
    }
}

@Composable
private fun VehicleListContent(
    state: OwnerUiState,
    onVehicleSelected: (String) -> Unit,
    onConnectVehicle: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        item {
            OwnerSummaryCard(state)
        }
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_vehicles)) }
        }
        if (state.vehicles.isEmpty()) {
            item {
                EmptyVehiclesState(onConnectVehicle)
            }
        } else {
            items(state.vehicles, key = { it.id }) { vehicle ->
                VehicleCard(vehicle = vehicle, onClick = { onVehicleSelected(vehicle.id) })
            }
        }
    }
}

@Composable
private fun ConnectVehicleScreen(
    state: OwnerUiState,
    onBackToVehicles: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
    onActivationCodeChange: (String) -> Unit,
    onScanQr: () -> Unit,
    onClaimVehicle: () -> Unit,
) {
    BackHandler(onBack = onBackToVehicles)

    Scaffold(
        topBar = {
            OwnerTopBar(
                title = stringResource(R.string.connect_vehicle),
                subtitle = stringResource(R.string.connect_vehicle_subtitle),
                isBusy = state.isConnecting,
                onRefresh = null,
                onLogout = null,
                navigationLabel = stringResource(R.string.back),
                onNavigation = onBackToVehicles,
            )
        },
        bottomBar = {
            Column {
                Surface(shadowElevation = 8.dp) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(AutonexisSpacing.lg),
                        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
                    ) {
                        Button(
                            onClick = onClaimVehicle,
                            enabled = !state.isConnecting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                        ) {
                            Text(if (state.isConnecting) stringResource(R.string.connecting) else stringResource(R.string.connect_vehicle))
                        }
                    }
                }
                OwnerNavigationBar(
                    selected = OwnerNavigationTab.VEHICLES,
                    notificationUnreadCount = state.notificationUnreadCount,
                    onVehicles = onBackToVehicles,
                    onRequests = onRequests,
                    onNotifications = onNotifications,
                onAccount = onAccount,
                )
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.lg),
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            ) {
                Column(
                    modifier = Modifier.padding(AutonexisSpacing.lg),
                    verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
                ) {
                    Text(
                        text = stringResource(R.string.connect_vehicle_instructions),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = state.activationCode,
                        onValueChange = onActivationCodeChange,
                        enabled = !state.isConnecting,
                        label = { Text(stringResource(R.string.activation_code)) },
                        supportingText = { Text(stringResource(R.string.activation_code_format)) },
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            keyboardType = KeyboardType.Ascii,
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedButton(
                        onClick = onScanQr,
                        enabled = !state.isConnecting,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                    ) {
                        Text(stringResource(R.string.scan_qr_code))
                    }
                    if (state.isConnecting) {
                        InlineProgress(stringResource(R.string.connecting_vehicle))
                    }
                    if (!state.message.isNullOrBlank()) {
                        StateMessage(state.message, state.isError)
                    }
                }
            }
        }
    }
}

@Composable
private fun OwnerTopBar(
    title: String,
    subtitle: String,
    isBusy: Boolean,
    onRefresh: (() -> Unit)?,
    onLogout: (() -> Unit)?,
    navigationLabel: String? = null,
    onNavigation: (() -> Unit)? = null,
) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        ) {
            if (onNavigation != null && navigationLabel != null) {
                TextButton(onClick = onNavigation, enabled = !isBusy) { Text(navigationLabel) }
            } else {
                Image(
                    painter = painterResource(R.drawable.autonexis_emblem),
                    contentDescription = stringResource(R.string.brand_name),
                    modifier = Modifier.size(40.dp),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (subtitle.isNotBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            onRefresh?.let {
                TextButton(onClick = it, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
            }
            onLogout?.let {
                TextButton(onClick = it, enabled = !isBusy) { Text(stringResource(R.string.logout)) }
            }
        }
    }
}

@Composable
internal fun OwnerNavigationBar(
    selected: OwnerNavigationTab,
    notificationUnreadCount: Int,
    onVehicles: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
) {
    val itemColors = NavigationBarItemDefaults.colors(
        selectedIconColor = MaterialTheme.colorScheme.primary,
        selectedTextColor = MaterialTheme.colorScheme.onSurface,
        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars,
    ) {
        NavigationBarItem(
            selected = selected == OwnerNavigationTab.VEHICLES,
            onClick = onVehicles,
            icon = {
                Icon(
                    painter = painterResource(R.drawable.ic_owner_vehicle),
                    contentDescription = null,
                )
            },
            label = { Text(stringResource(R.string.nav_vehicles)) },
            colors = itemColors,
        )
        NavigationBarItem(
            selected = selected == OwnerNavigationTab.REQUESTS,
            onClick = onRequests,
            icon = {
                Icon(
                    painter = painterResource(R.drawable.ic_owner_requests),
                    contentDescription = null,
                )
            },
            label = { Text(stringResource(R.string.nav_requests)) },
            colors = itemColors,
        )
        NavigationBarItem(
            selected = selected == OwnerNavigationTab.NOTIFICATIONS,
            onClick = onNotifications,
            icon = {
                val badgeLabel = if (notificationUnreadCount > 99) "99+" else notificationUnreadCount.toString()
                val description = when {
                    notificationUnreadCount > 99 -> stringResource(R.string.notifications_unread_overflow_cd)
                    notificationUnreadCount > 0 -> pluralStringResource(
                        R.plurals.notifications_unread_count_cd,
                        notificationUnreadCount,
                        notificationUnreadCount,
                    )
                    else -> stringResource(R.string.notifications_cd)
                }
                Box(
                    modifier = Modifier.semantics { contentDescription = description },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_owner_notifications),
                        contentDescription = null,
                    )
                    if (notificationUnreadCount > 0) {
                        Text(
                            text = badgeLabel,
                            color = MaterialTheme.colorScheme.onError,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .background(AutonexisColors.CriticalRed, RoundedCornerShape(999.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp),
                        )
                    }
                }
            },
            label = {
                Text(
                    stringResource(R.string.nav_notifications),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            },
            colors = itemColors,
        )
        NavigationBarItem(
            selected = selected == OwnerNavigationTab.ACCOUNT,
            onClick = onAccount,
            icon = {
                Icon(
                    painter = painterResource(R.drawable.ic_owner_account),
                    contentDescription = null,
                )
            },
            label = { Text(stringResource(R.string.nav_account)) },
            colors = itemColors,
        )
    }
}

@Composable
private fun OwnerSummaryCard(state: OwnerUiState) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
        ) {
            Text(
                text = state.user?.fullName?.takeIf { it.isNotBlank() } ?: stringResource(R.string.vehicle_owner),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = stringResource(R.string.owner_summary),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun VehicleCard(vehicle: Vehicle, onClick: () -> Unit) {
    val openDetailsDescription = stringResource(R.string.open_vehicle_details_cd, vehicle.brand, vehicle.model)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = openDetailsDescription }
            .clickable(role = Role.Button, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        ) {
            Text(
                text = "${vehicle.brand} ${vehicle.model}".trim(),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            VehiclePresentation.metadata(vehicle.year, vehicle.licensePlate)?.let { details ->
                Text(
                    text = details,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Text(
                text = stringResource(R.string.open_vehicle_details),
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun EmptyVehiclesState(onConnectVehicle: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        ) {
            Text(
                text = stringResource(R.string.no_vehicles_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = stringResource(R.string.no_vehicles_message),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
            Button(
                onClick = onConnectVehicle,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AutonexisColors.ElectricBlue,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) {
                ConnectVehicleButtonContent()
            }
        }
    }
}


@Composable
private fun ConnectVehicleButtonContent() {
    Row(
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_owner_vehicle),
            contentDescription = null,
            modifier = Modifier.size(20.dp),
        )
        Text(stringResource(R.string.connect_vehicle))
    }
}
@Composable
private fun BrandedLoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.autonexis_emblem),
            contentDescription = stringResource(R.string.brand_name),
            modifier = Modifier.size(72.dp),
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FullErrorState(message: String, onRetry: () -> Unit, onLogout: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = stringResource(R.string.could_not_load_vehicles),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(
            text = message,
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onLogout) { Text(stringResource(R.string.logout)) }
    }
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
        style = MaterialTheme.typography.bodyMedium,
    )
}
