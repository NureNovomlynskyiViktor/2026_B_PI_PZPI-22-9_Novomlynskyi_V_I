import { useMessages } from '../../i18n';
import { navigatePublic } from '../../navigation/publicNavigation';
import { PublicFooter } from './PublicFooter';
import { PublicHeader } from './PublicHeader';

function CapabilityIcon({ index }: { index: number }) {
  const variant = index % 3;

  return (
    <svg className="capability-icon" viewBox="0 0 48 48" aria-hidden="true" focusable="false">
      {variant === 0 && (
        <>
          <path d="M9 29h7l4-12 7 20 5-14h7" />
          <circle cx="20" cy="17" r="3" />
          <circle cx="32" cy="23" r="3" />
        </>
      )}
      {variant === 1 && (
        <>
          <path d="M24 8 11 14v10c0 10 5 17 13 22 8-5 13-12 13-22V14L24 8Z" />
          <path d="M17 25h14" />
          <path d="M24 18v14" />
        </>
      )}
      {variant === 2 && (
        <>
          <circle cx="15" cy="15" r="4" />
          <circle cx="33" cy="16" r="4" />
          <circle cx="24" cy="34" r="4" />
          <path d="M19 17l10 13" />
          <path d="M29 18l-4 12" />
        </>
      )}
    </svg>
  );
}

export function LandingPage() {
  const t = useMessages().landing;
  const supportEmail = import.meta.env.VITE_SUPPORT_EMAIL?.trim();

  return (
    <div className="landing-page" id="top">
      <PublicHeader navigation={t.navigation} />
      <main>
        <section className="landing-hero" aria-labelledby="landing-hero-title">
          <div className="landing-hero-copy">
            <p className="landing-kicker">{t.hero.kicker}</p>
            <h1 id="landing-hero-title">{t.hero.heading}</h1>
            <p>{t.hero.supportingText}</p>
            <div className="landing-actions">
              <button className="primary-button" type="button" onClick={() => navigatePublic('/login')}>
                {t.hero.primaryAction}
              </button>
              <a className="secondary-button link-button" href="#connect">
                {t.hero.secondaryAction}
              </a>
            </div>
          </div>
          <aside className="product-preview-card" aria-label={t.preview.ariaLabel}>
            <div className="preview-card-header">
              <span>{t.preview.label}</span>
              <strong>{t.preview.vehicle}</strong>
            </div>
            <div className="preview-status-row">
              <span>{t.preview.deviceOnline}</span>
              <span className="status-pill normal">{t.preview.overallStatus}</span>
            </div>
            <div className="preview-metrics">
              {t.preview.metrics.map((metric) => (
                <div className="preview-metric" key={metric.label}>
                  <span>{metric.label}</span>
                  <strong>{metric.value}</strong>
                </div>
              ))}
            </div>
            <p>{t.preview.updated}</p>
          </aside>
        </section>

        <section className="landing-section" id="about" aria-labelledby="about-title">
          <div className="section-heading">
            <p className="landing-kicker">{t.about.kicker}</p>
            <h2 id="about-title">{t.about.heading}</h2>
            <p>{t.about.body}</p>
          </div>
          <div className="value-grid">
            {t.about.points.map((point) => (
              <article className="value-card" key={point.title}>
                <h3>{point.title}</h3>
                <p>{point.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="landing-section" id="capabilities" aria-labelledby="capabilities-title">
          <div className="section-heading">
            <p className="landing-kicker">{t.capabilities.kicker}</p>
            <h2 id="capabilities-title">{t.capabilities.heading}</h2>
          </div>
          <div className="capability-grid">
            {t.capabilities.items.map((item, index) => (
              <article className="capability-card" key={item.title}>
                <CapabilityIcon index={index} />
                <h3>{item.title}</h3>
                <p>{item.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="landing-section landing-flow" id="how-it-works" aria-labelledby="how-title">
          <div className="section-heading">
            <p className="landing-kicker">{t.workflow.kicker}</p>
            <h2 id="how-title">{t.workflow.heading}</h2>
          </div>
          <ol className="workflow-list">
            {t.workflow.steps.map((step, index) => (
              <li key={step.title}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="landing-section" aria-labelledby="roles-title">
          <div className="section-heading">
            <p className="landing-kicker">{t.roles.kicker}</p>
            <h2 id="roles-title">{t.roles.heading}</h2>
          </div>
          <div className="role-grid">
            {t.roles.items.map((role) => (
              <article className="role-card" key={role.title}>
                <h3>{role.title}</h3>
                <p>{role.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="landing-section connect-section" id="connect" aria-labelledby="connect-title">
          <div className="section-heading">
            <p className="landing-kicker">{t.connect.kicker}</p>
            <h2 id="connect-title">{t.connect.heading}</h2>
            <p>{t.connect.body}</p>
          </div>
          <div className="connect-grid">
            <ol className="connect-steps">
              {t.connect.steps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            <aside className="connect-card">
              <h3>{t.connect.contactHeading}</h3>
              <p>{supportEmail ? t.connect.contactConfigured : t.connect.contactFallback}</p>
              {supportEmail && (
                <a className="primary-button link-button" href={`mailto:${supportEmail}`}>
                  {t.connect.contactAction}
                </a>
              )}
              <h4>{t.connect.infoHeading}</h4>
              <ul>
                {t.connect.infoRequired.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </aside>
          </div>
        </section>
      </main>
      <PublicFooter footer={t.footer} navigation={t.navigation} supportEmail={supportEmail} />
    </div>
  );
}