package ua.autonexis.mobile.ui

import androidx.annotation.StringRes
import ua.autonexis.mobile.R
import java.util.Locale

object UiStringResources {
    @StringRes
    fun metricLabelRes(metric: String): Int? {
        return when (metric.trim().lowercase(Locale.US)) {
            "engine_temperature" -> R.string.metric_engine_temperature
            "battery_voltage" -> R.string.metric_battery_voltage
            "vibration_level" -> R.string.metric_vibration_level
            "rpm" -> R.string.metric_rpm
            "speed" -> R.string.metric_speed
            "fuel_level" -> R.string.metric_fuel_level
            else -> null
        }
    }

    @StringRes
    fun statusLabelRes(status: String): Int? {
        return when (status.trim().lowercase(Locale.US)) {
            "normal" -> R.string.status_normal
            "warning" -> R.string.status_warning
            "critical" -> R.string.status_critical
            "unknown" -> R.string.status_unknown
            "active" -> R.string.status_active
            "cleared" -> R.string.status_cleared
            "resolved" -> R.string.status_resolved
            "pending" -> R.string.status_pending
            "assigned" -> R.string.status_assigned
            "in_progress" -> R.string.status_in_progress
            "completed" -> R.string.status_completed
            "cancelled" -> R.string.status_cancelled
            else -> null
        }
    }

    @StringRes
    fun priorityLabelRes(priority: String): Int? {
        return when (priority.trim().lowercase(Locale.US)) {
            "low" -> R.string.priority_low
            "normal" -> R.string.priority_normal
            "high" -> R.string.priority_high
            else -> null
        }
    }

    @StringRes
    fun notificationTypeLabelRes(notificationType: String): Int? {
        return when (notificationType) {
            "vehicle_alert" -> R.string.notification_type_vehicle_alert
            "service_request_assigned" -> R.string.notification_type_service_request_assigned
            "service_request_started" -> R.string.notification_type_service_request_started
            "service_request_completed" -> R.string.notification_type_service_request_completed
            else -> null
        }
    }
}
