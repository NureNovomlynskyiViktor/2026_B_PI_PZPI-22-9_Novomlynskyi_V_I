import type { ReactNode } from 'react';
import type { Alert } from '../api/types';
import { useMessages } from '../i18n';
import { formatStructuredLabel, formatTimestamp } from '../utils/presentation';

type AlertIncidentPanelProps = {
  title: string;
  description: string;
  alerts: Alert[];
  emptyMessage: string;
  isLoading: boolean;
  isRefreshing?: boolean;
  actionLabel?: string;
  actingAlertID?: string | null;
  onAction?: (alertID: string) => void;
  clearedNote?: string;
  renderAction?: (alert: Alert) => ReactNode;
  renderExtra?: (alert: Alert) => ReactNode;
};

const knownAlertStatuses = new Set(['active', 'cleared', 'resolved']);

export function formatAlertParameter(parameter: string, labels?: Partial<Record<string, string>>) {
  return formatStructuredLabel(parameter, undefined, labels);
}

export function formatAlertTimestamp(timestamp: string | null, fallback = 'not recorded') {
  return formatTimestamp(timestamp, fallback);
}

function statusClass(status: string) {
  return knownAlertStatuses.has(status) ? status : 'unknown';
}

export function splitAlertsByLifecycle(alerts: Alert[]) {
  return {
    activeAlerts: alerts.filter((alert) => alert.status === 'active'),
    clearedAlerts: alerts.filter((alert) => alert.status === 'cleared'),
    resolvedAlerts: alerts.filter((alert) => alert.status === 'resolved'),
    otherAlerts: alerts.filter((alert) => !knownAlertStatuses.has(alert.status)),
  };
}

export function AlertIncidentPanel({
  title,
  description,
  alerts,
  emptyMessage,
  isLoading,
  isRefreshing = false,
  actionLabel,
  actingAlertID = null,
  onAction,
  clearedNote,
  renderAction,
  renderExtra,
}: AlertIncidentPanelProps) {
  const { common, specialist, structuredLabels } = useMessages();
  const incidentMessages = specialist.incidents;
  const resolvedClearedNote = clearedNote ?? incidentMessages.clearedNote;
  const label = (value: string | null) =>
    formatStructuredLabel(value, common.notAvailable, structuredLabels).toLowerCase();
  const timestamp = (value: string | null) => formatTimestamp(value, common.notAvailable);

  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>{title}</h2>
          <p className="muted">{description}</p>
        </div>
        {isRefreshing && <span className="badge">{common.refreshing}</span>}
      </div>

      {isLoading && alerts.length === 0 ? (
        <p className="info-box">{common.loadingIncidents}</p>
      ) : alerts.length === 0 ? (
        <p className="empty-state">{emptyMessage}</p>
      ) : (
        <div className="list-stack">
          {alerts.map((alert) => (
            <article className="alert-card" key={alert.id}>
              <div>
                <div className="alert-title-row">
                  <strong>{formatAlertParameter(alert.type, structuredLabels)}</strong>
                  <span className={`alert-status-pill ${statusClass(alert.status)}`}>
                    {label(alert.status)}
                  </span>
                  <span className={`status-pill ${alert.severity}`}>
                    {incidentMessages.max} {label(alert.severity)}
                  </span>
                  {alert.status === 'active' && (
                    <span
                      className={`status-pill ${
                        alert.current_severity ?? 'unknown'
                      }`}
                    >
                      {incidentMessages.current} {label(alert.current_severity)}
                    </span>
                  )}
                </div>

                <div className="alert-meta-grid">
                  <span>
                    {incidentMessages.occurrences}
                    <strong>{alert.occurrence_count}</strong>
                  </span>
                  <span>
                    {common.created}
                    <strong>{timestamp(alert.created_at)}</strong>
                  </span>
                  {alert.last_triggered_at && (
                    <span>
                      {incidentMessages.lastTriggered}
                      <strong>{timestamp(alert.last_triggered_at)}</strong>
                    </span>
                  )}
                  {alert.cleared_at && (
                    <span>
                      {structuredLabels.cleared}
                      <strong>{timestamp(alert.cleared_at)}</strong>
                    </span>
                  )}
                  {alert.resolved_at && (
                    <span>
                      {structuredLabels.resolved}
                      <strong>{timestamp(alert.resolved_at)}</strong>
                    </span>
                  )}
                </div>

                <p>{alert.message}</p>
                {alert.recommendation && <small>{alert.recommendation}</small>}

                {alert.recovery_streak > 0 && (
                  <div className="alert-stabilization">
                    {incidentMessages.stabilizationProgress.replace(
                      '{count}',
                      String(alert.recovery_streak),
                    )}
                  </div>
                )}

                {alert.status === 'cleared' && (
                  <div className="alert-cleared-note">
                    {resolvedClearedNote}
                  </div>
                )}

                {alert.status === 'resolved' && alert.resolved_by_user_id && (
                  <div className="alert-resolution-note">
                    {incidentMessages.resolvedBySpecialist}
                  </div>
                )}

                {alert.status === 'resolved' && alert.resolution_note && (
                  <div className="alert-resolution-note">
                    <strong>{incidentMessages.resolutionNoteLabel}</strong> {alert.resolution_note}
                  </div>
                )}

                {renderExtra?.(alert)}
              </div>

              {renderAction?.(alert)}

              {onAction && actionLabel && (
                <button
                  className="secondary-button"
                  disabled={actingAlertID === alert.id}
                  type="button"
                  onClick={() => onAction(alert.id)}
                >
                  {actingAlertID === alert.id ? incidentMessages.saving : actionLabel}
                </button>
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
