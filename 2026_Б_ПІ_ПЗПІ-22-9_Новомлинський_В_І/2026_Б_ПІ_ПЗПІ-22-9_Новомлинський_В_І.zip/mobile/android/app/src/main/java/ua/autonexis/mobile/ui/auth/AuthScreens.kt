package ua.autonexis.mobile.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.R
import ua.autonexis.mobile.User
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing

@Composable
internal fun AuthRoot(
    state: AuthUiState,
    googleConfigured: Boolean,
    onLogin: (baseUrl: String, email: String, password: String) -> Unit,
    onGoogleSignIn: (baseUrl: String) -> Unit,
    onShowRegister: (baseUrl: String) -> Unit,
    onRegister: (
        baseUrl: String,
        fullName: String,
        email: String,
        password: String,
        confirmPassword: String,
    ) -> Unit,
    onShowLogin: (baseUrl: String) -> Unit,
    onDismissStatusMessage: () -> Unit,
    onLogout: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        when (state.screen) {
            AuthScreenMode.LOADING -> LoadingSessionScreen(state.statusMessage ?: stringResource(R.string.restore_session))
            AuthScreenMode.LOGIN -> LoginScreen(
                state = state,
                googleConfigured = googleConfigured,
                onLogin = onLogin,
                onGoogleSignIn = onGoogleSignIn,
                onShowRegister = onShowRegister,
                onDismissStatusMessage = onDismissStatusMessage,
            )
            AuthScreenMode.REGISTER -> RegisterScreen(
                state = state,
                onRegister = onRegister,
                onShowLogin = onShowLogin,
                onDismissStatusMessage = onDismissStatusMessage,
            )
            AuthScreenMode.UNSUPPORTED_ROLE -> UnsupportedRoleScreen(
                user = state.unsupportedUser,
                onLogout = onLogout,
            )
        }
    }
}

@Composable
private fun LoginScreen(
    state: AuthUiState,
    googleConfigured: Boolean,
    onLogin: (baseUrl: String, email: String, password: String) -> Unit,
    onGoogleSignIn: (baseUrl: String) -> Unit,
    onShowRegister: (baseUrl: String) -> Unit,
    onDismissStatusMessage: () -> Unit,
) {
    var baseUrl by rememberSaveable { mutableStateOf(state.initialBaseUrl) }
    var email by rememberSaveable { mutableStateOf("owner@example.com") }
    var password by rememberSaveable { mutableStateOf("DemoPass123!") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    AuthScreenFrame {
        BrandHeader(subtitle = stringResource(R.string.auth_subtitle))
        Text(
            text = stringResource(R.string.auth_headline),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )

        if (googleConfigured) {
            Button(
                enabled = !state.isAuthInFlight,
                modifier = Modifier.fillMaxWidth(),
                onClick = { onGoogleSignIn(baseUrl.trim()) },
            ) {
                Text(stringResource(R.string.continue_with_google))
            }
            Text(
                text = stringResource(R.string.google_role_note),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
            DividerWithText(stringResource(R.string.email_divider))
        } else {
            SupportMessage(stringResource(R.string.google_not_configured))
        }

        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = baseUrl,
            onValueChange = { baseUrl = it },
            label = { Text(stringResource(R.string.backend_url)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = email,
            onValueChange = { email = it },
            label = { Text(stringResource(R.string.email)) },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Next,
            ),
        )
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = password,
            onValueChange = { password = it },
            label = { Text(stringResource(R.string.password)) },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                TextButton(onClick = { passwordVisible = !passwordVisible }) {
                    Text(if (passwordVisible) stringResource(R.string.hide) else stringResource(R.string.show))
                }
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(
                onDone = { onLogin(baseUrl.trim(), email.trim(), password) },
            ),
        )
        Button(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onLogin(baseUrl.trim(), email.trim(), password) },
        ) {
            Text(if (state.isAuthInFlight) stringResource(R.string.please_wait) else stringResource(R.string.login))
        }
        TextButton(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onShowRegister(baseUrl.trim()) },
        ) {
            Text(stringResource(R.string.create_account))
        }
        StatusArea(state, onDismissStatusMessage)
    }
}

@Composable
private fun RegisterScreen(
    state: AuthUiState,
    onRegister: (
        baseUrl: String,
        fullName: String,
        email: String,
        password: String,
        confirmPassword: String,
    ) -> Unit,
    onShowLogin: (baseUrl: String) -> Unit,
    onDismissStatusMessage: () -> Unit,
) {
    var baseUrl by rememberSaveable { mutableStateOf(state.initialBaseUrl) }
    var fullName by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirmPassword by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var confirmPasswordVisible by rememberSaveable { mutableStateOf(false) }

    AuthScreenFrame {
        BrandHeader(subtitle = stringResource(R.string.auth_register_subtitle))
        Text(
            text = stringResource(R.string.auth_register_headline),
            style = MaterialTheme.typography.headlineMedium,
        )
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = baseUrl,
            onValueChange = { baseUrl = it },
            label = { Text(stringResource(R.string.backend_url)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text(stringResource(R.string.full_name)) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
        )
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = email,
            onValueChange = { email = it },
            label = { Text(stringResource(R.string.email)) },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Next,
            ),
        )
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = password,
            onValueChange = { password = it },
            label = { Text(stringResource(R.string.password)) },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                TextButton(onClick = { passwordVisible = !passwordVisible }) {
                    Text(if (passwordVisible) stringResource(R.string.hide) else stringResource(R.string.show))
                }
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Next,
            ),
        )
        PasswordRequirements(password)
        OutlinedTextField(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text(stringResource(R.string.confirm_password)) },
            visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                TextButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                    Text(if (confirmPasswordVisible) stringResource(R.string.hide) else stringResource(R.string.show))
                }
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    onRegister(
                        baseUrl.trim(),
                        fullName.trim(),
                        email.trim(),
                        password,
                        confirmPassword,
                    )
                },
            ),
        )
        Button(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                onRegister(
                    baseUrl.trim(),
                    fullName.trim(),
                    email.trim(),
                    password,
                    confirmPassword,
                )
            },
        ) {
            Text(if (state.isAuthInFlight) stringResource(R.string.creating) else stringResource(R.string.register))
        }
        TextButton(
            enabled = !state.isAuthInFlight,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onShowLogin(baseUrl.trim()) },
        ) {
            Text(stringResource(R.string.back_to_login))
        }
        StatusArea(state, onDismissStatusMessage)
    }
}

@Composable
private fun LoadingSessionScreen(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.lg),
                modifier = Modifier.padding(AutonexisSpacing.xl),
            ) {
                BrandHeader(subtitle = stringResource(R.string.auth_subtitle))
                CircularProgressIndicator()
                Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun UnsupportedRoleScreen(user: User?, onLogout: () -> Unit) {
    AuthScreenFrame {
        BrandHeader(subtitle = stringResource(R.string.unsupported_auth_success))
        Text(
            text = stringResource(R.string.unsupported_title),
            style = MaterialTheme.typography.headlineMedium,
        )
        Text(stringResource(R.string.unsupported_signed_in_as, user?.email ?: stringResource(R.string.unknown_user)))
        Text(stringResource(R.string.unsupported_role, user?.role ?: stringResource(R.string.unknown)))
        SupportMessage(stringResource(R.string.unsupported_staff_hint))
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = onLogout,
        ) {
            Text(stringResource(R.string.logout))
        }
    }
}

@Composable
private fun AuthScreenFrame(content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(AutonexisSpacing.lg),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(AutonexisSpacing.xl),
                verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
                content = content,
            )
        }
    }
}

@Composable
private fun BrandHeader(subtitle: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Image(
            painter = painterResource(R.drawable.autonexis_emblem),
            contentDescription = stringResource(R.string.brand_emblem_cd),
            modifier = Modifier.size(54.dp),
        )
        Column {
            Text(
                text = stringResource(R.string.brand_name),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun DividerWithText(label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        modifier = Modifier.fillMaxWidth(),
    ) {
        HorizontalDivider(modifier = Modifier.weight(1f))
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
        HorizontalDivider(modifier = Modifier.weight(1f))
    }
}

@Composable
private fun PasswordRequirements(password: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(
            text = stringResource(R.string.password_requirements),
            style = MaterialTheme.typography.labelLarge,
        )
        passwordRequirements(password).forEach { requirement ->
            Text(
                text = stringResource(if (requirement.isSatisfied) R.string.password_requirement_met else R.string.password_requirement_required, stringResource(requirement.labelRes)),
                color = if (requirement.isSatisfied) {
                    AutonexisColors.EmeraldGreen
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun StatusArea(state: AuthUiState, onDismissStatusMessage: () -> Unit) {
    state.errorMessage?.let { ErrorMessage(it) }
    state.statusMessage?.let {
        SupportMessage(
            message = it,
            actionLabel = stringResource(R.string.dismiss),
            onAction = onDismissStatusMessage,
        )
    }
}

@Composable
private fun ErrorMessage(message: String) {
    Text(
        text = message,
        color = MaterialTheme.colorScheme.error,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
    )
}

@Composable
private fun SupportMessage(
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(
            text = message,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth(),
        )
        if (actionLabel != null && onAction != null) {
            TextButton(
                modifier = Modifier.align(Alignment.End),
                onClick = onAction,
            ) {
                Text(actionLabel)
            }
        }
    }
}
