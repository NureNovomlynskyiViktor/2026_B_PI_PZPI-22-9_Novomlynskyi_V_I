package adminaudit

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
)

type Repository interface {
	List(ctx context.Context, filters ListFilters) ([]Log, int, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) List(ctx context.Context, filters ListFilters) ([]Log, int, error) {
	where, args := auditLogWhere(filters)
	joins := `
		FROM audit_logs
		LEFT JOIN users ON users.id = audit_logs.user_id
		LEFT JOIN roles ON roles.id = users.role_id
	`
	countQuery := "SELECT COUNT(*)" + joins + where

	var total int
	if err := r.db.QueryRowContext(ctx, countQuery, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count audit logs: %w", err)
	}

	query := `
		SELECT
			audit_logs.id,
			audit_logs.user_id,
			users.email,
			users.full_name,
			roles.code,
			audit_logs.action,
			audit_logs.entity_type,
			audit_logs.entity_id,
			COALESCE(audit_logs.metadata, '{}'::jsonb),
			audit_logs.created_at
	` + joins + where + `
		ORDER BY audit_logs.created_at DESC, audit_logs.id DESC
		LIMIT $` + fmt.Sprint(len(args)+1) + `
		OFFSET $` + fmt.Sprint(len(args)+2)

	args = append(args, filters.Limit, filters.Offset)

	rows, err := r.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query audit logs: %w", err)
	}
	defer rows.Close()

	items := make([]Log, 0)
	for rows.Next() {
		item, err := scanLog(rows)
		if err != nil {
			return nil, 0, fmt.Errorf("scan audit log: %w", err)
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate audit logs: %w", err)
	}

	return items, total, nil
}

func auditLogWhere(filters ListFilters) (string, []any) {
	clauses := make([]string, 0, 7)
	args := make([]any, 0, 7)

	addClause := func(clause string, value any) {
		args = append(args, value)
		clauses = append(clauses, fmt.Sprintf(clause, len(args)))
	}

	if filters.Action != "" {
		addClause("audit_logs.action = $%d", filters.Action)
	}
	if filters.ActorID != "" {
		addClause("audit_logs.user_id = $%d", filters.ActorID)
	}
	if filters.ActorSearch != "" {
		args = append(args, "%"+strings.ToLower(filters.ActorSearch)+"%")
		clauses = append(
			clauses,
			fmt.Sprintf(
				"(lower(users.email) LIKE $%d OR lower(users.full_name) LIKE $%d)",
				len(args),
				len(args),
			),
		)
	}
	if filters.EntityType != "" {
		addClause("audit_logs.entity_type = $%d", filters.EntityType)
	}
	if filters.EntityID != "" {
		addClause("audit_logs.entity_id = $%d", filters.EntityID)
	}
	if filters.DateFrom != nil {
		addClause("audit_logs.created_at >= $%d", *filters.DateFrom)
	}
	if filters.DateTo != nil {
		addClause("audit_logs.created_at <= $%d", *filters.DateTo)
	}
	if len(clauses) == 0 {
		return "", args
	}

	return " WHERE " + strings.Join(clauses, " AND "), args
}

type scanner interface {
	Scan(dest ...any) error
}

func scanLog(row scanner) (Log, error) {
	var (
		item          Log
		actorID       sql.NullString
		actorEmail    sql.NullString
		actorFullName sql.NullString
		actorRole     sql.NullString
		entityID      sql.NullString
		metadata      []byte
	)

	if err := row.Scan(
		&item.ID,
		&actorID,
		&actorEmail,
		&actorFullName,
		&actorRole,
		&item.Action,
		&item.EntityType,
		&entityID,
		&metadata,
		&item.CreatedAt,
	); err != nil {
		return Log{}, err
	}

	if actorID.Valid {
		item.Actor = &Actor{
			ID:       actorID.String,
			Email:    actorEmail.String,
			FullName: actorFullName.String,
			Role:     actorRole.String,
		}
	}
	if entityID.Valid {
		item.EntityID = &entityID.String
	}
	item.Metadata = map[string]any{}
	if len(metadata) > 0 {
		if err := json.Unmarshal(metadata, &item.Metadata); err != nil {
			return Log{}, fmt.Errorf("decode audit log metadata: %w", err)
		}
	}

	return item, nil
}
