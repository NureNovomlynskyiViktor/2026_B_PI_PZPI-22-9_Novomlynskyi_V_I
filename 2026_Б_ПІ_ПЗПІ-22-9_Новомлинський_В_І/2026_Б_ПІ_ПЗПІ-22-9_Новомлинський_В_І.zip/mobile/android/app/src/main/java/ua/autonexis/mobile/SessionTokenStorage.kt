package ua.autonexis.mobile

import android.content.SharedPreferences
import android.util.Base64

internal data class StoredTokenEnvelope(
    val ciphertext: String?,
    val iv: String?,
    val formatVersion: Int?,
)

internal interface SessionTokenPreferences {
    fun readSecureEnvelope(): StoredTokenEnvelope
    fun writeSecureEnvelope(envelope: StoredTokenEnvelope): Boolean
    fun clearSecureEnvelope(): Boolean
    fun readLegacyPlaintextToken(): String?
    fun clearLegacyPlaintextToken(): Boolean
}

internal interface TokenEnvelopeCodec {
    fun encode(bytes: ByteArray): String
    fun decode(encoded: String): ByteArray
}

internal object AndroidBase64TokenEnvelopeCodec : TokenEnvelopeCodec {
    override fun encode(bytes: ByteArray): String =
        Base64.encodeToString(bytes, Base64.NO_WRAP)

    override fun decode(encoded: String): ByteArray =
        Base64.decode(encoded, Base64.NO_WRAP)
}

internal class SharedPreferencesSessionTokenPreferences(
    private val legacyPreferences: SharedPreferences,
    private val securePreferences: SharedPreferences,
) : SessionTokenPreferences {
    override fun readSecureEnvelope(): StoredTokenEnvelope = StoredTokenEnvelope(
        ciphertext = securePreferences.getString(KEY_CIPHERTEXT, null),
        iv = securePreferences.getString(KEY_IV, null),
        formatVersion = if (securePreferences.contains(KEY_FORMAT_VERSION)) {
            securePreferences.getInt(KEY_FORMAT_VERSION, 0)
        } else {
            null
        },
    )

    override fun writeSecureEnvelope(envelope: StoredTokenEnvelope): Boolean {
        val ciphertext = envelope.ciphertext ?: return false
        val iv = envelope.iv ?: return false
        val formatVersion = envelope.formatVersion ?: return false

        return securePreferences.edit()
            .putString(KEY_CIPHERTEXT, ciphertext)
            .putString(KEY_IV, iv)
            .putInt(KEY_FORMAT_VERSION, formatVersion)
            .commit()
    }

    override fun clearSecureEnvelope(): Boolean = securePreferences.edit()
        .remove(KEY_CIPHERTEXT)
        .remove(KEY_IV)
        .remove(KEY_FORMAT_VERSION)
        .commit()

    override fun readLegacyPlaintextToken(): String? = legacyPreferences.getString(KEY_LEGACY_TOKEN, null)

    override fun clearLegacyPlaintextToken(): Boolean = legacyPreferences.edit()
        .remove(KEY_LEGACY_TOKEN)
        .commit()

    companion object {
        const val SECURE_PREFERENCES_NAME = "autonexis_secure_session"
        private const val KEY_CIPHERTEXT = "token_ciphertext"
        private const val KEY_IV = "token_iv"
        private const val KEY_FORMAT_VERSION = "token_format_version"
        private const val KEY_LEGACY_TOKEN = "access_token"
    }
}

internal class SecureSessionTokenStore(
    private val preferences: SessionTokenPreferences,
    private val cipher: SessionTokenCipherContract,
    private val codec: TokenEnvelopeCodec = AndroidBase64TokenEnvelopeCodec,
) {
    var token: String?
        get() = readEncryptedToken() ?: migrateLegacyPlaintextToken()
        set(value) {
            if (value == null) {
                clearToken()
                return
            }

            val trimmedToken = value.trim()
            if (trimmedToken.isEmpty()) {
                clearToken()
                return
            }

            if (!persistEncryptedToken(trimmedToken)) {
                clearAllTokenState()
                return
            }

            preferences.clearLegacyPlaintextToken()
        }

    fun clearToken() {
        clearAllTokenState()
    }

    private fun readEncryptedToken(): String? {
        val envelope = preferences.readSecureEnvelope()
        if (envelope.ciphertext == null && envelope.iv == null && envelope.formatVersion == null) {
            return null
        }

        if (!isCompleteSupportedEnvelope(envelope)) {
            clearAllTokenState()
            return null
        }

        return try {
            val ciphertext = codec.decode(envelope.ciphertext.orEmpty())
            val iv = codec.decode(envelope.iv.orEmpty())
            val decryptedToken = cipher.decrypt(ciphertext, iv).trim()
            if (decryptedToken.isEmpty()) {
                clearAllTokenState()
                null
            } else {
                decryptedToken
            }
        } catch (_: Exception) {
            clearAllTokenState()
            null
        }
    }

    private fun migrateLegacyPlaintextToken(): String? {
        val legacyToken = preferences.readLegacyPlaintextToken()?.trim()
        if (legacyToken.isNullOrEmpty()) {
            preferences.clearLegacyPlaintextToken()
            return null
        }

        return try {
            if (persistEncryptedToken(legacyToken)) {
                preferences.clearLegacyPlaintextToken()
                legacyToken
            } else {
                clearAllTokenState()
                null
            }
        } catch (_: Exception) {
            clearAllTokenState()
            null
        }
    }

    private fun persistEncryptedToken(plaintextToken: String): Boolean {
        return try {
            val encrypted = cipher.encrypt(plaintextToken)
            val envelope = StoredTokenEnvelope(
                ciphertext = codec.encode(encrypted.ciphertext),
                iv = codec.encode(encrypted.iv),
                formatVersion = FORMAT_VERSION,
            )
            preferences.writeSecureEnvelope(envelope)
        } catch (_: Exception) {
            false
        }
    }

    private fun isCompleteSupportedEnvelope(envelope: StoredTokenEnvelope): Boolean =
        !envelope.ciphertext.isNullOrBlank() &&
            !envelope.iv.isNullOrBlank() &&
            envelope.formatVersion == FORMAT_VERSION

    private fun clearAllTokenState() {
        preferences.clearSecureEnvelope()
        preferences.clearLegacyPlaintextToken()
    }

    companion object {
        private const val FORMAT_VERSION = 1
    }
}

