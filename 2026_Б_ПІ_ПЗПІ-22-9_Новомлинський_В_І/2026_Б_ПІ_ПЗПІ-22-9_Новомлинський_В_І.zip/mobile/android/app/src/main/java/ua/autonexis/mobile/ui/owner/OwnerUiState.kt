package ua.autonexis.mobile.ui.owner

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.User
import ua.autonexis.mobile.Vehicle

internal enum class OwnerDestination {
    VEHICLES,
    CONNECT_VEHICLE,
}

internal enum class OwnerNavigationTab {
    VEHICLES,
    REQUESTS,
    NOTIFICATIONS,
    ACCOUNT,
}

internal data class OwnerUiState(
    val user: User? = null,
    val vehicles: List<Vehicle> = emptyList(),
    val destination: OwnerDestination = OwnerDestination.VEHICLES,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val isConnecting: Boolean = false,
    val activationCode: String = "",
    val message: String? = null,
    val isError: Boolean = false,
    val notificationUnreadCount: Int = 0,
)

internal class OwnerViewModel {
    var uiState by mutableStateOf(OwnerUiState())
        private set

    fun showInitialLoading(message: String = "Loading owner dashboard...") {
        uiState = OwnerUiState(
            user = uiState.user,
            vehicles = emptyList(),
            destination = OwnerDestination.VEHICLES,
            isLoading = true,
            message = message,
            notificationUnreadCount = uiState.notificationUnreadCount,
        )
    }

    fun showVehicles(
        user: User,
        vehicles: List<Vehicle>,
        message: String? = null,
        isError: Boolean = false,
        notificationUnreadCount: Int = uiState.notificationUnreadCount,
    ) {
        uiState = uiState.copy(
            user = user,
            vehicles = vehicles,
            destination = OwnerDestination.VEHICLES,
            isLoading = false,
            isRefreshing = false,
            isConnecting = false,
            message = message,
            isError = isError,
            notificationUnreadCount = notificationUnreadCount,
        )
    }

    fun showConnectVehicle(
        message: String? = null,
        activationCode: String = uiState.activationCode,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            destination = OwnerDestination.CONNECT_VEHICLE,
            isLoading = false,
            isRefreshing = false,
            isConnecting = false,
            activationCode = activationCode,
            message = message,
            isError = isError,
        )
    }

    fun updateActivationCode(value: String) {
        uiState = uiState.copy(
            activationCode = value.uppercase(),
            message = null,
            isError = false,
        )
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isConnecting) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing vehicles...",
            isError = false,
        )
        return true
    }

    fun finishRefresh(user: User, vehicles: List<Vehicle>, message: String? = null) {
        showVehicles(
            user = user,
            vehicles = vehicles,
            message = message,
            isError = false,
            notificationUnreadCount = uiState.notificationUnreadCount,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isRefreshing = false,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun startConnect(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isConnecting) {
            return false
        }
        uiState = uiState.copy(
            isConnecting = true,
            message = "Connecting vehicle...",
            isError = false,
        )
        return true
    }

    fun failConnect(message: String) {
        uiState = uiState.copy(
            isConnecting = false,
            message = message,
            isError = true,
        )
    }

    fun finishConnect(user: User, vehicles: List<Vehicle>, message: String = "Vehicle connected.") {
        uiState = uiState.copy(
            user = user,
            vehicles = vehicles,
            destination = OwnerDestination.VEHICLES,
            isLoading = false,
            isRefreshing = false,
            isConnecting = false,
            activationCode = "",
            message = message,
            isError = false,
        )
    }

    fun applyScannedCode(code: String, message: String) {
        uiState = uiState.copy(
            destination = OwnerDestination.CONNECT_VEHICLE,
            activationCode = code,
            isConnecting = false,
            message = message,
            isError = false,
        )
    }

    fun applyQrMessage(message: String, isError: Boolean) {
        uiState = uiState.copy(
            destination = OwnerDestination.CONNECT_VEHICLE,
            isConnecting = false,
            message = message,
            isError = isError,
        )
    }

    fun updateNotificationUnreadCount(count: Int) {
        uiState = uiState.copy(notificationUnreadCount = count)
    }

    fun clearAuthenticatedState() {
        uiState = OwnerUiState()
    }

    fun canLogout(): Boolean = !uiState.isConnecting
}
