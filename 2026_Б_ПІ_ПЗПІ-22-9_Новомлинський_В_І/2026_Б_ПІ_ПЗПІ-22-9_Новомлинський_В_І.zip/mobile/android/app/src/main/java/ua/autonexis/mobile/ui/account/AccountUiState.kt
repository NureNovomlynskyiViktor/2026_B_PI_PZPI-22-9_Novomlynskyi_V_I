package ua.autonexis.mobile.ui.account

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.AuthMethods
import ua.autonexis.mobile.User

internal data class AccountUiState(
    val user: User? = null,
    val methods: AuthMethods? = null,
    val googleConfigured: Boolean = false,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val isLinkingGoogle: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
    val googleLinkMessage: String? = null,
    val googleLinkIsError: Boolean = false,
)

internal class AccountViewModel {
    var uiState by mutableStateOf(AccountUiState())
        private set

    fun showInitialLoading(user: User?, googleConfigured: Boolean) {
        uiState = AccountUiState(
            user = user,
            googleConfigured = googleConfigured,
            isLoading = true,
            message = "Loading account...",
        )
    }

    fun showAccount(
        user: User?,
        methods: AuthMethods,
        googleConfigured: Boolean = uiState.googleConfigured,
        message: String? = null,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            user = user,
            methods = methods,
            googleConfigured = googleConfigured,
            isLoading = false,
            isRefreshing = false,
            isLinkingGoogle = false,
            message = message,
            isError = isError,
        )
    }

    fun failInitialLoad(user: User?, googleConfigured: Boolean, message: String) {
        uiState = AccountUiState(
            user = user,
            googleConfigured = googleConfigured,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isLinkingGoogle) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing account...",
            isError = false,
            googleLinkMessage = null,
            googleLinkIsError = false,
        )
        return true
    }

    fun finishRefresh(methods: AuthMethods, message: String? = null) {
        uiState = uiState.copy(
            methods = methods,
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = false,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = true,
        )
    }

    fun startGoogleLink(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isLinkingGoogle) {
            return false
        }
        if (!uiState.googleConfigured || uiState.methods?.googleLinked == true) {
            return false
        }
        uiState = uiState.copy(
            isLinkingGoogle = true,
            message = null,
            isError = false,
            googleLinkMessage = "Opening Google sign-in...",
            googleLinkIsError = false,
        )
        return true
    }

    fun finishGoogleLink(methods: AuthMethods) {
        uiState = uiState.copy(
            methods = methods,
            isLinkingGoogle = false,
            message = null,
            isError = false,
            googleLinkMessage = "Google account connected.",
            googleLinkIsError = false,
        )
    }

    fun failGoogleLink(message: String) {
        uiState = uiState.copy(
            isLinkingGoogle = false,
            message = null,
            isError = false,
            googleLinkMessage = message,
            googleLinkIsError = true,
        )
    }
}