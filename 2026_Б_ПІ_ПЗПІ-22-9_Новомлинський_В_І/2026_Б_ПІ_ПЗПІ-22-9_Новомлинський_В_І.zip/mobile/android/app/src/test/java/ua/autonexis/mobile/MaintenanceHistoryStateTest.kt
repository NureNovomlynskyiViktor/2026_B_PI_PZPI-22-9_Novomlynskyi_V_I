package ua.autonexis.mobile

import java.time.Year
import java.time.ZoneOffset
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.maintenance.MaintenanceHistoryPresentation
import ua.autonexis.mobile.ui.maintenance.MaintenanceHistoryViewModel

class MaintenanceHistoryStateTest {
    @Test
    fun initialLoadingSuccessAndErrorStatesAreExplicit() {
        val viewModel = MaintenanceHistoryViewModel()

        viewModel.showInitialLoading("vehicle-1", "Toyota Corolla")
        assertTrue(viewModel.uiState.isLoading)
        assertEquals("vehicle-1", viewModel.uiState.vehicleId)
        assertEquals("Toyota Corolla", viewModel.uiState.vehicleLabel)
        assertEquals("Loading maintenance history...", viewModel.uiState.message)

        viewModel.showMaintenance(records = listOf(record(id = "a", serviceDate = "2026-06-18")))
        assertFalse(viewModel.uiState.isLoading)
        assertFalse(viewModel.uiState.isError)
        assertEquals(1, viewModel.uiState.records.size)

        viewModel.failInitialLoad("vehicle-2", "Honda Civic", "Could not load maintenance.")
        assertFalse(viewModel.uiState.isLoading)
        assertTrue(viewModel.uiState.isError)
        assertEquals("vehicle-2", viewModel.uiState.vehicleId)
        assertEquals("Honda Civic", viewModel.uiState.vehicleLabel)
        assertTrue(viewModel.uiState.records.isEmpty())
    }

    @Test
    fun maintenanceRecordsAreSortedNewestFirstWithStableFallbacks() {
        val ordered = MaintenanceHistoryPresentation.newestFirst(
            listOf(
                record(id = "a", serviceDate = "bad-date", createdAt = "2026-06-18T09:00:00Z"),
                record(id = "b", serviceDate = "2026-05-10", createdAt = "2026-06-18T12:00:00Z"),
                record(id = "c", serviceDate = "2026-05-10", createdAt = "2026-06-18T13:00:00Z"),
                record(id = "d", serviceDate = "2026-06-10", createdAt = "2026-01-01T00:00:00Z"),
                record(id = "e", serviceDate = "bad-date", createdAt = "2026-06-18T10:00:00Z"),
            ),
        )

        assertEquals(listOf("d", "c", "b", "e", "a"), ordered.map { it.id })
    }

    @Test
    fun summaryUsesLoadedRecordsOnly() {
        val currentYear = Year.now(ZoneOffset.UTC).value
        val summary = MaintenanceHistoryPresentation.summary(
            listOf(
                record(id = "a", title = "Oil change", serviceDate = "${currentYear - 1}-12-20"),
                record(id = "b", title = "Brake inspection", serviceDate = "$currentYear-01-15"),
                record(id = "c", title = "Battery check", serviceDate = "$currentYear-05-10"),
            ),
        )

        assertNotNull(summary)
        assertEquals(3, summary.totalRecords)
        assertEquals("$currentYear-05-10", summary.latestServiceDate)
        assertEquals("Battery check", summary.latestServiceTitle)
        assertEquals(2, summary.currentYearCount)
    }

    @Test
    fun currentYearCountIsAbsentWhenDatesCannotBeParsed() {
        val summary = MaintenanceHistoryPresentation.summary(
            listOf(record(id = "a", serviceDate = "not-a-date")),
        )

        assertNotNull(summary)
        assertNull(summary.currentYearCount)
        assertEquals("not-a-date", summary.latestServiceDate)
    }

    @Test
    fun malformedDatesStayVisibleInTimeline() {
        val sections = MaintenanceHistoryPresentation.timelineSections(
            listOf(
                record(id = "a", serviceDate = "2026-06-18"),
                record(id = "b", serviceDate = "malformed"),
            ),
        )

        assertEquals(listOf("2026", MaintenanceHistoryPresentation.DATE_UNKNOWN), sections.map { it.label })
        assertEquals(listOf("a"), sections.first { it.label == "2026" }.records.map { it.id })
        assertEquals(listOf("b"), sections.first { it.label == MaintenanceHistoryPresentation.DATE_UNKNOWN }.records.map { it.id })
    }

    @Test
    fun refreshLocksWhileInProgress() {
        val viewModel = MaintenanceHistoryViewModel()
        viewModel.showMaintenance(
            vehicleId = "vehicle-1",
            vehicleLabel = "Toyota Corolla",
            records = listOf(record()),
        )

        assertTrue(viewModel.startRefresh())
        assertFalse(viewModel.startRefresh())
        assertTrue(viewModel.uiState.isRefreshing)
    }

    @Test
    fun refreshSuccessReplacesRecordsAndSortsThem() {
        val viewModel = MaintenanceHistoryViewModel()
        viewModel.showMaintenance(records = listOf(record(id = "old", serviceDate = "2026-05-01")))

        assertTrue(viewModel.startRefresh())
        viewModel.finishRefresh(
            listOf(
                record(id = "a", serviceDate = "2026-06-01"),
                record(id = "b", serviceDate = "2026-07-01"),
            ),
        )

        assertFalse(viewModel.uiState.isRefreshing)
        assertEquals(listOf("b", "a"), viewModel.uiState.records.map { it.id })
    }

    @Test
    fun refreshFailurePreservesExistingRecords() {
        val viewModel = MaintenanceHistoryViewModel()
        val existing = record(id = "existing", serviceDate = "2026-06-18")
        viewModel.showMaintenance(records = listOf(existing))

        assertTrue(viewModel.startRefresh())
        viewModel.failRefresh("Network unavailable.")

        assertFalse(viewModel.uiState.isRefreshing)
        assertTrue(viewModel.uiState.isError)
        assertEquals("Network unavailable.", viewModel.uiState.message)
        assertEquals(listOf(existing), viewModel.uiState.records)
    }

    @Test
    fun emptyRecordsAreRepresentedAsSuccessfulEmptyState() {
        val viewModel = MaintenanceHistoryViewModel()

        viewModel.showMaintenance(vehicleId = "vehicle-1", vehicleLabel = "Toyota Corolla", records = emptyList())

        assertFalse(viewModel.uiState.isLoading)
        assertFalse(viewModel.uiState.isError)
        assertTrue(viewModel.uiState.records.isEmpty())
        assertNull(MaintenanceHistoryPresentation.summary(emptyList()))
    }

    @Test
    fun stateRecoversAfterFailedRefresh() {
        val viewModel = MaintenanceHistoryViewModel()
        viewModel.showMaintenance(records = listOf(record(id = "old", serviceDate = "2026-05-01")))

        assertTrue(viewModel.startRefresh())
        viewModel.failRefresh("Temporary failure.")
        assertTrue(viewModel.uiState.isError)

        assertTrue(viewModel.startRefresh())
        viewModel.finishRefresh(listOf(record(id = "new", serviceDate = "2026-07-01")))

        assertFalse(viewModel.uiState.isError)
        assertEquals(listOf("new"), viewModel.uiState.records.map { it.id })
    }

    private fun record(
        id: String = "record-1",
        title: String = "Oil change",
        description: String = "Changed oil and inspected filters.",
        serviceDate: String = "2026-06-18",
        createdAt: String = "2026-06-18T10:00:00Z",
    ): MaintenanceRecord {
        return MaintenanceRecord(
            id = id,
            title = title,
            description = description,
            serviceDate = serviceDate,
            createdAt = createdAt,
        )
    }
}
