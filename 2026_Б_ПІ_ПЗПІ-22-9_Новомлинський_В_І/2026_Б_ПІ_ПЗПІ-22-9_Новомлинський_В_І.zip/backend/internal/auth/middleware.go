package auth

import (
	"context"
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

func RequireUser(
	service Service,
	logger *slog.Logger,
	next http.HandlerFunc,
) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token, ok := bearerToken(r.Header.Get("Authorization"))
		if !ok {
			response.Error(w, http.StatusUnauthorized, "missing or invalid token")
			return
		}

		user, err := service.CurrentUser(r.Context(), token)
		if errors.Is(err, ErrUnauthorized) {
			response.Error(w, http.StatusUnauthorized, "missing or invalid token")
			return
		}
		if err != nil {
			logger.Error("failed to authenticate request", "error", err)
			response.Error(w, http.StatusInternalServerError, "internal server error")
			return
		}

		next.ServeHTTP(w, r.WithContext(WithUser(r.Context(), user)))
	}
}

func WithUser(ctx context.Context, user User) context.Context {
	return context.WithValue(ctx, userContextKey, user)
}

func UserFromContext(ctx context.Context) (User, bool) {
	user, ok := ctx.Value(userContextKey).(User)
	return user, ok
}
