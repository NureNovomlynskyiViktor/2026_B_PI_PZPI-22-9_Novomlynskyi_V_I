package telemetry

import (
	"context"
	"testing"
)

type stubRepository struct {
	records []Record
	record  Record
	err     error
	limit   int
}

func (s *stubRepository) ListByVehicle(
	context.Context,
	string,
	int,
) ([]Record, error) {
	return s.records, s.err
}

func (s *stubRepository) LatestByVehicle(context.Context, string) (Record, error) {
	return s.record, s.err
}

func (s *stubRepository) Create(context.Context, NewRecord) (Record, error) {
	return s.record, s.err
}

func TestParseLimit(t *testing.T) {
	tests := []struct {
		name    string
		raw     string
		want    int
		wantErr bool
	}{
		{name: "default", raw: "", want: DefaultLimit},
		{name: "valid", raw: "100", want: 100},
		{name: "maximum", raw: "200", want: MaxLimit},
		{name: "zero", raw: "0", wantErr: true},
		{name: "negative", raw: "-1", wantErr: true},
		{name: "too large", raw: "201", wantErr: true},
		{name: "not a number", raw: "many", wantErr: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseLimit(tt.raw)
			if (err != nil) != tt.wantErr {
				t.Fatalf("ParseLimit() error = %v, wantErr %v", err, tt.wantErr)
			}
			if got != tt.want {
				t.Fatalf("ParseLimit() = %d, want %d", got, tt.want)
			}
		})
	}
}

func TestServiceRejectsInvalidVehicleID(t *testing.T) {
	service := NewService(&stubRepository{})

	if _, err := service.ListByVehicle(context.Background(), "invalid", DefaultLimit); err != ErrInvalidVehicleID {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}
	if _, err := service.LatestByVehicle(context.Background(), "invalid"); err != ErrInvalidVehicleID {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}
}
