package vehicle

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var ErrInvalidInput = errors.New("invalid vehicle input")

type Service interface {
	List(ctx context.Context) ([]Vehicle, error)
	GetByID(ctx context.Context, id string) (Vehicle, error)
	ListByOwner(ctx context.Context, ownerID string) ([]Vehicle, error)
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (Vehicle, error)
	CreateForOwner(ctx context.Context, ownerID string, request CreateRequest) (Vehicle, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) List(ctx context.Context) ([]Vehicle, error) {
	return s.repository.List(ctx)
}

func (s *service) GetByID(ctx context.Context, id string) (Vehicle, error) {
	if !identifier.IsUUID(id) {
		return Vehicle{}, ErrNotFound
	}

	return s.repository.GetByID(ctx, id)
}

func (s *service) ListByOwner(
	ctx context.Context,
	ownerID string,
) ([]Vehicle, error) {
	if !identifier.IsUUID(ownerID) {
		return nil, ErrNotFound
	}

	return s.repository.ListByOwner(ctx, ownerID)
}

func (s *service) GetByIDForOwner(
	ctx context.Context,
	ownerID string,
	vehicleID string,
) (Vehicle, error) {
	if !identifier.IsUUID(ownerID) || !identifier.IsUUID(vehicleID) {
		return Vehicle{}, ErrNotFound
	}

	return s.repository.GetByIDForOwner(ctx, ownerID, vehicleID)
}

func (s *service) CreateForOwner(
	ctx context.Context,
	ownerID string,
	request CreateRequest,
) (Vehicle, error) {
	if !identifier.IsUUID(ownerID) {
		return Vehicle{}, ErrInvalidInput
	}

	normalized := normalizeCreateRequest(request)
	if !isValidCreateRequest(normalized) {
		return Vehicle{}, ErrInvalidInput
	}

	return s.repository.CreateForOwner(ctx, ownerID, normalized)
}

func normalizeCreateRequest(request CreateRequest) CreateRequest {
	return CreateRequest{
		VIN:          strings.TrimSpace(request.VIN),
		Brand:        strings.TrimSpace(request.Brand),
		Model:        strings.TrimSpace(request.Model),
		Year:         request.Year,
		LicensePlate: strings.TrimSpace(request.LicensePlate),
	}
}

func isValidCreateRequest(request CreateRequest) bool {
	return request.VIN != "" &&
		len(request.VIN) <= 17 &&
		request.Brand != "" &&
		request.Model != "" &&
		request.LicensePlate != "" &&
		request.Year >= 1886 &&
		request.Year <= 2100
}
