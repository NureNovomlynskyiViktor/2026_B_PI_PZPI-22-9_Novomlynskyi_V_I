package ownerthreshold

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type ThresholdService interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]threshold.Setting, error)
}

type VehicleService interface {
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
}

type Rule struct {
	ID          string    `json:"id"`
	VehicleID   string    `json:"vehicle_id"`
	Parameter   string    `json:"parameter"`
	Metric      string    `json:"metric"`
	Severity    string    `json:"severity"`
	RuleType    string    `json:"rule_type"`
	Value       float64   `json:"value"`
	Unit        string    `json:"unit"`
	Description string    `json:"description"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type Handler struct {
	thresholds ThresholdService
	vehicles   VehicleService
	logger     *slog.Logger
}

func NewHandler(
	thresholds ThresholdService,
	vehicles VehicleService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		thresholds: thresholds,
		vehicles:   vehicles,
		logger:     logger,
	}
}

func (h *Handler) ListByVehicle(w http.ResponseWriter, r *http.Request) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	if _, err := h.vehicles.GetByIDForOwner(r.Context(), user.ID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return
		}
		h.logger.Error(
			"failed to verify owner vehicle for thresholds",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	settings, err := h.thresholds.ListByVehicle(r.Context(), vehicleID)
	if err != nil {
		h.logger.Error(
			"failed to list owner thresholds",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, BuildRules(settings))
}

func BuildRules(settings []threshold.Setting) []Rule {
	rules := make([]Rule, 0, len(settings)*2)
	for _, setting := range settings {
		meta := metricMetadata(setting.Parameter)
		rules = append(
			rules,
			Rule{
				ID:          setting.ID,
				VehicleID:   setting.VehicleID,
				Parameter:   setting.Parameter,
				Metric:      meta.metric,
				Severity:    "warning",
				RuleType:    setting.Parameter + "_warning",
				Value:       setting.WarningValue,
				Unit:        meta.unit,
				Description: meta.warningDescription,
				CreatedAt:   setting.CreatedAt,
				UpdatedAt:   setting.UpdatedAt,
			},
			Rule{
				ID:          setting.ID,
				VehicleID:   setting.VehicleID,
				Parameter:   setting.Parameter,
				Metric:      meta.metric,
				Severity:    "critical",
				RuleType:    setting.Parameter + "_critical",
				Value:       setting.CriticalValue,
				Unit:        meta.unit,
				Description: meta.criticalDescription,
				CreatedAt:   setting.CreatedAt,
				UpdatedAt:   setting.UpdatedAt,
			},
		)
	}

	return rules
}

type metadata struct {
	metric              string
	unit                string
	warningDescription  string
	criticalDescription string
}

func metricMetadata(parameter string) metadata {
	switch parameter {
	case "engine_temperature":
		return metadata{
			metric:              "Engine temperature",
			unit:                "C",
			warningDescription:  "Warning limit for engine temperature.",
			criticalDescription: "Critical limit for engine temperature.",
		}
	case "battery_voltage":
		return metadata{
			metric:              "Battery voltage",
			unit:                "V",
			warningDescription:  "Warning lower limit for battery voltage.",
			criticalDescription: "Critical lower limit for battery voltage.",
		}
	case "vibration_level":
		return metadata{
			metric:              "Vibration level",
			unit:                "level",
			warningDescription:  "Warning limit for vibration level.",
			criticalDescription: "Critical limit for vibration level.",
		}
	case "rpm":
		return metadata{
			metric:              "Engine RPM",
			unit:                "rpm",
			warningDescription:  "Warning limit for engine speed.",
			criticalDescription: "Critical limit for engine speed.",
		}
	case "speed":
		return metadata{
			metric:              "Vehicle speed",
			unit:                "km/h",
			warningDescription:  "Warning limit for vehicle speed.",
			criticalDescription: "Critical limit for vehicle speed.",
		}
	case "fuel_level":
		return metadata{
			metric:              "Fuel level",
			unit:                "%",
			warningDescription:  "Warning lower limit for fuel level.",
			criticalDescription: "Critical lower limit for fuel level.",
		}
	default:
		return metadata{
			metric:              parameter,
			unit:                "",
			warningDescription:  "Warning monitoring limit.",
			criticalDescription: "Critical monitoring limit.",
		}
	}
}
