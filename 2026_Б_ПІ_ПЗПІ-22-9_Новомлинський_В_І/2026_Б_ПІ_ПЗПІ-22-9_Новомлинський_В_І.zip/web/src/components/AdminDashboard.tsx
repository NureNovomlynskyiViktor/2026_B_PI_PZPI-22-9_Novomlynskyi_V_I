import { useEffect, useMemo, useState, type FormEvent } from 'react';
import QRCode from 'qrcode';
import { api, errorMessage, isUnauthorizedError } from '../api/client';
import { useMessages } from '../i18n';
import { formatRoleLabel, formatStructuredLabel, formatTimestamp } from '../utils/presentation';
import { AdminAuditLogPanel } from './AdminAuditLogPanel';
import { WorkspaceSection, WorkspaceShell } from './WorkspaceShell';
import type {
  SpecialistAssignment,
  SpecialistCompetency,
  SpecialistRecommendation,
  ServiceRequest,
  User,
  Vehicle,
  VehicleActivationResponse,
} from '../api/types';

type Props = {
  token: string;
  user: User;
  onLogout: () => void;
  onOpenAccount: () => void;
  onSessionExpired: () => void;
};

const adminWorkspaceSectionIDs = [
  'overview',
  'vehicle-onboarding',
  'service-requests',
  'specialist-assignments',
  'users',
  'audit-log',
] as const;

const supportedCompetencies = [
  { code: 'engine_diagnostics', name: 'Engine diagnostics' },
  { code: 'battery_and_electrical', name: 'Battery and electrical systems' },
  { code: 'vibration_analysis', name: 'Vibration analysis' },
  { code: 'fuel_system', name: 'Fuel system' },
  { code: 'general_maintenance', name: 'General maintenance' },
  { code: 'iot_device_setup', name: 'IoT device setup' },
];

const openServiceRequestStatuses = new Set([
  'pending',
  'assigned',
  'in_progress',
]);

const requestQueueDefinitions = [
  {
    id: 'needs-assignment',
    statuses: ['pending'],
  },
  {
    id: 'active-work',
    statuses: ['assigned', 'in_progress'],
  },
  {
    id: 'completed-work',
    statuses: ['completed'],
  },
  {
    id: 'archived-work',
    statuses: ['cancelled'],
  },
] as const;

const serviceRequestStatusRank: Record<string, number> = {
  pending: 0,
  assigned: 1,
  in_progress: 2,
  completed: 3,
  cancelled: 4,
};

function compareServiceRequests(a: ServiceRequest, b: ServiceRequest) {
  const statusDelta =
    (serviceRequestStatusRank[a.status] ?? 99) -
    (serviceRequestStatusRank[b.status] ?? 99);

  if (statusDelta !== 0) {
    return statusDelta;
  }

  return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

function isStrongTemporaryPassword(value: string) {
  return (
    value.length >= 8 &&
    /[A-Z]/.test(value) &&
    /[a-z]/.test(value) &&
    /\d/.test(value) &&
    /[^A-Za-z0-9]/.test(value)
  );
}

type ActivationFormState = {
  vin: string;
  brand: string;
  model: string;
  year: string;
  license_plate: string;
  device_uid: string;
  device_name: string;
};

type CreateSpecialistFormState = {
  name: string;
  email: string;
  password: string;
};

const emptyActivationForm: ActivationFormState = {
  vin: '',
  brand: '',
  model: '',
  year: '',
  license_plate: '',
  device_uid: '',
  device_name: '',
};

const emptyCreateSpecialistForm: CreateSpecialistFormState = {
  name: '',
  email: '',
  password: '',
};

type AdminUserFilterState = {
  search: string;
  role: string;
  status: string;
};

type PendingUserAction = {
  user: User;
  action: 'deactivate' | 'reactivate';
};

const emptyAdminUserFilters: AdminUserFilterState = {
  search: '',
  role: '',
  status: '',
};

export function AdminDashboard({
  token,
  user,
  onLogout,
  onOpenAccount,
  onSessionExpired,
}: Props) {
  const localeMessages = useMessages();
  const accountMessages = localeMessages.account;
  const commonMessages = localeMessages.common;
  const workspaceMessages = localeMessages.workspace.admin;
  const sharedWorkspaceMessages = localeMessages.workspace;
  const adminMessages = localeMessages.admin;
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [specialists, setSpecialists] = useState<User[]>([]);
  const [assignments, setAssignments] = useState<SpecialistAssignment[]>([]);
  const [recommendations, setRecommendations] = useState<SpecialistRecommendation[]>(
    [],
  );
  const [competencies, setCompetencies] = useState<SpecialistCompetency[]>([]);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  const [adminUsers, setAdminUsers] = useState<User[]>([]);
  const [selectedVehicleID, setSelectedVehicleID] = useState<string | null>(null);
  const [selectedSpecialistID, setSelectedSpecialistID] = useState('');
  const [serviceRequestStatusFilter, setServiceRequestStatusFilter] = useState('');
  const [adminUserFilters, setAdminUserFilters] = useState<AdminUserFilterState>(
    emptyAdminUserFilters,
  );
  const [auditLogRefreshKey, setAuditLogRefreshKey] = useState(0);
  const [serviceRequestSpecialistSelections, setServiceRequestSpecialistSelections] =
    useState<Record<string, string>>({});
  const [selectedCompetencySpecialistID, setSelectedCompetencySpecialistID] =
    useState<string | null>(null);
  const [selectedCompetencyCodes, setSelectedCompetencyCodes] = useState<string[]>(
    [],
  );
  const [createSpecialistForm, setCreateSpecialistForm] = useState<CreateSpecialistFormState>(
    emptyCreateSpecialistForm,
  );
  const [createSpecialistCompetencyCodes, setCreateSpecialistCompetencyCodes] =
    useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingAssignments, setIsLoadingAssignments] = useState(false);
  const [isLoadingRecommendations, setIsLoadingRecommendations] = useState(false);
  const [isLoadingCompetencies, setIsLoadingCompetencies] = useState(false);
  const [isLoadingServiceRequests, setIsLoadingServiceRequests] = useState(false);
  const [isLoadingAdminUsers, setIsLoadingAdminUsers] = useState(false);
  const [isAssigning, setIsAssigning] = useState(false);
  const [actingServiceRequestID, setActingServiceRequestID] = useState<string | null>(
    null,
  );
  const [actingUserID, setActingUserID] = useState<string | null>(null);
  const [pendingUserAction, setPendingUserAction] =
    useState<PendingUserAction | null>(null);
  const [deactivationReason, setDeactivationReason] = useState('');
  const [isCreatingActivation, setIsCreatingActivation] = useState(false);
  const [isCreatingSpecialist, setIsCreatingSpecialist] = useState(false);
  const [assigningRecommendationID, setAssigningRecommendationID] = useState<
    string | null
  >(null);
  const [isSavingCompetencies, setIsSavingCompetencies] = useState(false);
  const [removingSpecialistID, setRemovingSpecialistID] = useState<string | null>(
    null,
  );
  const [activationForm, setActivationForm] =
    useState<ActivationFormState>(emptyActivationForm);
  const [activationResult, setActivationResult] =
    useState<VehicleActivationResponse | null>(null);
  const [activationQrDataUrl, setActivationQrDataUrl] = useState<string | null>(
    null,
  );
  const [activationQrError, setActivationQrError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [activeWorkspaceSection, setActiveWorkspaceSection] = useState('overview');

  const adminWorkspaceSections = useMemo(
    () =>
      adminWorkspaceSectionIDs.map((id) => ({
        id,
        label:
          id === 'vehicle-onboarding'
            ? workspaceMessages.sections.vehicleOnboarding
            : id === 'service-requests'
              ? workspaceMessages.sections.serviceRequests
              : id === 'specialist-assignments'
                ? workspaceMessages.sections.specialistAssignments
                : id === 'audit-log'
                  ? workspaceMessages.sections.auditLog
                  : workspaceMessages.sections[id],
      })),
    [workspaceMessages],
  );
  const serviceRequestStatusOptions = [
    { value: '', label: adminMessages.serviceRequests.allStatuses },
    { value: 'pending', label: formatStructuredLabel('pending', undefined, localeMessages.structuredLabels) },
    { value: 'assigned', label: formatStructuredLabel('assigned', undefined, localeMessages.structuredLabels) },
    { value: 'in_progress', label: formatStructuredLabel('in_progress', undefined, localeMessages.structuredLabels) },
    { value: 'completed', label: formatStructuredLabel('completed', undefined, localeMessages.structuredLabels) },
    { value: 'cancelled', label: formatStructuredLabel('cancelled', undefined, localeMessages.structuredLabels) },
  ];
  const adminUserRoleFilterOptions = [
    { value: '', label: adminMessages.users.allRoles },
    { value: 'vehicle_owner', label: formatRoleLabel('vehicle_owner', localeMessages.structuredLabels) },
    { value: 'technical_specialist', label: formatRoleLabel('technical_specialist', localeMessages.structuredLabels) },
    { value: 'administrator', label: formatRoleLabel('administrator', localeMessages.structuredLabels) },
  ];
  const adminUserStatusFilterOptions = [
    { value: '', label: adminMessages.users.allStatuses },
    { value: 'active', label: adminMessages.users.active },
    { value: 'inactive', label: adminMessages.users.inactive },
  ];
  const selectedVehicle = useMemo(
    () => vehicles.find((vehicle) => vehicle.id === selectedVehicleID) ?? null,
    [selectedVehicleID, vehicles],
  );
  const selectedCompetencySpecialist = useMemo(
    () =>
      specialists.find(
        (specialist) => specialist.id === selectedCompetencySpecialistID,
      ) ?? null,
    [selectedCompetencySpecialistID, specialists],
  );
  const assignedSpecialistIDs = useMemo(
    () => new Set(assignments.map((assignment) => assignment.specialist_id)),
    [assignments],
  );
  const availableSpecialists = useMemo(
    () =>
      specialists.filter(
        (specialist) => !assignedSpecialistIDs.has(specialist.id),
      ),
    [assignedSpecialistIDs, specialists],
  );
  const vehiclesByID = useMemo(
    () => new Map(vehicles.map((vehicle) => [vehicle.id, vehicle])),
    [vehicles],
  );
  const specialistsByID = useMemo(
    () => new Map(specialists.map((specialist) => [specialist.id, specialist])),
    [specialists],
  );
  const openServiceRequestCount = useMemo(
    () =>
      serviceRequests.filter((request) =>
        openServiceRequestStatuses.has(request.status),
      ).length,
    [serviceRequests],
  );
  const pendingServiceRequestCount = useMemo(
    () => serviceRequests.filter((request) => request.status === 'pending').length,
    [serviceRequests],
  );
  const activeUserCount = useMemo(
    () => adminUsers.filter((adminUser) => adminUser.is_active).length,
    [adminUsers],
  );
  const inactiveUserCount = adminUsers.length - activeUserCount;
  const requestQueues = useMemo(
    () =>
      requestQueueDefinitions.map((queue) => ({
        ...queue,
        requests: serviceRequests
          .filter((request) => (queue.statuses as readonly string[]).includes(request.status))
          .sort(compareServiceRequests),
      })),
    [serviceRequests],
  );

  function serviceRequestQueueTitle(id: (typeof requestQueueDefinitions)[number]['id']) {
    switch (id) {
      case 'needs-assignment':
        return adminMessages.serviceRequests.needsAssignment;
      case 'active-work':
        return adminMessages.serviceRequests.assignedInProgress;
      case 'completed-work':
        return adminMessages.serviceRequests.completed;
      case 'archived-work':
        return adminMessages.serviceRequests.cancelledArchived;
    }
  }

  function serviceRequestQueueDescription(id: (typeof requestQueueDefinitions)[number]['id']) {
    switch (id) {
      case 'needs-assignment':
        return adminMessages.serviceRequests.needsAssignmentDescription;
      case 'active-work':
        return adminMessages.serviceRequests.assignedInProgressDescription;
      case 'completed-work':
        return adminMessages.serviceRequests.completedDescription;
      case 'archived-work':
        return adminMessages.serviceRequests.cancelledArchivedDescription;
    }
  }

  function adminUserFilterRequest(filters = adminUserFilters) {
    return {
      role: filters.role
        ? (filters.role as 'vehicle_owner' | 'technical_specialist' | 'administrator')
        : undefined,
      is_active:
        filters.status === 'active'
          ? true
          : filters.status === 'inactive'
            ? false
            : undefined,
      search: filters.search.trim() || undefined,
    };
  }

  async function refreshAdminUsers(filters = adminUserFilters) {
    const loadedUsers = await api.listAdminUsers(token, adminUserFilterRequest(filters));
    setAdminUsers(loadedUsers);
  }

  async function refreshSpecialistDerivedData(
    loadedSpecialists?: User[],
    preferredCompetencySpecialistID?: string,
  ) {
    const nextSpecialists = loadedSpecialists ?? (await api.listAdminSpecialists(token));
    const activeSpecialistIDs = new Set(
      nextSpecialists.map((specialist) => specialist.id),
    );
    const preferredSpecialistID =
      preferredCompetencySpecialistID ?? selectedCompetencySpecialistID;
    const nextCompetencySpecialistID =
      preferredSpecialistID && activeSpecialistIDs.has(preferredSpecialistID)
        ? preferredSpecialistID
        : nextSpecialists[0]?.id ?? null;

    setSpecialists(nextSpecialists);
    setSelectedSpecialistID((current) =>
      current && activeSpecialistIDs.has(current) ? current : '',
    );
    setSelectedCompetencySpecialistID(nextCompetencySpecialistID);
    setServiceRequestSpecialistSelections((current) =>
      Object.fromEntries(
        Object.entries(current).filter(([, specialistID]) =>
          activeSpecialistIDs.has(specialistID),
        ),
      ),
    );

    if (nextCompetencySpecialistID) {
      const loadedCompetencies = await api.listAdminSpecialistCompetencies(
        token,
        nextCompetencySpecialistID,
      );
      setCompetencies(loadedCompetencies);
      setSelectedCompetencyCodes(
        loadedCompetencies.map((competency) => competency.code),
      );
    } else {
      setCompetencies([]);
      setSelectedCompetencyCodes([]);
    }

    if (selectedVehicleID) {
      const [loadedAssignments, loadedRecommendations] = await Promise.all([
        api.listAdminVehicleSpecialists(token, selectedVehicleID),
        api.listAdminRecommendedSpecialists(token, selectedVehicleID),
      ]);
      setAssignments(loadedAssignments);
      setRecommendations(loadedRecommendations);
    } else {
      setAssignments([]);
      setRecommendations([]);
    }
  }

  async function refreshActiveSpecialists() {
    await refreshSpecialistDerivedData();
  }

  useEffect(() => {
    let isCurrent = true;

    async function loadDashboard() {
      setIsLoading(true);
      setError(null);
      try {
        const [loadedVehicles, loadedSpecialists] = await Promise.all([
          api.listAdminVehicles(token),
          api.listAdminSpecialists(token),
        ]);

        if (!isCurrent) {
          return;
        }

        setVehicles(loadedVehicles);
        setSpecialists(loadedSpecialists);
        setSelectedCompetencySpecialistID((current) => {
          if (
            current &&
            loadedSpecialists.some((specialist) => specialist.id === current)
          ) {
            return current;
          }

          return loadedSpecialists[0]?.id ?? null;
        });
        setSelectedVehicleID((current) => {
          if (current && loadedVehicles.some((vehicle) => vehicle.id === current)) {
            return current;
          }

          return loadedVehicles[0]?.id ?? null;
        });
      } catch (err) {
        if (isCurrent) {
          handleAdminError(err, commonMessages.loading);
        }
      } finally {
        if (isCurrent) {
          setIsLoading(false);
        }
      }
    }

    void loadDashboard();

    return () => {
      isCurrent = false;
    };
  }, [token]);

  useEffect(() => {
    let isCurrent = true;
    setIsLoadingAdminUsers(true);
    setError(null);

    api
      .listAdminUsers(token, adminUserFilterRequest())
      .then((loadedUsers) => {
        if (isCurrent) {
          setAdminUsers(loadedUsers);
        }
      })
      .catch((err) => {
        if (isCurrent) {
          handleAdminError(err, adminMessages.users.noMatches);
        }
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoadingAdminUsers(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [adminUserFilters.role, adminUserFilters.search, adminUserFilters.status, token]);

  useEffect(() => {
    let isCurrent = true;
    setIsLoadingServiceRequests(true);
    setError(null);

    api
      .listAdminServiceRequests(token, serviceRequestStatusFilter || undefined)
      .then((loadedRequests) => {
        if (isCurrent) {
          setServiceRequests(loadedRequests);
        }
      })
      .catch((err) => {
        if (isCurrent) {
          handleAdminError(err, adminMessages.serviceRequests.noMatching);
        }
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoadingServiceRequests(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [serviceRequestStatusFilter, token]);

  useEffect(() => {
    if (!selectedVehicleID) {
      setAssignments([]);
      setRecommendations([]);
      return;
    }

    let isCurrent = true;
    setIsLoadingAssignments(true);
    setError(null);

    api
      .listAdminVehicleSpecialists(token, selectedVehicleID)
      .then((loadedAssignments) => {
        if (isCurrent) {
          setAssignments(loadedAssignments);
        }
      })
      .catch((err) => {
        if (isCurrent) {
          handleAdminError(err, adminMessages.assignments.assignError);
        }
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoadingAssignments(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [selectedVehicleID, token]);

  useEffect(() => {
    if (!selectedVehicleID) {
      setRecommendations([]);
      return;
    }

    let isCurrent = true;
    setIsLoadingRecommendations(true);
    setError(null);

    api
      .listAdminRecommendedSpecialists(token, selectedVehicleID)
      .then((loadedRecommendations) => {
        if (isCurrent) {
          setRecommendations(loadedRecommendations);
        }
      })
      .catch((err) => {
        if (isCurrent) {
          handleAdminError(err, adminMessages.assignments.noRecommendations);
        }
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoadingRecommendations(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [selectedVehicleID, token]);

  useEffect(() => {
    let isCurrent = true;

    if (!activationResult) {
      setActivationQrDataUrl(null);
      setActivationQrError(null);
      return () => {
        isCurrent = false;
      };
    }

    setActivationQrDataUrl(null);
    setActivationQrError(null);
    QRCode.toDataURL(activationResult.activation_uri, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 180,
    })
      .then((dataUrl) => {
        if (isCurrent) {
          setActivationQrDataUrl(dataUrl);
        }
      })
      .catch(() => {
        if (isCurrent) {
          setActivationQrError(adminMessages.onboarding.qrError);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [activationResult]);

  useEffect(() => {
    if (
      selectedSpecialistID &&
      !availableSpecialists.some((specialist) => specialist.id === selectedSpecialistID)
    ) {
      setSelectedSpecialistID('');
    }
  }, [availableSpecialists, selectedSpecialistID]);

  useEffect(() => {
    if (
      selectedCompetencySpecialistID &&
      !specialists.some(
        (specialist) => specialist.id === selectedCompetencySpecialistID,
      )
    ) {
      setSelectedCompetencySpecialistID(specialists[0]?.id ?? null);
    }
  }, [selectedCompetencySpecialistID, specialists]);

  useEffect(() => {
    if (!selectedCompetencySpecialistID) {
      setCompetencies([]);
      setSelectedCompetencyCodes([]);
      return;
    }

    let isCurrent = true;
    setIsLoadingCompetencies(true);
    setError(null);

    api
      .listAdminSpecialistCompetencies(token, selectedCompetencySpecialistID)
      .then((loadedCompetencies) => {
        if (!isCurrent) {
          return;
        }
        setCompetencies(loadedCompetencies);
        setSelectedCompetencyCodes(
          loadedCompetencies.map((competency) => competency.code),
        );
      })
      .catch((err) => {
        if (isCurrent) {
          handleAdminError(err, adminMessages.assignments.competenciesError);
        }
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoadingCompetencies(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [selectedCompetencySpecialistID, token]);

  async function handleRefresh() {
    setIsLoading(true);
    setError(null);
    setMessage(null);
    try {
      const [loadedVehicles, loadedSpecialists] = await Promise.all([
        api.listAdminVehicles(token),
        api.listAdminSpecialists(token),
      ]);
      setVehicles(loadedVehicles);
      await refreshSpecialistDerivedData(loadedSpecialists);
      const loadedRequests = await api.listAdminServiceRequests(
        token,
        serviceRequestStatusFilter || undefined,
      );
      setServiceRequests(loadedRequests);
      await refreshAdminUsers();
      setAuditLogRefreshKey((current) => current + 1);
      setMessage(adminMessages.overview.refreshed);
    } catch (err) {
      handleAdminError(err, adminMessages.overview.refreshError);
    } finally {
      setIsLoading(false);
    }
  }

  async function refreshServiceRequests() {
    const loadedRequests = await api.listAdminServiceRequests(
      token,
      serviceRequestStatusFilter || undefined,
    );
    setServiceRequests(loadedRequests);
  }

  async function handleRefreshAdminUsers() {
    setIsLoadingAdminUsers(true);
    setError(null);
    setMessage(null);
    try {
      await refreshAdminUsers();
      setMessage(adminMessages.users.refreshed);
    } catch (err) {
      handleAdminError(err, adminMessages.users.refreshError);
    } finally {
      setIsLoadingAdminUsers(false);
    }
  }

  function vehicleLabel(vehicleID: string) {
    const vehicle = vehiclesByID.get(vehicleID);
    if (!vehicle) {
      return vehicleID;
    }

    return `${vehicle.brand} ${vehicle.model} - ${vehicle.license_plate ?? vehicle.vin ?? vehicle.id}`;
  }

  function specialistLabel(specialistID?: string | null) {
    if (!specialistID) {
      return commonMessages.notAssigned;
    }

    const specialist = specialistsByID.get(specialistID);
    return specialist?.full_name || specialist?.email || specialistID;
  }

  function specialistOptionLabel(specialist: User) {
    if (specialist.full_name && specialist.email) {
      return specialist.full_name + ' - ' + specialist.email;
    }

    return specialist.full_name || specialist.email;
  }

  function previewText(value: string, maxLength = 140) {
    const normalized = value.trim().replace(/\s+/g, ' ');
    if (normalized.length <= maxLength) {
      return normalized;
    }

    return `${normalized.slice(0, maxLength - 1).trimEnd()}...`;
  }

  function renderRequestCard(request: ServiceRequest) {
    const canAssign = request.status === 'pending' || request.status === 'assigned';
    const canCancel = request.status === 'pending' || request.status === 'assigned';
    const isActing = actingServiceRequestID === request.id;

    return (
      <article
        className={`admin-request-card ${canAssign || canCancel ? 'actionable' : 'readonly'}`}
        key={request.id}
      >
        <div className="admin-request-main">
          <div className="admin-request-heading">
            <div>
              <h3>{request.title}</h3>
              <p className="muted">{vehicleLabel(request.vehicle_id)}</p>
            </div>
            <div className="admin-request-badges">
              <span className={`priority-pill ${request.priority}`}>
                {formatStructuredLabel(request.priority, undefined, localeMessages.structuredLabels)}
              </span>
              <span className={`status-pill ${request.status}`}>
                {formatStructuredLabel(request.status, undefined, localeMessages.structuredLabels)}
              </span>
            </div>
          </div>
          <p className="admin-request-description">
            {previewText(request.description)}
          </p>
          <div className="admin-request-time-row">
            <span>{commonMessages.created} {formatTimestamp(request.created_at)}</span>
            {request.assigned_at && (
              <span>{commonMessages.assignedAt} {formatTimestamp(request.assigned_at)}</span>
            )}
            {request.started_at && (
              <span>{commonMessages.started} {formatTimestamp(request.started_at)}</span>
            )}
            {request.completed_at && (
              <span>{commonMessages.completedAt} {formatTimestamp(request.completed_at)}</span>
            )}
            {request.cancelled_at && (
              <span>{commonMessages.cancelledAt} {formatTimestamp(request.cancelled_at)}</span>
            )}
          </div>
          <div className="admin-request-specialist">
            <span>{adminMessages.serviceRequests.specialist}</span>
            <strong>{specialistLabel(request.assigned_specialist_id)}</strong>
          </div>
        </div>

        {(canAssign || canCancel) && (
          <div className="admin-request-actions">
            {canAssign && (
              <label>
                {adminMessages.assignments.selectSpecialist}
                <select
                  disabled={isActing || specialists.length === 0}
                  value={
                    serviceRequestSpecialistSelections[request.id] ??
                    request.assigned_specialist_id ??
                    ''
                  }
                  onChange={(event) =>
                    setServiceRequestSpecialistSelections((current) => ({
                      ...current,
                      [request.id]: event.target.value,
                    }))
                  }
                >
                  <option value="">{adminMessages.serviceRequests.selectSpecialist}</option>
                  {specialists.map((specialist) => (
                    <option key={specialist.id} value={specialist.id}>
                      {specialistOptionLabel(specialist)}
                    </option>
                  ))}
                </select>
              </label>
            )}
            <div className="button-row compact">
              {canAssign && (
                <button
                  className="primary-button"
                  disabled={isActing || specialists.length === 0}
                  type="button"
                  onClick={() => void handleAssignServiceRequest(request)}
                >
                  {isActing
                    ? adminMessages.users.saving
                    : request.status === 'assigned'
                      ? adminMessages.serviceRequests.reassign
                      : adminMessages.serviceRequests.assign}
                </button>
              )}
              {canCancel && (
                <button
                  className="secondary-button"
                  disabled={isActing}
                  type="button"
                  onClick={() => void handleCancelServiceRequest(request.id)}
                >
                  {isActing ? adminMessages.serviceRequests.cancelling : adminMessages.serviceRequests.cancel}
                </button>
              )}
            </div>
          </div>
        )}
      </article>
    );
  }

  function handleUnauthorizedError(err: unknown) {
    if (!isUnauthorizedError(err)) {
      return false;
    }

    onSessionExpired();
    return true;
  }

  function handleAdminError(err: unknown, fallback: string) {
    if (handleUnauthorizedError(err)) {
      return;
    }

    setError(errorMessage(err, fallback));
  }

  function isDuplicateEmailError(err: unknown) {
    return err instanceof Error && err.message.toLowerCase().includes('email already exists');
  }

  function handleCreateSpecialistError(err: unknown) {
    if (handleUnauthorizedError(err)) {
      return;
    }

    setError(
      isDuplicateEmailError(err)
        ? adminMessages.assignments.createSpecialistDuplicateEmail
        : errorMessage(err, adminMessages.assignments.createSpecialistError),
    );
  }

  function userLifecycleErrorMessage(err: unknown, action: PendingUserAction['action']) {
    const fallback =
      action === 'deactivate'
        ? adminMessages.users.deactivateError
        : adminMessages.users.reactivateError;
    const message = err instanceof Error ? err.message : fallback;
    const normalized = message.toLowerCase();

    if (
      normalized.includes('own account') ||
      normalized.includes('self-deactivation') ||
      normalized.includes('deactivate yourself')
    ) {
      return adminMessages.users.selfDeactivateTitle;
    }

    if (message === 'user cannot be deactivated') {
      return adminMessages.users.lifecycleError;
    }

    return message;
  }

  function updateAdminUserFilter(
    field: keyof AdminUserFilterState,
    value: string,
  ) {
    setAdminUserFilters((current) => ({ ...current, [field]: value }));
    setMessage(null);
  }

  function clearAdminUserFilters() {
    setAdminUserFilters(emptyAdminUserFilters);
    setMessage(null);
  }

  function openUserAction(targetUser: User, action: PendingUserAction['action']) {
    setPendingUserAction({ user: targetUser, action });
    setDeactivationReason('');
    setError(null);
    setMessage(null);
  }

  function closeUserAction() {
    setPendingUserAction(null);
    setDeactivationReason('');
  }

  async function handleConfirmUserAction() {
    if (!pendingUserAction || actingUserID) {
      return;
    }

    const { user: targetUser, action } = pendingUserAction;
    setActingUserID(targetUser.id);
    setError(null);
    setMessage(null);

    try {
      if (action === 'deactivate') {
        await api.deactivateAdminUser(token, targetUser.id, {
          reason: deactivationReason.trim() || undefined,
        });
      } else {
        await api.reactivateAdminUser(token, targetUser.id);
      }

      await Promise.all([refreshAdminUsers(), refreshActiveSpecialists()]);
      setAuditLogRefreshKey((current) => current + 1);
      closeUserAction();
      setMessage(
        action === 'deactivate'
          ? adminMessages.users.deactivatedSuccess
          : adminMessages.users.reactivatedSuccess,
      );
    } catch (err) {
      if (handleUnauthorizedError(err)) {
        return;
      }

      setError(userLifecycleErrorMessage(err, action));
    } finally {
      setActingUserID(null);
    }
  }

  async function handleAssignServiceRequest(request: ServiceRequest) {
    const specialistID =
      serviceRequestSpecialistSelections[request.id] ??
      request.assigned_specialist_id ??
      '';
    if (!specialistID) {
      setError(adminMessages.serviceRequests.selectSpecialist);
      return;
    }

    setActingServiceRequestID(request.id);
    setError(null);
    setMessage(null);
    try {
      await api.assignAdminServiceRequest(token, request.id, specialistID);
      await refreshServiceRequests();
      setServiceRequestSpecialistSelections((current) => ({
        ...current,
        [request.id]: '',
      }));
      setMessage(
        request.status === 'assigned'
          ? adminMessages.serviceRequests.reassigned
          : adminMessages.serviceRequests.assigned,
      );
    } catch (err) {
      handleAdminError(err, adminMessages.serviceRequests.assignError);
    } finally {
      setActingServiceRequestID(null);
    }
  }

  async function handleCancelServiceRequest(requestID: string) {
    setActingServiceRequestID(requestID);
    setError(null);
    setMessage(null);
    try {
      await api.cancelAdminServiceRequest(token, requestID);
      await refreshServiceRequests();
      setMessage(adminMessages.serviceRequests.cancelled);
    } catch (err) {
      handleAdminError(err, adminMessages.serviceRequests.cancelError);
    } finally {
      setActingServiceRequestID(null);
    }
  }

  function handleActivationFieldChange(
    field: keyof ActivationFormState,
    value: string,
  ) {
    setActivationForm((current) => ({ ...current, [field]: value }));
    setMessage(null);
  }

  async function handleCreateActivation(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (isCreatingActivation) {
      return;
    }

    const year = Number(activationForm.year);
    if (!Number.isInteger(year)) {
      setError(adminMessages.onboarding.error);
      return;
    }

    setIsCreatingActivation(true);
    setError(null);
    setMessage(null);
    setActivationResult(null);

    try {
      const result = await api.createVehicleActivation(token, {
        vin: activationForm.vin,
        brand: activationForm.brand,
        model: activationForm.model,
        year,
        license_plate: activationForm.license_plate,
        device_uid: activationForm.device_uid,
        device_name: activationForm.device_name,
      });
      setActivationResult(result);
      setActivationForm(emptyActivationForm);

      const loadedVehicles = await api.listAdminVehicles(token);
      setVehicles(loadedVehicles);
      setSelectedVehicleID(result.vehicle.id);
      setMessage(adminMessages.onboarding.success);
    } catch (err) {
      handleAdminError(err, adminMessages.onboarding.error);
    } finally {
      setIsCreatingActivation(false);
    }
  }

  async function handleCopyActivationText(value: string, label: string) {
    setError(null);
    setMessage(null);
    try {
      await navigator.clipboard.writeText(value);
      setMessage(label);
    } catch {
      setError(adminMessages.onboarding.copyUnavailable);
    }
  }

  function handleToggleCompetency(code: string) {
    setSelectedCompetencyCodes((current) =>
      current.includes(code)
        ? current.filter((item) => item !== code)
        : [...current, code],
    );
  }

  function handleToggleCreateSpecialistCompetency(code: string) {
    setCreateSpecialistCompetencyCodes((current) =>
      current.includes(code)
        ? current.filter((item) => item !== code)
        : [...current, code],
    );
  }

  async function handleCreateSpecialist(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = createSpecialistForm.name.trim();
    const email = createSpecialistForm.email.trim().toLowerCase();
    const password = createSpecialistForm.password;

    setError(null);
    setMessage(null);

    if (!name || !email || !password) {
      setError(adminMessages.assignments.createSpecialistRequired);
      return;
    }

    if (!isValidEmail(email)) {
      setError(adminMessages.assignments.createSpecialistEmailInvalid);
      return;
    }

    if (!isStrongTemporaryPassword(password)) {
      setError(adminMessages.assignments.createSpecialistPasswordInvalid);
      return;
    }

    setIsCreatingSpecialist(true);
    try {
      const createdSpecialist = await api.createAdminSpecialist(token, {
        name,
        email,
        password,
        competencies: createSpecialistCompetencyCodes,
      });
      setCreateSpecialistForm(emptyCreateSpecialistForm);
      setCreateSpecialistCompetencyCodes([]);
      await refreshSpecialistDerivedData(undefined, createdSpecialist.user.id);
      await refreshAdminUsers();
      setAuditLogRefreshKey((current) => current + 1);
      setMessage(adminMessages.assignments.createSpecialistSuccess);
    } catch (err) {
      handleCreateSpecialistError(err);
    } finally {
      setIsCreatingSpecialist(false);
    }
  }

  async function handleSaveCompetencies() {
    if (!selectedCompetencySpecialistID) {
      return;
    }

    setIsSavingCompetencies(true);
    setError(null);
    setMessage(null);
    try {
      const savedCompetencies = await api.replaceAdminSpecialistCompetencies(
        token,
        selectedCompetencySpecialistID,
        selectedCompetencyCodes,
      );
      setCompetencies(savedCompetencies);
      setSelectedCompetencyCodes(
        savedCompetencies.map((competency) => competency.code),
      );
      setMessage(adminMessages.assignments.competenciesSaved);
    } catch (err) {
      handleAdminError(err, adminMessages.assignments.competenciesError);
    } finally {
      setIsSavingCompetencies(false);
    }
  }

  async function handleAssign(specialistID = selectedSpecialistID) {
    if (!selectedVehicleID || !specialistID) {
      return;
    }

    setIsAssigning(true);
    setAssigningRecommendationID(specialistID);
    setError(null);
    setMessage(null);
    try {
      await api.assignAdminVehicleSpecialist(
        token,
        selectedVehicleID,
        specialistID,
      );
      const [loadedAssignments, loadedRecommendations] = await Promise.all([
        api.listAdminVehicleSpecialists(token, selectedVehicleID),
        api.listAdminRecommendedSpecialists(token, selectedVehicleID),
      ]);
      setAssignments(loadedAssignments);
      setRecommendations(loadedRecommendations);
      setSelectedSpecialistID('');
      setMessage(adminMessages.assignments.assignedSuccess);
    } catch (err) {
      handleAdminError(err, adminMessages.assignments.assignError);
    } finally {
      setIsAssigning(false);
      setAssigningRecommendationID(null);
    }
  }

  async function handleRemove(specialistID: string) {
    if (!selectedVehicleID) {
      return;
    }

    setRemovingSpecialistID(specialistID);
    setError(null);
    setMessage(null);
    try {
      await api.removeAdminVehicleSpecialist(token, selectedVehicleID, specialistID);
      setAssignments((current) =>
        current.filter((assignment) => assignment.specialist_id !== specialistID),
      );
      const loadedRecommendations = await api.listAdminRecommendedSpecialists(
        token,
        selectedVehicleID,
      );
      setRecommendations(loadedRecommendations);
      setMessage(adminMessages.assignments.removedSuccess);
    } catch (err) {
      handleAdminError(err, adminMessages.assignments.removeError);
    } finally {
      setRemovingSpecialistID(null);
    }
  }

  return (
    <WorkspaceShell
      eyebrow={workspaceMessages.kicker}
      title={workspaceMessages.title}
      description={workspaceMessages.description}
      userEmail={user.email}
      userRole={formatStructuredLabel(user.role, commonMessages.notAvailable, localeMessages.structuredLabels)}
      sections={adminWorkspaceSections}
      activeSection={activeWorkspaceSection}
      onSectionChange={setActiveWorkspaceSection}
      onOpenAccount={onOpenAccount}
      onLogout={onLogout}
      accountLabel={accountMessages.button}
      logoutLabel={commonMessages.logout}
      navigationLabel={sharedWorkspaceMessages.navigationLabel}
      sectionsLabel={sharedWorkspaceMessages.sectionsLabel}
      metricsLabel={sharedWorkspaceMessages.metricsLabel}
      metrics={[
        { label: workspaceMessages.metrics.vehicles, value: vehicles.length },
        { label: workspaceMessages.metrics.technicalSpecialists, value: specialists.length },
        { label: workspaceMessages.metrics.openServiceRequests, value: openServiceRequestCount },
        { label: workspaceMessages.metrics.usersInCurrentFilter, value: adminUsers.length },
      ]}
    >
      {error && <p className="error-box">{error}</p>}
      {message && <p className="success-box">{message}</p>}

      <WorkspaceSection active={activeWorkspaceSection === 'overview'}>
        <section className="panel admin-overview-panel">
          <div className="panel-header">
            <div>
              <h2>{adminMessages.overview.title}</h2>
              <p className="muted">{adminMessages.overview.description}</p>
            </div>
            <button
              className="secondary-button"
              disabled={isLoading}
              type="button"
              onClick={() => void handleRefresh()}
            >
              {isLoading ? commonMessages.refreshing : commonMessages.refreshAll}
            </button>
          </div>

          <div className="admin-overview-grid">
            <article className="admin-overview-card">
              <span className="badge">{adminMessages.overview.vehicleOnboardingTitle}</span>
              <strong>{vehicles.length}</strong>
              <p className="muted">{adminMessages.overview.vehicleOnboardingDescription}</p>
              <button
                className="secondary-button"
                type="button"
                onClick={() => setActiveWorkspaceSection('vehicle-onboarding')}
              >
                {adminMessages.overview.registerVehicle}
              </button>
            </article>

            <article className="admin-overview-card emphasis">
              <span className="badge">{adminMessages.overview.serviceRequestsTitle}</span>
              <strong>{openServiceRequestCount}</strong>
              <p className="muted">
                {adminMessages.overview.serviceRequestsDescription.replace('{count}', String(pendingServiceRequestCount))}
              </p>
              <button
                className="primary-button"
                type="button"
                onClick={() => setActiveWorkspaceSection('service-requests')}
              >
                {adminMessages.overview.triageRequests}
              </button>
            </article>

            <article className="admin-overview-card">
              <span className="badge">{adminMessages.overview.specialistsTitle}</span>
              <strong>{specialists.length}</strong>
              <p className="muted">{adminMessages.overview.specialistsDescription}</p>
              <button
                className="secondary-button"
                type="button"
                onClick={() => setActiveWorkspaceSection('specialist-assignments')}
              >
                {adminMessages.overview.matchSpecialists}
              </button>
            </article>

            <article className="admin-overview-card">
              <span className="badge">{adminMessages.overview.usersTitle}</span>
              <strong>{adminUsers.length}</strong>
              <p className="muted">
                {adminMessages.overview.usersDescription
                  .replace('{active}', String(activeUserCount))
                  .replace('{inactive}', String(inactiveUserCount))}
              </p>
              <button
                className="secondary-button"
                type="button"
                onClick={() => setActiveWorkspaceSection('users')}
              >
                {adminMessages.overview.manageUsers}
              </button>
            </article>

            <article className="admin-overview-card audit">
              <span className="badge">{adminMessages.overview.auditLogTitle}</span>
              <strong>{adminMessages.overview.auditLogValue}</strong>
              <p className="muted">{adminMessages.overview.auditLogDescription}</p>
              <button
                className="secondary-button"
                type="button"
                onClick={() => setActiveWorkspaceSection('audit-log')}
              >
                {adminMessages.overview.openAuditLog}
              </button>
            </article>
          </div>
        </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'users'}>
      <section className="panel user-management-panel">
        <div className="panel-header">
          <div>
            <h2>{adminMessages.users.title}</h2>
            <p className="muted">{adminMessages.users.description}</p>
          </div>
          <button
            className="secondary-button"
            disabled={isLoadingAdminUsers}
            type="button"
            onClick={() => void handleRefreshAdminUsers()}
          >
            {isLoadingAdminUsers ? commonMessages.refreshing : commonMessages.refreshUsers}
          </button>
        </div>

        <div className="admin-user-summary metric-grid compact">
          <div className="metric-card">
            <span>{adminMessages.users.usersShown}</span>
            <strong>{adminUsers.length}</strong>
          </div>
          <div className="metric-card">
            <span>{adminMessages.users.active}</span>
            <strong>{activeUserCount}</strong>
          </div>
          <div className="metric-card">
            <span>{adminMessages.users.inactive}</span>
            <strong>{inactiveUserCount}</strong>
          </div>
        </div>

        <div className="filter-grid" role="search" aria-label={adminMessages.users.title}>
          <label>
            {adminMessages.users.search}
            <input
              aria-label={adminMessages.users.nameOrEmail}
              placeholder={adminMessages.users.nameOrEmail}
              value={adminUserFilters.search}
              onChange={(event) =>
                updateAdminUserFilter('search', event.target.value)
              }
            />
          </label>
          <label>
            {adminMessages.users.role}
            <select
              aria-label={adminMessages.users.role}
              value={adminUserFilters.role}
              onChange={(event) =>
                updateAdminUserFilter('role', event.target.value)
              }
            >
              {adminUserRoleFilterOptions.map((role) => (
                <option key={role.value} value={role.value}>
                  {role.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            {adminMessages.users.status}
            <select
              aria-label={adminMessages.users.status}
              value={adminUserFilters.status}
              onChange={(event) =>
                updateAdminUserFilter('status', event.target.value)
              }
            >
              {adminUserStatusFilterOptions.map((status) => (
                <option key={status.value} value={status.value}>
                  {status.label}
                </option>
              ))}
            </select>
          </label>
          <button
            className="secondary-button"
            type="button"
            onClick={clearAdminUserFilters}
          >
            {adminMessages.users.clearFilters}
          </button>
        </div>

        {pendingUserAction && (
          <div className="inline-confirmation" role="dialog" aria-live="polite">
            <div>
              <span className="badge">
                {pendingUserAction.action === 'deactivate'
                  ? adminMessages.users.confirmDeactivate
                  : adminMessages.users.confirmReactivate}
              </span>
              <h3>
                {pendingUserAction.user.full_name || pendingUserAction.user.email}
              </h3>
              <p className="muted">{pendingUserAction.user.email}</p>
              {pendingUserAction.action === 'deactivate' ? (
                <label>
                  {adminMessages.users.optionalReason}
                  <textarea
                    rows={3}
                    value={deactivationReason}
                    onChange={(event) =>
                      setDeactivationReason(event.target.value)
                    }
                    placeholder={adminMessages.users.reasonPlaceholder}
                  />
                </label>
              ) : (
                <p>{adminMessages.users.reactivateHelp}</p>
              )}
            </div>
            <div className="confirmation-actions">
              <button
                className={
                  pendingUserAction.action === 'deactivate'
                    ? 'danger-button'
                    : 'primary-button'
                }
                disabled={actingUserID === pendingUserAction.user.id}
                type="button"
                onClick={() => void handleConfirmUserAction()}
              >
                {actingUserID === pendingUserAction.user.id
                  ? adminMessages.users.saving
                  : pendingUserAction.action === 'deactivate'
                    ? adminMessages.users.deactivateAccount
                    : adminMessages.users.reactivateAccount}
              </button>
              <button
                className="secondary-button"
                disabled={actingUserID === pendingUserAction.user.id}
                type="button"
                onClick={closeUserAction}
              >
                {adminMessages.users.cancel}
              </button>
            </div>
          </div>
        )}

        {isLoadingAdminUsers ? (
          <p className="info-box">{commonMessages.loadingUsers}</p>
        ) : adminUsers.length === 0 ? (
          <div className="empty-state">
            <p>{adminMessages.users.noMatches}</p>
            <button
              className="secondary-button"
              type="button"
              onClick={() => void handleRefreshAdminUsers()}
            >
              {adminMessages.users.retry}
            </button>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>{adminMessages.users.user}</th>
                  <th>{adminMessages.users.role}</th>
                  <th>{adminMessages.users.status}</th>
                  <th>{adminMessages.users.created}</th>
                  <th>{adminMessages.users.deactivated}</th>
                  <th>{adminMessages.users.action}</th>
                </tr>
              </thead>
              <tbody>
                {adminUsers.map((adminUser) => {
                  const isCurrentAdmin = adminUser.id === user.id;
                  const isActing = actingUserID === adminUser.id;

                  return (
                    <tr key={adminUser.id}>
                      <td>
                        <div className="user-identity">
                          <strong>{adminUser.full_name || adminUser.email}</strong>
                          <small>{adminUser.email}</small>
                          {isCurrentAdmin && <span className="badge">{adminMessages.users.you}</span>}
                        </div>
                      </td>
                      <td><span className="badge">{formatRoleLabel(adminUser.role, localeMessages.structuredLabels)}</span></td>
                      <td>
                        <span
                          className={`status-pill ${
                            adminUser.is_active ? 'active' : 'inactive'
                          }`}
                        >
                          {adminUser.is_active ? adminMessages.users.active : adminMessages.users.inactive}
                        </span>
                      </td>
                      <td>{formatTimestamp(adminUser.created_at)}</td>
                      <td>
                        {adminUser.deactivated_at
                          ? formatTimestamp(adminUser.deactivated_at)
                          : adminMessages.users.notDeactivated}
                      </td>
                      <td>
                        {adminUser.is_active ? (
                          <button
                            className="secondary-button"
                            disabled={isCurrentAdmin || isActing}
                            title={
                              isCurrentAdmin
                                ? adminMessages.users.selfDeactivateTitle
                                : undefined
                            }
                            type="button"
                            onClick={() => openUserAction(adminUser, 'deactivate')}
                          >
                            {isCurrentAdmin
                              ? adminMessages.users.currentAccount
                              : isActing
                                ? adminMessages.users.saving
                                : adminMessages.users.deactivate}
                          </button>
                        ) : (
                          <button
                            className="primary-button"
                            disabled={isActing}
                            type="button"
                            onClick={() => openUserAction(adminUser, 'reactivate')}
                          >
                            {isActing ? adminMessages.users.saving : adminMessages.users.reactivate}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'audit-log'}>
      <AdminAuditLogPanel
        token={token}
        refreshKey={auditLogRefreshKey}
        onSessionExpired={onSessionExpired}
      />
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'service-requests'}>
        <section className="panel admin-service-requests-panel">
          <div className="panel-header">
            <div>
              <h2>{adminMessages.serviceRequests.title}</h2>
              <p className="muted">{adminMessages.serviceRequests.description}</p>
            </div>
            <label className="select-label compact-select">
              {adminMessages.serviceRequests.status}
              <select
                disabled={isLoadingServiceRequests}
                value={serviceRequestStatusFilter}
                onChange={(event) => {
                  setServiceRequestStatusFilter(event.target.value);
                  setMessage(null);
                }}
              >
                {serviceRequestStatusOptions.map((status) => (
                  <option key={status.value} value={status.value}>
                    {status.label}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="admin-request-summary metric-grid compact">
            <div className="metric-card">
              <span>{adminMessages.serviceRequests.needsAssignment}</span>
              <strong>{pendingServiceRequestCount}</strong>
            </div>
            <div className="metric-card">
              <span>{adminMessages.serviceRequests.open}</span>
              <strong>{openServiceRequestCount}</strong>
            </div>
            <div className="metric-card">
              <span>{adminMessages.serviceRequests.loaded}</span>
              <strong>{serviceRequests.length}</strong>
            </div>
          </div>

          {isLoadingServiceRequests ? (
            <p className="info-box">{commonMessages.loadingServiceRequests}</p>
          ) : serviceRequests.length === 0 ? (
            <p className="empty-state">
              {adminMessages.serviceRequests.noMatching}
            </p>
          ) : (
            <div className="admin-request-queues">
              {requestQueues.map((queue) => (
                <section className="admin-request-queue" key={queue.id}>
                  <div className="admin-request-queue-header">
                    <div>
                      <h3>{serviceRequestQueueTitle(queue.id)}</h3>
                      <p className="muted">{serviceRequestQueueDescription(queue.id)}</p>
                    </div>
                    <span className="badge">{queue.requests.length}</span>
                  </div>

                  {queue.requests.length === 0 ? (
                    <p className="empty-state compact-empty">
                      {adminMessages.serviceRequests.noQueueRequests}
                    </p>
                  ) : (
                    <div className="list-stack">
                      {queue.requests.map((request) => renderRequestCard(request))}
                    </div>
                  )}
                </section>
              ))}
            </div>
          )}
        </section>
      </WorkspaceSection>
      <WorkspaceSection active={activeWorkspaceSection === 'vehicle-onboarding'}>
      <section className="panel">
        <div className="panel-header">
          <div>
            <h2>{adminMessages.onboarding.title}</h2>
            <p className="muted">{adminMessages.onboarding.description}</p>
          </div>
        </div>

        <div className="admin-onboarding-steps">
          <article>
            <span className="badge">1</span>
            <strong>{adminMessages.onboarding.vehicleDeviceTitle}</strong>
            <p className="muted">
              {adminMessages.onboarding.vehicleDeviceDescription}
            </p>
          </article>
          <article>
            <span className="badge">2</span>
            <strong>{adminMessages.onboarding.thresholdsTitle}</strong>
            <p className="muted">
              {adminMessages.onboarding.thresholdsDescription}
            </p>
          </article>
          <article>
            <span className="badge">3</span>
            <strong>{adminMessages.onboarding.ownerActivationTitle}</strong>
            <p className="muted">
              {adminMessages.onboarding.ownerActivationDescription}
            </p>
          </article>
        </div>

        <form className="form-grid admin-onboarding-form" onSubmit={(event) => void handleCreateActivation(event)}>
          <div className="two-column">
            <label>
              {adminMessages.onboarding.vin}
              <input
                required
                disabled={isCreatingActivation}
                value={activationForm.vin}
                onChange={(event) =>
                  handleActivationFieldChange('vin', event.target.value)
                }
              />
            </label>
            <label>
              {adminMessages.onboarding.licensePlate}
              <input
                required
                disabled={isCreatingActivation}
                value={activationForm.license_plate}
                onChange={(event) =>
                  handleActivationFieldChange('license_plate', event.target.value)
                }
              />
            </label>
          </div>

          <div className="two-column">
            <label>
              {adminMessages.onboarding.brand}
              <input
                required
                disabled={isCreatingActivation}
                value={activationForm.brand}
                onChange={(event) =>
                  handleActivationFieldChange('brand', event.target.value)
                }
              />
            </label>
            <label>
              {adminMessages.onboarding.model}
              <input
                required
                disabled={isCreatingActivation}
                value={activationForm.model}
                onChange={(event) =>
                  handleActivationFieldChange('model', event.target.value)
                }
              />
            </label>
          </div>

          <div className="two-column">
            <label>
              {adminMessages.onboarding.year}
              <input
                required
                disabled={isCreatingActivation}
                min="1900"
                max="2100"
                type="number"
                value={activationForm.year}
                onChange={(event) =>
                  handleActivationFieldChange('year', event.target.value)
                }
              />
            </label>
            <label>
              {adminMessages.onboarding.deviceUid}
              <input
                required
                disabled={isCreatingActivation}
                value={activationForm.device_uid}
                onChange={(event) =>
                  handleActivationFieldChange('device_uid', event.target.value)
                }
              />
            </label>
          </div>

          <label>
            {adminMessages.onboarding.deviceName}
            <input
              required
              disabled={isCreatingActivation}
              value={activationForm.device_name}
              onChange={(event) =>
                handleActivationFieldChange('device_name', event.target.value)
              }
            />
          </label>

          <button
            className="primary-button"
            disabled={isCreatingActivation}
            type="submit"
          >
            {isCreatingActivation ? adminMessages.onboarding.registering : adminMessages.onboarding.registerVehicle}
          </button>
        </form>

        {activationResult && (
          <div className="activation-package-card">
            <div className="activation-package-main">
              <span className="badge">{adminMessages.onboarding.activationPackage}</span>
              <h3>
                {activationResult.vehicle.brand} {activationResult.vehicle.model}
              </h3>
              <div className="activation-detail-grid">
                <span>
                  {adminMessages.onboarding.vehicle}
                  <strong>
                    {activationResult.vehicle.license_plate ??
                      activationResult.vehicle.vin ??
                      activationResult.vehicle.id}
                  </strong>
                </span>
                <span>
                  {adminMessages.onboarding.deviceUid}
                  <strong>{activationResult.device.device_uid}</strong>
                </span>
                <span>
                  {adminMessages.onboarding.expires}
                  <strong>{formatTimestamp(activationResult.expires_at, adminMessages.onboarding.noExpiration)}</strong>
                </span>
              </div>
              <div className="activation-code-box">
                <span>{adminMessages.onboarding.activationCode}</span>
                <strong>{activationResult.activation_code}</strong>
              </div>
              <p className="muted">
                {adminMessages.onboarding.ownerInstruction}
              </p>
              <div className="button-row compact">
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() =>
                    void handleCopyActivationText(
                      activationResult.activation_code,
                      adminMessages.onboarding.codeCopied,
                    )
                  }
                >
                  {adminMessages.onboarding.copyCode}
                </button>
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() =>
                    void handleCopyActivationText(
                      activationResult.activation_uri,
                      adminMessages.onboarding.uriCopied,
                    )
                  }
                >
                  {adminMessages.onboarding.copyUri}
                </button>
              </div>
            </div>
            <div className="activation-qr-box activation-package-qr">
              {activationQrDataUrl ? (
                <img alt={adminMessages.onboarding.qrAlt} src={activationQrDataUrl} />
              ) : activationQrError ? (
                <p className="error-box inline">{activationQrError}</p>
              ) : (
                <p className="muted">{adminMessages.onboarding.qrGenerating}</p>
              )}
            </div>
          </div>
        )}
      </section>
      </WorkspaceSection>

      <WorkspaceSection active={activeWorkspaceSection === 'specialist-assignments'}>
      <div className="admin-specialist-layout">
        <div className="admin-specialist-sidebar">
          <section className="panel">
            <h2>{adminMessages.assignments.vehicleMatching}</h2>
            {vehicles.length === 0 ? (
              <p className="empty-state">{adminMessages.assignments.noVehicles}</p>
            ) : (
              <div className="list-stack">
                {vehicles.map((vehicle) => (
                  <button
                    className={
                      selectedVehicleID === vehicle.id
                        ? 'list-item admin-vehicle-item selected'
                        : 'list-item admin-vehicle-item'
                    }
                    key={vehicle.id}
                    type="button"
                    onClick={() => {
                      setSelectedVehicleID(vehicle.id);
                      setMessage(null);
                    }}
                  >
                    <span>
                      <strong>
                        {vehicle.brand} {vehicle.model}
                      </strong>
                      <small>{vehicle.vin ?? adminMessages.assignments.vinNotSet}</small>
                    </span>
                    <span className="badge">{vehicle.license_plate ?? adminMessages.assignments.noPlate}</span>
                  </button>
                ))}
              </div>
            )}
          </section>

          <section className="panel">
            <h2>{adminMessages.assignments.technicalSpecialists}</h2>
            {specialists.length === 0 ? (
              <p className="empty-state">
                {adminMessages.assignments.noSpecialists}
              </p>
            ) : (
              <div className="table-wrap admin-specialist-table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>{adminMessages.assignments.email}</th>
                      <th>{adminMessages.assignments.name}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {specialists.map((specialist) => (
                      <tr key={specialist.id}>
                        <td className="admin-specialist-email">{specialist.email}</td>
                        <td className="admin-specialist-name">{specialist.full_name}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section className="panel">
            <div className="panel-header">
              <div>
                <h2>{adminMessages.assignments.createSpecialistTitle}</h2>
                <p className="muted">
                  {adminMessages.assignments.createSpecialistDescription}
                </p>
              </div>
            </div>
            <form className="form-grid" onSubmit={(event) => void handleCreateSpecialist(event)}>
              <label>
                {adminMessages.assignments.fullName}
                <input
                  autoComplete="name"
                  disabled={isCreatingSpecialist}
                  value={createSpecialistForm.name}
                  onChange={(event) =>
                    setCreateSpecialistForm((current) => ({
                      ...current,
                      name: event.target.value,
                    }))
                  }
                />
              </label>
              <label>
                {adminMessages.assignments.email}
                <input
                  autoComplete="email"
                  disabled={isCreatingSpecialist}
                  inputMode="email"
                  type="email"
                  value={createSpecialistForm.email}
                  onChange={(event) =>
                    setCreateSpecialistForm((current) => ({
                      ...current,
                      email: event.target.value,
                    }))
                  }
                />
              </label>
              <label>
                {adminMessages.assignments.temporaryPassword}
                <input
                  autoComplete="new-password"
                  disabled={isCreatingSpecialist}
                  type="password"
                  value={createSpecialistForm.password}
                  onChange={(event) =>
                    setCreateSpecialistForm((current) => ({
                      ...current,
                      password: event.target.value,
                    }))
                  }
                />
              </label>
              <p className="muted">
                {adminMessages.assignments.temporaryPasswordHint}
              </p>
              <div>
                <strong>{adminMessages.assignments.initialCompetencies}</strong>
                <p className="muted">
                  {adminMessages.assignments.initialCompetenciesDescription}
                </p>
                <div className="checkbox-grid">
                  {supportedCompetencies.map((competency) => (
                    <label className="checkbox-card" key={competency.code}>
                      <input
                        checked={createSpecialistCompetencyCodes.includes(competency.code)}
                        disabled={isCreatingSpecialist}
                        type="checkbox"
                        onChange={() => handleToggleCreateSpecialistCompetency(competency.code)}
                      />
                      <span>
                        <strong>{formatStructuredLabel(competency.code, competency.name, localeMessages.structuredLabels)}</strong>
                      </span>
                    </label>
                  ))}
                </div>
              </div>
              <button
                className="primary-button"
                disabled={isCreatingSpecialist}
                type="submit"
              >
                {isCreatingSpecialist
                  ? adminMessages.assignments.creatingSpecialist
                  : adminMessages.assignments.createSpecialist}
              </button>
            </form>
          </section>

          <section className="panel">
            <div className="panel-header">
              <div>
                <h2>{adminMessages.assignments.specialistCompetencies}</h2>
                <p className="muted">
                  {adminMessages.assignments.competencyHelper}
                </p>
              </div>
              {isLoadingCompetencies && <span className="badge">{commonMessages.refreshing}</span>}
            </div>

            <label className="select-label">
              {adminMessages.assignments.selectSpecialist}
              <select
                disabled={specialists.length === 0 || isSavingCompetencies}
                value={selectedCompetencySpecialistID ?? ''}
                onChange={(event) => {
                  setSelectedCompetencySpecialistID(event.target.value || null);
                  setMessage(null);
                }}
              >
                <option value="">{adminMessages.serviceRequests.selectSpecialist}</option>
                {specialists.map((specialist) => (
                  <option key={specialist.id} value={specialist.id}>
                    {specialistOptionLabel(specialist)}
                  </option>
                ))}
              </select>
            </label>

            {selectedCompetencySpecialist ? (
              <div className="checkbox-grid">
                {supportedCompetencies.map((competency) => (
                  <label className="checkbox-card" key={competency.code}>
                    <input
                      checked={selectedCompetencyCodes.includes(competency.code)}
                      disabled={isSavingCompetencies}
                      type="checkbox"
                      onChange={() => handleToggleCompetency(competency.code)}
                    />
                    <span>
                      <strong>{formatStructuredLabel(competency.code, competency.name, localeMessages.structuredLabels)}</strong>
                    </span>
                  </label>
                ))}
              </div>
            ) : (
              <p className="empty-state">
                {adminMessages.assignments.selectSpecialistForCompetencies}
              </p>
            )}

            <button
              className="primary-button"
              disabled={!selectedCompetencySpecialistID || isSavingCompetencies}
              type="button"
              onClick={() => void handleSaveCompetencies()}
            >
              {isSavingCompetencies ? adminMessages.assignments.saving : adminMessages.assignments.saveCompetencies}
            </button>
          </section>
        </div>

        <div className="admin-specialist-main">
          <section className="panel">
            <div className="panel-header">
              <div>
                <h2>{adminMessages.assignments.selectedVehicle}</h2>
                {selectedVehicle ? (
                  <p className="muted">
                    {selectedVehicle.brand} {selectedVehicle.model} ({selectedVehicle.license_plate ?? adminMessages.assignments.noPlate})
                  </p>
                ) : (
                  <p className="muted">{adminMessages.assignments.selectVehicle}</p>
                )}
              </div>
              {isLoadingAssignments && <span className="badge">{commonMessages.refreshing}</span>}
            </div>

            <div className="form-grid">
              <label className="select-label">
                {adminMessages.assignments.assignTechnicalSpecialist}
                <select
                  disabled={
                    !selectedVehicleID ||
                    availableSpecialists.length === 0 ||
                    isAssigning
                  }
                  value={selectedSpecialistID}
                  onChange={(event) => setSelectedSpecialistID(event.target.value)}
                >
                  <option value="">{adminMessages.serviceRequests.selectSpecialist}</option>
                  {availableSpecialists.map((specialist) => (
                    <option key={specialist.id} value={specialist.id}>
                      {specialistOptionLabel(specialist)}
                    </option>
                  ))}
                </select>
              </label>
              <button
                className="primary-button"
                disabled={!selectedSpecialistID || isAssigning}
                type="button"
                onClick={() => void handleAssign()}
              >
                {isAssigning ? adminMessages.assignments.assigning : adminMessages.assignments.assignSpecialist}
              </button>
            </div>

            {availableSpecialists.length === 0 && specialists.length > 0 && (
              <p className="muted">
                {adminMessages.assignments.allAssigned}
              </p>
            )}
          </section>

          <section className="panel">
            <div className="panel-header">
              <div>
                <h2>{adminMessages.assignments.recommendedSpecialists}</h2>
                <p className="muted">
                  {adminMessages.assignments.recommendationDescription}
                </p>
              </div>
              {isLoadingRecommendations && <span className="badge">{commonMessages.refreshing}</span>}
            </div>

            {recommendations.length === 0 ? (
              <p className="empty-state">
                {adminMessages.assignments.noRecommendations}
              </p>
            ) : (
              <div className="list-stack">
                {recommendations.map((recommendation) => (
                  <div className="recommendation-card" key={recommendation.specialist.id}>
                    <div>
                      <div className="alert-title-row admin-recommendation-title">
                        <span className="admin-specialist-identity">
                          <strong>{recommendation.specialist.full_name || recommendation.specialist.email}</strong>
                          {recommendation.specialist.full_name && (
                            <small>{recommendation.specialist.email}</small>
                          )}
                        </span>
                        <span className="badge">{adminMessages.assignments.score} {recommendation.score}</span>
                        {recommendation.already_assigned && (
                          <span className="status-pill normal">{formatStructuredLabel('assigned', undefined, localeMessages.structuredLabels)}</span>
                        )}
                      </div>
                      <p className="muted">
                        {adminMessages.assignments.activeAssignments}{' '}
                        {recommendation.active_assignment_count}
                      </p>
                      <p>
                        <strong>{adminMessages.assignments.matchedCompetencies}</strong>{' '}
                        {recommendation.matched_competencies.length > 0
                          ? recommendation.matched_competencies.map((competency) => formatStructuredLabel(competency, undefined, localeMessages.structuredLabels)).join(', ')
                          : adminMessages.assignments.noDirectMatches}
                      </p>
                      <p>
                        <strong>{adminMessages.assignments.allCompetencies}</strong>{' '}
                        {recommendation.competencies.length > 0
                          ? recommendation.competencies
                              .map((competency) => formatStructuredLabel(competency.code, competency.name, localeMessages.structuredLabels))
                              .join(', ')
                          : adminMessages.assignments.noCompetencies}
                      </p>
                      {recommendation.reasons.length > 0 && (
                        <ul className="reason-list">
                          {recommendation.reasons.map((reason) => (
                            <li key={reason}>{reason}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                    <button
                      className="primary-button"
                      disabled={
                        recommendation.already_assigned ||
                        assigningRecommendationID === recommendation.specialist.id
                      }
                      type="button"
                      onClick={() =>
                        void handleAssign(recommendation.specialist.id)
                      }
                    >
                      {recommendation.already_assigned
                        ? adminMessages.assignments.alreadyAssigned
                        : assigningRecommendationID === recommendation.specialist.id
                          ? adminMessages.assignments.assigning
                          : adminMessages.serviceRequests.assign}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="panel">
            <h2>{adminMessages.assignments.assignedSpecialists}</h2>
            {assignments.length === 0 ? (
              <p className="empty-state">
                {adminMessages.assignments.noAssignments}
              </p>
            ) : (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>{adminMessages.assignments.email}</th>
                      <th>{adminMessages.assignments.name}</th>
                      <th>{adminMessages.assignments.assignedAt}</th>
                      <th>{adminMessages.users.action}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assignments.map((assignment) => (
                      <tr key={assignment.id}>
                        <td>{assignment.specialist.email}</td>
                        <td>{assignment.specialist.full_name}</td>
                        <td>
                          {formatTimestamp(assignment.created_at)}
                        </td>
                        <td>
                          <button
                            className="secondary-button"
                            disabled={
                              removingSpecialistID === assignment.specialist_id
                            }
                            type="button"
                            onClick={() =>
                              void handleRemove(assignment.specialist_id)
                            }
                          >
                            {removingSpecialistID === assignment.specialist_id
                              ? adminMessages.assignments.removing
                              : adminMessages.assignments.remove}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section className="panel">
            <h2>{adminMessages.assignments.plannedAdminFunctions}</h2>
            <p className="muted">
              {adminMessages.assignments.plannedAdminFunctionsText}
            </p>
          </section>
        </div>
      </div>
      </WorkspaceSection>
    </WorkspaceShell>
  );
}
