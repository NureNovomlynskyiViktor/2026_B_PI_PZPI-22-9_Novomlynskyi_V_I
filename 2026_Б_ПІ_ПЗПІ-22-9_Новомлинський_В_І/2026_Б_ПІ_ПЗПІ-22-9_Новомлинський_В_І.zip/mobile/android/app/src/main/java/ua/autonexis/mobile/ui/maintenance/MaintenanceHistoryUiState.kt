package ua.autonexis.mobile.ui.maintenance

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.MaintenanceRecord

internal data class MaintenanceHistoryUiState(
    val vehicleId: String = "",
    val vehicleLabel: String = "Selected vehicle",
    val records: List<MaintenanceRecord> = emptyList(),
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
)

internal class MaintenanceHistoryViewModel {
    var uiState by mutableStateOf(MaintenanceHistoryUiState())
        private set

    fun showInitialLoading(vehicleId: String, vehicleLabel: String) {
        uiState = MaintenanceHistoryUiState(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            isLoading = true,
            message = "Loading maintenance history...",
        )
    }

    fun showMaintenance(
        vehicleId: String = uiState.vehicleId,
        vehicleLabel: String = uiState.vehicleLabel,
        records: List<MaintenanceRecord>,
        message: String? = null,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            records = MaintenanceHistoryPresentation.newestFirst(records),
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = isError,
        )
    }

    fun failInitialLoad(vehicleId: String, vehicleLabel: String, message: String) {
        uiState = MaintenanceHistoryUiState(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing maintenance history...",
            isError = false,
        )
        return true
    }

    fun finishRefresh(records: List<MaintenanceRecord>, message: String? = null) {
        uiState = uiState.copy(
            records = MaintenanceHistoryPresentation.newestFirst(records),
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = false,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = true,
        )
    }
}
