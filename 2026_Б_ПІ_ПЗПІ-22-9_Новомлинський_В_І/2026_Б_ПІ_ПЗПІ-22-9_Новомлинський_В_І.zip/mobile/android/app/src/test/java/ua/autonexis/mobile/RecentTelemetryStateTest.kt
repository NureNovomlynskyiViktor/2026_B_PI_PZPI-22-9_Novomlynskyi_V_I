package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.telemetry.RecentTelemetryPresentation
import ua.autonexis.mobile.ui.telemetry.RecentTelemetryViewModel

class RecentTelemetryStateTest {
    @Test
    fun initialLoadingSuccessAndErrorStatesAreExplicit() {
        val viewModel = RecentTelemetryViewModel()

        viewModel.showInitialLoading("vehicle-1", "Toyota Corolla")
        assertTrue(viewModel.uiState.isLoading)
        assertEquals("vehicle-1", viewModel.uiState.vehicleId)
        assertEquals("Toyota Corolla", viewModel.uiState.vehicleLabel)
        assertEquals("Loading recent telemetry...", viewModel.uiState.message)

        viewModel.showTelemetry(records = listOf(record(measuredAt = "2026-06-18T10:00:00Z")))
        assertFalse(viewModel.uiState.isLoading)
        assertFalse(viewModel.uiState.isError)
        assertEquals(1, viewModel.uiState.records.size)

        viewModel.failInitialLoad("vehicle-2", "Honda Civic", "Could not load telemetry.")
        assertFalse(viewModel.uiState.isLoading)
        assertTrue(viewModel.uiState.isError)
        assertEquals("vehicle-2", viewModel.uiState.vehicleId)
        assertEquals("Honda Civic", viewModel.uiState.vehicleLabel)
        assertTrue(viewModel.uiState.records.isEmpty())
    }

    @Test
    fun telemetryRecordsAreSortedNewestFirstWithTimestampParsing() {
        val ordered = RecentTelemetryPresentation.newestFirst(
            listOf(
                record(measuredAt = "malformed", rpm = 700),
                record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900),
                record(measuredAt = "2026-06-18T13:00:00+02:00", rpm = 1100),
                record(measuredAt = "2026-06-18T10:00:00Z", rpm = 1000),
            ),
        )

        assertEquals(listOf(1100, 1000, 900, 700), ordered.map { it.rpm })
    }

    @Test
    fun newestAndOldestRecordsUseChronologicalOrderingSafely() {
        val records = listOf(
            record(measuredAt = "malformed", rpm = 700),
            record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900),
            record(measuredAt = "2026-06-18T11:00:00Z", rpm = 1100),
        )

        assertEquals(1100, RecentTelemetryPresentation.latestRecord(records)?.rpm)
        assertEquals(900, RecentTelemetryPresentation.oldestRecord(records)?.rpm)
    }

    @Test
    fun chronologicalChartSeriesIsOldestFirst() {
        val series = RecentTelemetryPresentation.chartSeries(
            listOf(
                record(measuredAt = "2026-06-18T11:00:00Z", rpm = 1100),
                record(measuredAt = "bad", rpm = 700),
                record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900),
                record(measuredAt = "2026-06-18T10:00:00Z", rpm = 1000),
            ),
            "rpm",
        )

        assertEquals(listOf(900.0, 1000.0, 1100.0, 700.0), series.map { it.value })
    }

    @Test
    fun overviewUsesSharedTimestampLabels() {
        val overview = RecentTelemetryPresentation.overview(
            listOf(
                record(measuredAt = "2026-06-18T12:15:30+02:00", rpm = 1100),
                record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900),
            ),
        )

        assertNotNull(overview)
        assertEquals(2, overview.readingCount)
        assertFalse(overview.oldestTimestamp.contains("2026-06-18T"))
        assertFalse(overview.oldestTimestamp.contains(":00:00"))
        assertFalse(overview.newestTimestamp.contains("2026-06-18T"))
        assertFalse(overview.newestTimestamp.contains("+02:00"))
    }

    @Test
    fun metricStatisticsUseCorrectUnitsAndFormatting() {
        val records = listOf(
            record(
                measuredAt = "2026-06-18T09:00:00Z",
                engineTemperature = 80.0,
                batteryVoltage = 13.5,
                vibrationLevel = 1.0,
                rpm = 1000,
                speed = 40,
                fuelLevel = 60.0,
            ),
            record(
                measuredAt = "2026-06-18T10:00:00Z",
                engineTemperature = 100.0,
                batteryVoltage = 13.7,
                vibrationLevel = 2.0,
                rpm = 2001,
                speed = 71,
                fuelLevel = 79.0,
            ),
        )

        assertEquals("100.0 \u00B0C", stats(records, "engine_temperature").current)
        assertEquals("80.0 \u00B0C", stats(records, "engine_temperature").minimum)
        assertEquals("90.0 \u00B0C", stats(records, "engine_temperature").average)
        assertEquals("13.6 V", stats(records, "battery_voltage").average)
        assertEquals("1.5", stats(records, "vibration_level").average)
        assertEquals("2001 rpm", stats(records, "rpm").current)
        assertEquals("1500.5 rpm", stats(records, "rpm").average)
        assertEquals("71 km/h", stats(records, "speed").current)
        assertEquals("55.5 km/h", stats(records, "speed").average)
        assertEquals("69.5 %", stats(records, "fuel_level").average)
    }

    @Test
    fun oneRecordStatisticsAreSafe() {
        val statistics = stats(
            listOf(record(engineTemperature = 81.24)),
            "engine_temperature",
        )

        assertEquals("81.2 \u00B0C", statistics.current)
        assertEquals("81.2 \u00B0C", statistics.minimum)
        assertEquals("81.2 \u00B0C", statistics.average)
        assertEquals("81.2 \u00B0C", statistics.maximum)
    }

    @Test
    fun equalValueChartInputIsPreservedForSafeRendering() {
        val series = RecentTelemetryPresentation.chartSeries(
            listOf(
                record(measuredAt = "2026-06-18T09:00:00Z", engineTemperature = 80.0),
                record(measuredAt = "2026-06-18T10:00:00Z", engineTemperature = 80.0),
                record(measuredAt = "2026-06-18T11:00:00Z", engineTemperature = 80.0),
            ),
            "engine_temperature",
        )

        assertEquals(listOf(80.0, 80.0, 80.0), series.map { it.value })
    }

    @Test
    fun malformedTimestampsNeverCrashAndKeepRecordsAccessible() {
        val records = listOf(
            record(measuredAt = "bad-one", rpm = 1),
            record(measuredAt = "bad-two", rpm = 2),
        )

        assertEquals(listOf(1, 2), RecentTelemetryPresentation.newestFirst(records).map { it.rpm })
        assertEquals(listOf(1.0, 2.0), RecentTelemetryPresentation.chartSeries(records, "rpm").map { it.value })
        assertEquals("n/a", RecentTelemetryPresentation.overview(records)?.oldestTimestamp)
    }

    @Test
    fun selectedMetricChangesWithoutClearingLoadedData() {
        val viewModel = RecentTelemetryViewModel()
        val records = listOf(record(rpm = 900))
        viewModel.showTelemetry(records = records)

        viewModel.selectMetric("rpm")

        assertEquals("rpm", viewModel.uiState.selectedMetricKey)
        assertEquals(records, viewModel.uiState.records)
        assertFalse(viewModel.uiState.isLoading)
        assertFalse(viewModel.uiState.isRefreshing)
    }

    @Test
    fun unknownMetricSelectionIsIgnored() {
        val viewModel = RecentTelemetryViewModel()
        viewModel.showTelemetry(records = listOf(record()))

        viewModel.selectMetric("unknown_metric")

        assertEquals(RecentTelemetryPresentation.DEFAULT_METRIC_KEY, viewModel.uiState.selectedMetricKey)
    }

    @Test
    fun collapsedAndExpandedHistoryUseLoadedRecordsOnly() {
        val records = (1..7).map { index ->
            record(measuredAt = "2026-06-18T0$index:00:00Z", rpm = index)
        }

        assertEquals(
            listOf(7, 6, 5, 4, 3),
            RecentTelemetryPresentation.historyRecords(records, expanded = false).map { it.rpm },
        )
        assertEquals(
            listOf(7, 6, 5, 4, 3, 2, 1),
            RecentTelemetryPresentation.historyRecords(records, expanded = true).map { it.rpm },
        )
        assertTrue(RecentTelemetryPresentation.canToggleHistory(records))
    }

    @Test
    fun refreshLocksWhileInProgress() {
        val viewModel = RecentTelemetryViewModel()
        viewModel.showTelemetry(
            vehicleId = "vehicle-1",
            vehicleLabel = "Toyota Corolla",
            records = listOf(record()),
        )

        assertTrue(viewModel.startRefresh())
        assertFalse(viewModel.startRefresh())
        assertTrue(viewModel.uiState.isRefreshing)
    }

    @Test
    fun refreshSuccessReplacesRecordsAndPreservesSelectedMetric() {
        val viewModel = RecentTelemetryViewModel()
        viewModel.showTelemetry(records = listOf(record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900)))
        viewModel.selectMetric("rpm")

        assertTrue(viewModel.startRefresh())
        viewModel.finishRefresh(
            listOf(
                record(measuredAt = "2026-06-18T10:00:00Z", rpm = 1000),
                record(measuredAt = "2026-06-18T12:00:00Z", rpm = 1200),
            ),
        )

        assertFalse(viewModel.uiState.isRefreshing)
        assertEquals("rpm", viewModel.uiState.selectedMetricKey)
        assertEquals(listOf(1200, 1000), viewModel.uiState.records.map { it.rpm })
    }

    @Test
    fun refreshFailurePreservesExistingRecordsAndSelectedMetric() {
        val viewModel = RecentTelemetryViewModel()
        val existing = record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900)
        viewModel.showTelemetry(records = listOf(existing))
        viewModel.selectMetric("rpm")

        assertTrue(viewModel.startRefresh())
        viewModel.failRefresh("Network unavailable.")

        assertFalse(viewModel.uiState.isRefreshing)
        assertTrue(viewModel.uiState.isError)
        assertEquals("Network unavailable.", viewModel.uiState.message)
        assertEquals("rpm", viewModel.uiState.selectedMetricKey)
        assertEquals(listOf(existing), viewModel.uiState.records)
    }

    @Test
    fun emptyRecordsAreRepresentedAsSuccessfulEmptyState() {
        val viewModel = RecentTelemetryViewModel()

        viewModel.showTelemetry(vehicleId = "vehicle-1", vehicleLabel = "Toyota Corolla", records = emptyList())

        assertFalse(viewModel.uiState.isLoading)
        assertFalse(viewModel.uiState.isError)
        assertTrue(viewModel.uiState.records.isEmpty())
    }

    @Test
    fun metricFormattingReusesVehicleDetailsFormatting() {
        val metrics = RecentTelemetryPresentation.metrics(
            record(
                engineTemperature = 81.24,
                batteryVoltage = 13.65,
                vibrationLevel = 1.35,
                rpm = 2080,
                speed = 58,
                fuelLevel = 69.44,
            ),
        )

        assertEquals("81.2 \u00B0C", metrics.first { it.first == "Engine temperature" }.second)
        assertEquals("13.7 V", metrics.first { it.first == "Battery voltage" }.second)
        assertEquals("1.4", metrics.first { it.first == "Vibration level" }.second)
        assertEquals("2080", metrics.first { it.first == "RPM" }.second)
        assertEquals("58 km/h", metrics.first { it.first == "Speed" }.second)
        assertEquals("69.4 %", metrics.first { it.first == "Fuel level" }.second)
    }

    @Test
    fun stateRecoversAfterFailedRefresh() {
        val viewModel = RecentTelemetryViewModel()
        viewModel.showTelemetry(records = listOf(record(measuredAt = "2026-06-18T09:00:00Z", rpm = 900)))

        assertTrue(viewModel.startRefresh())
        viewModel.failRefresh("Temporary failure.")
        assertTrue(viewModel.uiState.isError)

        assertTrue(viewModel.startRefresh())
        viewModel.finishRefresh(listOf(record(measuredAt = "2026-06-18T12:00:00Z", rpm = 1200)))

        assertFalse(viewModel.uiState.isError)
        assertEquals(listOf(1200), viewModel.uiState.records.map { it.rpm })
    }

    private fun stats(records: List<TelemetryRecord>, metricKey: String) =
        requireNotNull(RecentTelemetryPresentation.statistics(records, metricKey))

    private fun record(
        measuredAt: String = "2026-06-18T10:00:00Z",
        engineTemperature: Double = 89.9,
        batteryVoltage: Double = 13.7,
        vibrationLevel: Double = 1.4,
        rpm: Int = 2280,
        speed: Int = 58,
        fuelLevel: Double = 69.4,
    ): TelemetryRecord {
        return TelemetryRecord(
            measuredAt = measuredAt,
            engineTemperature = engineTemperature,
            batteryVoltage = batteryVoltage,
            vibrationLevel = vibrationLevel,
            rpm = rpm,
            speed = speed,
            fuelLevel = fuelLevel,
        )
    }
}
