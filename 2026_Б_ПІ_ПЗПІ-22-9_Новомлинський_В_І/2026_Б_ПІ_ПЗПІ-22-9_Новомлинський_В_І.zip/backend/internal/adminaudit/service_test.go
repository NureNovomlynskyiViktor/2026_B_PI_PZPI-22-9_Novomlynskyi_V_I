package adminaudit

import (
	"context"
	"errors"
	"testing"
	"time"
)

const testActorID = "11111111-1111-1111-1111-111111111111"

func TestListDefaultsAndNormalizesFilters(t *testing.T) {
	repository := &repositoryStub{total: 52}
	service := NewService(repository)
	dateFrom := time.Date(2026, 6, 18, 10, 0, 0, 0, time.UTC)
	dateTo := time.Date(2026, 6, 18, 11, 0, 0, 0, time.UTC)

	result, err := service.List(context.Background(), ListFilters{
		Action:      "  user.deactivated  ",
		ActorID:     "  " + testActorID + "  ",
		ActorSearch: "  Admin@Example.com  ",
		EntityType:  "  user  ",
		EntityID:    "  target-user  ",
		DateFrom:    &dateFrom,
		DateTo:      &dateTo,
	})
	if err != nil {
		t.Fatalf("List returned error: %v", err)
	}

	if repository.filters.Action != "user.deactivated" {
		t.Fatalf("unexpected action filter: %q", repository.filters.Action)
	}
	if repository.filters.ActorID != testActorID {
		t.Fatalf("unexpected actor_id filter: %q", repository.filters.ActorID)
	}
	if repository.filters.ActorSearch != "Admin@Example.com" {
		t.Fatalf("unexpected actor_search filter: %q", repository.filters.ActorSearch)
	}
	if repository.filters.EntityType != "user" || repository.filters.EntityID != "target-user" {
		t.Fatalf("unexpected entity filters: %#v", repository.filters)
	}
	if repository.filters.Limit != DefaultLimit || repository.filters.Offset != 0 {
		t.Fatalf("unexpected pagination defaults: %#v", repository.filters)
	}
	if result.Pagination.Limit != DefaultLimit ||
		result.Pagination.Offset != 0 ||
		result.Pagination.Total != 52 ||
		!result.Pagination.HasMore {
		t.Fatalf("unexpected pagination response: %#v", result.Pagination)
	}
}

func TestListRejectsInvalidFilters(t *testing.T) {
	now := time.Date(2026, 6, 18, 11, 0, 0, 0, time.UTC)
	later := now.Add(time.Hour)

	tests := []struct {
		name    string
		filters ListFilters
	}{
		{name: "bad actor id", filters: ListFilters{ActorID: "bad"}},
		{name: "date order", filters: ListFilters{DateFrom: &later, DateTo: &now}},
		{name: "low limit", filters: ListFilters{Limit: -1}},
		{name: "explicit zero limit", filters: ListFilters{Limit: 0, LimitSet: true}},
		{name: "high limit", filters: ListFilters{Limit: MaxLimit + 1}},
		{name: "negative offset", filters: ListFilters{Offset: -1}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := NewService(&repositoryStub{})

			_, err := service.List(context.Background(), tt.filters)
			if !errors.Is(err, ErrInvalidInput) {
				t.Fatalf("expected ErrInvalidInput, got %v", err)
			}
		})
	}
}

func TestListRejectsOverlongTrimmedFilters(t *testing.T) {
	tests := []struct {
		name    string
		filters ListFilters
	}{
		{
			name:    "action",
			filters: ListFilters{Action: "  " + stringOfRunes('a', maxActionLength+1) + "  "},
		},
		{
			name:    "actor search",
			filters: ListFilters{ActorSearch: stringOfRunes('ш', maxActorSearchLength+1)},
		},
		{
			name:    "entity type",
			filters: ListFilters{EntityType: stringOfRunes('e', maxEntityTypeLength+1)},
		},
		{
			name:    "entity id",
			filters: ListFilters{EntityID: stringOfRunes('і', maxEntityIDLength+1)},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := NewService(&repositoryStub{})

			_, err := service.List(context.Background(), tt.filters)
			if !errors.Is(err, ErrInvalidInput) {
				t.Fatalf("expected ErrInvalidInput, got %v", err)
			}
		})
	}
}

func stringOfRunes(value rune, count int) string {
	result := make([]rune, count)
	for index := range result {
		result[index] = value
	}

	return string(result)
}

type repositoryStub struct {
	filters ListFilters
	total   int
	err     error
}

func (r *repositoryStub) List(_ context.Context, filters ListFilters) ([]Log, int, error) {
	r.filters = filters
	if r.err != nil {
		return nil, 0, r.err
	}
	return []Log{{ID: 1}}, r.total, nil
}
