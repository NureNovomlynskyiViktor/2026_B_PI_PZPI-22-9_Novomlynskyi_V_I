# Autonexis Backend

Go backend foundation for the basic functional version of Autonexis.

The current implementation provides:

- environment-based configuration;
- PostgreSQL connection pooling through `database/sql` and the pgx driver;
- structured JSON logging;
- graceful HTTP server startup and shutdown;
- liveness and readiness endpoints;
- read-only API v1 endpoints for vehicles, devices, telemetry, alerts, and current vehicle status;
- explicit threshold evaluation that can create active alerts;
- REST telemetry ingestion for simulating IoT input;
- optional MQTT telemetry consumption through the same ingestion service;
- email/password authentication foundation with JWT access tokens;
- optional Google Sign-In foundation that exchanges verified Google ID tokens for Autonexis JWT access tokens;
- authenticated Google account-linking endpoints for existing Autonexis users;
- protected current-user vehicle, device, telemetry history, alert lifecycle, and threshold visibility endpoints;
- administrator specialist-assignment endpoints for organizational vehicle access management;
- administrator-managed positive competency profiles for technical specialists.

Google unlinking, Google account-linking UI, refresh tokens/logout, user profile editing, role management, broad role-based access control, general CRUD operations, and other business functions are intentionally not implemented yet.

## Requirements

- Go 1.24 or newer;
- Docker Desktop with Docker Compose;
- the PostgreSQL container configured in the repository root `docker-compose.yml`.

PostgreSQL and Mosquitto do not need to be installed directly on Windows.

## Environment variables

The backend reads configuration directly from process environment variables. It does not automatically load `.env` files.

| Variable | Local default | Description |
|---|---|---|
| `APP_ENV` | `local` | Application environment used in logs |
| `HTTP_HOST` | `0.0.0.0` | HTTP server bind address |
| `HTTP_PORT` | `8080` | HTTP server port |
| `POSTGRES_HOST` | `localhost` | PostgreSQL host |
| `POSTGRES_PORT` | `5432` | PostgreSQL port |
| `POSTGRES_DB` | `vehicle_monitoring` | Database name |
| `POSTGRES_USER` | `vehicle_monitoring` | Database user |
| `POSTGRES_PASSWORD` | `change_me` | Database password for local development |
| `POSTGRES_SSLMODE` | `disable` | PostgreSQL SSL mode |
| `MQTT_ENABLED` | `false` | Enables the MQTT telemetry consumer |
| `MQTT_BROKER_HOST` | `localhost` | MQTT broker host used by the Go backend |
| `MQTT_BROKER_PORT` | `1883` | MQTT broker TCP port |
| `MQTT_CLIENT_ID` | `autonexis-backend` | Unique MQTT client identifier |
| `MQTT_TELEMETRY_TOPIC` | `autonexis/devices/+/telemetry` | MQTT telemetry subscription filter |
| `JWT_SECRET` | `local-development-autonexis-change-me` | Secret used to sign JWT access tokens |
| `JWT_ACCESS_TOKEN_TTL` | `1h` | Access token lifetime as a Go duration |
| `CORS_ALLOWED_ORIGINS` | `http://localhost:5173` | Comma-separated browser origins allowed to call the API |
| `GOOGLE_AUTH_ENABLED` | `false` | Enables POST `/api/v1/auth/google` when set to `true` |
| `GOOGLE_OAUTH_CLIENT_IDS` | empty | Comma-separated Google OAuth client IDs accepted as ID-token audiences |

The default database password and JWT secret are intended only for local development. Change `JWT_SECRET` outside local development.

## Start Docker services

From the repository root, start PostgreSQL and Mosquitto:

```powershell
docker-compose --env-file .env.example up -d postgres mosquitto
```

The Compose configuration publishes PostgreSQL on `localhost:5432`. The backend's local defaults match the database name, user, and password from `.env.example`.

The initial database migration must already be applied to the PostgreSQL database. Migration execution is intentionally outside the current backend foundation.

## Development seed

The optional `seeds/dev_seed.sql` file inserts:

- login-ready demo users for `vehicle_owner`, `technical_specialist`, and `administrator`;
- one demo vehicle;
- one demo ESP32 device;
- five telemetry records;
- four vehicle threshold settings;
- three alerts: active warning, active critical, and resolved;
- demo technical specialist competencies;
- one demo specialist assignment for the specialist dashboard.

These accounts are for local development only:

| Email | Role | Password |
|---|---|---|
| `owner@example.com` | `vehicle_owner` | `DemoPass123!` |
| `specialist@example.com` | `technical_specialist` | `DemoPass123!` |
| `specialist.engine@example.com` | `technical_specialist` | `DemoPass123!` |
| `specialist.electrical@example.com` | `technical_specialist` | `DemoPass123!` |
| `admin@example.com` | `administrator` | `DemoPass123!` |

The password hash in the seed is a development-only bcrypt hash. Do not reuse these accounts or this password outside local demonstration.

The seed is separate from migrations and uses stable identifiers:

| Entity | ID |
|---|---|
| Demo owner | `11111111-1111-1111-1111-111111111111` |
| Demo general specialist | `77777777-7777-7777-7777-777777777777` |
| Demo engine specialist | `88888888-8888-8888-8888-888888888888` |
| Demo electrical specialist | `aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa` |
| Demo administrator | `99999999-9999-9999-9999-999999999999` |
| Demo vehicle | `22222222-2222-2222-2222-222222222222` |
| Demo device | `33333333-3333-3333-3333-333333333333` |
| Active warning alert | `44444444-4444-4444-4444-444444444441` |
| Active critical alert | `44444444-4444-4444-4444-444444444442` |
| Resolved alert | `44444444-4444-4444-4444-444444444443` |

After PostgreSQL is running and all migrations have been applied, run these commands from the repository root:

```powershell
docker cp backend/seeds/dev_seed.sql vehicle-monitoring-postgres:/tmp/autonexis_dev_seed.sql
docker exec vehicle-monitoring-postgres psql -U vehicle_monitoring -d vehicle_monitoring -f /tmp/autonexis_dev_seed.sql
```

The seed can be applied repeatedly. It updates demo users, thresholds, competencies, specialist assignment, and the demo alert state so the recommendation scenario can be restored after a demonstration.

Recommended specialists are meaningful with the seed data: the demo vehicle has active engine temperature and vibration alerts, while `specialist.engine@example.com` has `engine_diagnostics` and `vibration_analysis` competencies. This specialist should rank above the general and electrical specialists in the administrator dashboard.

### Local demo workflow

1. Start Docker services:

   ```powershell
   docker-compose --env-file .env.example up -d postgres mosquitto
   ```

2. Apply migrations, including `003_create_specialist_competencies`.
3. Apply the development seed:

   ```powershell
   docker cp backend/seeds/dev_seed.sql vehicle-monitoring-postgres:/tmp/autonexis_dev_seed.sql
   docker exec vehicle-monitoring-postgres psql -U vehicle_monitoring -d vehicle_monitoring -f /tmp/autonexis_dev_seed.sql
   ```

4. Start the backend from the `backend` directory:

   ```powershell
   go run ./cmd/server
   ```

5. Start the web dashboard from the `web` directory:

   ```powershell
   npm run dev
   ```

6. Login as `admin@example.com` with `DemoPass123!` and verify vehicles, specialists, competencies, assignments, and recommended specialists.
7. Login as `specialist@example.com` with `DemoPass123!` and verify the assigned vehicle status and read-only thresholds.
8. Login as `owner@example.com` with `DemoPass123!` and verify the owner demo dashboard.

## Run locally

From the `backend` directory:

```powershell
go mod download
go run ./cmd/server
```

To override configuration for the current PowerShell session:

```powershell
$env:HTTP_PORT = "8081"
$env:POSTGRES_HOST = "localhost"
$env:POSTGRES_SSLMODE = "disable"
go run ./cmd/server
```

Stop the process with `Ctrl+C`. The server will stop accepting new requests and wait briefly for active requests to complete.

## MQTT telemetry consumer

The MQTT consumer is disabled by default, so HTTP development does not depend on broker availability. To enable it for a backend running locally on Windows:

```powershell
$env:MQTT_ENABLED = "true"
$env:MQTT_BROKER_HOST = "localhost"
$env:MQTT_BROKER_PORT = "1883"
$env:MQTT_CLIENT_ID = "autonexis-backend-local"
$env:MQTT_TELEMETRY_TOPIC = "autonexis/devices/+/telemetry"
go run ./cmd/server
```

The consumer subscribes to:

```text
autonexis/devices/+/telemetry
```

The `+` segment is interpreted as `device_uid`. For example:

```text
autonexis/devices/esp32-demo-001/telemetry
```

Payload:

```json
{
  "measured_at": "2026-06-15T14:30:00+03:00",
  "engine_temperature": 98.2,
  "battery_voltage": 13.5,
  "vibration_level": 2.3,
  "rpm": 2700,
  "speed": 75,
  "fuel_level": 62.1
}
```

Publish the message through the existing Mosquitto container. Passing the JSON through standard input avoids PowerShell quote conversion:

```powershell
$mqttPayload = @{
  measured_at = "2026-06-15T14:30:00+03:00"
  engine_temperature = 98.2
  battery_voltage = 13.5
  vibration_level = 2.3
  rpm = 2700
  speed = 75
  fuel_level = 62.1
} | ConvertTo-Json -Compress

$mqttPayload | docker exec -i vehicle-monitoring-mosquitto mosquitto_pub `
  -h localhost `
  -p 1883 `
  -q 1 `
  -t "autonexis/devices/esp32-demo-001/telemetry" `
  -s
```

The backend logs the device UID, inserted telemetry ID, created-alert count, and overall result. Invalid topics or payloads are logged and skipped without stopping the backend.

Verify ingestion:

```powershell
$vehicleId = "22222222-2222-2222-2222-222222222222"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/telemetry/latest"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/status"
```

When the backend runs in another Docker container on the Compose network, use `MQTT_BROKER_HOST=mosquitto`. A locally launched backend should use `localhost` because Mosquitto publishes port `1883` to Windows.

## Health endpoints

### Liveness

```http
GET /health
```

Checks whether the backend process is running:

```powershell
Invoke-RestMethod http://localhost:8080/health
```

Expected response:

```json
{
  "status": "ok",
  "service": "autonexis-backend"
}
```

### Readiness

```http
GET /ready
```

Checks whether PostgreSQL is available through `PingContext`:

```powershell
Invoke-RestMethod http://localhost:8080/ready
```

Ready response with HTTP status `200`:

```json
{
  "status": "ready",
  "database": "ok"
}
```

If PostgreSQL is unavailable, the endpoint returns HTTP status `503`:

```json
{
  "status": "not_ready",
  "database": "unavailable"
}
```

## API v1

The current API reads data from the existing `vehicles`, `devices`, `telemetry_records`, and `alerts` PostgreSQL tables.

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/vehicles` | List all vehicles |
| `GET` | `/api/v1/vehicles/{id}` | Get one vehicle by UUID |
| `GET` | `/api/v1/devices` | List all devices |
| `GET` | `/api/v1/devices/{id}` | Get one device by UUID |
| `GET` | `/api/v1/vehicles/{vehicle_id}/telemetry` | List vehicle telemetry, newest first |
| `GET` | `/api/v1/vehicles/{vehicle_id}/telemetry/latest` | Get the latest vehicle telemetry record |
| `GET` | `/api/v1/vehicles/{vehicle_id}/alerts` | List vehicle alerts, newest first |
| `GET` | `/api/v1/vehicles/{vehicle_id}/alerts/active` | List active vehicle alerts |
| `GET` | `/api/v1/alerts/{id}` | Get one alert by UUID |
| `GET` | `/api/v1/vehicles/{vehicle_id}/status` | Get the combined current vehicle status |
| `POST` | `/api/v1/vehicles/{vehicle_id}/alerts/evaluate` | Evaluate latest telemetry and create missing active alerts |
| `POST` | `/api/v1/devices/{device_uid}/telemetry` | Save device telemetry and evaluate alerts |
| `POST` | `/api/v1/auth/register` | Register a user with the `vehicle_owner` role |
| `POST` | `/api/v1/auth/login` | Login with email and password |
| `POST` | `/api/v1/auth/google` | Exchange a verified Google ID token for an Autonexis JWT |
| `GET` | `/api/v1/auth/methods` | Return password/Google authentication-method status for the current user |
| `POST` | `/api/v1/auth/google/link` | Link a verified Google identity to the current authenticated user |
| `GET` | `/api/v1/auth/me` | Return the current user from a Bearer token |
| `GET` | `/api/v1/me/vehicles` | List vehicles owned by the current user |
| `POST` | `/api/v1/me/vehicles` | Create a vehicle owned by the current user |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}` | Get one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/status` | Get current status for one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/devices` | List devices assigned to one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/telemetry` | List telemetry history for one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/alerts` | List alerts for one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/alerts/active` | List active alerts for one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/thresholds` | List read-only threshold rules for one current-user vehicle |
| `GET` | `/api/v1/me/vehicles/{vehicle_id}/specialists` | List technical specialists assigned to one current-user vehicle |
| `POST` | `/api/v1/me/vehicles/{vehicle_id}/specialists` | Assign a technical specialist to one current-user vehicle |
| `DELETE` | `/api/v1/me/vehicles/{vehicle_id}/specialists/{specialist_id}` | Remove a specialist assignment from one current-user vehicle |
| `POST` | `/api/v1/me/vehicles/{vehicle_id}/devices` | Create a device assigned to one current-user vehicle |
| `GET` | `/api/v1/me/devices` | List all devices assigned to current-user vehicles |
| `GET` | `/api/v1/me/devices/{device_id}` | Get one current-user device |
| `GET` | `/api/v1/specialist/vehicles` | List vehicles assigned to the current technical specialist |
| `GET` | `/api/v1/specialist/vehicles/{vehicle_id}/status` | Get status for an assigned specialist vehicle |
| `GET` | `/api/v1/specialist/vehicles/{vehicle_id}/thresholds` | Get read-only thresholds for an assigned specialist vehicle |
| `GET` | `/api/v1/admin/vehicles` | List all vehicles for administrator assignment management |
| `GET` | `/api/v1/admin/specialists` | List active users with the `technical_specialist` role |
| `GET` | `/api/v1/admin/specialists/{specialist_id}/competencies` | List competencies for one technical specialist |
| `PUT` | `/api/v1/admin/specialists/{specialist_id}/competencies` | Replace competencies for one technical specialist |
| `GET` | `/api/v1/admin/vehicles/{vehicle_id}/specialists` | List specialists assigned to a vehicle |
| `GET` | `/api/v1/admin/vehicles/{vehicle_id}/recommended-specialists` | List advisory specialist recommendations for a vehicle |
| `POST` | `/api/v1/admin/vehicles/{vehicle_id}/specialists` | Assign a technical specialist to a vehicle |
| `DELETE` | `/api/v1/admin/vehicles/{vehicle_id}/specialists/{specialist_id}` | Remove a specialist assignment from a vehicle |

### Authentication

Registration always assigns the `vehicle_owner` role from the `roles` table. The client cannot choose `administrator` or `technical_specialist` during registration. Existing telemetry, status, device, vehicle, and alert endpoints remain public in this step. `/api/v1/auth/me` and `/api/v1/me/...` endpoints require a Bearer token.

Auth responses and `/api/v1/auth/me` include the user's role code in the `role` field. The web dashboard uses that field to render the owner, technical specialist, or administrator workspace.

Register:

```powershell
$registerBody = @{
  email = "user@example.com"
  password = "StrongPassword123!"
  first_name = "Viktor"
  last_name = "Novomlynskyi"
} | ConvertTo-Json

$registerResponse = Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/auth/register" `
  -ContentType "application/json" `
  -Body $registerBody

$registerResponse
```

Login:

```powershell
$loginBody = @{
  email = "user@example.com"
  password = "StrongPassword123!"
} | ConvertTo-Json

$loginResponse = Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/auth/login" `
  -ContentType "application/json" `
  -Body $loginBody

$token = $loginResponse.access_token
```


Google Sign-In:

```powershell
$googleBody = @{
  id_token = "google-id-token-from-google-client"
} | ConvertTo-Json

$googleResponse = Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/auth/google" `
  -ContentType "application/json" `
  -Body $googleBody

$googleToken = $googleResponse.access_token
```

Google Sign-In is disabled by default. Enable it only after configuring Google OAuth client IDs:

```powershell
$env:GOOGLE_AUTH_ENABLED = "true"
$env:GOOGLE_OAUTH_CLIENT_IDS = "web-client-id.apps.googleusercontent.com,android-client-id.apps.googleusercontent.com"
```

The backend verifies Google ID-token signatures, expiry, issuer, and audience using the configured client IDs. The accepted issuers are `accounts.google.com` and `https://accounts.google.com`. The `sub` claim is stored as the Google `provider_account_id`; email is never used as the external identity key. New Google users are created as active `vehicle_owner` accounts with `password_hash = NULL`. Existing users with the same email are not linked automatically and receive `409 Conflict`; they must first sign in with their existing Autonexis method and then use the authenticated Google linking endpoint. No Google client secret is required for ID-token verification, and raw ID tokens must not be logged.

Authentication method status:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/auth/methods" `
  -Headers @{ Authorization = "Bearer $token" }
```

Example response:

```json
{
  "password_enabled": true,
  "google_linked": false
}
```

Authenticated Google account linking:

```powershell
$linkBody = @{
  id_token = "google-id-token-from-google-client"
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/auth/google/link" `
  -Headers @{ Authorization = "Bearer $token" } `
  -ContentType "application/json" `
  -Body $linkBody
```

Google linking requires an existing authenticated Autonexis session and never creates a new user, changes the current role, changes account ownership, or merges users automatically. The verified Google email must match the current Autonexis account email case-insensitively. A Google identity already linked to another user returns `409 Conflict`, and a user already linked to a different Google identity also returns `409 Conflict`. Unlinking is intentionally not supported in this foundation step.
Get current user:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/auth/me" `
  -Headers @{ Authorization = "Bearer $token" }
```

Example auth response:

```json
{
  "user": {
    "id": "generated-user-uuid",
    "role_id": "00000000-0000-0000-0000-000000000001",
    "role": "vehicle_owner",
    "email": "user@example.com",
    "full_name": "Viktor Novomlynskyi",
    "is_active": true,
    "created_at": "2026-06-16T10:00:00Z",
    "updated_at": "2026-06-16T10:00:00Z"
  },
  "access_token": "jwt-access-token",
  "token_type": "Bearer",
  "expires_at": 1781607600
}
```

Duplicate registration returns `409`. Invalid login returns `401` without revealing whether the email or password was wrong. Missing, invalid, or expired Bearer tokens for protected endpoints return `401`. Password hashes are never returned in API responses.

### Current user's vehicles

The `/api/v1/me/vehicles` endpoints are protected with the JWT Bearer token. They only return or modify vehicles where `vehicles.owner_id` matches the current authenticated user. If a vehicle exists but belongs to another user, the API returns `404`.

Create a vehicle for the current user:

```powershell
$vehicleBody = @{
  vin = "TESTVIN0000000001"
  brand = "Toyota"
  model = "Corolla"
  year = 2020
  license_plate = "AA1234BB"
} | ConvertTo-Json

$createdVehicle = Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/me/vehicles" `
  -Headers @{ Authorization = "Bearer $token" } `
  -ContentType "application/json" `
  -Body $vehicleBody

$createdVehicle
```

List the current user's vehicles:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles" `
  -Headers @{ Authorization = "Bearer $token" }
```

Get the created vehicle:

```powershell
$ownedVehicleId = $createdVehicle.id

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId" `
  -Headers @{ Authorization = "Bearer $token" }
```

Get current status for the created vehicle:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/status" `
  -Headers @{ Authorization = "Bearer $token" }
```

Vehicle creation requires `vin`, `brand`, `model`, `year`, and `license_plate`. The year must be between `1886` and `2100`. Duplicate VIN values return `409` when the database unique constraint is triggered. Invalid vehicle UUIDs return `400`; missing or invalid Bearer tokens return `401`.

### Current user's devices

The `/api/v1/me/.../devices` endpoints are protected with the same JWT Bearer token. A user can create and view devices only for vehicles where `vehicles.owner_id` matches the current authenticated user. If a vehicle or device exists but belongs to another user, the API returns `404`.

Create a device for the current user's vehicle:

```powershell
$deviceBody = @{
  device_uid = "esp32-user-001"
  name = "My ESP32"
} | ConvertTo-Json

$createdDevice = Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/devices" `
  -Headers @{ Authorization = "Bearer $token" } `
  -ContentType "application/json" `
  -Body $deviceBody

$createdDevice
```

List devices for the current user's vehicle:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/devices" `
  -Headers @{ Authorization = "Bearer $token" }
```

List all current-user devices:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/devices" `
  -Headers @{ Authorization = "Bearer $token" }
```

Get the created device:

```powershell
$ownedDeviceId = $createdDevice.id

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/devices/$ownedDeviceId" `
  -Headers @{ Authorization = "Bearer $token" }
```

Device creation requires `device_uid` and `name`. Device UIDs must match `^[A-Za-z0-9_-]{3,64}$`. New devices are created with status `active`. Duplicate `device_uid` values return `409`. Invalid vehicle or device UUIDs return `400`; missing or invalid Bearer tokens return `401`.

Telemetry for the created device can be sent through REST:

```powershell
$telemetryBody = @{
  measured_at = "2026-06-15T14:00:00+03:00"
  engine_temperature = 92.5
  battery_voltage = 13.8
  vibration_level = 1.8
  rpm = 2200
  speed = 64
  fuel_level = 70.0
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/devices/$($createdDevice.device_uid)/telemetry" `
  -ContentType "application/json" `
  -Body $telemetryBody
```

For MQTT ingestion, publish telemetry to:

```text
autonexis/devices/{device_uid}/telemetry
```

For the example above:

```text
autonexis/devices/esp32-user-001/telemetry
```

List protected telemetry history for the current user's vehicle:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/telemetry?limit=50" `
  -Headers @{ Authorization = "Bearer $token" }
```

The protected telemetry endpoint verifies that the vehicle belongs to the current authenticated user before returning records. Records are sorted by `measured_at` descending. The default limit is `50`, and the maximum is `200`. Missing or invalid Bearer tokens return `401`; invalid vehicle UUIDs return `400`; another user's vehicle returns `404`.

List active protected alerts for the current user's vehicle:

```powershell
$activeAlerts = Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/alerts/active" `
  -Headers @{ Authorization = "Bearer $token" }

$activeAlerts
```

Vehicle owners cannot resolve alert incidents. Cleared incidents remain visible
until a technical specialist confirms resolution. Owners should create and track
service requests when an alert needs inspection:

```powershell
$alertId = $activeAlerts[0].id

Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/service-requests" `
  -Headers @{ Authorization = "Bearer $token" } `
  -ContentType "application/json" `
  -Body (@{
    title = "Inspect active alert"
    description = "Please inspect the vehicle condition reported by the alert."
    priority = "normal"
    source_alert_id = $alertId
  } | ConvertTo-Json)
```

Missing or invalid Bearer tokens return `401`; invalid UUIDs return `400`; another user's vehicle or alert returns `404`.

List read-only threshold rules for the current user's vehicle:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/thresholds" `
  -Headers @{ Authorization = "Bearer $token" }
```

Example response:

```json
[
  {
    "id": "55555555-5555-5555-5555-555555555551",
    "vehicle_id": "22222222-2222-2222-2222-222222222222",
    "parameter": "engine_temperature",
    "metric": "Engine temperature",
    "severity": "warning",
    "rule_type": "engine_temperature_warning",
    "value": 90,
    "unit": "C",
    "description": "Warning limit for engine temperature.",
    "created_at": "2026-06-15T09:15:00Z",
    "updated_at": "2026-06-15T09:15:00Z"
  }
]
```

Thresholds are technical monitoring limits. Vehicle owners can view them to understand what is monitored, but this backend step does not provide threshold editing. Editing is planned for future `technical_specialist` and `administrator` workflows with a safer access model.

Assign a technical specialist to the current user's vehicle:

```powershell
$specialistBody = @{
  email = "specialist@example.com"
} | ConvertTo-Json

$assignment = Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/specialists" `
  -Headers @{ Authorization = "Bearer $token" } `
  -ContentType "application/json" `
  -Body $specialistBody

$assignment
```

List assigned specialists:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/specialists" `
  -Headers @{ Authorization = "Bearer $token" }
```

Remove a specialist assignment:

```powershell
Invoke-RestMethod `
  -Method Delete `
  -Uri "http://localhost:8080/api/v1/me/vehicles/$ownedVehicleId/specialists/$($assignment.specialist_id)" `
  -Headers @{ Authorization = "Bearer $token" }
```

Only users with the `technical_specialist` role can be assigned. Assigning a `vehicle_owner` user returns `400`, and duplicate assignments return `409`.

For local development, registration still creates `vehicle_owner` users. To convert a local test account into a technical specialist after registering it, run:

```powershell
docker exec vehicle-monitoring-postgres psql `
  -U vehicle_monitoring `
  -d vehicle_monitoring `
  -c "UPDATE users SET role_id = (SELECT id FROM roles WHERE code = 'technical_specialist') WHERE email = 'specialist@example.com';"
```

Specialist access endpoints require a Bearer token for a user whose role is `technical_specialist`:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/specialist/vehicles" `
  -Headers @{ Authorization = "Bearer $specialistToken" }

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/specialist/vehicles/$ownedVehicleId/status" `
  -Headers @{ Authorization = "Bearer $specialistToken" }

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/specialist/vehicles/$ownedVehicleId/thresholds" `
  -Headers @{ Authorization = "Bearer $specialistToken" }

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/specialist/vehicles/$ownedVehicleId/telemetry?limit=50" `
  -Headers @{ Authorization = "Bearer $specialistToken" }

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/specialist/vehicles/$ownedVehicleId/alerts?status=all&limit=50" `
  -Headers @{ Authorization = "Bearer $specialistToken" }

$body = @{
  resolution_note = "Cooling system repaired and verified during inspection."
  service_request_id = "66666666-6666-6666-6666-666666666666"
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Patch `
  -Uri "http://localhost:8080/api/v1/specialist/alerts/$clearedAlertId/resolve" `
  -Headers @{ Authorization = "Bearer $specialistToken" } `
  -ContentType "application/json" `
  -Body $body
```

Specialists can access only assigned vehicles. Unassigned vehicles return `404`, and users without the `technical_specialist` role receive `403`. Thresholds, telemetry history, and alert history are read-only. A technical specialist may confirm resolution only for a `cleared` alert on a directly assigned vehicle. The `resolution_note` is required and must be 10 to 2000 characters. If `service_request_id` is provided, it must be a completed service request for the same vehicle, linked to the same alert, and assigned to the requesting specialist.

### Administrator user lifecycle

Administrator user-management endpoints require a Bearer token for an active user with the `administrator` role:

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/admin/users` | List users, optionally filtered by `role`, `is_active`, and `search` |
| `GET` | `/api/v1/admin/users/{user_id}` | Get one user profile for administration |
| `PATCH` | `/api/v1/admin/users/{user_id}/deactivate` | Deactivate a user without deleting historical data |
| `PATCH` | `/api/v1/admin/users/{user_id}/reactivate` | Reactivate a previously deactivated user |

Deactivation sets `users.is_active = false`, records `deactivated_at`, and leaves vehicles, alerts, notifications, maintenance records, service requests, and historical specialist assignments intact. Reactivation sets `is_active = true` and clears `deactivated_at`; the user can log in again with their existing credentials.

Administrators cannot deactivate their own account, and the system never allows the number of active administrator accounts to become zero. A technical specialist cannot be deactivated while they have service requests in `assigned` or `in_progress`. Inactive technical specialists are excluded from new assignment candidate lists and cannot be assigned directly by ID or email, while historical assignments remain visible.

Each successful deactivation or reactivation writes an `audit_logs` record in the same PostgreSQL transaction as the user status change. Audit metadata includes the target email, target role, previous/new active state, deactivation timestamps, and the optional deactivation reason. If the audit insert fails, the user status change rolls back too.

Administrators can inspect audit history with `GET /api/v1/admin/audit-logs`. The endpoint is read-only and supports `action`, `actor_id`, `actor_search`, `entity_type`, `entity_id`, `date_from`, `date_to`, `limit`, and `offset` query filters. It returns newest records first in `items` with nullable actor context, JSON metadata, and pagination details. Audit read access does not expose password hashes, OAuth identities, or other authentication secrets.

Administrative service-request assignment, reassignment, and cancellation are also recorded as `service_request.assigned`, `service_request.reassigned`, and `service_request.cancelled` audit actions. These records use `entity_type = service_request` and include non-sensitive request context such as vehicle, owner, title, priority, status transition, and previous/new specialist identifiers.

Administrator vehicle onboarding writes `vehicle.activation_created` with `entity_type = vehicle`. Metadata includes vehicle and device identifiers, VIN, brand, model, year, license plate, activation record ID, activation expiration, and default threshold count; it never includes the plaintext activation code or activation-code hash.

Specialist-confirmed alert resolution writes `alert.resolution_confirmed` with `entity_type = alert`. Metadata includes alert, vehicle, severity, status transition, occurrence count, cleared/resolved timestamps, the confirming specialist, optional linked service request, and resolution-note length.

Hard deletion of users is intentionally unsupported. A later privacy-oriented anonymization workflow may be added separately for cases where personal data must be minimized while preserving required operational history.

### Administrator specialist assignment

Administrator endpoints require a Bearer token for a user whose role is `administrator`. Users without the administrator role receive `403`.

For local development, registration still creates `vehicle_owner` users. To convert a local test account into an administrator after registering it, run:

```powershell
docker exec vehicle-monitoring-postgres psql `
  -U vehicle_monitoring `
  -d vehicle_monitoring `
  -c "UPDATE users SET role_id = (SELECT id FROM roles WHERE code = 'administrator') WHERE email = 'admin@example.com';"
```

List vehicles and technical specialists:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/admin/vehicles" `
  -Headers @{ Authorization = "Bearer $adminToken" }

Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/admin/specialists" `
  -Headers @{ Authorization = "Bearer $adminToken" }
```

Assign a technical specialist to a vehicle:

```powershell
$adminAssignmentBody = @{
  specialist_id = $specialistUserId
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/admin/vehicles/$ownedVehicleId/specialists" `
  -Headers @{ Authorization = "Bearer $adminToken" } `
  -ContentType "application/json" `
  -Body $adminAssignmentBody
```

The assignment request also accepts `email` instead of `specialist_id`:

```json
{
  "email": "specialist@example.com"
}
```

List and remove assigned specialists:

```powershell
$adminAssignments = Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/admin/vehicles/$ownedVehicleId/specialists" `
  -Headers @{ Authorization = "Bearer $adminToken" }

Invoke-RestMethod `
  -Method Delete `
  -Uri "http://localhost:8080/api/v1/admin/vehicles/$ownedVehicleId/specialists/$($adminAssignments[0].specialist_id)" `
  -Headers @{ Authorization = "Bearer $adminToken" }
```

Only existing users with the `technical_specialist` role can be assigned. Unknown vehicles or specialists return `404`, invalid UUIDs return `400`, and duplicate assignments return `409`. The assignment endpoints reuse the existing `vehicle_specialist_assignments` table. Threshold editing is planned later.

### Recommended specialists

Recommended specialists are advisory only. The backend does not assign specialists automatically; the administrator still makes the final assignment decision. The recommendation logic is rule-based and uses only positive specialist competencies, not weaknesses. No AI/ML is used.

List recommended specialists for a vehicle:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/admin/vehicles/$ownedVehicleId/recommended-specialists" `
  -Headers @{ Authorization = "Bearer $adminToken" }
```

The service uses active alerts for the selected vehicle and maps alert types to competencies:

| Alert type | Competency |
|---|---|
| `engine_temperature`, `coolant_temperature`, `rpm` | `engine_diagnostics` |
| `battery_voltage` | `battery_and_electrical` |
| `vibration_level` | `vibration_analysis` |
| `fuel_level` | `fuel_system` |
| device, offline, or sensor-related alerts | `iot_device_setup` |
| other alert types | `general_maintenance` |

Scoring is intentionally simple:

- `+50` for each competency that matches active alerts;
- fallback score for `general_maintenance` or `iot_device_setup` when there are no active alerts;
- small penalty for existing assignment count;
- already assigned specialists are still returned and marked with `already_assigned`.

Example response:

```json
[
  {
    "specialist": {
      "id": "generated-specialist-uuid",
      "role": "technical_specialist",
      "email": "specialist@example.com",
      "full_name": "Technical Specialist",
      "is_active": true
    },
    "competencies": [
      {
        "code": "engine_diagnostics",
        "name": "Engine diagnostics"
      }
    ],
    "score": 50,
    "matched_competencies": ["engine_diagnostics"],
    "reasons": ["Matches active engine temperature alert"],
    "active_assignment_count": 2,
    "already_assigned": false
  }
]
```

Invalid vehicle UUIDs return `400`, unknown vehicles return `404`, and users without the administrator role receive `403`.

### Specialist competencies

Specialist competencies are positive strong sides managed by administrators. They do not describe weaknesses. The rule-based recommendation endpoint uses these competencies together with active vehicle alerts to suggest suitable technical specialists.

Supported competency codes:

| Code | Name |
|---|---|
| `engine_diagnostics` | Engine diagnostics |
| `battery_and_electrical` | Battery and electrical systems |
| `vibration_analysis` | Vibration analysis |
| `fuel_system` | Fuel system |
| `general_maintenance` | General maintenance |
| `iot_device_setup` | IoT device setup |

List competencies for a technical specialist:

```powershell
Invoke-RestMethod `
  -Method Get `
  -Uri "http://localhost:8080/api/v1/admin/specialists/$specialistUserId/competencies" `
  -Headers @{ Authorization = "Bearer $adminToken" }
```

Replace competencies for a technical specialist:

```powershell
$competencyBody = @{
  codes = @(
    "engine_diagnostics",
    "vibration_analysis"
  )
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Put `
  -Uri "http://localhost:8080/api/v1/admin/specialists/$specialistUserId/competencies" `
  -Headers @{ Authorization = "Bearer $adminToken" } `
  -ContentType "application/json" `
  -Body $competencyBody
```

The `PUT` request replaces the full competency list for that specialist. Unknown specialists return `404`, invalid UUIDs return `400`, and unsupported competency codes return `400`. Users without the administrator role receive `403`.

This feature uses the `specialist_competencies` table introduced in migration `003_create_specialist_competencies`. The table is intentionally separate from vehicle assignment data because competencies describe the specialist profile, not a single vehicle relationship.

List vehicles:

```powershell
Invoke-RestMethod http://localhost:8080/api/v1/vehicles
```

Get a vehicle by ID:

```powershell
$vehicleId = "22222222-2222-2222-2222-222222222222"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId"
```

List devices:

```powershell
Invoke-RestMethod http://localhost:8080/api/v1/devices
```

Get a device by ID:

```powershell
$deviceId = "33333333-3333-3333-3333-333333333333"
Invoke-RestMethod "http://localhost:8080/api/v1/devices/$deviceId"
```

List telemetry for the demo vehicle:

```powershell
$vehicleId = "22222222-2222-2222-2222-222222222222"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/telemetry"
```

Use the optional `limit` query parameter:

```powershell
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/telemetry?limit=3"
```

The default limit is `50`; the accepted range is `1` to `200`.

Get the latest telemetry record:

```powershell
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/telemetry/latest"
```

Telemetry list requests return an empty JSON array when no records exist. An invalid telemetry `vehicle_id` or `limit` returns HTTP status `400`. The latest endpoint returns `404` when no telemetry exists for the vehicle. Unexpected database errors are logged internally and returned as HTTP status `500` with a generic JSON error.

List alerts for the demo vehicle:

```powershell
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/alerts"
```

Use the optional `limit` query parameter:

```powershell
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/alerts?limit=2"
```

List active alerts:

```powershell
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/alerts/active"
```

Get the active warning alert:

```powershell
$alertId = "44444444-4444-4444-4444-444444444441"
Invoke-RestMethod "http://localhost:8080/api/v1/alerts/$alertId"
```

Alert lists return an empty JSON array when no records exist. An invalid alert `vehicle_id`, alert UUID, or `limit` returns HTTP status `400`. An unknown valid alert UUID returns `404`.

Get the current status of the demo vehicle:

```powershell
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/status"
```

Example response:

```json
{
  "vehicle": {
    "id": "22222222-2222-2222-2222-222222222222",
    "owner_id": "11111111-1111-1111-1111-111111111111",
    "vin": "DEMOAUTONEXIS0001",
    "brand": "Autonexis",
    "model": "Demo Car",
    "year": 2024,
    "license_plate": "DEMO-001",
    "created_at": "2026-06-15T09:05:00Z",
    "updated_at": "2026-06-15T09:05:00Z"
  },
  "device": {
    "id": "33333333-3333-3333-3333-333333333333",
    "vehicle_id": "22222222-2222-2222-2222-222222222222",
    "device_uid": "esp32-demo-001",
    "name": "Demo ESP32",
    "status": "active",
    "last_seen_at": "2026-06-15T10:20:00Z",
    "created_at": "2026-06-15T09:10:00Z",
    "updated_at": "2026-06-15T10:20:00Z"
  },
  "latest_telemetry": {
    "id": 5,
    "vehicle_id": "22222222-2222-2222-2222-222222222222",
    "device_id": "33333333-3333-3333-3333-333333333333",
    "measured_at": "2026-06-15T10:20:00Z",
    "received_at": "2026-06-15T10:20:01Z",
    "engine_temperature": 94.1,
    "battery_voltage": 13.7,
    "vibration_level": 1.9,
    "rpm": 2400,
    "speed": 70,
    "fuel_level": 65.7
  },
  "active_alerts": [
    {
      "id": "44444444-4444-4444-4444-444444444442",
      "vehicle_id": "22222222-2222-2222-2222-222222222222",
      "telemetry_record_id": 4,
      "type": "vibration_level",
      "severity": "critical",
      "current_severity": "critical",
      "status": "active",
      "message": "Vehicle vibration reached a critical level.",
      "recommendation": "Stop the vehicle safely and inspect the engine and mounting components.",
      "occurrence_count": 1,
      "recovery_streak": 0,
      "created_at": "2026-06-15T10:17:00Z",
      "last_triggered_at": "2026-06-15T10:20:01Z",
      "cleared_at": null,
      "resolved_at": null
    }
  ],
  "overall_status": "critical"
}
```

The overall status is `critical` when any active alert has `current_severity = critical`, otherwise `warning` when any active alert has `current_severity = warning`, and `normal` when neither exists. The historical `severity` field stores the maximum severity reached during the incident and does not decrease after a critical-to-warning downgrade. If the vehicle has no assigned device or telemetry, the corresponding response field is `null`. Invalid vehicle UUIDs return `400`; unknown vehicles return `404`.

Evaluate the latest telemetry against the demo vehicle thresholds:

```powershell
$vehicleId = "22222222-2222-2222-2222-222222222222"
Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/vehicles/$vehicleId/alerts/evaluate"
```

Example first-call response:

```json
{
  "vehicle_id": "22222222-2222-2222-2222-222222222222",
  "telemetry_record_id": 5,
  "evaluated_rules": 4,
  "created_alerts": [
    {
      "id": "66666666-6666-6666-6666-666666666666",
      "vehicle_id": "22222222-2222-2222-2222-222222222222",
      "telemetry_record_id": 5,
      "type": "rpm",
      "severity": "warning",
      "current_severity": "warning",
      "status": "active",
      "message": "rpm reached warning level (measured value: 2400.000).",
      "recommendation": "Reduce vehicle load and monitor rpm; schedule an inspection if the condition persists.",
      "occurrence_count": 1,
      "recovery_streak": 0,
      "created_at": "2026-06-15T12:00:00Z",
      "last_triggered_at": "2026-06-15T12:00:00Z",
      "cleared_at": null,
      "resolved_at": null
    }
  ],
  "existing_alerts": [
    {
      "id": "44444444-4444-4444-4444-444444444441",
      "vehicle_id": "22222222-2222-2222-2222-222222222222",
      "telemetry_record_id": 3,
      "type": "engine_temperature",
      "severity": "warning",
      "current_severity": "warning",
      "status": "active",
      "message": "Engine temperature is above the warning threshold.",
      "recommendation": "Reduce engine load and monitor the temperature.",
      "occurrence_count": 1,
      "recovery_streak": 0,
      "created_at": "2026-06-15T10:12:00Z",
      "last_triggered_at": "2026-06-15T10:12:00Z",
      "cleared_at": null,
      "resolved_at": null
    },
    {
      "id": "44444444-4444-4444-4444-444444444442",
      "vehicle_id": "22222222-2222-2222-2222-222222222222",
      "telemetry_record_id": 4,
      "type": "vibration_level",
      "severity": "critical",
      "current_severity": "critical",
      "status": "active",
      "message": "Vehicle vibration reached a critical level.",
      "recommendation": "Stop the vehicle safely and inspect the engine and mounting components.",
      "occurrence_count": 1,
      "recovery_streak": 0,
      "created_at": "2026-06-15T10:17:00Z",
      "last_triggered_at": "2026-06-15T10:17:00Z",
      "cleared_at": null,
      "resolved_at": null
    }
  ],
  "overall_result": "critical"
}
```

The current database schema has no `is_active` column in `threshold_settings`, so every threshold row assigned to the vehicle is evaluated. The evaluator checks `critical_value` before `warning_value`. Higher values are worse for engine temperature, vibration, RPM, and speed; lower values are worse for battery voltage and fuel level.

Threshold rows also define `recovery_margin` and `recovery_samples`. Higher-is-worse parameters recover only after consecutive samples at or below `warning_value - recovery_margin`; lower-is-worse parameters recover only after consecutive samples at or above `warning_value + recovery_margin`. Values between the warning threshold and the recovery threshold remain active because of hysteresis. The default recovery sample count is 3, with allowed values from 1 to 10.

Alerts are now tracked as incidents. A warning or critical violation creates one active incident for the vehicle and telemetry parameter when no non-resolved incident exists. Repeated violation samples update that same incident without duplicate alerts or notifications. `current_severity` may move from critical back to warning, but `severity` remains the maximum severity reached. Recovery samples increment `recovery_streak`; when the configured sample count is reached, the incident becomes `cleared`, `current_severity` is set to `null`, and `cleared_at` is recorded. If a cleared incident violates again, the same alert ID is reopened, `occurrence_count` increments, and maximum severity is preserved. A manually `resolved` incident is terminal, so a later violation creates a new alert. Invalid vehicle UUIDs return `400`; unknown vehicles and vehicles without telemetry return `404`.

Vehicle owners can view active, cleared, and resolved alert incidents and create service requests for inspection, but they cannot resolve incidents. Technical specialists confirm resolution through `PATCH /api/v1/specialist/alerts/{alert_id}/resolve`; this stores `resolved_by_user_id`, `resolution_note`, and optional `resolution_service_request_id`. Already resolved alerts are returned unchanged. Alert listing filters accept `status=active`, `status=cleared`, `status=resolved`, or `status=all`.

### Telemetry ingestion

The REST ingestion endpoint simulates the future ESP32/MQTT input flow. It resolves the device by `device_uid`, stores telemetry for its linked vehicle, updates the device `last_seen_at`, and evaluates the saved record against vehicle thresholds.

```powershell
$deviceUid = "esp32-demo-001"
$body = @{
  measured_at = "2026-06-15T14:00:00+03:00"
  engine_temperature = 96.5
  battery_voltage = 13.6
  vibration_level = 2.1
  rpm = 2600
  speed = 72
  fuel_level = 63.5
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:8080/api/v1/devices/$deviceUid/telemetry" `
  -ContentType "application/json" `
  -Body $body
```

Successful ingestion returns HTTP status `201`:

```json
{
  "telemetry": {
    "id": 6,
    "vehicle_id": "22222222-2222-2222-2222-222222222222",
    "device_id": "33333333-3333-3333-3333-333333333333",
    "measured_at": "2026-06-15T14:00:00+03:00",
    "received_at": "2026-06-15T20:49:12+03:00",
    "engine_temperature": 96.5,
    "battery_voltage": 13.6,
    "vibration_level": 2.1,
    "rpm": 2600,
    "speed": 72,
    "fuel_level": 63.5
  },
  "created_alerts": [
    {
      "id": "66666666-6666-6666-6666-666666666666",
      "vehicle_id": "22222222-2222-2222-2222-222222222222",
      "telemetry_record_id": 6,
      "type": "rpm",
      "severity": "warning",
      "status": "active",
      "message": "rpm reached warning level (measured value: 2600.000).",
      "recommendation": "Reduce vehicle load and monitor rpm; schedule an inspection if the condition persists.",
      "created_at": "2026-06-15T20:49:12+03:00",
      "resolved_at": null
    }
  ],
  "existing_alerts": [
    {
      "id": "44444444-4444-4444-4444-444444444442",
      "vehicle_id": "22222222-2222-2222-2222-222222222222",
      "telemetry_record_id": 4,
      "type": "vibration_level",
      "severity": "critical",
      "status": "active",
      "message": "Vehicle vibration reached a critical level.",
      "recommendation": "Stop the vehicle safely and inspect the engine and mounting components.",
      "created_at": "2026-06-15T10:17:00Z",
      "resolved_at": null
    }
  ],
  "overall_result": "critical"
}
```

`measured_at` is optional and defaults to the server receipt time. When provided, it must be RFC 3339 and cannot be more than five minutes in the future. The numeric ranges match the PostgreSQL constraints:

| Field | Accepted range |
|---|---:|
| `engine_temperature` | `-40` to `150` |
| `battery_voltage` | `0` to `24` |
| `vibration_level` | `0` to `100` |
| `rpm` | `0` to `10000` |
| `speed` | `0` to `300` |
| `fuel_level` | `0` to `100` |

Device UIDs must match `^[A-Za-z0-9_-]{3,64}$`. Invalid UIDs, malformed JSON, unknown fields, missing telemetry fields, and out-of-range values return `400`. A valid but unknown device UID returns `404`.

Confirm that the saved record is current:

```powershell
$vehicleId = "22222222-2222-2222-2222-222222222222"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/telemetry/latest"
Invoke-RestMethod "http://localhost:8080/api/v1/vehicles/$vehicleId/status"
```

Vehicle and device list endpoints return an empty JSON array when the corresponding table has no rows. Their detail endpoints return HTTP status `404` for an invalid or unknown UUID.

## In-app notifications and future push delivery

The `notifications` table is the authoritative domain record for owner-facing in-app notifications. Alert evaluation creates `vehicle_alert` notifications when an incident is created, escalated, reopened, or cleared; repeated unchanged samples do not create duplicate notifications. Specialist-confirmed alert resolution also creates a `vehicle_alert` notification for the vehicle owner. Service-request lifecycle transitions create provider-neutral notification records for assignment, work start, and completion.

Service-request lifecycle code writes these notification records through a small notification writer abstraction inside the same PostgreSQL transaction as the lifecycle update. If notification insertion fails, the lifecycle change is rolled back too. The lifecycle code does not call Firebase, email, WebSocket, or any other external delivery provider.

A later push-notification implementation can be added without changing service-request lifecycle logic by introducing push-device registrations, a notification outbox, delivery-attempt tracking, and an asynchronous worker that sends pending notifications through Firebase Cloud Messaging or another provider. External push-provider requests should happen outside the service-request database transaction.

## Tests

Run backend tests from the `backend` directory:

```powershell
go test ./...
```

The current tests cover configuration, liveness, readiness, API routing, authentication helpers and handlers, vehicle/device handlers, telemetry ingestion and validation, alert validation, current-status aggregation, MQTT topic/payload handling, and threshold evaluation.
