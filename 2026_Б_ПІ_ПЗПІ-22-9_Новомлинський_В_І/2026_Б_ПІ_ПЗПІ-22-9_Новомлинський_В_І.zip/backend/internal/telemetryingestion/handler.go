package telemetryingestion

import (
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

const maximumRequestBodySize = 1 << 20

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) Ingest(w http.ResponseWriter, r *http.Request) {
	deviceUID := r.PathValue("device_uid")
	var input Input

	r.Body = http.MaxBytesReader(w, r.Body, maximumRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&input); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return
	}

	result, err := h.service.Ingest(r.Context(), deviceUID, input)
	if errors.Is(err, ErrInvalidDeviceUID) {
		response.Error(w, http.StatusBadRequest, "invalid device_uid")
		return
	}
	if errors.Is(err, ErrDeviceNotFound) {
		response.Error(w, http.StatusNotFound, "device not found")
		return
	}
	if errors.Is(err, ErrInvalidPayload) {
		response.Error(w, http.StatusBadRequest, "invalid telemetry payload")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to ingest telemetry",
			"device_uid", deviceUID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, result)
}
