package servicerequest

import (
	"context"
	"errors"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
)

const (
	testOwnerID      = "11111111-1111-1111-1111-111111111111"
	testVehicleID    = "22222222-2222-2222-2222-222222222222"
	testRequestID    = "33333333-3333-3333-3333-333333333333"
	testSpecialistID = "44444444-4444-4444-4444-444444444444"
	testAdminID      = "55555555-5555-5555-5555-555555555555"
)

func TestCreateNormalizesAndDefaultsPriority(t *testing.T) {
	repo := &fakeRepository{}
	service := NewService(repo, &fakeAssignments{})
	sourceAlertID := " 66666666-6666-6666-6666-666666666666 "

	item, err := service.Create(context.Background(), CreateRequest{
		VehicleID:     testVehicleID,
		OwnerID:       testOwnerID,
		Title:         "  Strange engine sound ",
		Description:   "  Noise appears above 2000 RPM ",
		SourceAlertID: &sourceAlertID,
	})
	if err != nil {
		t.Fatalf("Create returned error: %v", err)
	}
	if item.Priority != PriorityNormal {
		t.Fatalf("expected default priority %q, got %q", PriorityNormal, item.Priority)
	}
	if repo.created.Title != "Strange engine sound" {
		t.Fatalf("expected trimmed title, got %q", repo.created.Title)
	}
	if repo.created.SourceAlertID == nil ||
		*repo.created.SourceAlertID != "66666666-6666-6666-6666-666666666666" {
		t.Fatalf("expected trimmed source alert ID, got %#v", repo.created.SourceAlertID)
	}
}

func TestCreateRejectsInvalidInput(t *testing.T) {
	service := NewService(&fakeRepository{}, &fakeAssignments{})

	_, err := service.Create(context.Background(), CreateRequest{
		VehicleID:   testVehicleID,
		OwnerID:     testOwnerID,
		Title:       " ",
		Description: "details",
		Priority:    PriorityNormal,
	})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}
}

func TestCreateRejectsInvalidSourceAlertID(t *testing.T) {
	service := NewService(&fakeRepository{}, &fakeAssignments{})
	sourceAlertID := "not-a-uuid"

	_, err := service.Create(context.Background(), CreateRequest{
		VehicleID:     testVehicleID,
		OwnerID:       testOwnerID,
		Title:         "Engine warning",
		Description:   "Owner requests diagnostics",
		Priority:      PriorityHigh,
		SourceAlertID: &sourceAlertID,
	})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}
}

func TestOwnerCanCancelOnlyPendingRequests(t *testing.T) {
	repo := &fakeRepository{current: Request{
		ID:      testRequestID,
		OwnerID: testOwnerID,
		Status:  StatusAssigned,
	}}
	service := NewService(repo, &fakeAssignments{})

	_, err := service.CancelByOwner(context.Background(), testOwnerID, testRequestID)
	if !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("expected ErrInvalidTransition, got %v", err)
	}

	repo.current.Status = StatusPending
	item, err := service.CancelByOwner(context.Background(), testOwnerID, testRequestID)
	if err != nil {
		t.Fatalf("CancelByOwner returned error: %v", err)
	}
	if item.Status != StatusCancelled {
		t.Fatalf("expected cancelled status, got %q", item.Status)
	}
}

func TestAdminAssignsActiveSpecialistAndReusesExistingAssignment(t *testing.T) {
	assignments := &fakeAssignments{
		activeSpecialists: []auth.User{{
			ID:       testSpecialistID,
			Role:     auth.TechnicalSpecialistRoleCode,
			IsActive: true,
		}},
		assignErr: specialistassignment.ErrDuplicate,
	}
	repo := &fakeRepository{current: Request{
		ID:        testRequestID,
		VehicleID: testVehicleID,
		Status:    StatusPending,
	}}
	service := NewService(repo, assignments)

	item, err := service.Assign(context.Background(), AssignRequest{
		RequestID:    testRequestID,
		SpecialistID: testSpecialistID,
		AdminID:      testAdminID,
	})
	if err != nil {
		t.Fatalf("Assign returned error: %v", err)
	}
	if item.Status != StatusAssigned {
		t.Fatalf("expected assigned status, got %q", item.Status)
	}
	if assignments.assignCalls != 1 {
		t.Fatalf("expected assignment call, got %d", assignments.assignCalls)
	}
}

func TestAdminAssignRejectsInactiveSpecialist(t *testing.T) {
	repo := &fakeRepository{current: Request{
		ID:        testRequestID,
		VehicleID: testVehicleID,
		Status:    StatusPending,
	}}
	service := NewService(repo, &fakeAssignments{
		activeSpecialists: []auth.User{{
			ID:       "66666666-6666-6666-6666-666666666666",
			Role:     auth.TechnicalSpecialistRoleCode,
			IsActive: true,
		}},
	})

	_, err := service.Assign(context.Background(), AssignRequest{
		RequestID:    testRequestID,
		SpecialistID: testSpecialistID,
		AdminID:      testAdminID,
	})
	if !errors.Is(err, ErrSpecialistUnavailable) {
		t.Fatalf("expected ErrSpecialistUnavailable, got %v", err)
	}
}

func TestAdminReassignOnlyWhileAssigned(t *testing.T) {
	repo := &fakeRepository{current: Request{
		ID:        testRequestID,
		VehicleID: testVehicleID,
		Status:    StatusInProgress,
	}}
	service := NewService(repo, &fakeAssignments{})

	_, err := service.Assign(context.Background(), AssignRequest{
		RequestID:    testRequestID,
		SpecialistID: testSpecialistID,
		AdminID:      testAdminID,
	})
	if !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("expected ErrInvalidTransition, got %v", err)
	}
	if repo.assignCalls != 0 {
		t.Fatalf("expected no assignment repository call for rejected transition, got %d", repo.assignCalls)
	}
}

func TestAdminCancelPropagatesActor(t *testing.T) {
	repo := &fakeRepository{current: Request{
		ID:     testRequestID,
		Status: StatusAssigned,
	}}
	service := NewService(repo, &fakeAssignments{})

	item, err := service.CancelByAdmin(context.Background(), AdminCancelRequest{
		RequestID: testRequestID,
		AdminID:   testAdminID,
	})
	if err != nil {
		t.Fatalf("CancelByAdmin returned error: %v", err)
	}
	if item.Status != StatusCancelled {
		t.Fatalf("expected cancelled status, got %q", item.Status)
	}
	if repo.adminID != testAdminID {
		t.Fatalf("expected admin actor %q, got %q", testAdminID, repo.adminID)
	}
}

func TestSpecialistStartAndCompleteTransitions(t *testing.T) {
	repo := &fakeRepository{current: Request{
		ID:                   testRequestID,
		AssignedSpecialistID: stringPtr(testSpecialistID),
		Status:               StatusAssigned,
	}}
	service := NewService(repo, &fakeAssignments{})

	item, err := service.Start(context.Background(), testSpecialistID, testRequestID)
	if err != nil {
		t.Fatalf("Start returned error: %v", err)
	}
	if item.Status != StatusInProgress {
		t.Fatalf("expected in_progress status, got %q", item.Status)
	}

	_, err = service.Complete(context.Background(), testSpecialistID, testRequestID, " ")
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for blank result, got %v", err)
	}

	item, err = service.Complete(context.Background(), testSpecialistID, testRequestID, "  Replaced battery terminal. ")
	if err != nil {
		t.Fatalf("Complete returned error: %v", err)
	}
	if item.Status != StatusCompleted {
		t.Fatalf("expected completed status, got %q", item.Status)
	}
	if item.ResultSummary == nil || *item.ResultSummary != "Replaced battery terminal." {
		t.Fatalf("expected trimmed result summary, got %#v", item.ResultSummary)
	}
}

func TestRejectedSpecialistTransitionsDoNotReachRepository(t *testing.T) {
	repo := &fakeRepository{current: Request{
		ID:                   testRequestID,
		AssignedSpecialistID: stringPtr(testSpecialistID),
		Status:               StatusPending,
	}}
	service := NewService(repo, &fakeAssignments{})

	_, err := service.Start(context.Background(), testSpecialistID, testRequestID)
	if !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("expected ErrInvalidTransition, got %v", err)
	}
	if repo.startCalls != 0 {
		t.Fatalf("expected no start repository call for rejected transition, got %d", repo.startCalls)
	}

	_, err = service.Complete(context.Background(), testSpecialistID, testRequestID, "Done")
	if !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("expected ErrInvalidTransition, got %v", err)
	}
	if repo.completeCalls != 0 {
		t.Fatalf("expected no complete repository call for rejected transition, got %d", repo.completeCalls)
	}
}

type fakeRepository struct {
	created       CreateRequest
	current       Request
	assignCalls   int
	adminID       string
	startCalls    int
	completeCalls int
}

func (r *fakeRepository) Create(_ context.Context, request CreateRequest) (Request, error) {
	r.created = request
	return Request{
		ID:          testRequestID,
		VehicleID:   request.VehicleID,
		OwnerID:     request.OwnerID,
		Title:       request.Title,
		Description: request.Description,
		Priority:    request.Priority,
		Status:      StatusPending,
	}, nil
}

func (r *fakeRepository) ListForOwner(context.Context, string) ([]Request, error) {
	return []Request{r.current}, nil
}

func (r *fakeRepository) GetForOwner(context.Context, string, string) (Request, error) {
	return r.current, nil
}

func (r *fakeRepository) ListForAdmin(context.Context, string) ([]Request, error) {
	return []Request{r.current}, nil
}

func (r *fakeRepository) GetByID(context.Context, string) (Request, error) {
	return r.current, nil
}

func (r *fakeRepository) Assign(context.Context, string, string, string) (Request, error) {
	r.assignCalls++
	r.current.Status = StatusAssigned
	r.current.AssignedSpecialistID = stringPtr(testSpecialistID)
	return r.current, nil
}

func (r *fakeRepository) CancelByOwner(context.Context, string, string) (Request, error) {
	r.current.Status = StatusCancelled
	return r.current, nil
}

func (r *fakeRepository) CancelByAdmin(_ context.Context, adminID string, _ string) (Request, error) {
	r.adminID = adminID
	r.current.Status = StatusCancelled
	return r.current, nil
}

func (r *fakeRepository) ListForSpecialist(context.Context, string) ([]Request, error) {
	return []Request{r.current}, nil
}

func (r *fakeRepository) GetForSpecialist(context.Context, string, string) (Request, error) {
	return r.current, nil
}

func (r *fakeRepository) Start(context.Context, string, string) (Request, error) {
	r.startCalls++
	r.current.Status = StatusInProgress
	return r.current, nil
}

func (r *fakeRepository) Complete(context.Context, string, string, string) (Request, error) {
	r.completeCalls++
	r.current.Status = StatusCompleted
	r.current.ResultSummary = stringPtr("Replaced battery terminal.")
	return r.current, nil
}

type fakeAssignments struct {
	activeSpecialists []auth.User
	assignErr         error
	assignCalls       int
}

func (a *fakeAssignments) AssignByID(
	context.Context,
	string,
	string,
	string,
) (specialistassignment.Assignment, error) {
	a.assignCalls++
	return specialistassignment.Assignment{}, a.assignErr
}

func (a *fakeAssignments) ListSpecialists(context.Context) ([]auth.User, error) {
	return a.activeSpecialists, nil
}

func stringPtr(value string) *string {
	return &value
}
