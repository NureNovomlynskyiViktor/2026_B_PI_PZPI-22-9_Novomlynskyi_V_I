package ua.autonexis.mobile.ui.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.AuthResult
import ua.autonexis.mobile.User
import ua.autonexis.mobile.authenticationSuccess

internal enum class AuthScreenMode {
    LOADING,
    LOGIN,
    REGISTER,
    UNSUPPORTED_ROLE,
}

internal data class AuthUiState(
    val screen: AuthScreenMode = AuthScreenMode.LOADING,
    val isAuthInFlight: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    val unsupportedUser: User? = null,
    val initialBaseUrl: String = "",
)

internal sealed interface AuthRoute {
    data class OwnerDashboard(val token: String) : AuthRoute
    data class UnsupportedRole(val user: User) : AuthRoute
}

internal sealed interface AuthAction {
    data object ShowLogin : AuthAction
    data object ShowRegister : AuthAction
    data object Logout : AuthAction
    data class Login(val baseUrl: String, val email: String, val password: String) : AuthAction
    data class Register(
        val baseUrl: String,
        val fullName: String,
        val email: String,
        val password: String,
        val confirmPassword: String,
    ) : AuthAction
    data class GoogleSignIn(val baseUrl: String) : AuthAction
}

internal class AuthViewModel {
    var uiState by mutableStateOf(AuthUiState())
        private set

    fun showLoading(message: String = "Restoring session...") {
        uiState = AuthUiState(
            screen = AuthScreenMode.LOADING,
            statusMessage = message,
            initialBaseUrl = uiState.initialBaseUrl,
        )
    }

    fun showLogin(message: String? = null, baseUrl: String = uiState.initialBaseUrl) {
        uiState = AuthUiState(
            screen = AuthScreenMode.LOGIN,
            statusMessage = message,
            initialBaseUrl = baseUrl,
        )
    }

    fun showRegister(baseUrl: String = uiState.initialBaseUrl, message: String? = null) {
        uiState = AuthUiState(
            screen = AuthScreenMode.REGISTER,
            statusMessage = message,
            initialBaseUrl = baseUrl,
        )
    }

    fun showUnsupportedRole(user: User) {
        uiState = AuthUiState(
            screen = AuthScreenMode.UNSUPPORTED_ROLE,
            unsupportedUser = user,
            initialBaseUrl = uiState.initialBaseUrl,
        )
    }

    fun showError(message: String) {
        uiState = uiState.copy(
            isAuthInFlight = false,
            statusMessage = null,
            errorMessage = message,
        )
    }

    fun showStatus(message: String) {
        uiState = uiState.copy(statusMessage = message, errorMessage = null)
    }

    fun clearStatusMessage() {
        uiState = uiState.copy(statusMessage = null)
    }

    fun tryStartAuthentication(statusMessage: String): Boolean {
        if (uiState.isAuthInFlight) {
            return false
        }
        uiState = uiState.copy(
            isAuthInFlight = true,
            statusMessage = statusMessage,
            errorMessage = null,
        )
        return true
    }

    fun finishAuthentication() {
        uiState = uiState.copy(isAuthInFlight = false)
    }

    fun routeAfterAuthentication(baseUrl: String, result: AuthResult): AuthRoute {
        val success = authenticationSuccess(baseUrl, result)
        return if (success.opensOwnerDashboard) {
            AuthRoute.OwnerDashboard(success.accessToken)
        } else {
            AuthRoute.UnsupportedRole(success.user)
        }
    }
}
