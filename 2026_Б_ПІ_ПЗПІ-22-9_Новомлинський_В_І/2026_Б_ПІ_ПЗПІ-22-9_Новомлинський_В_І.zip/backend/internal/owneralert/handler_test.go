package owneralert

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
	testAlertID   = "44444444-4444-4444-4444-444444444441"
)

type stubAlertService struct {
	alerts          []alert.Alert
	err             error
	capturedVehicle string
	capturedLimit   int
}

func (s *stubAlertService) ListByVehicle(
	_ context.Context,
	vehicleID string,
	limit int,
) ([]alert.Alert, error) {
	s.capturedVehicle = vehicleID
	s.capturedLimit = limit
	return s.alerts, s.err
}

func (s *stubAlertService) ListActiveByVehicle(
	_ context.Context,
	vehicleID string,
) ([]alert.Alert, error) {
	s.capturedVehicle = vehicleID
	return s.alerts, s.err
}

type stubVehicleService struct {
	err             error
	capturedOwner   string
	capturedVehicle string
}

func (s *stubVehicleService) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) (vehicle.Vehicle, error) {
	s.capturedOwner = ownerID
	s.capturedVehicle = vehicleID
	if s.err != nil {
		return vehicle.Vehicle{}, s.err
	}
	return vehicle.Vehicle{ID: vehicleID, OwnerID: ownerID}, nil
}

func TestListByVehicleRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(
		&stubAlertService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/alerts",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestListByVehicleRejectsInvalidUUID(t *testing.T) {
	handler := NewHandler(
		&stubAlertService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/not-a-uuid/alerts",
	)
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListActiveForAnotherUsersVehicleReturnsNotFound(t *testing.T) {
	alertService := &stubAlertService{}
	handler := NewHandler(
		alertService,
		&stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/alerts/active",
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListActiveByVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
	if alertService.capturedVehicle != "" {
		t.Fatal("expected alert service not to be called")
	}
}

func authenticatedRequest(method string, path string) *http.Request {
	request := httptest.NewRequest(method, path, nil)
	return request.WithContext(auth.WithUser(
		request.Context(),
		auth.User{ID: testOwnerID, Email: "owner@example.com", Role: auth.DefaultRoleCode},
	))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
