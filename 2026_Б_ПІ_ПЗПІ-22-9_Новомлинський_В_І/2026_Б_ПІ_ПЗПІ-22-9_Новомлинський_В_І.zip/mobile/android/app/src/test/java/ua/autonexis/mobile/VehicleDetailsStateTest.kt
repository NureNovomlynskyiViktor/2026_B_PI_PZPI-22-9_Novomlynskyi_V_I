package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsData
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsDestination
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsPresentation
import ua.autonexis.mobile.ui.vehicle.VehicleDetailsViewModel
import ua.autonexis.mobile.ui.vehicle.VehicleQuickAction

class VehicleDetailsStateTest {
    @Test
    fun loadingThenLoadedShowsDetails() {
        val viewModel = VehicleDetailsViewModel()
        val details = detailsData(overallStatus = "normal")

        viewModel.showInitialLoading("vehicle-1")
        assertTrue(viewModel.uiState.isLoading)
        assertNull(viewModel.uiState.data)

        viewModel.showDetails("vehicle-1", details)

        assertFalse(viewModel.uiState.isLoading)
        assertEquals(details, viewModel.uiState.data)
        assertEquals("vehicle-1", viewModel.uiState.vehicleId)
    }

    @Test
    fun refreshLockPreventsDuplicates() {
        val viewModel = VehicleDetailsViewModel()
        viewModel.showDetails("vehicle-1", detailsData())

        assertTrue(viewModel.startRefresh())
        assertFalse(viewModel.startRefresh())
    }

    @Test
    fun refreshFailurePreservesPreviousData() {
        val viewModel = VehicleDetailsViewModel()
        val details = detailsData()
        viewModel.showDetails("vehicle-1", details)
        viewModel.startRefresh()

        viewModel.failRefresh("Could not refresh.")

        assertEquals(details, viewModel.uiState.data)
        assertFalse(viewModel.uiState.isRefreshing)
        assertTrue(viewModel.uiState.isError)
    }

    @Test
    fun initialFailureProducesRetryableState() {
        val viewModel = VehicleDetailsViewModel()

        viewModel.failInitialLoad("vehicle-1", "Could not load vehicle details.")

        assertEquals("vehicle-1", viewModel.uiState.vehicleId)
        assertNull(viewModel.uiState.data)
        assertTrue(viewModel.uiState.isError)
        assertFalse(viewModel.uiState.isLoading)
    }


    @Test
    fun quickActionsDoNotDuplicateRecentTelemetryNavigation() {
        val actions = VehicleDetailsPresentation.quickActions()

        assertEquals(
            listOf(
                VehicleQuickAction.MAINTENANCE_HISTORY,
                VehicleQuickAction.SERVICE_REQUESTS,
                VehicleQuickAction.CREATE_MANUAL_SERVICE_REQUEST,
            ),
            actions,
        )
        assertFalse(actions.toString().contains("TELEMETRY"))
    }

    @Test
    fun statusMappingSupportsBackendStates() {
        assertEquals("NORMAL", VehicleDetailsPresentation.statusLabel("normal"))
        assertEquals("WARNING", VehicleDetailsPresentation.statusLabel("warning"))
        assertEquals("CRITICAL", VehicleDetailsPresentation.statusLabel("critical"))
        assertEquals("UNKNOWN", VehicleDetailsPresentation.statusLabel("unknown"))
        assertEquals("UNKNOWN", VehicleDetailsPresentation.statusLabel("future"))
    }

    @Test
    fun telemetryValueFormattingUsesActualValues() {
        val metrics = VehicleDetailsPresentation.telemetryMetrics(telemetry())

        assertEquals("Engine temperature" to "89.5 \u00B0C", metrics[0])
        assertEquals("Battery voltage" to "13.7 V", metrics[1])
        assertEquals("Vibration level" to "1.4", metrics[2])
        assertEquals("RPM" to "2080", metrics[3])
        assertEquals("Speed" to "58 km/h", metrics[4])
        assertEquals("Fuel level" to "69.4 %", metrics[5])
    }

    @Test
    fun inspectionBannerUsesExistingHelper() {
        val clearedCritical = alert(
            id = "alert-critical",
            status = "cleared",
            severity = "critical",
            currentSeverity = null,
            clearedAt = "2026-06-21T12:00:00Z",
        )

        val result = AlertLifecyclePresentation.latestClearedCriticalWhenInspectionRecommended(
            overallStatus = "normal",
            alerts = listOf(clearedCritical),
        )

        assertEquals(clearedCritical, result)
    }

    @Test
    fun groupingKeepsActiveClearedResolvedAndOtherSeparate() {
        val groups = AlertLifecyclePresentation.group(
            listOf(
                alert(id = "active", status = "active"),
                alert(id = "cleared", status = "cleared"),
                alert(id = "resolved", status = "resolved"),
                alert(id = "future", status = "archived"),
            ),
        )

        assertEquals("active", groups.active.single().id)
        assertEquals("cleared", groups.cleared.single().id)
        assertEquals("resolved", groups.resolved.single().id)
        assertEquals("future", groups.historicalOther.single().id)
    }

    @Test
    fun activeIncidentIncludesCurrentSeverityButClearedDoesNot() {
        val active = alert(status = "active", currentSeverity = "warning")
        val cleared = alert(status = "cleared", currentSeverity = null)

        assertTrue(VehicleDetailsPresentation.shouldShowCurrentSeverity(active))
        assertFalse(VehicleDetailsPresentation.shouldShowCurrentSeverity(cleared))
    }

    @Test
    fun ownerNeverGetsResolveAction() {
        assertFalse(VehicleDetailsPresentation.ownerCanResolveAlert(alert()))
    }

    @Test
    fun createServiceRequestIsAvailableOnlyWhenEligibleAndNoOpenLinkedRequestExists() {
        val alert = alert(id = "alert-1", severity = "warning", currentSeverity = "warning")
        val openRequest = serviceRequest(id = "request-1", sourceAlertId = "alert-1", status = "pending")
        val cancelledRequest = serviceRequest(id = "request-2", sourceAlertId = "alert-1", status = "cancelled")

        assertTrue(VehicleDetailsPresentation.canCreateServiceRequest(alert, emptyList()))
        assertFalse(VehicleDetailsPresentation.canCreateServiceRequest(alert, listOf(openRequest)))
        assertTrue(VehicleDetailsPresentation.canCreateServiceRequest(alert, listOf(cancelledRequest)))
    }

    @Test
    fun resolvedRequestMetadataIsPreserved() {
        val request = serviceRequest(
            id = "request-1",
            sourceAlertId = "alert-1",
            status = "completed",
            resultSummary = "Thermostat inspected and repaired.",
        )
        val alert = alert(
            id = "alert-1",
            status = "resolved",
            resolutionServiceRequestId = "request-1",
            resolutionNote = "Repair confirmed after road test.",
        )

        val linked = assertNotNull(AlertLifecyclePresentation.linkedResolutionServiceRequest(alert, listOf(request)))
        assertEquals("Thermostat inspected and repaired.", linked.resultSummary)
        assertEquals("Repair confirmed after road test.", alert.resolutionNote)
    }

    @Test
    fun safeErrorsDoNotContainAccessTokensWhenCallerPassesSafeMessage() {
        val viewModel = VehicleDetailsViewModel()
        val token = "secret-access-token"
        viewModel.showDetails("vehicle-1", detailsData())

        viewModel.failRefresh("Could not refresh vehicle details.")

        assertFalse(viewModel.uiState.message.orEmpty().contains(token))
    }


    @Test
    fun resolvedIncidentsAreSortedNewestFirstByResolvedAt() {
        val older = alert(id = "older", status = "resolved", resolvedAt = "2026-06-20T10:00:00Z", clearedAt = "2026-06-22T10:00:00Z")
        val newer = alert(id = "newer", status = "resolved", resolvedAt = "2026-06-21T10:00:00Z", clearedAt = "2026-06-19T10:00:00Z")

        val sorted = VehicleDetailsPresentation.resolvedIncidentsNewestFirst(listOf(older, newer))

        assertEquals(listOf("newer", "older"), sorted.map { it.id })
    }

    @Test
    fun resolvedAtTakesPrecedenceOverFallbackTimestamps() {
        val resolvedAtWins = alert(id = "resolved", status = "resolved", resolvedAt = "2026-06-20T10:00:00Z", clearedAt = "2026-06-22T10:00:00Z")
        val fallbackLater = alert(id = "fallback", status = "resolved", resolvedAt = null, clearedAt = "2026-06-21T10:00:00Z")

        val sorted = VehicleDetailsPresentation.resolvedIncidentsNewestFirst(listOf(fallbackLater, resolvedAtWins))

        assertEquals("fallback", sorted.first().id)
    }

    @Test
    fun fallbackTimestampSortingUsesClearedThenLastTriggeredThenCreated() {
        val byCreated = alert(id = "created", status = "resolved", resolvedAt = null, clearedAt = null, lastTriggeredAt = null)
        val byLastTriggered = alert(id = "last", status = "resolved", resolvedAt = null, clearedAt = null, lastTriggeredAt = "2026-06-23T10:00:00Z")
        val byCleared = alert(id = "cleared", status = "resolved", resolvedAt = null, clearedAt = "2026-06-24T10:00:00Z")

        val sorted = VehicleDetailsPresentation.resolvedIncidentsNewestFirst(listOf(byCreated, byLastTriggered, byCleared))

        assertEquals(listOf("cleared", "last", "created"), sorted.map { it.id })
    }

    @Test
    fun resolvedOverviewIsLimitedToThreeItemsButFullHistoryPreservesAll() {
        val alerts = (1..5).map { index ->
            alert(id = "alert-$index", status = "resolved", resolvedAt = "2026-06-2${index}T10:00:00Z")
        }

        assertEquals(3, VehicleDetailsPresentation.resolvedIncidentOverviewItems(alerts).size)
        assertEquals(5, VehicleDetailsPresentation.resolvedIncidentsNewestFirst(alerts).size)
    }

    @Test
    fun activeAndClearedGroupsAreNotLimited() {
        val alerts = (1..5).map { index -> alert(id = "active-$index", status = "active") } +
            (1..4).map { index -> alert(id = "cleared-$index", status = "cleared") }

        val groups = AlertLifecyclePresentation.group(alerts)

        assertEquals(5, groups.active.size)
        assertEquals(4, groups.cleared.size)
    }

    @Test
    fun compactResolvedPreviewExcludesVerboseFields() {
        val resolved = alert(status = "resolved", resolutionNote = "Full diagnostic note", resolvedAt = "2026-06-22T10:00:00Z")

        val preview = VehicleDetailsPresentation.resolvedIncidentPreview(resolved).toString()

        assertFalse(preview.contains("Engine temperature is high."))
        assertFalse(preview.contains("Full diagnostic note"))
        assertTrue(preview.contains("engine_temperature"))
    }

    @Test
    fun fullHistorySourcePreservesResolutionNoteAndLinkedRequestMetadata() {
        val request = serviceRequest(
            id = "request-1",
            sourceAlertId = "alert-1",
            status = "completed",
            resultSummary = "Repair completed.",
        )
        val resolved = alert(
            id = "alert-1",
            status = "resolved",
            resolutionServiceRequestId = "request-1",
            resolutionNote = "Confirmed by specialist.",
            resolvedAt = "2026-06-22T10:00:00Z",
        )

        val fullHistory = VehicleDetailsPresentation.resolvedIncidentsNewestFirst(listOf(resolved))
        val linked = assertNotNull(AlertLifecyclePresentation.linkedResolutionServiceRequest(fullHistory.single(), listOf(request)))

        assertEquals("Confirmed by specialist.", fullHistory.single().resolutionNote)
        assertEquals("Repair completed.", linked.resultSummary)
    }

    @Test
    fun backDestinationReturnsToOverviewState() {
        val viewModel = VehicleDetailsViewModel()
        viewModel.showDetails("vehicle-1", detailsData())
        viewModel.showResolvedHistory()
        assertEquals(VehicleDetailsDestination.RESOLVED_HISTORY, viewModel.uiState.destination)

        viewModel.showOverview()

        assertEquals(VehicleDetailsDestination.OVERVIEW, viewModel.uiState.destination)
        assertNotNull(viewModel.uiState.data)
    }

    @Test
    fun encodingSafeFormattersProduceDegreeAndBulletWithoutReplacementCharacter() {
        val temperature = VehicleDetailsPresentation.telemetryMetrics(telemetry()).first().second
        val metadata = VehicleDetailsPresentation.vehicleMetadata(2024, "DEMO-001")

        assertEquals("89.5 \u00B0C", temperature)
        assertEquals("2024 \u2022 DEMO-001", metadata)
        assertFalse(VehicleDetailsPresentation.hasReplacementCharacter(temperature))
        assertFalse(VehicleDetailsPresentation.hasReplacementCharacter(metadata))
    }
    private fun detailsData(overallStatus: String = "normal") = VehicleDetailsData(
        status = VehicleStatus(
            vehicle = Vehicle("vehicle-1", "Toyota", "Corolla", 2022, "AX-0002"),
            device = Device("device-1", "esp32-demo-002", "Owner ESP32", "active", null),
            latestTelemetry = telemetry(),
            activeAlerts = emptyList(),
            overallStatus = overallStatus,
        ),
        thresholds = emptyList(),
        alerts = emptyList(),
        serviceRequests = emptyList(),
    )

    private fun telemetry() = TelemetryRecord(
        measuredAt = "2026-06-22T10:00:00Z",
        engineTemperature = 89.5,
        batteryVoltage = 13.7,
        vibrationLevel = 1.35,
        rpm = 2080,
        speed = 58,
        fuelLevel = 69.4,
    )

    private fun alert(
        id: String = "alert-1",
        type: String = "engine_temperature",
        severity: String = "warning",
        currentSeverity: String? = "warning",
        status: String = "active",
        clearedAt: String? = null,
        resolvedAt: String? = null,
        lastTriggeredAt: String? = "2026-06-22T10:00:00Z",
        resolutionServiceRequestId: String? = null,
        resolutionNote: String? = null,
    ) = Alert(
        id = id,
        type = type,
        severity = severity,
        currentSeverity = currentSeverity,
        status = status,
        occurrenceCount = 1,
        recoveryStreak = 0,
        lastTriggeredAt = lastTriggeredAt,
        message = "Engine temperature is high.",
        recommendation = "Inspect cooling system.",
        createdAt = "2026-06-22T09:55:00Z",
        clearedAt = clearedAt,
        resolvedAt = resolvedAt,
        resolvedByUserId = if (status == "resolved") "specialist-1" else null,
        resolutionNote = resolutionNote,
        resolutionServiceRequestId = resolutionServiceRequestId,
    )

    private fun serviceRequest(
        id: String,
        sourceAlertId: String?,
        status: String,
        resultSummary: String? = null,
    ) = ServiceRequest(
        id = id,
        vehicleId = "vehicle-1",
        ownerId = "owner-1",
        sourceAlertId = sourceAlertId,
        assignedSpecialistId = "specialist-1",
        assignedBy = "admin-1",
        title = "Cooling system inspection",
        description = "Inspect engine temperature alert.",
        priority = "normal",
        status = status,
        resultSummary = resultSummary,
        createdAt = "2026-06-22T09:56:00Z",
        updatedAt = "2026-06-22T10:10:00Z",
        assignedAt = null,
        startedAt = null,
        completedAt = null,
        cancelledAt = null,
    )
}