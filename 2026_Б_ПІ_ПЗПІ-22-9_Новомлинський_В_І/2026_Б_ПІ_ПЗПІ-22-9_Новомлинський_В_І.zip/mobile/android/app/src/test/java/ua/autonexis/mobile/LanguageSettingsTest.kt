package ua.autonexis.mobile

import java.io.File
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.UiStringResources

class LanguageSettingsTest {
    @Test
    fun parseModeAcceptsKnownValuesAndDefaultsSafely() {
        assertEquals(LanguageMode.SYSTEM, LanguageStore.parseMode(null))
        assertEquals(LanguageMode.SYSTEM, LanguageStore.parseMode(""))
        assertEquals(LanguageMode.SYSTEM, LanguageStore.parseMode("future"))
        assertEquals(LanguageMode.ENGLISH, LanguageStore.parseMode("english"))
        assertEquals(LanguageMode.UKRAINIAN, LanguageStore.parseMode(" UKRAINIAN "))
    }

    @Test
    fun localeTagsMatchLanguageModes() {
        assertEquals("", LanguageStore.localeTagFor(LanguageMode.SYSTEM))
        assertEquals("en", LanguageStore.localeTagFor(LanguageMode.ENGLISH))
        assertEquals("uk", LanguageStore.localeTagFor(LanguageMode.UKRAINIAN))
    }

    @Test
    fun selectedLanguagePersistsIndependentlyFromRestoreFlag() {
        val storage = FakeLanguagePreferenceStorage()
        val store = LanguageStore(storage)

        store.mode = LanguageMode.UKRAINIAN
        store.restoreAccountAfterLanguageChange = true

        assertEquals("UKRAINIAN", storage.rawLanguageMode)
        assertEquals(LanguageMode.UKRAINIAN, store.mode)
        assertTrue(store.restoreAccountAfterLanguageChange)

        store.restoreAccountAfterLanguageChange = false

        assertEquals(LanguageMode.UKRAINIAN, store.mode)
        assertFalse(store.restoreAccountAfterLanguageChange)
    }

    @Test
    fun englishAndUkrainianResourcesHaveMatchingKeys() {
        val defaultKeys = resourceKeys(File("src/main/res/values"))
        val ukrainianKeys = resourceKeys(File("src/main/res/values-uk"))

        assertEquals(defaultKeys, ukrainianKeys)
    }

    @Test
    fun structuredPresentationValuesMapToLocalizedResources() {
        assertEquals(R.string.status_warning, UiStringResources.statusLabelRes("warning"))
        assertEquals(R.string.status_in_progress, UiStringResources.statusLabelRes("in_progress"))
        assertEquals(R.string.priority_high, UiStringResources.priorityLabelRes("high"))
        assertEquals(R.string.metric_engine_temperature, UiStringResources.metricLabelRes("engine_temperature"))
        assertEquals(R.string.notification_type_service_request_completed, UiStringResources.notificationTypeLabelRes("service_request_completed"))
    }

    @Test
    fun localizedPluralResourcesArePresentInBothLocales() {
        val defaultKeys = resourceKeys(File("src/main/res/values"))
        val ukrainianKeys = resourceKeys(File("src/main/res/values-uk"))

        listOf("notification_summary_count", "notifications_unread_count_cd", "records_count", "resolved_incident_count").forEach { key ->
            assertTrue(key in defaultKeys, "Missing default plural/string resource: $key")
            assertTrue(key in ukrainianKeys, "Missing Ukrainian plural/string resource: $key")
        }
    }

    private fun resourceKeys(directory: File): Set<String> {
        return directory.listFiles { file -> file.extension == "xml" }
            .orEmpty()
            .flatMap { file -> resourceKeysFromFile(file) }
            .toSortedSet()
    }

    private fun resourceKeysFromFile(file: File): Set<String> {
        val document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file)
        val keys = linkedSetOf<String>()
        listOf("string", "plurals").forEach { tagName ->
            val nodes = document.getElementsByTagName(tagName)
            for (index in 0 until nodes.length) {
                val node = nodes.item(index)
                val name = node.attributes?.getNamedItem("name")?.nodeValue
                if (!name.isNullOrBlank()) {
                    keys += name
                }
            }
        }
        return keys
    }

    private class FakeLanguagePreferenceStorage : LanguagePreferenceStorage {
        override var rawLanguageMode: String? = null
        override var restoreAccountAfterLanguageChange: Boolean = false
    }
}
