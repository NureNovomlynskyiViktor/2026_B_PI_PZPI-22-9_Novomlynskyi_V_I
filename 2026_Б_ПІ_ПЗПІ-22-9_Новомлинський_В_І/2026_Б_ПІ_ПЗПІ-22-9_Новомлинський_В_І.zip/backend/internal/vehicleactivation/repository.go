package vehicleactivation

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	ActionVehicleActivationCreated = "vehicle.activation_created"
	EntityTypeVehicle              = "vehicle"
)

type PostgresRepository struct {
	db     *sql.DB
	audits auditlog.Writer
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{
		db:     db,
		audits: auditlog.NewPostgresWriter(),
	}
}

func (r *PostgresRepository) CreateUnclaimed(
	ctx context.Context,
	input CreateInput,
) (CreateResult, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return CreateResult{}, fmt.Errorf("begin vehicle activation transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	vehicleItem, err := insertUnclaimedVehicle(ctx, tx, input.Request)
	if isUniqueViolation(err, "vehicles_vin_key") {
		return CreateResult{}, ErrDuplicateVIN
	}
	if err != nil {
		return CreateResult{}, err
	}

	deviceItem, err := insertInactiveDevice(ctx, tx, vehicleItem.ID, input.Request)
	if isUniqueViolation(err, "devices_device_uid_key") {
		return CreateResult{}, ErrDuplicateDevice
	}
	if err != nil {
		return CreateResult{}, err
	}

	if err := insertDefaultThresholds(ctx, tx, vehicleItem.ID, input.DefaultRules); err != nil {
		return CreateResult{}, err
	}

	activation, err := insertActivationCode(ctx, tx, vehicleItem.ID, input)
	if err != nil {
		return CreateResult{}, err
	}

	result := CreateResult{
		Vehicle:    vehicleItem,
		Device:     deviceItem,
		Activation: activation,
	}
	if err := r.writeActivationCreatedAudit(ctx, tx, input, result); err != nil {
		return CreateResult{}, err
	}

	if err := tx.Commit(); err != nil {
		return CreateResult{}, fmt.Errorf("commit vehicle activation transaction: %w", err)
	}

	return result, nil
}

func (r *PostgresRepository) Claim(
	ctx context.Context,
	ownerID string,
	_ string,
	verify func(hash string) bool,
	now time.Time,
) (vehicle.Vehicle, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("begin claim activation transaction: %w", err)
	}
	defer func() {
		_ = tx.Rollback()
	}()

	rows, err := tx.QueryContext(
		ctx,
		`
			SELECT id, vehicle_id, code_hash, expires_at, claimed_at
			FROM vehicle_activation_codes
			WHERE claimed_at IS NULL
			ORDER BY created_at ASC, id ASC
			FOR UPDATE
		`,
	)
	if err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("query activation codes for claim: %w", err)
	}
	defer rows.Close()

	var matched struct {
		id        string
		vehicleID string
		expiresAt time.Time
	}
	found := false
	for rows.Next() {
		var (
			id        string
			vehicleID string
			codeHash  string
			expiresAt time.Time
			claimedAt sql.NullTime
		)
		if err := rows.Scan(&id, &vehicleID, &codeHash, &expiresAt, &claimedAt); err != nil {
			return vehicle.Vehicle{}, fmt.Errorf("scan activation code for claim: %w", err)
		}
		if claimedAt.Valid {
			continue
		}
		if verify(codeHash) {
			matched.id = id
			matched.vehicleID = vehicleID
			matched.expiresAt = expiresAt
			found = true
			break
		}
	}
	if err := rows.Err(); err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("iterate activation codes for claim: %w", err)
	}
	if err := rows.Close(); err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("close activation code rows: %w", err)
	}
	if !found {
		return vehicle.Vehicle{}, ErrInvalidCode
	}
	if !matched.expiresAt.After(now) {
		return vehicle.Vehicle{}, ErrExpiredCode
	}

	vehicleItem, err := assignVehicleOwner(ctx, tx, matched.vehicleID, ownerID)
	if errors.Is(err, sql.ErrNoRows) {
		return vehicle.Vehicle{}, ErrVehicleClaimed
	}
	if err != nil {
		return vehicle.Vehicle{}, err
	}

	if err := activateVehicleDevices(ctx, tx, matched.vehicleID); err != nil {
		return vehicle.Vehicle{}, err
	}
	if err := markActivationClaimed(ctx, tx, matched.id, ownerID); err != nil {
		return vehicle.Vehicle{}, err
	}
	if err := tx.Commit(); err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("commit claim activation transaction: %w", err)
	}

	return vehicleItem, nil
}

type txExecutor interface {
	ExecContext(ctx context.Context, query string, args ...any) (sql.Result, error)
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

func insertUnclaimedVehicle(
	ctx context.Context,
	tx txExecutor,
	request AdminCreateRequest,
) (vehicle.Vehicle, error) {
	const query = `
		INSERT INTO vehicles (
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate
		)
		VALUES (NULL, $1, $2, $3, $4, $5)
		RETURNING
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
	`

	item, err := scanVehicle(tx.QueryRowContext(
		ctx,
		query,
		request.VIN,
		request.Brand,
		request.Model,
		request.Year,
		request.LicensePlate,
	))
	if err != nil {
		return vehicle.Vehicle{}, fmt.Errorf("insert unclaimed vehicle: %w", err)
	}

	return item, nil
}

func insertInactiveDevice(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	request AdminCreateRequest,
) (device.Device, error) {
	const query = `
		INSERT INTO devices (
			vehicle_id,
			device_uid,
			name,
			status
		)
		VALUES ($1, $2, $3, 'inactive')
		RETURNING
			id,
			vehicle_id,
			device_uid,
			name,
			status,
			last_seen_at,
			created_at,
			updated_at
	`

	item, err := scanDevice(tx.QueryRowContext(
		ctx,
		query,
		vehicleID,
		request.DeviceUID,
		request.DeviceName,
	))
	if err != nil {
		return device.Device{}, fmt.Errorf("insert inactive device: %w", err)
	}

	return item, nil
}

func insertDefaultThresholds(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	rules []DefaultThreshold,
) error {
	const query = `
		INSERT INTO threshold_settings (
			vehicle_id,
			parameter,
			warning_value,
			critical_value,
			recovery_margin,
			recovery_samples
		)
		VALUES ($1, $2, $3, $4, $5, $6)
	`

	for _, rule := range rules {
		if _, err := tx.ExecContext(
			ctx,
			query,
			vehicleID,
			rule.Parameter,
			rule.WarningValue,
			rule.CriticalValue,
			rule.RecoveryMargin,
			rule.RecoverySamples,
		); err != nil {
			return fmt.Errorf("insert default threshold %s: %w", rule.Parameter, err)
		}
	}

	return nil
}

func insertActivationCode(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	input CreateInput,
) (Activation, error) {
	const query = `
		INSERT INTO vehicle_activation_codes (
			vehicle_id,
			code_hash,
			expires_at,
			created_by
		)
		VALUES ($1, $2, $3, $4)
		RETURNING
			id,
			vehicle_id,
			expires_at,
			claimed_at,
			claimed_by,
			created_by,
			created_at
	`

	item, err := scanActivation(tx.QueryRowContext(
		ctx,
		query,
		vehicleID,
		input.CodeHash,
		input.ExpiresAt,
		input.CreatedBy,
	))
	if err != nil {
		return Activation{}, fmt.Errorf("insert activation code: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) writeActivationCreatedAudit(
	ctx context.Context,
	tx auditlog.Executor,
	input CreateInput,
	result CreateResult,
) error {
	writer := r.audits
	if writer == nil {
		writer = auditlog.NewPostgresWriter()
	}

	if err := writer.Write(ctx, tx, activationCreatedAuditEntry(input, result)); err != nil {
		return fmt.Errorf("write vehicle activation audit: %w", err)
	}

	return nil
}

func activationCreatedAuditEntry(input CreateInput, result CreateResult) auditlog.Entry {
	return auditlog.Entry{
		ActorID:    input.CreatedBy,
		Action:     ActionVehicleActivationCreated,
		EntityType: EntityTypeVehicle,
		EntityID:   result.Vehicle.ID,
		Metadata:   activationCreatedAuditMetadata(input, result),
	}
}

func activationCreatedAuditMetadata(
	input CreateInput,
	result CreateResult,
) map[string]any {
	return map[string]any{
		"vehicle_id":              result.Vehicle.ID,
		"device_id":               result.Device.ID,
		"device_uid":              result.Device.DeviceUID,
		"vin":                     stringValue(result.Vehicle.VIN),
		"brand":                   result.Vehicle.Brand,
		"model":                   result.Vehicle.Model,
		"year":                    intValue(result.Vehicle.Year),
		"license_plate":           stringValue(result.Vehicle.LicensePlate),
		"activation_id":           result.Activation.ID,
		"activation_expires_at":   result.Activation.ExpiresAt,
		"default_threshold_count": len(input.DefaultRules),
	}
}

func stringValue(value *string) any {
	if value == nil {
		return nil
	}

	return *value
}

func intValue(value *int16) any {
	if value == nil {
		return nil
	}

	return *value
}

func assignVehicleOwner(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
	ownerID string,
) (vehicle.Vehicle, error) {
	const query = `
		UPDATE vehicles
		SET
			owner_id = $2,
			updated_at = NOW()
		WHERE id = $1
		  AND owner_id IS NULL
		RETURNING
			id,
			owner_id,
			vin,
			brand,
			model,
			year,
			license_plate,
			created_at,
			updated_at
	`

	return scanVehicle(tx.QueryRowContext(ctx, query, vehicleID, ownerID))
}

func activateVehicleDevices(
	ctx context.Context,
	tx txExecutor,
	vehicleID string,
) error {
	const query = `
		UPDATE devices
		SET
			status = 'active',
			updated_at = NOW()
		WHERE vehicle_id = $1
	`

	if _, err := tx.ExecContext(ctx, query, vehicleID); err != nil {
		return fmt.Errorf("activate vehicle devices: %w", err)
	}

	return nil
}

func markActivationClaimed(
	ctx context.Context,
	tx txExecutor,
	activationID string,
	ownerID string,
) error {
	const query = `
		UPDATE vehicle_activation_codes
		SET
			claimed_at = NOW(),
			claimed_by = $2
		WHERE id = $1
		  AND claimed_at IS NULL
	`

	result, err := tx.ExecContext(ctx, query, activationID, ownerID)
	if err != nil {
		return fmt.Errorf("mark activation code claimed: %w", err)
	}
	count, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("check activation claim update: %w", err)
	}
	if count != 1 {
		return ErrAlreadyClaimed
	}

	return nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanVehicle(row scanner) (vehicle.Vehicle, error) {
	var (
		item         vehicle.Vehicle
		ownerID      sql.NullString
		vin          sql.NullString
		year         sql.NullInt16
		licensePlate sql.NullString
	)

	if err := row.Scan(
		&item.ID,
		&ownerID,
		&vin,
		&item.Brand,
		&item.Model,
		&year,
		&licensePlate,
		&item.CreatedAt,
		&item.UpdatedAt,
	); err != nil {
		return vehicle.Vehicle{}, err
	}

	if ownerID.Valid {
		item.OwnerID = ownerID.String
	}
	if vin.Valid {
		item.VIN = &vin.String
	}
	if year.Valid {
		value := year.Int16
		item.Year = &value
	}
	if licensePlate.Valid {
		item.LicensePlate = &licensePlate.String
	}

	return item, nil
}

func scanDevice(row scanner) (device.Device, error) {
	var (
		item       device.Device
		name       sql.NullString
		lastSeenAt sql.NullTime
	)

	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.DeviceUID,
		&name,
		&item.Status,
		&lastSeenAt,
		&item.CreatedAt,
		&item.UpdatedAt,
	); err != nil {
		return device.Device{}, err
	}

	if name.Valid {
		item.Name = &name.String
	}
	if lastSeenAt.Valid {
		value := lastSeenAt.Time
		item.LastSeenAt = &value
	}

	return item, nil
}

func scanActivation(row scanner) (Activation, error) {
	var (
		item      Activation
		claimedAt sql.NullTime
		claimedBy sql.NullString
	)

	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.ExpiresAt,
		&claimedAt,
		&claimedBy,
		&item.CreatedBy,
		&item.CreatedAt,
	); err != nil {
		return Activation{}, err
	}
	if claimedAt.Valid {
		value := claimedAt.Time
		item.ClaimedAt = &value
	}
	if claimedBy.Valid {
		value := claimedBy.String
		item.ClaimedBy = &value
	}

	return item, nil
}

func isUniqueViolation(err error, constraint string) bool {
	if err == nil {
		return false
	}

	message := err.Error()
	return strings.Contains(message, constraint) ||
		strings.Contains(message, "duplicate key")
}
