export { BrandMark } from './BrandMark';
