package notification

import "time"

const (
	TypeVehicleAlert            = "vehicle_alert"
	TypeServiceRequestAssigned  = "service_request_assigned"
	TypeServiceRequestStarted   = "service_request_started"
	TypeServiceRequestCompleted = "service_request_completed"
)

type Notification struct {
	ID               string    `json:"id"`
	UserID           string    `json:"user_id"`
	AlertID          *string   `json:"alert_id"`
	ServiceRequestID *string   `json:"service_request_id"`
	NotificationType string    `json:"notification_type"`
	Title            string    `json:"title"`
	Message          string    `json:"message"`
	IsRead           bool      `json:"is_read"`
	CreatedAt        time.Time `json:"created_at"`
}

type NewNotification struct {
	UserID           string
	AlertID          *string
	ServiceRequestID *string
	NotificationType string
	Title            string
	Message          string
}
