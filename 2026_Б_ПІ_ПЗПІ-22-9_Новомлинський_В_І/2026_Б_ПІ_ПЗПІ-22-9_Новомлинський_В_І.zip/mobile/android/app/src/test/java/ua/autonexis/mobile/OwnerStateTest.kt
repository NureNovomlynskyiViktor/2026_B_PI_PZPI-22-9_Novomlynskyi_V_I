package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.owner.OwnerDestination
import ua.autonexis.mobile.ui.owner.OwnerViewModel

class OwnerStateTest {
    @Test
    fun loadingThenLoadedShowsVehicles() {
        val viewModel = OwnerViewModel()
        val owner = user()
        val vehicles = listOf(vehicle())

        viewModel.showInitialLoading()
        assertTrue(viewModel.uiState.isLoading)
        assertTrue(viewModel.uiState.vehicles.isEmpty())

        viewModel.showVehicles(owner, vehicles)

        assertFalse(viewModel.uiState.isLoading)
        assertEquals(owner, viewModel.uiState.user)
        assertEquals(vehicles, viewModel.uiState.vehicles)
        assertEquals(OwnerDestination.VEHICLES, viewModel.uiState.destination)
    }

    @Test
    fun emptyVehicleStateIsRepresentedWithoutFakeVehicles() {
        val viewModel = OwnerViewModel()

        viewModel.showVehicles(user(), emptyList())

        assertFalse(viewModel.uiState.isLoading)
        assertTrue(viewModel.uiState.vehicles.isEmpty())
        assertEquals(OwnerDestination.VEHICLES, viewModel.uiState.destination)
    }

    @Test
    fun refreshLockPreventsDuplicateRefresh() {
        val viewModel = OwnerViewModel()
        viewModel.showVehicles(user(), listOf(vehicle()))

        assertTrue(viewModel.startRefresh())
        assertFalse(viewModel.startRefresh())

        viewModel.finishRefresh(user(), listOf(vehicle(id = "vehicle-2")))
        assertFalse(viewModel.uiState.isRefreshing)
    }

    @Test
    fun connectLockPreventsDuplicateClaims() {
        val viewModel = OwnerViewModel()
        viewModel.showConnectVehicle(activationCode = "AX7K-29QP")

        assertTrue(viewModel.startConnect())
        assertFalse(viewModel.startConnect())
        assertTrue(viewModel.uiState.isConnecting)
    }

    @Test
    fun activationCodeIsPreservedAfterFailedClaim() {
        val viewModel = OwnerViewModel()
        viewModel.showConnectVehicle(activationCode = "AX7K-29QP")
        viewModel.startConnect()

        viewModel.failConnect("Activation code is invalid.")

        assertEquals("AX7K-29QP", viewModel.uiState.activationCode)
        assertFalse(viewModel.uiState.isConnecting)
        assertTrue(viewModel.uiState.isError)
    }

    @Test
    fun successfulClaimClearsActivationCodeAndReturnsToVehicles() {
        val viewModel = OwnerViewModel()
        viewModel.showConnectVehicle(activationCode = "AX7K-29QP")
        viewModel.startConnect()

        viewModel.finishConnect(user(), listOf(vehicle()))

        assertEquals("", viewModel.uiState.activationCode)
        assertEquals(OwnerDestination.VEHICLES, viewModel.uiState.destination)
        assertFalse(viewModel.uiState.isConnecting)
        assertEquals(1, viewModel.uiState.vehicles.size)
    }

    @Test
    fun qrSuccessUpdatesActivationCode() {
        val viewModel = OwnerViewModel()
        viewModel.showConnectVehicle(activationCode = "ABCD-1234")

        viewModel.applyScannedCode("RNF6-CQSD", "Review the scanned activation code, then press Connect.")

        assertEquals("RNF6-CQSD", viewModel.uiState.activationCode)
        assertEquals(OwnerDestination.CONNECT_VEHICLE, viewModel.uiState.destination)
        assertFalse(viewModel.uiState.isError)
    }

    @Test
    fun qrCancellationPreservesPreviousInput() {
        val viewModel = OwnerViewModel()
        viewModel.showConnectVehicle(activationCode = "AX7K-29QP")

        viewModel.applyQrMessage("QR scanning was cancelled.", isError = true)

        assertEquals("AX7K-29QP", viewModel.uiState.activationCode)
        assertTrue(viewModel.uiState.isError)
    }

    @Test
    fun logoutActionRemainsAvailableWhenNotConnecting() {
        val viewModel = OwnerViewModel()
        viewModel.showVehicles(user(), listOf(vehicle()))

        assertTrue(viewModel.canLogout())
    }

    @Test
    fun safeErrorsDoNotContainAccessTokensWhenCallerPassesSafeMessage() {
        val viewModel = OwnerViewModel()
        val token = "secret-access-token"
        viewModel.showVehicles(user(), listOf(vehicle()))

        viewModel.failRefresh("Could not load vehicles.")

        assertFalse(viewModel.uiState.message.orEmpty().contains(token))
    }

    private fun user() = User(
        id = "owner-1",
        email = "owner@example.com",
        role = "vehicle_owner",
        fullName = "Owner Example",
    )

    private fun vehicle(id: String = "vehicle-1") = Vehicle(
        id = id,
        brand = "Toyota",
        model = "Corolla",
        year = 2022,
        licensePlate = "AX-0002",
    )
}