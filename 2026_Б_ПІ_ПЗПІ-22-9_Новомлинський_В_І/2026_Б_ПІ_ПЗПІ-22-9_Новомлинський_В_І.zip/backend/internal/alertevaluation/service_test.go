package alertevaluation

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	evaluationVehicleID = "22222222-2222-2222-2222-222222222222"
	evaluationOwnerID   = "11111111-1111-1111-1111-111111111111"
)

type vehicleService struct {
	err error
}

func (s vehicleService) GetByID(context.Context, string) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{
		ID:      evaluationVehicleID,
		OwnerID: evaluationOwnerID,
		Brand:   "Toyota",
		Model:   "Corolla",
	}, s.err
}

type telemetryService struct {
	record telemetry.Record
	err    error
}

func (s telemetryService) LatestByVehicle(
	context.Context,
	string,
) (telemetry.Record, error) {
	return s.record, s.err
}

type thresholdService struct {
	settings []threshold.Setting
	err      error
}

func (s thresholdService) ListByVehicle(
	context.Context,
	string,
) ([]threshold.Setting, error) {
	return s.settings, s.err
}

type alertWriter struct {
	incidents  map[string]alert.Alert
	inputs     []alert.NewAlert
	recoveries []alert.RecoveryInput
	err        error
}

func (w *alertWriter) ApplyEvaluation(
	_ context.Context,
	input alert.NewAlert,
) (alert.Alert, alert.LifecycleAction, error) {
	w.inputs = append(w.inputs, input)
	if w.err != nil {
		return alert.Alert{}, "", w.err
	}

	if w.incidents == nil {
		w.incidents = make(map[string]alert.Alert)
	}

	if existing, ok := w.incidents[input.Type]; ok && existing.Status != alert.StatusResolved {
		if existing.Status == alert.StatusCleared {
			current := input.Severity
			existing.TelemetryRecordID = input.TelemetryRecordID
			if severityRank(input.Severity) > severityRank(existing.Severity) {
				existing.Severity = input.Severity
			}
			existing.CurrentSeverity = &current
			existing.Status = alert.StatusActive
			existing.Message = input.Message
			existing.Recommendation = &input.Recommendation
			existing.OccurrenceCount++
			existing.RecoveryStreak = 0
			existing.ClearedAt = nil
			w.incidents[input.Type] = existing
			return existing, alert.LifecycleReopened, nil
		}
		current := input.Severity
		if severityRank(input.Severity) > severityRank(existing.Severity) {
			existing.TelemetryRecordID = input.TelemetryRecordID
			existing.Severity = input.Severity
			existing.CurrentSeverity = &current
			existing.Message = input.Message
			existing.Recommendation = &input.Recommendation
			existing.RecoveryStreak = 0
			w.incidents[input.Type] = existing
			return existing, alert.LifecycleEscalated, nil
		}
		if existing.CurrentSeverity == nil || *existing.CurrentSeverity != input.Severity {
			existing.TelemetryRecordID = input.TelemetryRecordID
			existing.CurrentSeverity = &current
			existing.Message = input.Message
			existing.Recommendation = &input.Recommendation
			existing.RecoveryStreak = 0
			w.incidents[input.Type] = existing
			return existing, alert.LifecycleUpdated, nil
		}
		return existing, alert.LifecycleExisting, nil
	}

	current := input.Severity
	created := alert.Alert{
		ID:                "created-" + key(input),
		VehicleID:         input.VehicleID,
		TelemetryRecordID: input.TelemetryRecordID,
		Type:              input.Type,
		Severity:          input.Severity,
		CurrentSeverity:   &current,
		Status:            alert.StatusActive,
		Message:           input.Message,
		OccurrenceCount:   1,
	}
	w.incidents[input.Type] = created

	return created, alert.LifecycleCreated, nil
}

func (w *alertWriter) ApplyRecovery(
	_ context.Context,
	input alert.RecoveryInput,
) (alert.Alert, alert.LifecycleAction, error) {
	w.recoveries = append(w.recoveries, input)
	if w.err != nil {
		return alert.Alert{}, "", w.err
	}
	if w.incidents == nil {
		return alert.Alert{}, alert.LifecycleExisting, nil
	}

	existing, ok := w.incidents[input.Type]
	if !ok || existing.Status != alert.StatusActive {
		return alert.Alert{}, alert.LifecycleExisting, nil
	}

	if input.Recovered {
		existing.RecoveryStreak++
		if existing.RecoveryStreak >= input.RequiredSamples {
			existing.TelemetryRecordID = input.TelemetryRecordID
			existing.Status = alert.StatusCleared
			existing.CurrentSeverity = nil
			existing.RecoveryStreak = 0
			w.incidents[input.Type] = existing
			return existing, alert.LifecycleCleared, nil
		}
	} else {
		existing.RecoveryStreak = 0
	}
	existing.TelemetryRecordID = input.TelemetryRecordID
	w.incidents[input.Type] = existing
	return existing, alert.LifecycleExisting, nil
}

func key(input alert.NewAlert) string {
	return input.Type + ":" + input.Severity
}

func severityRank(severity string) int {
	switch severity {
	case "critical":
		return 2
	case "warning":
		return 1
	default:
		return 0
	}
}

type notificationWriter struct {
	inputs []notification.NewNotification
	err    error
}

func (w *notificationWriter) Create(
	_ context.Context,
	input notification.NewNotification,
) (notification.Notification, error) {
	w.inputs = append(w.inputs, input)
	if w.err != nil {
		return notification.Notification{}, w.err
	}

	return notification.Notification{
		ID:               "notification",
		UserID:           input.UserID,
		AlertID:          input.AlertID,
		NotificationType: input.NotificationType,
		Title:            input.Title,
		Message:          input.Message,
	}, nil
}

func TestServiceEvaluate(t *testing.T) {
	record := telemetry.Record{
		ID:                5,
		VehicleID:         evaluationVehicleID,
		EngineTemperature: 94.1,
		BatteryVoltage:    13.7,
		VibrationLevel:    1.9,
		RPM:               2400,
	}
	settings := []threshold.Setting{
		{Parameter: "engine_temperature", WarningValue: 90, CriticalValue: 105},
		{Parameter: "battery_voltage", WarningValue: 12.2, CriticalValue: 11.5},
		{Parameter: "vibration_level", WarningValue: 1.5, CriticalValue: 1.8},
		{Parameter: "rpm", WarningValue: 2200, CriticalValue: 3500},
	}
	writer := &alertWriter{
		incidents: map[string]alert.Alert{
			"engine_temperature": {
				ID:              "existing-warning",
				Type:            "engine_temperature",
				Severity:        "warning",
				CurrentSeverity: stringPtr("warning"),
				Status:          alert.StatusActive,
			},
			"vibration_level": {
				ID:              "existing-critical",
				Type:            "vibration_level",
				Severity:        "critical",
				CurrentSeverity: stringPtr("critical"),
				Status:          alert.StatusActive,
			},
		},
	}
	notifications := &notificationWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{record: record},
		thresholdService{settings: settings},
		writer,
		notifications,
	)

	result, err := service.Evaluate(context.Background(), evaluationVehicleID)
	if err != nil {
		t.Fatalf("Evaluate() returned an error: %v", err)
	}
	if result.TelemetryRecordID != 5 {
		t.Fatalf("expected telemetry record 5, got %d", result.TelemetryRecordID)
	}
	if result.EvaluatedRules != 4 {
		t.Fatalf("expected 4 evaluated rules, got %d", result.EvaluatedRules)
	}
	if len(result.CreatedAlerts) != 1 || result.CreatedAlerts[0].Type != "rpm" {
		t.Fatalf("expected one created RPM alert, got %#v", result.CreatedAlerts)
	}
	if len(result.ExistingAlerts) != 2 {
		t.Fatalf("expected two existing alerts, got %d", len(result.ExistingAlerts))
	}
	if result.OverallResult != "critical" {
		t.Fatalf("expected critical result, got %s", result.OverallResult)
	}
	if len(writer.inputs) != 3 {
		t.Fatalf("expected three exceeded thresholds, got %d", len(writer.inputs))
	}
	if len(notifications.inputs) != 1 {
		t.Fatalf("expected one notification for created alert, got %d", len(notifications.inputs))
	}
	if notifications.inputs[0].UserID != evaluationOwnerID {
		t.Fatalf("expected owner notification for %s, got %s", evaluationOwnerID, notifications.inputs[0].UserID)
	}
}

func TestEvaluateRecordCreatesNotificationForNewWarningAlert(t *testing.T) {
	notifications := &notificationWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{Parameter: "engine_temperature", WarningValue: 90, CriticalValue: 105},
		}},
		&alertWriter{},
		notifications,
	)

	result, err := service.EvaluateRecord(
		context.Background(),
		telemetry.Record{
			ID:                7,
			VehicleID:         evaluationVehicleID,
			EngineTemperature: 95,
		},
	)
	if err != nil {
		t.Fatalf("EvaluateRecord() returned an error: %v", err)
	}
	if len(result.CreatedAlerts) != 1 || result.CreatedAlerts[0].Severity != "warning" {
		t.Fatalf("expected one warning alert, got %#v", result.CreatedAlerts)
	}
	if len(notifications.inputs) != 1 {
		t.Fatalf("expected one notification, got %d", len(notifications.inputs))
	}
	if notifications.inputs[0].AlertID == nil ||
		*notifications.inputs[0].AlertID != result.CreatedAlerts[0].ID {
		t.Fatalf("expected notification linked to created alert")
	}
	if notifications.inputs[0].NotificationType != notification.TypeVehicleAlert {
		t.Fatalf("expected vehicle alert notification type, got %q", notifications.inputs[0].NotificationType)
	}
	if notifications.inputs[0].Title != "WARNING alert: engine_temperature" {
		t.Fatalf("unexpected notification title: %q", notifications.inputs[0].Title)
	}
}

func TestEvaluateRecordCreatesNotificationForNewCriticalAlert(t *testing.T) {
	notifications := &notificationWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{Parameter: "vibration_level", WarningValue: 1.5, CriticalValue: 2.0},
		}},
		&alertWriter{},
		notifications,
	)

	result, err := service.EvaluateRecord(
		context.Background(),
		telemetry.Record{
			ID:             8,
			VehicleID:      evaluationVehicleID,
			VibrationLevel: 2.7,
		},
	)
	if err != nil {
		t.Fatalf("EvaluateRecord() returned an error: %v", err)
	}
	if len(result.CreatedAlerts) != 1 || result.CreatedAlerts[0].Severity != "critical" {
		t.Fatalf("expected one critical alert, got %#v", result.CreatedAlerts)
	}
	if len(notifications.inputs) != 1 {
		t.Fatalf("expected one notification, got %d", len(notifications.inputs))
	}
	if notifications.inputs[0].Title != "CRITICAL alert: vibration_level" {
		t.Fatalf("unexpected notification title: %q", notifications.inputs[0].Title)
	}
}

func TestEvaluateRecordSkipsNotificationForExistingAlert(t *testing.T) {
	notifications := &notificationWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{Parameter: "rpm", WarningValue: 2200, CriticalValue: 3500},
		}},
		&alertWriter{
			incidents: map[string]alert.Alert{
				"rpm": {
					ID:              "existing-rpm-warning",
					Type:            "rpm",
					Severity:        "warning",
					CurrentSeverity: stringPtr("warning"),
					Status:          alert.StatusActive,
				},
			},
		},
		notifications,
	)

	result, err := service.EvaluateRecord(
		context.Background(),
		telemetry.Record{
			ID:        9,
			VehicleID: evaluationVehicleID,
			RPM:       2500,
		},
	)
	if err != nil {
		t.Fatalf("EvaluateRecord() returned an error: %v", err)
	}
	if len(result.CreatedAlerts) != 0 || len(result.ExistingAlerts) != 1 {
		t.Fatalf("expected existing alert only, got created=%#v existing=%#v", result.CreatedAlerts, result.ExistingAlerts)
	}
	if len(notifications.inputs) != 0 {
		t.Fatalf("expected no duplicate notification, got %d", len(notifications.inputs))
	}
}

func TestEvaluateRecordFollowsAlertLifecycleTransitions(t *testing.T) {
	writer := &alertWriter{}
	notifications := &notificationWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{
				Parameter:       "engine_temperature",
				WarningValue:    90,
				CriticalValue:   105,
				RecoveryMargin:  3,
				RecoverySamples: 3,
			},
		}},
		writer,
		notifications,
	)

	evaluateTemperature := func(id int64, temperature float64) Result {
		t.Helper()
		result, err := service.EvaluateRecord(
			context.Background(),
			telemetry.Record{
				ID:                id,
				VehicleID:         evaluationVehicleID,
				EngineTemperature: temperature,
			},
		)
		if err != nil {
			t.Fatalf("EvaluateRecord() returned an error: %v", err)
		}
		return result
	}

	result := evaluateTemperature(10, 80)
	if len(result.CreatedAlerts) != 0 ||
		len(result.ExistingAlerts) != 0 ||
		len(result.UpdatedAlerts) != 0 ||
		len(result.ResolvedAlerts) != 0 ||
		len(notifications.inputs) != 0 {
		t.Fatalf("expected normal state to create nothing, got %#v", result)
	}

	result = evaluateTemperature(11, 95)
	if len(result.CreatedAlerts) != 1 ||
		result.CreatedAlerts[0].Severity != "warning" ||
		len(notifications.inputs) != 1 {
		t.Fatalf("expected normal -> warning to create alert and notification, got %#v notifications=%#v", result, notifications.inputs)
	}

	result = evaluateTemperature(12, 96)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].Severity != "warning" ||
		len(notifications.inputs) != 1 {
		t.Fatalf("expected warning -> warning to create nothing new, got %#v notifications=%#v", result, notifications.inputs)
	}

	result = evaluateTemperature(13, 110)
	if len(result.UpdatedAlerts) != 1 ||
		result.UpdatedAlerts[0].Severity != "critical" ||
		len(notifications.inputs) != 2 ||
		notifications.inputs[1].Title != "CRITICAL escalation: engine_temperature" {
		t.Fatalf("expected warning -> critical escalation notification, got %#v notifications=%#v", result, notifications.inputs)
	}
	criticalID := result.UpdatedAlerts[0].ID

	result = evaluateTemperature(14, 111)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].Severity != "critical" ||
		len(notifications.inputs) != 2 {
		t.Fatalf("expected critical -> critical to create nothing new, got %#v notifications=%#v", result, notifications.inputs)
	}

	result = evaluateTemperature(15, 96)
	if len(result.UpdatedAlerts) != 1 ||
		result.UpdatedAlerts[0].ID != criticalID ||
		result.UpdatedAlerts[0].Status != alert.StatusActive ||
		result.UpdatedAlerts[0].Severity != "critical" ||
		result.UpdatedAlerts[0].CurrentSeverity == nil ||
		*result.UpdatedAlerts[0].CurrentSeverity != "warning" ||
		len(notifications.inputs) != 2 {
		t.Fatalf("expected critical -> warning to update active alert without notification, got %#v notifications=%#v", result, notifications.inputs)
	}
	active := writer.incidents["engine_temperature"]
	if active.ID != criticalID {
		t.Fatalf("expected same active alert ID %q after downgrade, got %q", criticalID, active.ID)
	}
	if active.Status != alert.StatusActive {
		t.Fatalf("expected downgraded alert to remain active, got %q", active.Status)
	}
	if active.Severity != "critical" {
		t.Fatalf("expected maximum severity to remain critical, got %q", active.Severity)
	}
	if active.CurrentSeverity == nil || *active.CurrentSeverity != "warning" {
		t.Fatalf("expected current severity warning, got %#v", active.CurrentSeverity)
	}
	if active.TelemetryRecordID != 15 {
		t.Fatalf("expected latest telemetry record 15, got %d", active.TelemetryRecordID)
	}
	if !strings.Contains(active.Message, "96.000") {
		t.Fatalf("expected warning message to contain latest measured value, got %q", active.Message)
	}
	if active.Recommendation == nil || !strings.Contains(*active.Recommendation, "schedule an inspection") {
		t.Fatalf("expected warning recommendation to be stored, got %#v", active.Recommendation)
	}
	if len(writer.incidents) != 1 {
		t.Fatalf("expected one incident for vehicle and parameter, got %d", len(writer.incidents))
	}

	result = evaluateTemperature(16, 80)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].RecoveryStreak != 1 ||
		len(notifications.inputs) != 2 {
		t.Fatalf("expected first recovery sample to keep alert active, got %#v notifications=%#v", result, notifications.inputs)
	}

	result = evaluateTemperature(17, 80)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].RecoveryStreak != 2 ||
		len(notifications.inputs) != 2 {
		t.Fatalf("expected second recovery sample to keep alert active, got %#v notifications=%#v", result, notifications.inputs)
	}

	result = evaluateTemperature(18, 80)
	if len(result.ResolvedAlerts) != 1 ||
		result.ResolvedAlerts[0].Status != alert.StatusCleared ||
		len(notifications.inputs) != 3 ||
		notifications.inputs[2].Title != "Alert cleared: engine_temperature" {
		t.Fatalf("expected third recovery sample to clear active alert and notify, got %#v notifications=%#v", result, notifications.inputs)
	}

	result = evaluateTemperature(19, 95)
	if len(result.UpdatedAlerts) != 1 ||
		result.UpdatedAlerts[0].ID != criticalID ||
		result.UpdatedAlerts[0].OccurrenceCount != 2 ||
		result.UpdatedAlerts[0].Severity != "critical" ||
		len(notifications.inputs) != 4 ||
		notifications.inputs[3].Title != "Reopened alert: engine_temperature" {
		t.Fatalf("expected cleared -> warning recurrence to reopen same alert and notify, got %#v notifications=%#v", result, notifications.inputs)
	}
}

func TestEvaluateRecordHysteresisHoldZoneKeepsAlertActive(t *testing.T) {
	writer := &alertWriter{}
	notifications := &notificationWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{
				Parameter:       "engine_temperature",
				WarningValue:    90,
				CriticalValue:   105,
				RecoveryMargin:  3,
				RecoverySamples: 2,
			},
		}},
		writer,
		notifications,
	)

	evaluateTemperature := func(id int64, temperature float64) Result {
		t.Helper()
		result, err := service.EvaluateRecord(
			context.Background(),
			telemetry.Record{
				ID:                id,
				VehicleID:         evaluationVehicleID,
				EngineTemperature: temperature,
			},
		)
		if err != nil {
			t.Fatalf("EvaluateRecord() returned an error: %v", err)
		}
		return result
	}

	evaluateTemperature(30, 95)
	result := evaluateTemperature(31, 88)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].Status != alert.StatusActive ||
		result.ExistingAlerts[0].RecoveryStreak != 0 ||
		result.OverallResult != "warning" {
		t.Fatalf("expected hold-zone sample to keep active alert without recovery streak, got %#v", result)
	}

	result = evaluateTemperature(32, 86)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].RecoveryStreak != 1 {
		t.Fatalf("expected first recovery-zone sample to increment streak, got %#v", result)
	}

	result = evaluateTemperature(33, 86)
	if len(result.ResolvedAlerts) != 1 ||
		result.ResolvedAlerts[0].Status != alert.StatusCleared {
		t.Fatalf("expected second recovery-zone sample to clear alert, got %#v", result)
	}
}

func TestEvaluateRecordLowerIsWorseBatteryRecovery(t *testing.T) {
	writer := &alertWriter{}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{
				Parameter:       "battery_voltage",
				WarningValue:    12.2,
				CriticalValue:   11.5,
				RecoveryMargin:  0.2,
				RecoverySamples: 1,
			},
		}},
		writer,
		&notificationWriter{},
	)

	evaluateBattery := func(id int64, voltage float64) Result {
		t.Helper()
		result, err := service.EvaluateRecord(
			context.Background(),
			telemetry.Record{
				ID:             id,
				VehicleID:      evaluationVehicleID,
				BatteryVoltage: voltage,
			},
		)
		if err != nil {
			t.Fatalf("EvaluateRecord() returned an error: %v", err)
		}
		return result
	}

	result := evaluateBattery(40, 12.0)
	if len(result.CreatedAlerts) != 1 ||
		result.CreatedAlerts[0].CurrentSeverity == nil ||
		*result.CreatedAlerts[0].CurrentSeverity != "warning" {
		t.Fatalf("expected low battery warning, got %#v", result)
	}

	result = evaluateBattery(41, 12.3)
	if len(result.ExistingAlerts) != 1 ||
		result.ExistingAlerts[0].Status != alert.StatusActive {
		t.Fatalf("expected battery hysteresis hold zone to remain active, got %#v", result)
	}

	result = evaluateBattery(42, 12.4)
	if len(result.ResolvedAlerts) != 1 ||
		result.ResolvedAlerts[0].Status != alert.StatusCleared {
		t.Fatalf("expected battery to clear at warning plus margin, got %#v", result)
	}
}

func TestEvaluateRecordResolvedIncidentCreatesNewAlert(t *testing.T) {
	writer := &alertWriter{
		incidents: map[string]alert.Alert{
			"engine_temperature": {
				ID:       "resolved-incident",
				Type:     "engine_temperature",
				Severity: "warning",
				Status:   alert.StatusResolved,
			},
		},
	}
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{settings: []threshold.Setting{
			{Parameter: "engine_temperature", WarningValue: 90, CriticalValue: 105},
		}},
		writer,
		&notificationWriter{},
	)

	result, err := service.EvaluateRecord(
		context.Background(),
		telemetry.Record{
			ID:                50,
			VehicleID:         evaluationVehicleID,
			EngineTemperature: 95,
		},
	)
	if err != nil {
		t.Fatalf("EvaluateRecord() returned an error: %v", err)
	}
	if len(result.CreatedAlerts) != 1 ||
		result.CreatedAlerts[0].ID == "resolved-incident" {
		t.Fatalf("expected terminal resolved incident to create a new alert, got %#v", result)
	}
}

func TestEvaluateSupportsAllTelemetryFields(t *testing.T) {
	record := telemetry.Record{
		EngineTemperature: 101,
		BatteryVoltage:    11,
		VibrationLevel:    3,
		RPM:               4000,
		Speed:             140,
		FuelLevel:         9,
	}
	tests := []struct {
		parameter string
		warning   float64
		critical  float64
	}{
		{parameter: "engine_temperature", warning: 90, critical: 100},
		{parameter: "battery_voltage", warning: 12, critical: 11.5},
		{parameter: "vibration_level", warning: 2, critical: 2.5},
		{parameter: "rpm", warning: 3000, critical: 3500},
		{parameter: "speed", warning: 120, critical: 130},
		{parameter: "fuel_level", warning: 15, critical: 10},
	}

	for _, tt := range tests {
		t.Run(tt.parameter, func(t *testing.T) {
			_, severity, exceeded := evaluate(
				record,
				threshold.Setting{
					Parameter:     tt.parameter,
					WarningValue:  tt.warning,
					CriticalValue: tt.critical,
				},
			)
			if !exceeded || severity != "critical" {
				t.Fatalf("expected critical threshold result, got %q", severity)
			}
		})
	}
}

func TestServiceValidationAndNotFoundErrors(t *testing.T) {
	service := NewService(
		vehicleService{},
		telemetryService{},
		thresholdService{},
		&alertWriter{},
		&notificationWriter{},
	)
	if _, err := service.Evaluate(context.Background(), "invalid"); !errors.Is(err, ErrInvalidVehicleID) {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}

	service = NewService(
		vehicleService{err: vehicle.ErrNotFound},
		telemetryService{},
		thresholdService{},
		&alertWriter{},
		&notificationWriter{},
	)
	if _, err := service.Evaluate(context.Background(), evaluationVehicleID); !errors.Is(err, ErrVehicleNotFound) {
		t.Fatalf("expected ErrVehicleNotFound, got %v", err)
	}

	service = NewService(
		vehicleService{},
		telemetryService{err: telemetry.ErrNotFound},
		thresholdService{},
		&alertWriter{},
		&notificationWriter{},
	)
	if _, err := service.Evaluate(context.Background(), evaluationVehicleID); !errors.Is(err, ErrTelemetryNotFound) {
		t.Fatalf("expected ErrTelemetryNotFound, got %v", err)
	}
}

func stringPtr(value string) *string {
	return &value
}
