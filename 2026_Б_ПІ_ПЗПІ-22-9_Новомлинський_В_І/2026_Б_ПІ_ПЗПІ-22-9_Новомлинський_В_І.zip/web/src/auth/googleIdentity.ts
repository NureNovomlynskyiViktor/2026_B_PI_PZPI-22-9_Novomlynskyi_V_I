const GOOGLE_IDENTITY_SCRIPT_SRC = 'https://accounts.google.com/gsi/client';
const GOOGLE_IDENTITY_SCRIPT_ID = 'autonexis-google-identity-script';

export type GoogleCredentialResponse = {
  credential?: string;
  select_by?: string;
};

type GoogleIdentityInitializeConfig = {
  client_id: string;
  callback: (response: GoogleCredentialResponse) => void;
  ux_mode: 'popup';
  auto_select?: boolean;
};

export type GoogleButtonConfig = {
  type: 'standard' | 'icon';
  theme: 'outline' | 'filled_blue' | 'filled_black';
  size: 'large' | 'medium' | 'small';
  text: 'signin_with' | 'signup_with' | 'continue_with' | 'signin';
  shape: 'rectangular' | 'pill' | 'circle' | 'square';
  logo_alignment: 'left' | 'center';
  width?: string;
};

type GoogleIdentityAPI = {
  accounts: {
    id: {
      initialize(config: GoogleIdentityInitializeConfig): void;
      renderButton(parent: HTMLElement, options: GoogleButtonConfig): void;
    };
  };
};

declare global {
  interface Window {
    google?: GoogleIdentityAPI;
  }
}

let scriptPromise: Promise<void> | null = null;
let initializedClientID: string | null = null;
let credentialCallback: ((response: GoogleCredentialResponse) => void) | null = null;

export function loadGoogleIdentityScript(): Promise<void> {
  if (hasGoogleIdentityAPI()) {
    return Promise.resolve();
  }

  if (scriptPromise) {
    return scriptPromise;
  }

  const existingScript = document.querySelector<HTMLScriptElement>(
    `script[src="${GOOGLE_IDENTITY_SCRIPT_SRC}"]`,
  );

  scriptPromise = new Promise<void>((resolve, reject) => {
    const script = existingScript ?? document.createElement('script');

    const handleLoad = () => {
      if (hasGoogleIdentityAPI()) {
        resolve();
        return;
      }

      scriptPromise = null;
      reject(new Error('Google Identity Services loaded without an accounts API.'));
    };

    const handleError = () => {
      if (script.id === GOOGLE_IDENTITY_SCRIPT_ID) {
        script.remove();
      }
      scriptPromise = null;
      reject(new Error('Google Identity Services failed to load.'));
    };

    script.addEventListener('load', handleLoad, { once: true });
    script.addEventListener('error', handleError, { once: true });

    if (!existingScript) {
      script.id = GOOGLE_IDENTITY_SCRIPT_ID;
      script.src = GOOGLE_IDENTITY_SCRIPT_SRC;
      script.async = true;
      script.defer = true;
      document.head.appendChild(script);
      return;
    }

    if (hasGoogleIdentityAPI()) {
      resolve();
    }
  });

  return scriptPromise;
}

export async function initializeGoogleIdentity(
  clientID: string,
  onCredential: (response: GoogleCredentialResponse) => void,
): Promise<void> {
  const normalizedClientID = clientID.trim();
  if (!normalizedClientID) {
    throw new Error('Google client ID is not configured.');
  }

  await loadGoogleIdentityScript();

  const googleAPI = window.google?.accounts.id;
  if (!googleAPI) {
    throw new Error('Google Identity Services is unavailable.');
  }

  credentialCallback = onCredential;

  if (initializedClientID) {
    if (initializedClientID !== normalizedClientID) {
      throw new Error('Google Identity Services was initialized with a different client ID.');
    }
    return;
  }

  initializedClientID = normalizedClientID;
  googleAPI.initialize({
    client_id: normalizedClientID,
    ux_mode: 'popup',
    auto_select: false,
    callback(response) {
      credentialCallback?.(response);
    },
  });
}

export function renderGoogleSignInButton(
  container: HTMLElement,
  options: GoogleButtonConfig,
): void {
  const googleAPI = window.google?.accounts.id;
  if (!googleAPI) {
    throw new Error('Google Identity Services is unavailable.');
  }

  container.replaceChildren();
  googleAPI.renderButton(container, options);
}

function hasGoogleIdentityAPI(): boolean {
  return Boolean(window.google?.accounts.id);
}
