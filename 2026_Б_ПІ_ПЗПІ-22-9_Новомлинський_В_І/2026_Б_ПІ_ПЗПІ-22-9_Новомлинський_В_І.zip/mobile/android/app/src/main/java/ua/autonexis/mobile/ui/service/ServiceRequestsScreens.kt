package ua.autonexis.mobile.ui.service

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.R
import ua.autonexis.mobile.ServiceRequest
import ua.autonexis.mobile.ServiceRequestDraft
import ua.autonexis.mobile.ui.UiStringResources
import ua.autonexis.mobile.ui.owner.OwnerNavigationBar
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets
import java.util.Locale

@Composable
internal fun ServiceRequestsRoot(
    state: ServiceRequestsUiState,
    notificationUnreadCount: Int,
    onBackToVehicleDetails: () -> Unit,
    onRequests: () -> Unit,
    onRefresh: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
    onOpenDetails: (String) -> Unit,
    onBackToList: () -> Unit,
    onBackFromDetails: () -> Unit,
    onCreateManualRequest: () -> Unit,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onPriorityChange: (String) -> Unit,
    onSubmitCreate: () -> Unit,
    onBackFromCreate: () -> Unit,
    onRequestCancel: (String) -> Unit,
    onDismissCancel: () -> Unit,
    onConfirmCancel: (String) -> Unit,
) {
    val selectedRequest = state.requests.firstOrNull { it.id == state.selectedRequestId }
    val createManualServiceRequestLabel = stringResource(R.string.create_manual_service_request)
    val title = when (state.destination) {
        ServiceRequestsDestination.LIST -> stringResource(R.string.service_requests)
        ServiceRequestsDestination.DETAILS -> stringResource(R.string.request_details)
        ServiceRequestsDestination.CREATE -> stringResource(R.string.create_request)
    }
    val backTarget = ServiceRequestsPresentation.backTarget(
        mode = state.mode,
        destination = state.destination,
        detailsOrigin = state.detailsOrigin,
        formOrigin = state.formOrigin,
    )
    val backAction = when (backTarget) {
        ServiceRequestsBackTarget.VEHICLE_DETAILS,
        ServiceRequestsBackTarget.VEHICLES -> onBackToVehicleDetails
        ServiceRequestsBackTarget.REQUESTS_LIST,
        ServiceRequestsBackTarget.NOTIFICATIONS -> onBackFromDetails
        ServiceRequestsBackTarget.REQUEST_DETAILS -> onBackFromCreate
    }
    BackHandler(onBack = backAction)

    Scaffold(
        topBar = {
            ServiceRequestsTopBar(
                title = title,
                subtitle = state.vehicleLabel,
                isBusy = state.isLoading || state.isRefreshing || state.isSubmitting || state.cancellingRequestId != null,
                onBack = backAction,
                onRefresh = if (state.destination == ServiceRequestsDestination.CREATE) null else onRefresh,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = when (state.detailsOrigin) {
                    ServiceRequestDetailsOrigin.NOTIFICATIONS -> OwnerNavigationTab.NOTIFICATIONS
                    else -> if (state.mode == ServiceRequestsMode.GLOBAL) OwnerNavigationTab.REQUESTS else OwnerNavigationTab.VEHICLES
                },
                notificationUnreadCount = notificationUnreadCount,
                onVehicles = onBackToVehicleDetails,
                onRequests = onRequests,
                onNotifications = onNotifications,
                onAccount = onAccount,
            )
        },
        floatingActionButton = {
            if (
                state.destination == ServiceRequestsDestination.LIST &&
                state.requests.isNotEmpty() &&
                ServiceRequestsPresentation.canCreateInMode(state.mode) &&
                !state.isLoading
            ) {
                ExtendedFloatingActionButton(
                    onClick = onCreateManualRequest,
                    containerColor = AutonexisColors.ElectricBlue,
                    contentColor = AutonexisColors.White,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.semantics { contentDescription = createManualServiceRequestLabel },
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_owner_requests),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(stringResource(R.string.create_request))
                    }
                }
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.requests.isEmpty() -> LoadingState(state.message ?: stringResource(R.string.loading_service_requests))
                state.isError && state.requests.isEmpty() && state.destination == ServiceRequestsDestination.LIST -> InitialErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_service_requests_message),
                    onRetry = onRefresh,
                    onBack = onBackToVehicleDetails,
                )
                state.destination == ServiceRequestsDestination.LIST -> ServiceRequestsListContent(
                    state = state,
                    onOpenDetails = onOpenDetails,
                    onCreateManualRequest = onCreateManualRequest,
                )
                state.destination == ServiceRequestsDestination.DETAILS -> ServiceRequestDetailsContent(
                    request = selectedRequest,
                    state = state,
                    onBackToList = onBackFromDetails,
                    onRequestCancel = onRequestCancel,
                )
                state.destination == ServiceRequestsDestination.CREATE -> ServiceRequestFormContent(
                    state = state,
                    onTitleChange = onTitleChange,
                    onDescriptionChange = onDescriptionChange,
                    onPriorityChange = onPriorityChange,
                    onSubmitCreate = onSubmitCreate,
                )
            }

            val pendingRequest = state.pendingCancelRequestId?.let { pendingId ->
                state.requests.firstOrNull { it.id == pendingId }
            }
            if (pendingRequest != null) {
                CancelConfirmationDialog(
                    request = pendingRequest,
                    onDismiss = onDismissCancel,
                    onConfirm = { onConfirmCancel(pendingRequest.id) },
                )
            }
        }
    }
}

@Composable
private fun localizedStatusLabel(status: String): String {
    return UiStringResources.statusLabelRes(status)?.let { stringResource(it) }
        ?: ServiceRequestsPresentation.statusLabel(status)
}

@Composable
private fun localizedPriorityLabel(priority: String): String {
    return UiStringResources.priorityLabelRes(priority)?.let { stringResource(it) }
        ?: ServiceRequestsPresentation.priorityLabel(priority)
}

@Composable
private fun specialistAssignmentLabel(request: ServiceRequest): String {
    return if (request.assignedSpecialistId.isNullOrBlank()) {
        stringResource(R.string.no_specialist_assigned)
    } else {
        stringResource(R.string.specialist_assigned)
    }
}

@Composable
private fun ServiceRequestsListContent(
    state: ServiceRequestsUiState,
    onOpenDetails: (String) -> Unit,
    onCreateManualRequest: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        item { SummaryCard(state.mode, state.requests) }
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_service_requests)) }
        }
        if (state.requests.isEmpty()) {
            item { EmptyRequestsState(state.mode, onCreateManualRequest) }
        } else {
            items(state.requests, key = { it.id }) { request ->
                ServiceRequestListCard(
                    request = request,
                    vehicleLabel = if (state.mode == ServiceRequestsMode.GLOBAL) ServiceRequestsPresentation.vehicleLabel(request, state.vehicleLabels) else null,
                    onClick = { onOpenDetails(request.id) },
                )
            }
        }
    }
}

@Composable
private fun ServiceRequestDetailsContent(
    request: ServiceRequest?,
    state: ServiceRequestsUiState,
    onBackToList: () -> Unit,
    onRequestCancel: (String) -> Unit,
) {
    if (request == null) {
        InitialErrorState(
            message = stringResource(R.string.selected_request_missing),
            onRetry = onBackToList,
            onBack = onBackToList,
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        item {
            InfoCard {
                Text(request.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                StatusAndPriorityRow(request)
                Text(request.description)
                if (state.mode == ServiceRequestsMode.GLOBAL) {
                    InfoText(ServiceRequestsPresentation.vehicleLabel(request, state.vehicleLabels))
                }
                if (ServiceRequestsPresentation.createdFromAlert(request)) {
                    InfoText(stringResource(R.string.created_from_vehicle_alert))
                } else {
                    InfoText(stringResource(R.string.manual_owner_request))
                }
                InfoText(specialistAssignmentLabel(request))
                request.resultSummary?.takeIf { it.isNotBlank() }?.let { result ->
                    DetailBlock(stringResource(R.string.result_summary), result)
                }
            }
        }
        item {
            InfoCard {
                SectionHeader(stringResource(R.string.timeline))
                TimestampLine(stringResource(R.string.created_label), request.createdAt)
                TimestampLine(stringResource(R.string.updated_label), request.updatedAt)
                TimestampLine(stringResource(R.string.assigned_label), request.assignedAt)
                TimestampLine(stringResource(R.string.started_label), request.startedAt)
                TimestampLine(stringResource(R.string.completed_label), request.completedAt)
                TimestampLine(stringResource(R.string.cancelled_label), request.cancelledAt)
            }
        }
        item {
            InfoCard {
                SectionHeader(stringResource(R.string.actions))
                if (ServiceRequestsPresentation.canCancel(request)) {
                    Button(
                        onClick = { onRequestCancel(request.id) },
                        enabled = state.cancellingRequestId == null && !state.isSubmitting,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                    ) {
                        Text(if (state.cancellingRequestId == request.id) stringResource(R.string.cancelling) else stringResource(R.string.cancel_request))
                    }
                } else {
                    EmptyText(stringResource(R.string.no_owner_actions))
                }
                OutlinedButton(
                    onClick = onBackToList,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Text(stringResource(R.string.back_to_requests))
                }
            }
        }
    }
}

@Composable
private fun ServiceRequestFormContent(
    state: ServiceRequestsUiState,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onPriorityChange: (String) -> Unit,
    onSubmitCreate: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(AutonexisSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        InfoCard {
            SectionHeader(stringResource(R.string.service_request))
            Text(
                text = stringResource(R.string.service_request_description),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (!state.draft.sourceAlertId.isNullOrBlank()) {
                InfoText(stringResource(R.string.linked_to_vehicle_alert))
                InfoText(stringResource(R.string.request_does_not_resolve_alert))
            } else {
                InfoText(stringResource(R.string.manual_request_not_linked))
            }
        }
        InfoCard {
            OutlinedTextField(
                value = state.draft.title,
                onValueChange = onTitleChange,
                enabled = !state.isSubmitting,
                label = { Text(stringResource(R.string.title_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = state.draft.description,
                onValueChange = onDescriptionChange,
                enabled = !state.isSubmitting,
                label = { Text(stringResource(R.string.description_label)) },
                minLines = 4,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(stringResource(R.string.priority), style = MaterialTheme.typography.labelLarge)
            PrioritySelector(
                selectedPriority = state.draft.priority,
                enabled = !state.isSubmitting,
                onPriorityChange = onPriorityChange,
            )
            if (!state.message.isNullOrBlank()) {
                StateMessage(state.message, state.isError)
            }
            Button(
                onClick = onSubmitCreate,
                enabled = !state.isSubmitting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) {
                Text(if (state.isSubmitting) stringResource(R.string.creating) else stringResource(R.string.create_request))
            }
        }
    }
}

@Composable
private fun ServiceRequestsTopBar(
    title: String,
    subtitle: String,
    isBusy: Boolean,
    onBack: () -> Unit,
    onRefresh: (() -> Unit)?,
) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack, enabled = !isBusy) { Text(stringResource(R.string.back)) }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            onRefresh?.let {
                TextButton(onClick = it, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
            }
        }
    }
}

@Composable
private fun SummaryCard(mode: ServiceRequestsMode, requests: List<ServiceRequest>) {
    val openCount = requests.count(ServiceRequestsPresentation::isOpen)
    val completedCount = requests.count { it.status.equals("completed", ignoreCase = true) }
    val cancelledCount = requests.count { it.status.equals("cancelled", ignoreCase = true) }
    InfoCard {
        SectionHeader(if (mode == ServiceRequestsMode.GLOBAL) stringResource(R.string.all_service_requests) else stringResource(R.string.vehicle_service_requests))
        Text(
            text = if (mode == ServiceRequestsMode.GLOBAL) {
                stringResource(R.string.global_requests_description)
            } else {
                stringResource(R.string.vehicle_requests_description)
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
            MetricTile(stringResource(R.string.open), openCount.toString(), Modifier.weight(1f))
            MetricTile(stringResource(R.string.status_completed), completedCount.toString(), Modifier.weight(1f))
            MetricTile(stringResource(R.string.status_cancelled), cancelledCount.toString(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun EmptyRequestsState(mode: ServiceRequestsMode, onCreateManualRequest: () -> Unit) {
    InfoCard {
        SectionHeader(stringResource(R.string.no_service_requests_yet))
        Text(
            text = if (mode == ServiceRequestsMode.GLOBAL) {
                stringResource(R.string.global_no_requests_message)
            } else {
                stringResource(R.string.vehicle_no_requests_message)
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (ServiceRequestsPresentation.canCreateInMode(mode)) {
            Button(
                onClick = onCreateManualRequest,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) {
                Text(stringResource(R.string.create_request))
            }
        }
    }
}

@Composable
private fun ServiceRequestListCard(request: ServiceRequest, vehicleLabel: String?, onClick: () -> Unit) {
    val openServiceRequestDescription = stringResource(R.string.open_service_request_cd, request.title)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = openServiceRequestDescription }
            .clickable(role = Role.Button, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        ) {
            Text(request.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (!vehicleLabel.isNullOrBlank()) {
                InfoText(vehicleLabel)
            }
            StatusAndPriorityRow(request)
            Text(request.description, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (ServiceRequestsPresentation.createdFromAlert(request)) {
                InfoText(stringResource(R.string.created_from_vehicle_alert))
            }
            InfoText(specialistAssignmentLabel(request))
            request.resultSummary?.takeIf { it.isNotBlank() }?.let { result ->
                Text(stringResource(R.string.result_label, result), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            DetailLine(stringResource(R.string.created_label), displayTimestamp(request.createdAt))
        }
    }
}

@Composable
private fun StatusAndPriorityRow(request: ServiceRequest) {
    Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
        Badge(
            label = localizedStatusLabel(request.status),
            color = statusTone(request.status),
        )
        Badge(
            label = localizedPriorityLabel(request.priority),
            color = priorityTone(request.priority),
        )
    }
}

@Composable
private fun PrioritySelector(
    selectedPriority: String,
    enabled: Boolean,
    onPriorityChange: (String) -> Unit,
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
        listOf("low", "normal", "high").forEach { priority ->
            val selected = ServiceRequestsPresentation.normalizedPriority(selectedPriority) == priority
            val label = localizedPriorityLabel(priority)
            if (selected) {
                Button(
                    onClick = { onPriorityChange(priority) },
                    enabled = enabled,
                    modifier = Modifier.weight(1f),
                ) { PriorityButtonLabel(label) }
            } else {
                OutlinedButton(
                    onClick = { onPriorityChange(priority) },
                    enabled = enabled,
                    modifier = Modifier.weight(1f),
                ) { PriorityButtonLabel(label) }
            }
        }
    }
}


@Composable
private fun PriorityButtonLabel(label: String) {
    Text(
        text = label,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Clip,
    )
}

@Composable
private fun CancelConfirmationDialog(
    request: ServiceRequest,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.cancel_service_request_title)) },
        text = {
            Text(
                stringResource(R.string.cancel_service_request_message, request.title),
            )
        },
        confirmButton = {
            Button(onClick = onConfirm) { Text(stringResource(R.string.cancel_request)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.keep_request)) }
        },
    )
}

@Composable
private fun LoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InitialErrorState(message: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(stringResource(R.string.could_not_load_service_requests), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onBack) { Text(stringResource(R.string.back_to_vehicle_details)) }
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            content = content,
        )
    }
}

@Composable
private fun MetricTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable
private fun InfoText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun EmptyText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun DetailBlock(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Text(value)
    }
}

@Composable
private fun TimestampLine(label: String, value: String?) {
    if (!value.isNullOrBlank()) {
        DetailLine(label, displayTimestamp(value))
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Text("$label: $value", color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Badge(label: String, color: Color) {
    Text(
        text = label,
        color = color,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(999.dp))
            .padding(horizontal = AutonexisSpacing.sm, vertical = AutonexisSpacing.xs),
    )
}

@Composable
private fun statusTone(status: String): Color {
    return when (status.trim().lowercase(Locale.US)) {
        "pending" -> AutonexisColors.Amber
        "assigned" -> MaterialTheme.colorScheme.primary
        "in_progress" -> AutonexisColors.LightBlue
        "completed" -> AutonexisColors.EmeraldGreen
        "cancelled" -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}

@Composable
private fun priorityTone(priority: String): Color {
    return when (priority.trim().lowercase(Locale.US)) {
        "high" -> AutonexisColors.CriticalRed
        "normal" -> MaterialTheme.colorScheme.primary
        "low" -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}

private fun displayTimestamp(value: String): String {
    return value
        .replace("T", " ")
        .removeSuffix("Z")
        .substringBefore(".")
}
