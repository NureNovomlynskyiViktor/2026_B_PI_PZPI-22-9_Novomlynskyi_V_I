BEGIN;

DROP INDEX IF EXISTS notifications_service_request_idx;

ALTER TABLE notifications
	DROP CONSTRAINT IF EXISTS notifications_type_check;

DELETE FROM notifications
WHERE alert_id IS NULL;

ALTER TABLE notifications
	DROP COLUMN IF EXISTS service_request_id,
	DROP COLUMN IF EXISTS notification_type;

ALTER TABLE notifications
	ALTER COLUMN alert_id SET NOT NULL;

COMMIT;
