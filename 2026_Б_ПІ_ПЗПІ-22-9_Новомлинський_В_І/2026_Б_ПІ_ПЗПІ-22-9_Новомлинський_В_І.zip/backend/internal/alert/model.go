package alert

import "time"

type Alert struct {
	ID                         string     `json:"id"`
	VehicleID                  string     `json:"vehicle_id"`
	TelemetryRecordID          int64      `json:"telemetry_record_id"`
	Type                       string     `json:"type"`
	Severity                   string     `json:"severity"`
	CurrentSeverity            *string    `json:"current_severity"`
	Status                     string     `json:"status"`
	Message                    string     `json:"message"`
	Recommendation             *string    `json:"recommendation"`
	OccurrenceCount            int        `json:"occurrence_count"`
	RecoveryStreak             int        `json:"recovery_streak"`
	CreatedAt                  time.Time  `json:"created_at"`
	LastTriggeredAt            *time.Time `json:"last_triggered_at"`
	ClearedAt                  *time.Time `json:"cleared_at"`
	ResolvedAt                 *time.Time `json:"resolved_at"`
	ResolvedByUserID           *string    `json:"resolved_by_user_id"`
	ResolutionNote             *string    `json:"resolution_note"`
	ResolutionServiceRequestID *string    `json:"resolution_service_request_id"`
}

type SpecialistResolution struct {
	AlertID          string
	SpecialistID     string
	ResolutionNote   string
	ServiceRequestID *string
}
