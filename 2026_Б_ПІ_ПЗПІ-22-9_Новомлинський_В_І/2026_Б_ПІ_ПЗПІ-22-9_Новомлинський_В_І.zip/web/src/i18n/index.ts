import { en } from './locales/en';
import { uk } from './locales/uk';
import type { LanguageMode, Locale, LocaleMessages } from './types';

export const defaultLocale: Locale = 'en';
export const languageModeStorageKey = 'autonexis_web_language_mode';

export const messages: Record<Locale, LocaleMessages> = {
  en,
  uk,
};

export {
  LocaleProvider,
  resolveLocale,
  useLocale,
  useMessages,
} from './LocaleProvider';

export type { LanguageMode, Locale, LocaleMessages };
