package device

import (
	"context"
	"testing"
)

const (
	serviceOwnerID   = "11111111-1111-1111-1111-111111111111"
	serviceVehicleID = "22222222-2222-2222-2222-222222222222"
	serviceDeviceID  = "33333333-3333-3333-3333-333333333333"
)

type repositoryStub struct {
	capturedOwnerID   string
	capturedVehicleID string
	capturedDeviceID  string
	capturedRequest   CreateRequest
}

func (r *repositoryStub) List(context.Context) ([]Device, error) {
	return []Device{}, nil
}

func (r *repositoryStub) GetByID(context.Context, string) (Device, error) {
	return Device{}, nil
}

func (r *repositoryStub) GetByUID(context.Context, string) (Device, error) {
	return Device{}, nil
}

func (r *repositoryStub) GetByVehicleID(context.Context, string) (Device, error) {
	return Device{}, nil
}

func (r *repositoryStub) ListByOwner(_ context.Context, ownerID string) ([]Device, error) {
	r.capturedOwnerID = ownerID
	return []Device{{ID: serviceDeviceID, VehicleID: serviceVehicleID}}, nil
}

func (r *repositoryStub) ListByVehicleForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) ([]Device, error) {
	r.capturedOwnerID = ownerID
	r.capturedVehicleID = vehicleID
	return []Device{{ID: serviceDeviceID, VehicleID: vehicleID}}, nil
}

func (r *repositoryStub) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	deviceID string,
) (Device, error) {
	r.capturedOwnerID = ownerID
	r.capturedDeviceID = deviceID
	return Device{ID: deviceID, VehicleID: serviceVehicleID}, nil
}

func (r *repositoryStub) CreateForOwnedVehicle(
	_ context.Context,
	ownerID string,
	vehicleID string,
	request CreateRequest,
) (Device, error) {
	r.capturedOwnerID = ownerID
	r.capturedVehicleID = vehicleID
	r.capturedRequest = request
	return Device{
		ID:        serviceDeviceID,
		VehicleID: vehicleID,
		DeviceUID: request.DeviceUID,
		Status:    "active",
	}, nil
}

func TestServiceListByOwnerPassesOwnerID(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	devices, err := service.ListByOwner(context.Background(), serviceOwnerID)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if repository.capturedOwnerID != serviceOwnerID {
		t.Fatalf("expected owner %s, got %s", serviceOwnerID, repository.capturedOwnerID)
	}
	if len(devices) != 1 {
		t.Fatalf("expected one device, got %+v", devices)
	}
}

func TestServiceCreateForOwnedVehicleNormalizesRequest(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	_, err := service.CreateForOwnedVehicle(
		context.Background(),
		serviceOwnerID,
		serviceVehicleID,
		CreateRequest{
			DeviceUID: " esp32-user-001 ",
			Name:      " My ESP32 ",
		},
	)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if repository.capturedOwnerID != serviceOwnerID {
		t.Fatalf("expected owner %s, got %s", serviceOwnerID, repository.capturedOwnerID)
	}
	if repository.capturedVehicleID != serviceVehicleID {
		t.Fatalf("expected vehicle %s, got %s", serviceVehicleID, repository.capturedVehicleID)
	}
	if repository.capturedRequest.DeviceUID != "esp32-user-001" {
		t.Fatalf("expected normalized request, got %+v", repository.capturedRequest)
	}
}

func TestServiceCreateForOwnedVehicleRejectsInvalidUID(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	_, err := service.CreateForOwnedVehicle(
		context.Background(),
		serviceOwnerID,
		serviceVehicleID,
		CreateRequest{DeviceUID: "no", Name: "My ESP32"},
	)

	if err != ErrInvalidInput {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}
	if repository.capturedOwnerID != "" {
		t.Fatal("expected invalid input to be rejected before repository call")
	}
}

func TestServiceGetByIDForOwnerPassesOwnerAndDeviceID(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	_, err := service.GetByIDForOwner(
		context.Background(),
		serviceOwnerID,
		serviceDeviceID,
	)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if repository.capturedOwnerID != serviceOwnerID {
		t.Fatalf("expected owner %s, got %s", serviceOwnerID, repository.capturedOwnerID)
	}
	if repository.capturedDeviceID != serviceDeviceID {
		t.Fatalf("expected device %s, got %s", serviceDeviceID, repository.capturedDeviceID)
	}
}
