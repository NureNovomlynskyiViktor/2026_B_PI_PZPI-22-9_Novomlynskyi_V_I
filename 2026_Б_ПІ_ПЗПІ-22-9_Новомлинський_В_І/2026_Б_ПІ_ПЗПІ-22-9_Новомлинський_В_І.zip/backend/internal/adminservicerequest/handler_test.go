package adminservicerequest

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
)

const (
	testAdminID   = "11111111-1111-1111-1111-111111111111"
	testRequestID = "22222222-2222-2222-2222-222222222222"
)

func TestCancelPassesAdministratorActor(t *testing.T) {
	service := &serviceStub{}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(
		http.MethodPatch,
		"/api/v1/admin/service-requests/"+testRequestID+"/cancel",
		nil,
	)
	request.SetPathValue("request_id", testRequestID)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:   testAdminID,
		Role: auth.AdministratorRoleCode,
	}))
	recorder := httptest.NewRecorder()

	handler.Cancel(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.cancelRequest.AdminID != testAdminID {
		t.Fatalf("expected admin actor %q, got %q", testAdminID, service.cancelRequest.AdminID)
	}
	if service.cancelRequest.RequestID != testRequestID {
		t.Fatalf("expected request ID %q, got %q", testRequestID, service.cancelRequest.RequestID)
	}
}

type serviceStub struct {
	cancelRequest servicerequest.AdminCancelRequest
}

func (s *serviceStub) ListForAdmin(context.Context, string) ([]servicerequest.Request, error) {
	return []servicerequest.Request{}, nil
}

func (s *serviceStub) GetForAdmin(context.Context, string) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testRequestID}, nil
}

func (s *serviceStub) Assign(
	context.Context,
	servicerequest.AssignRequest,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testRequestID}, nil
}

func (s *serviceStub) CancelByAdmin(
	_ context.Context,
	request servicerequest.AdminCancelRequest,
) (servicerequest.Request, error) {
	s.cancelRequest = request
	return servicerequest.Request{ID: request.RequestID, Status: servicerequest.StatusCancelled}, nil
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
