package health

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type stubDatabase struct {
	err error
}

func (s stubDatabase) PingContext(context.Context) error {
	return s.err
}

func TestHealth(t *testing.T) {
	handler := New(stubDatabase{}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/health", nil)
	recorder := httptest.NewRecorder()

	handler.Health(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"status":"ok"`) {
		t.Fatalf("expected healthy JSON response, got %s", body)
	}
}

func TestReady(t *testing.T) {
	tests := []struct {
		name       string
		database   stubDatabase
		wantStatus int
		wantBody   string
	}{
		{
			name:       "database available",
			database:   stubDatabase{},
			wantStatus: http.StatusOK,
			wantBody:   `"status":"ready"`,
		},
		{
			name:       "database unavailable",
			database:   stubDatabase{err: errors.New("database unavailable")},
			wantStatus: http.StatusServiceUnavailable,
			wantBody:   `"status":"not_ready"`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := New(tt.database, testLogger())
			request := httptest.NewRequest(http.MethodGet, "/ready", nil)
			recorder := httptest.NewRecorder()

			handler.Ready(recorder, request)

			if recorder.Code != tt.wantStatus {
				t.Fatalf("expected status %d, got %d", tt.wantStatus, recorder.Code)
			}
			if body := recorder.Body.String(); !strings.Contains(body, tt.wantBody) {
				t.Fatalf("expected response containing %s, got %s", tt.wantBody, body)
			}
		})
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
