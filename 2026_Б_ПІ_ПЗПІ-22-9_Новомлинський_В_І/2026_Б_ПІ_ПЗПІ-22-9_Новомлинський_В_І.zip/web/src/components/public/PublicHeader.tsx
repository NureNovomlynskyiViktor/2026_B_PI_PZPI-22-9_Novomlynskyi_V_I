import { useState } from 'react';
import { navigatePublic } from '../../navigation/publicNavigation';
import type { LocaleMessages } from '../../i18n';
import { AppearanceSelector } from '../appearance/AppearanceSelector';
import { BrandMark } from '../brand';
import { LanguageSelector } from '../i18n/LanguageSelector';

type Props = {
  navigation: LocaleMessages['landing']['navigation'];
};

export function PublicHeader({ navigation }: Props) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  function goToLogin() {
    setIsMenuOpen(false);
    navigatePublic('/login');
  }

  function closeMenu() {
    setIsMenuOpen(false);
  }

  return (
    <header className="public-header">
      <nav className="public-nav" aria-label={navigation.ariaLabel}>
        <a className="public-brand-link" href="#top" onClick={closeMenu}>
          <BrandMark size={44} />
        </a>
        <button
          className="public-menu-button"
          type="button"
          aria-expanded={isMenuOpen}
          aria-controls="public-navigation-links"
          onClick={() => setIsMenuOpen((current) => !current)}
        >
          <span aria-hidden="true"></span>
          <span className="sr-only">{navigation.menu}</span>
        </button>
        <div
          id="public-navigation-links"
          className={isMenuOpen ? 'public-nav-links open' : 'public-nav-links'}
        >
          <a href="#about" onClick={closeMenu}>{navigation.about}</a>
          <a href="#capabilities" onClick={closeMenu}>{navigation.capabilities}</a>
          <a href="#how-it-works" onClick={closeMenu}>{navigation.howItWorks}</a>
          <a href="#connect" onClick={closeMenu}>{navigation.connectVehicle}</a>
          <LanguageSelector className="public-language-selector" />
          <AppearanceSelector className="public-language-selector" />
          <button className="primary-button public-signin-button" type="button" onClick={goToLogin}>
            {navigation.signIn}
          </button>
        </div>
      </nav>
    </header>
  );
}
