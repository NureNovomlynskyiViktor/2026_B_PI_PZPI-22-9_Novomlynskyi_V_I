package adminuser

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

func TestAuditMetadataIncludesLifecycleContextAndReason(t *testing.T) {
	reason := "Administrative decision"
	deactivatedAt := time.Date(2026, 6, 18, 12, 0, 0, 0, time.UTC)
	metadata := auditMetadata(
		User{
			Email:    "owner@example.com",
			Role:     auth.DefaultRoleCode,
			IsActive: true,
		},
		User{
			Email:         "owner@example.com",
			Role:          auth.DefaultRoleCode,
			IsActive:      false,
			DeactivatedAt: &deactivatedAt,
		},
		&reason,
	)

	if metadata["target_email"] != "owner@example.com" {
		t.Fatalf("unexpected target email: %#v", metadata["target_email"])
	}
	if metadata["target_role"] != auth.DefaultRoleCode {
		t.Fatalf("unexpected target role: %#v", metadata["target_role"])
	}
	if metadata["previous_active_state"] != true || metadata["new_active_state"] != false {
		t.Fatalf("unexpected active-state metadata: %#v", metadata)
	}
	if metadata["reason"] != reason {
		t.Fatalf("unexpected reason: %#v", metadata["reason"])
	}
}

func TestAuditMetadataOmitsBlankReason(t *testing.T) {
	metadata := auditMetadata(
		User{Email: "admin@example.com", Role: auth.AdministratorRoleCode, IsActive: false},
		User{Email: "admin@example.com", Role: auth.AdministratorRoleCode, IsActive: true},
		nil,
	)

	if _, ok := metadata["reason"]; ok {
		t.Fatalf("reason should be omitted when absent: %#v", metadata)
	}
}

func TestSpecialistDeactivationCleanupMetadata(t *testing.T) {
	metadata := specialistDeactivationCleanupMetadata(
		User{
			ID:    testTargetUserID,
			Email: "specialist@example.com",
			Role:  auth.TechnicalSpecialistRoleCode,
		},
		2,
	)

	if metadata["specialist_id"] != testTargetUserID ||
		metadata["email"] != "specialist@example.com" ||
		metadata["removed_vehicle_assignments"] != 2 {
		t.Fatalf("unexpected cleanup metadata: %#v", metadata)
	}
	for _, forbidden := range []string{"password", "password_hash", "token"} {
		if _, ok := metadata[forbidden]; ok {
			t.Fatalf("cleanup metadata exposed secret field %q: %#v", forbidden, metadata)
		}
	}
}

func TestCleanupActiveVehicleAssignments(t *testing.T) {
	executor := &cleanupExecutor{rowsAffected: 3}

	removed, err := cleanupActiveVehicleAssignments(
		context.Background(),
		executor,
		testTargetUserID,
	)
	if err != nil {
		t.Fatalf("cleanupActiveVehicleAssignments returned error: %v", err)
	}
	if removed != 3 {
		t.Fatalf("expected 3 removed assignments, got %d", removed)
	}
	if !strings.Contains(executor.query, "DELETE FROM vehicle_specialist_assignments") {
		t.Fatalf("expected vehicle assignment delete query, got %q", executor.query)
	}
	if len(executor.args) != 1 || executor.args[0] != testTargetUserID {
		t.Fatalf("unexpected cleanup args: %#v", executor.args)
	}
}

func TestCleanupActiveVehicleAssignmentsPropagatesErrors(t *testing.T) {
	expected := errors.New("database unavailable")
	_, err := cleanupActiveVehicleAssignments(
		context.Background(),
		&cleanupExecutor{err: expected},
		testTargetUserID,
	)
	if !errors.Is(err, expected) {
		t.Fatalf("expected delete error, got %v", err)
	}

	_, err = cleanupActiveVehicleAssignments(
		context.Background(),
		&cleanupExecutor{rowsErr: expected},
		testTargetUserID,
	)
	if !errors.Is(err, expected) {
		t.Fatalf("expected rows affected error, got %v", err)
	}
}

type cleanupExecutor struct {
	query        string
	args         []any
	rowsAffected int64
	err          error
	rowsErr      error
}

func (e *cleanupExecutor) ExecContext(
	_ context.Context,
	query string,
	args ...any,
) (sql.Result, error) {
	e.query = query
	e.args = args
	return cleanupResult{rowsAffected: e.rowsAffected, err: e.rowsErr}, e.err
}

type cleanupResult struct {
	rowsAffected int64
	err          error
}

func (cleanupResult) LastInsertId() (int64, error) {
	return 0, nil
}

func (r cleanupResult) RowsAffected() (int64, error) {
	return r.rowsAffected, r.err
}
