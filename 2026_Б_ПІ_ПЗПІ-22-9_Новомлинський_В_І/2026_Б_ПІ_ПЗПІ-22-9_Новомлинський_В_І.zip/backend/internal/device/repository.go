package device

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
)

var ErrNotFound = errors.New("device not found")
var ErrDuplicateUID = errors.New("device UID already exists")

type Repository interface {
	List(ctx context.Context) ([]Device, error)
	GetByID(ctx context.Context, id string) (Device, error)
	GetByUID(ctx context.Context, deviceUID string) (Device, error)
	GetByVehicleID(ctx context.Context, vehicleID string) (Device, error)
	ListByOwner(ctx context.Context, ownerID string) ([]Device, error)
	ListByVehicleForOwner(
		ctx context.Context,
		ownerID string,
		vehicleID string,
	) ([]Device, error)
	GetByIDForOwner(ctx context.Context, ownerID string, deviceID string) (Device, error)
	CreateForOwnedVehicle(
		ctx context.Context,
		ownerID string,
		vehicleID string,
		request CreateRequest,
	) (Device, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) List(ctx context.Context) ([]Device, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			device_uid,
			name,
			status,
			last_seen_at,
			created_at,
			updated_at
		FROM devices
		ORDER BY created_at DESC, id
	`

	rows, err := r.db.QueryContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("query devices: %w", err)
	}
	defer rows.Close()

	devices := make([]Device, 0)
	for rows.Next() {
		item, err := scanDevice(rows)
		if err != nil {
			return nil, fmt.Errorf("scan device: %w", err)
		}
		devices = append(devices, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate devices: %w", err)
	}

	return devices, nil
}

func (r *PostgresRepository) GetByID(ctx context.Context, id string) (Device, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			device_uid,
			name,
			status,
			last_seen_at,
			created_at,
			updated_at
		FROM devices
		WHERE id = $1
	`

	item, err := scanDevice(r.db.QueryRowContext(ctx, query, id))
	if errors.Is(err, sql.ErrNoRows) {
		return Device{}, ErrNotFound
	}
	if err != nil {
		return Device{}, fmt.Errorf("query device by ID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) GetByUID(
	ctx context.Context,
	deviceUID string,
) (Device, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			device_uid,
			name,
			status,
			last_seen_at,
			created_at,
			updated_at
		FROM devices
		WHERE device_uid = $1
	`

	item, err := scanDevice(r.db.QueryRowContext(ctx, query, deviceUID))
	if errors.Is(err, sql.ErrNoRows) {
		return Device{}, ErrNotFound
	}
	if err != nil {
		return Device{}, fmt.Errorf("query device by UID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) GetByVehicleID(
	ctx context.Context,
	vehicleID string,
) (Device, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			device_uid,
			name,
			status,
			last_seen_at,
			created_at,
			updated_at
		FROM devices
		WHERE vehicle_id = $1
		ORDER BY created_at DESC, id
		LIMIT 1
	`

	item, err := scanDevice(r.db.QueryRowContext(ctx, query, vehicleID))
	if errors.Is(err, sql.ErrNoRows) {
		return Device{}, ErrNotFound
	}
	if err != nil {
		return Device{}, fmt.Errorf("query device by vehicle ID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ListByOwner(
	ctx context.Context,
	ownerID string,
) ([]Device, error) {
	const query = `
		SELECT
			d.id,
			d.vehicle_id,
			d.device_uid,
			d.name,
			d.status,
			d.last_seen_at,
			d.created_at,
			d.updated_at
		FROM devices d
		INNER JOIN vehicles v ON v.id = d.vehicle_id
		WHERE v.owner_id = $1
		ORDER BY d.created_at DESC, d.id
	`

	rows, err := r.db.QueryContext(ctx, query, ownerID)
	if err != nil {
		return nil, fmt.Errorf("query owner devices: %w", err)
	}
	defer rows.Close()

	devices := make([]Device, 0)
	for rows.Next() {
		item, err := scanDevice(rows)
		if err != nil {
			return nil, fmt.Errorf("scan owner device: %w", err)
		}
		devices = append(devices, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate owner devices: %w", err)
	}

	return devices, nil
}

func (r *PostgresRepository) ListByVehicleForOwner(
	ctx context.Context,
	ownerID string,
	vehicleID string,
) ([]Device, error) {
	const query = `
		SELECT
			d.id,
			d.vehicle_id,
			d.device_uid,
			d.name,
			d.status,
			d.last_seen_at,
			d.created_at,
			d.updated_at
		FROM devices d
		INNER JOIN vehicles v ON v.id = d.vehicle_id
		WHERE d.vehicle_id = $1 AND v.owner_id = $2
		ORDER BY d.created_at DESC, d.id
	`

	rows, err := r.db.QueryContext(ctx, query, vehicleID, ownerID)
	if err != nil {
		return nil, fmt.Errorf("query owner vehicle devices: %w", err)
	}
	defer rows.Close()

	devices := make([]Device, 0)
	for rows.Next() {
		item, err := scanDevice(rows)
		if err != nil {
			return nil, fmt.Errorf("scan owner vehicle device: %w", err)
		}
		devices = append(devices, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate owner vehicle devices: %w", err)
	}

	return devices, nil
}

func (r *PostgresRepository) GetByIDForOwner(
	ctx context.Context,
	ownerID string,
	deviceID string,
) (Device, error) {
	const query = `
		SELECT
			d.id,
			d.vehicle_id,
			d.device_uid,
			d.name,
			d.status,
			d.last_seen_at,
			d.created_at,
			d.updated_at
		FROM devices d
		INNER JOIN vehicles v ON v.id = d.vehicle_id
		WHERE d.id = $1 AND v.owner_id = $2
	`

	item, err := scanDevice(r.db.QueryRowContext(ctx, query, deviceID, ownerID))
	if errors.Is(err, sql.ErrNoRows) {
		return Device{}, ErrNotFound
	}
	if err != nil {
		return Device{}, fmt.Errorf("query owner device by ID: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) CreateForOwnedVehicle(
	ctx context.Context,
	ownerID string,
	vehicleID string,
	request CreateRequest,
) (Device, error) {
	const query = `
		INSERT INTO devices (
			vehicle_id,
			device_uid,
			name,
			status
		)
		SELECT
			v.id,
			$3,
			$4,
			'active'
		FROM vehicles v
		WHERE v.id = $2 AND v.owner_id = $1
		RETURNING
			id,
			vehicle_id,
			device_uid,
			name,
			status,
			last_seen_at,
			created_at,
			updated_at
	`

	item, err := scanDevice(r.db.QueryRowContext(
		ctx,
		query,
		ownerID,
		vehicleID,
		request.DeviceUID,
		request.Name,
	))
	if errors.Is(err, sql.ErrNoRows) {
		return Device{}, ErrNotFound
	}
	if isUniqueViolation(err, "devices_device_uid_key") {
		return Device{}, ErrDuplicateUID
	}
	if err != nil {
		return Device{}, fmt.Errorf("create owner device: %w", err)
	}

	return item, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanDevice(row scanner) (Device, error) {
	var (
		item       Device
		name       sql.NullString
		lastSeenAt sql.NullTime
	)

	if err := row.Scan(
		&item.ID,
		&item.VehicleID,
		&item.DeviceUID,
		&name,
		&item.Status,
		&lastSeenAt,
		&item.CreatedAt,
		&item.UpdatedAt,
	); err != nil {
		return Device{}, err
	}

	if name.Valid {
		item.Name = &name.String
	}
	if lastSeenAt.Valid {
		value := lastSeenAt.Time
		item.LastSeenAt = &value
	}

	return item, nil
}

func isUniqueViolation(err error, constraint string) bool {
	if err == nil {
		return false
	}

	message := err.Error()
	return strings.Contains(message, constraint) ||
		strings.Contains(message, "duplicate key")
}
