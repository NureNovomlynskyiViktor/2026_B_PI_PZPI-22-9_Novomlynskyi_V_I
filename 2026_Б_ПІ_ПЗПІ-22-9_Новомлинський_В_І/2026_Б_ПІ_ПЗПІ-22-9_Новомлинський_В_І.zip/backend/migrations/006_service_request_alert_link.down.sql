BEGIN;

DROP INDEX IF EXISTS vehicle_service_requests_open_source_alert_unique;
DROP INDEX IF EXISTS vehicle_service_requests_source_alert_idx;

ALTER TABLE vehicle_service_requests
	DROP COLUMN IF EXISTS source_alert_id;

COMMIT;
