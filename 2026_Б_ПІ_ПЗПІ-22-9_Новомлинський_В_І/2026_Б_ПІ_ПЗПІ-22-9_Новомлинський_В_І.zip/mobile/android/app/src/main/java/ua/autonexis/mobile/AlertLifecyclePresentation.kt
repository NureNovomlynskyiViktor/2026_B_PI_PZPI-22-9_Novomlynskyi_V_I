package ua.autonexis.mobile

import androidx.annotation.StringRes
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

data class AlertLifecycleGroups(
    val active: List<Alert>,
    val cleared: List<Alert>,
    val resolved: List<Alert>,
    val historicalOther: List<Alert>,
)

object AlertLifecyclePresentation {
    private val openServiceRequestStatuses = setOf("pending", "assigned", "in_progress")

    fun group(alerts: List<Alert>): AlertLifecycleGroups {
        return AlertLifecycleGroups(
            active = alerts.filter { it.status.equals("active", ignoreCase = true) },
            cleared = alerts.filter { it.status.equals("cleared", ignoreCase = true) },
            resolved = alerts.filter { it.status.equals("resolved", ignoreCase = true) },
            historicalOther = alerts.filterNot { alert ->
                alert.status.equals("active", ignoreCase = true) ||
                    alert.status.equals("cleared", ignoreCase = true) ||
                    alert.status.equals("resolved", ignoreCase = true)
            },
        )
    }


    fun displayTimestamp(value: String?, fallback: String = "n/a"): String {
        return displayTimestamp(
            value = value,
            fallback = fallback,
            locale = Locale.getDefault(),
            zoneId = ZoneId.systemDefault(),
        )
    }

    internal fun displayTimestamp(
        value: String?,
        fallback: String,
        locale: Locale,
        zoneId: ZoneId,
    ): String {
        if (value.isNullOrBlank()) {
            return fallback
        }

        val trimmed = value.trim()
        val instant = runCatching { Instant.parse(trimmed) }.getOrNull()
            ?: runCatching {
                OffsetDateTime.parse(trimmed).toInstant()
            }.getOrNull()
            ?: runCatching {
                LocalDateTime.parse(trimmed).atZone(zoneId).toInstant()
            }.getOrNull()
            ?: return fallback

        return DateTimeFormatter
            .ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
            .withLocale(locale)
            .format(instant.atZone(zoneId))
    }

    fun isWarningOrCritical(alert: Alert): Boolean {
        return alert.severity.equals("warning", ignoreCase = true) ||
            alert.severity.equals("critical", ignoreCase = true) ||
            alert.currentSeverity.equals("warning", ignoreCase = true) ||
            alert.currentSeverity.equals("critical", ignoreCase = true)
    }

    fun ownerCanResolveAlert(alert: Alert): Boolean {
        return false
    }

    fun openLinkedServiceRequest(alert: Alert, requests: List<ServiceRequest>): ServiceRequest? {
        return requests.firstOrNull { request ->
            request.sourceAlertId == alert.id &&
                openServiceRequestStatuses.any { status ->
                    request.status.equals(status, ignoreCase = true)
                }
        }
    }

    fun linkedResolutionServiceRequest(
        alert: Alert,
        requests: List<ServiceRequest>,
    ): ServiceRequest? {
        val requestId = alert.resolutionServiceRequestId ?: return null
        return requests.firstOrNull { request -> request.id == requestId }
    }

    @StringRes
    fun resolvedHistoryLabelRes(alert: Alert): Int {
        return if (alert.resolvedByUserId.isNullOrBlank()) {
            R.string.legacy_manual_incident_history
        } else {
            R.string.resolved_by_technical_specialist
        }
    }

    fun latestClearedCriticalWhenInspectionRecommended(
        overallStatus: String,
        alerts: List<Alert>,
    ): Alert? {
        val groups = group(alerts)
        if (!overallStatus.equals("normal", ignoreCase = true) || groups.active.isNotEmpty()) {
            return null
        }

        return groups.cleared
            .filter { it.severity.equals("critical", ignoreCase = true) }
            .maxByOrNull { it.clearedAt ?: it.lastTriggeredAt ?: it.createdAt }
    }
}
