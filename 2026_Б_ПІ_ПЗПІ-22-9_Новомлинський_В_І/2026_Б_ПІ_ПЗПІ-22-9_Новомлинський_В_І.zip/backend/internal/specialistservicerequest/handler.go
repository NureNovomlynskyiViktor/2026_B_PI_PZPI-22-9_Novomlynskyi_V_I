package specialistservicerequest

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
)

const maximumSpecialistServiceRequestBodySize = 1 << 20

type ServiceRequestService interface {
	ListForSpecialist(ctx context.Context, specialistID string) ([]servicerequest.Request, error)
	GetForSpecialist(ctx context.Context, specialistID string, requestID string) (servicerequest.Request, error)
	Start(ctx context.Context, specialistID string, requestID string) (servicerequest.Request, error)
	Complete(ctx context.Context, specialistID string, requestID string, resultSummary string) (servicerequest.Request, error)
}

type Handler struct {
	requests ServiceRequestService
	logger   *slog.Logger
}

func NewHandler(requests ServiceRequestService, logger *slog.Logger) *Handler {
	return &Handler{
		requests: requests,
		logger:   logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := specialistUser(w, r)
	if !ok {
		return
	}

	items, err := h.requests.ListForSpecialist(r.Context(), user.ID)
	if errors.Is(err, servicerequest.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid specialist request")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list specialist service requests",
			"specialist_id", user.ID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, items)
}

func (h *Handler) Get(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := specialistRequestID(w, r)
	if !ok {
		return
	}

	item, err := h.requests.GetForSpecialist(r.Context(), user.ID, requestID)
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get specialist service request",
			"specialist_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Start(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := specialistRequestID(w, r)
	if !ok {
		return
	}

	item, err := h.requests.Start(r.Context(), user.ID, requestID)
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if errors.Is(err, servicerequest.ErrInvalidTransition) {
		response.Error(w, http.StatusConflict, "service request must be assigned before it can be started")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to start service request",
			"specialist_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Complete(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := specialistRequestID(w, r)
	if !ok {
		return
	}

	var request completeRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	item, err := h.requests.Complete(r.Context(), user.ID, requestID, request.ResultSummary)
	if errors.Is(err, servicerequest.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "result_summary is required")
		return
	}
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if errors.Is(err, servicerequest.ErrInvalidTransition) {
		response.Error(w, http.StatusConflict, "service request must be in progress before completion")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to complete service request",
			"specialist_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

type completeRequest struct {
	ResultSummary string `json:"result_summary"`
}

func specialistRequestID(w http.ResponseWriter, r *http.Request) (auth.User, string, bool) {
	user, ok := specialistUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	requestID := r.PathValue("request_id")
	if !identifier.IsUUID(requestID) {
		response.Error(w, http.StatusBadRequest, "invalid request_id")
		return auth.User{}, "", false
	}

	return user, requestID, true
}

func specialistUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.TechnicalSpecialistRoleCode {
		response.Error(w, http.StatusForbidden, "technical specialist role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumSpecialistServiceRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
