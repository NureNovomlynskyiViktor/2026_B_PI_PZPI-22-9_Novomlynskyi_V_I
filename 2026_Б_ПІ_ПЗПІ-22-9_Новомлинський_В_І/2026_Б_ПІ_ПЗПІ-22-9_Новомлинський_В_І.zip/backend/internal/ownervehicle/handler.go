package ownervehicle

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumVehicleRequestBodySize = 1 << 20

type VehicleService interface {
	ListByOwner(ctx context.Context, ownerID string) ([]vehicle.Vehicle, error)
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
	CreateForOwner(ctx context.Context, ownerID string, request vehicle.CreateRequest) (vehicle.Vehicle, error)
}

type StatusService interface {
	GetByVehicleID(ctx context.Context, vehicleID string) (vehiclestatus.VehicleStatus, error)
}

type Handler struct {
	vehicles VehicleService
	statuses StatusService
	logger   *slog.Logger
}

func NewHandler(
	vehicles VehicleService,
	statuses StatusService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		vehicles: vehicles,
		statuses: statuses,
		logger:   logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicles, err := h.vehicles.ListByOwner(r.Context(), user.ID)
	if err != nil {
		h.logger.Error("failed to list owner vehicles", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, vehicles)
}

func (h *Handler) Create(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	var request vehicle.CreateRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	item, err := h.vehicles.CreateForOwner(r.Context(), user.ID, request)
	if errors.Is(err, vehicle.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle data")
		return
	}
	if errors.Is(err, vehicle.ErrDuplicateVIN) {
		response.Error(w, http.StatusConflict, "vehicle VIN already exists")
		return
	}
	if err != nil {
		h.logger.Error("failed to create owner vehicle", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, item)
}

func (h *Handler) GetByID(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	item, err := h.vehicles.GetByIDForOwner(r.Context(), user.ID, vehicleID)
	if errors.Is(err, vehicle.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get owner vehicle",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Status(w http.ResponseWriter, r *http.Request) {
	user, ok := currentUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	if _, err := h.vehicles.GetByIDForOwner(r.Context(), user.ID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return
		}
		h.logger.Error(
			"failed to verify owner vehicle",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	currentStatus, err := h.statuses.GetByVehicleID(r.Context(), vehicleID)
	if errors.Is(err, vehiclestatus.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, vehiclestatus.ErrVehicleNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get owner vehicle status",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, currentStatus)
}

func currentUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumVehicleRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
