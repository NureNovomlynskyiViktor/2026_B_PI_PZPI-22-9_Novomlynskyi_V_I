package ua.autonexis.mobile.ui.vehicle

import androidx.annotation.StringRes
import ua.autonexis.mobile.Alert
import ua.autonexis.mobile.AlertLifecyclePresentation
import ua.autonexis.mobile.ServiceRequest
import ua.autonexis.mobile.TelemetryRecord
import ua.autonexis.mobile.ui.VehiclePresentation
import java.util.Locale

internal enum class VehicleQuickAction {
    MAINTENANCE_HISTORY,
    SERVICE_REQUESTS,
    CREATE_MANUAL_SERVICE_REQUEST,
}

internal data class ResolvedIncidentPreview(
    val parameter: String,
    val maximumSeverity: String,
    val resolvedTimestamp: String,
    val occurrenceCount: Int,
    @StringRes val resolutionLabelRes: Int,
)

internal object VehicleDetailsPresentation {
    private val supportedStatuses = setOf("normal", "warning", "critical", "unknown")

    fun statusLabel(status: String): String {
        val normalized = status.trim().lowercase(Locale.US)
        return if (normalized in supportedStatuses) normalized.uppercase(Locale.US) else "UNKNOWN"
    }


    fun telemetryMetrics(record: TelemetryRecord): List<Pair<String, String>> = listOf(
        "Engine temperature" to formatOneDecimal(record.engineTemperature, "\u00B0C"),
        "Battery voltage" to formatOneDecimal(record.batteryVoltage, "V"),
        "Vibration level" to formatOneDecimal(record.vibrationLevel, null),
        "RPM" to record.rpm.toString(),
        "Speed" to "${record.speed} km/h",
        "Fuel level" to formatOneDecimal(record.fuelLevel, "%"),
    )

    fun vehicleMetadata(year: Int?, licensePlate: String?): String? = VehiclePresentation.metadata(year, licensePlate)

    fun resolvedIncidentsNewestFirst(alerts: List<Alert>): List<Alert> {
        return alerts.sortedWith(
            compareByDescending<Alert> { resolvedSortTimestamp(it) }
                .thenByDescending { it.id },
        )
    }

    fun resolvedIncidentOverviewItems(alerts: List<Alert>, limit: Int = 3): List<ResolvedIncidentPreview> {
        return resolvedIncidentsNewestFirst(alerts)
            .take(limit)
            .map(::resolvedIncidentPreview)
    }

    fun resolvedIncidentPreview(alert: Alert): ResolvedIncidentPreview {
        return ResolvedIncidentPreview(
            parameter = alert.type,
            maximumSeverity = alert.severity.uppercase(Locale.US),
            resolvedTimestamp = AlertLifecyclePresentation.displayTimestamp(alert.resolvedAt),
            occurrenceCount = alert.occurrenceCount,
            resolutionLabelRes = AlertLifecyclePresentation.resolvedHistoryLabelRes(alert),
        )
    }

    fun canCreateServiceRequest(alert: Alert, serviceRequests: List<ServiceRequest>): Boolean {
        return AlertLifecyclePresentation.isWarningOrCritical(alert) &&
            AlertLifecyclePresentation.openLinkedServiceRequest(alert, serviceRequests) == null
    }

    fun shouldShowCurrentSeverity(alert: Alert): Boolean {
        return alert.status.equals("active", ignoreCase = true) && !alert.currentSeverity.isNullOrBlank()
    }

    fun ownerCanResolveAlert(@Suppress("UNUSED_PARAMETER") alert: Alert): Boolean = false

    fun quickActions(): List<VehicleQuickAction> = listOf(
        VehicleQuickAction.MAINTENANCE_HISTORY,
        VehicleQuickAction.SERVICE_REQUESTS,
        VehicleQuickAction.CREATE_MANUAL_SERVICE_REQUEST,
    )

    fun hasReplacementCharacter(value: String?): Boolean {
        return value?.contains('\uFFFD') == true
    }

    private fun resolvedSortTimestamp(alert: Alert): String {
        return alert.resolvedAt ?: alert.clearedAt ?: alert.lastTriggeredAt ?: alert.createdAt
    }

    private fun formatOneDecimal(value: Double, unit: String?): String {
        val formatted = String.format(Locale.US, "%.1f", value)
        return if (unit == null) formatted else "$formatted $unit"
    }
}
