import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { AppearanceProvider } from './appearance';
import { LocaleProvider } from './i18n';
import './styles/tokens.css';
import './styles/main.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <LocaleProvider>
      <AppearanceProvider>
        <App />
      </AppearanceProvider>
    </LocaleProvider>
  </React.StrictMode>,
);
