package vehicleactivation

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

func TestActivationCreatedAuditEntry(t *testing.T) {
	input, result := testActivationAuditData()

	entry := activationCreatedAuditEntry(input, result)
	if entry.ActorID != testAdminID {
		t.Fatalf("expected actor %q, got %q", testAdminID, entry.ActorID)
	}
	if entry.Action != ActionVehicleActivationCreated {
		t.Fatalf("expected action %q, got %q", ActionVehicleActivationCreated, entry.Action)
	}
	if entry.EntityType != EntityTypeVehicle {
		t.Fatalf("expected entity type %q, got %q", EntityTypeVehicle, entry.EntityType)
	}
	if entry.EntityID != testVehicleID {
		t.Fatalf("expected vehicle entity ID %q, got %q", testVehicleID, entry.EntityID)
	}

	metadata := entry.Metadata.(map[string]any)
	if metadata["vehicle_id"] != testVehicleID ||
		metadata["device_id"] != testDeviceID ||
		metadata["device_uid"] != "esp32-demo-002" ||
		metadata["vin"] != "AUTONEXISDEMO0002" ||
		metadata["brand"] != "Toyota" ||
		metadata["model"] != "Corolla" ||
		metadata["year"] != int16(2022) ||
		metadata["license_plate"] != "AX-0002" ||
		metadata["activation_id"] != result.Activation.ID ||
		metadata["activation_expires_at"] != result.Activation.ExpiresAt ||
		metadata["default_threshold_count"] != 4 {
		t.Fatalf("unexpected audit metadata: %#v", metadata)
	}
}

func TestActivationCreatedAuditMetadataExcludesSecrets(t *testing.T) {
	input, result := testActivationAuditData()
	metadata := activationCreatedAuditMetadata(input, result)

	payload, err := json.Marshal(metadata)
	if err != nil {
		t.Fatalf("metadata should be JSON encodable: %v", err)
	}
	serialized := string(payload)
	for _, secret := range []string{
		"AX7K-29QP",
		"hashed-activation-code",
		"activation_code",
		"code_hash",
		"password",
		"token",
		"secret",
	} {
		if strings.Contains(serialized, secret) {
			t.Fatalf("metadata leaked %q: %s", secret, serialized)
		}
	}
}

func TestWriteActivationCreatedAuditFailurePropagates(t *testing.T) {
	input, result := testActivationAuditData()
	repository := &PostgresRepository{audits: &activationAuditWriter{
		err: auditlog.ErrWriteFailed,
	}}

	err := repository.writeActivationCreatedAudit(context.Background(), nil, input, result)
	if !errors.Is(err, auditlog.ErrWriteFailed) {
		t.Fatalf("expected audit write failure, got %v", err)
	}
}

func TestWriteActivationCreatedAuditUsesCreatedVehicleBeforeCommit(t *testing.T) {
	input, result := testActivationAuditData()
	writer := &activationAuditWriter{}
	repository := &PostgresRepository{audits: writer}

	err := repository.writeActivationCreatedAudit(context.Background(), nil, input, result)
	if err != nil {
		t.Fatalf("writeActivationCreatedAudit returned error: %v", err)
	}
	if !writer.called {
		t.Fatal("expected audit writer to be called")
	}
	if writer.entry.EntityID != result.Vehicle.ID ||
		writer.entry.ActorID != input.CreatedBy ||
		writer.entry.Action != ActionVehicleActivationCreated ||
		writer.entry.EntityType != EntityTypeVehicle {
		t.Fatalf("unexpected audit entry: %#v", writer.entry)
	}
}

type activationAuditWriter struct {
	called bool
	entry  auditlog.Entry
	err    error
}

func (w *activationAuditWriter) Write(
	_ context.Context,
	_ auditlog.Executor,
	entry auditlog.Entry,
) error {
	w.called = true
	w.entry = entry
	return w.err
}

func testActivationAuditData() (CreateInput, CreateResult) {
	year := int16(2022)
	vin := "AUTONEXISDEMO0002"
	licensePlate := "AX-0002"
	expiresAt := time.Date(2026, 6, 20, 12, 0, 0, 0, time.UTC)
	activationID := "55555555-5555-5555-5555-555555555555"

	return CreateInput{
			Request: AdminCreateRequest{
				VIN:          vin,
				Brand:        "Toyota",
				Model:        "Corolla",
				Year:         int(year),
				LicensePlate: licensePlate,
				DeviceUID:    "esp32-demo-002",
				DeviceName:   "Owner ESP32",
			},
			CreatedBy: testAdminID,
			CodeHash:  "hashed-activation-code",
			ExpiresAt: expiresAt,
			DefaultRules: []DefaultThreshold{
				{Parameter: "engine_temperature"},
				{Parameter: "battery_voltage"},
				{Parameter: "vibration_level"},
				{Parameter: "rpm"},
			},
		},
		CreateResult{
			Vehicle: vehicle.Vehicle{
				ID:           testVehicleID,
				VIN:          &vin,
				Brand:        "Toyota",
				Model:        "Corolla",
				Year:         &year,
				LicensePlate: &licensePlate,
			},
			Device: device.Device{
				ID:        testDeviceID,
				VehicleID: testVehicleID,
				DeviceUID: "esp32-demo-002",
				Status:    "inactive",
			},
			Activation: Activation{
				ID:        activationID,
				VehicleID: testVehicleID,
				ExpiresAt: expiresAt,
				CreatedBy: testAdminID,
			},
		}
}
