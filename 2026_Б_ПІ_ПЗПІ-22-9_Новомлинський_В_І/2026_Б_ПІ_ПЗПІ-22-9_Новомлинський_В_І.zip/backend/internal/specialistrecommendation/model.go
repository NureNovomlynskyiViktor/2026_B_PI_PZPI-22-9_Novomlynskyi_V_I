package specialistrecommendation

import (
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

type Recommendation struct {
	Specialist            auth.User                         `json:"specialist"`
	Competencies          []specialistcompetency.Competency `json:"competencies"`
	Score                 int                               `json:"score"`
	MatchedCompetencies   []string                          `json:"matched_competencies"`
	Reasons               []string                          `json:"reasons"`
	ActiveAssignmentCount int                               `json:"active_assignment_count"`
	AlreadyAssigned       bool                              `json:"already_assigned"`
}
