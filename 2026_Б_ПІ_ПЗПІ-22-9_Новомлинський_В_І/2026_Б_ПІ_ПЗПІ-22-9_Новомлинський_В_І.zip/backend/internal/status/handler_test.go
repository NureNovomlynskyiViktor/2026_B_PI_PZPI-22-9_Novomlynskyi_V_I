package status

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type stubService struct {
	result VehicleStatus
	err    error
}

func (s stubService) GetByVehicleID(context.Context, string) (VehicleStatus, error) {
	return s.result, s.err
}

func TestHandlerSuccess(t *testing.T) {
	handler := NewHandler(stubService{
		result: VehicleStatus{
			Vehicle:       vehicle.Vehicle{ID: testVehicleID},
			OverallStatus: "critical",
			ActiveAlerts:  nil,
		},
	}, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/status",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.GetByVehicleID(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if body := recorder.Body.String(); !strings.Contains(body, `"overall_status":"critical"`) {
		t.Fatalf("expected critical status response, got %s", body)
	}
}

func TestHandlerErrors(t *testing.T) {
	tests := []struct {
		name       string
		err        error
		wantStatus int
	}{
		{name: "invalid ID", err: ErrInvalidVehicleID, wantStatus: http.StatusBadRequest},
		{name: "not found", err: ErrVehicleNotFound, wantStatus: http.StatusNotFound},
		{name: "internal error", err: errors.New("database details"), wantStatus: http.StatusInternalServerError},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := NewHandler(stubService{err: tt.err}, testLogger())
			request := httptest.NewRequest(
				http.MethodGet,
				"/api/v1/vehicles/"+testVehicleID+"/status",
				nil,
			)
			request.SetPathValue("vehicle_id", testVehicleID)
			recorder := httptest.NewRecorder()

			handler.GetByVehicleID(recorder, request)

			if recorder.Code != tt.wantStatus {
				t.Fatalf("expected status %d, got %d", tt.wantStatus, recorder.Code)
			}
			if strings.Contains(recorder.Body.String(), "database details") {
				t.Fatal("response exposed an internal error")
			}
		})
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
