﻿package ua.autonexis.mobile.ui.notification

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.OwnerNotification

internal data class NotificationsUiState(
    val items: List<OwnerNotification> = emptyList(),
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val markingReadIds: Set<String> = emptySet(),
    val showUnreadOnly: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
) {
    val unreadCount: Int
        get() = items.count { !it.isRead }

    val visibleItems: List<OwnerNotification>
        get() = if (showUnreadOnly) items.filter { !it.isRead } else items
}

internal class NotificationsViewModel {
    var uiState by mutableStateOf(NotificationsUiState())
        private set

    fun showInitialLoading(message: String = "Loading notifications...") {
        uiState = NotificationsUiState(isLoading = true, message = message)
    }

    fun showNotifications(
        items: List<OwnerNotification>,
        message: String? = null,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            items = NotificationsPresentation.newestFirst(items),
            isLoading = false,
            isRefreshing = false,
            markingReadIds = emptySet(),
            message = message,
            isError = isError,
        )
    }

    fun failInitialLoad(message: String) {
        uiState = NotificationsUiState(
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun toggleUnreadOnly() {
        uiState = uiState.copy(
            showUnreadOnly = !uiState.showUnreadOnly,
            message = null,
            isError = false,
        )
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.markingReadIds.isNotEmpty()) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing notifications...",
            isError = false,
        )
        return true
    }

    fun finishRefresh(items: List<OwnerNotification>, message: String? = null) {
        uiState = uiState.copy(
            items = NotificationsPresentation.newestFirst(items),
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = false,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = true,
        )
    }

    fun startMarkRead(notificationId: String): Boolean {
        val item = uiState.items.firstOrNull { it.id == notificationId } ?: return false
        if (item.isRead || notificationId in uiState.markingReadIds || uiState.isLoading) {
            return false
        }
        uiState = uiState.copy(
            markingReadIds = uiState.markingReadIds + notificationId,
            message = null,
            isError = false,
        )
        return true
    }

    fun finishMarkRead(notification: OwnerNotification, message: String = "Notification marked as read.") {
        uiState = uiState.copy(
            items = NotificationsPresentation.newestFirst(
                uiState.items.map { item -> if (item.id == notification.id) notification else item },
            ),
            markingReadIds = uiState.markingReadIds - notification.id,
            message = message,
            isError = false,
        )
    }

    fun failMarkRead(notificationId: String, message: String) {
        uiState = uiState.copy(
            markingReadIds = uiState.markingReadIds - notificationId,
            message = message,
            isError = true,
        )
    }
}
