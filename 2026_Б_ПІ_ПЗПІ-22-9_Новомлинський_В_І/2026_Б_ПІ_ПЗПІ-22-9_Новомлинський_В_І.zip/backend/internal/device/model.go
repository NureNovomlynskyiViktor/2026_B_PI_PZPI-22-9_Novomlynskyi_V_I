package device

import "time"

type Device struct {
	ID         string     `json:"id"`
	VehicleID  string     `json:"vehicle_id"`
	DeviceUID  string     `json:"device_uid"`
	Name       *string    `json:"name"`
	Status     string     `json:"status"`
	LastSeenAt *time.Time `json:"last_seen_at"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at"`
}

type CreateRequest struct {
	DeviceUID string `json:"device_uid"`
	Name      string `json:"name"`
}
