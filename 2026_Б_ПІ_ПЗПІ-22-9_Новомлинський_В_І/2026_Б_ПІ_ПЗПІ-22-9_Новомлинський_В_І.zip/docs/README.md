# Documentation

Project documentation is organized into:

- `specification` - requirements and system specifications;
- `diagrams` - architecture and design diagrams;
- `screenshots` - screenshots of the software system;
- `testing` - test plans and test results.
