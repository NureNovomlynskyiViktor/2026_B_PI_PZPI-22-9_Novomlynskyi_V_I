BEGIN;

ALTER TABLE vehicles
    ALTER COLUMN owner_id DROP NOT NULL;

CREATE TABLE vehicle_activation_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    code_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    claimed_at TIMESTAMPTZ,
    claimed_by UUID REFERENCES users(id),
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT vehicle_activation_claim_consistency_check
        CHECK (
            (claimed_at IS NULL AND claimed_by IS NULL)
            OR
            (claimed_at IS NOT NULL AND claimed_by IS NOT NULL)
        )
);

CREATE UNIQUE INDEX vehicle_activation_codes_one_unclaimed_per_vehicle_idx
    ON vehicle_activation_codes (vehicle_id)
    WHERE claimed_at IS NULL;

CREATE INDEX vehicle_activation_codes_expires_at_idx
    ON vehicle_activation_codes (expires_at);

COMMIT;
