package ua.autonexis.mobile

import android.content.Context

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    private val tokenStore = SecureSessionTokenStore(
        preferences = SharedPreferencesSessionTokenPreferences(
            legacyPreferences = prefs,
            securePreferences = context.getSharedPreferences(
                SharedPreferencesSessionTokenPreferences.SECURE_PREFERENCES_NAME,
                Context.MODE_PRIVATE,
            ),
        ),
        cipher = SessionTokenCipher(),
    )

    var baseUrl: String
        get() = prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(value) = prefs.edit().putString(KEY_BASE_URL, value.trim().trimEnd('/')).apply()

    var token: String?
        get() = tokenStore.token
        set(value) {
            tokenStore.token = value
        }

    fun clearToken() {
        tokenStore.clearToken()
    }

    companion object {
        val DEFAULT_BASE_URL: String = BuildConfig.API_BASE_URL
        private const val PREFERENCES_NAME = "autonexis_owner_session"
        private const val KEY_BASE_URL = "base_url"
    }
}
