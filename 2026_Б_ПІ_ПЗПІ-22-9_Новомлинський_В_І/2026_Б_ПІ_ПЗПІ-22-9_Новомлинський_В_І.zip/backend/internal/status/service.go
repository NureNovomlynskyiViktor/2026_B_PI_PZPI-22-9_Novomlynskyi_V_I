package status

import (
	"context"
	"errors"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

var (
	ErrInvalidVehicleID = errors.New("invalid vehicle ID")
	ErrVehicleNotFound  = errors.New("vehicle not found")
)

type VehicleService interface {
	GetByID(ctx context.Context, id string) (vehicle.Vehicle, error)
}

type DeviceService interface {
	GetByVehicleID(ctx context.Context, vehicleID string) (device.Device, error)
}

type TelemetryService interface {
	LatestByVehicle(ctx context.Context, vehicleID string) (telemetry.Record, error)
}

type AlertService interface {
	ListActiveByVehicle(ctx context.Context, vehicleID string) ([]alert.Alert, error)
}

type Service interface {
	GetByVehicleID(ctx context.Context, vehicleID string) (VehicleStatus, error)
}

type service struct {
	vehicles  VehicleService
	devices   DeviceService
	telemetry TelemetryService
	alerts    AlertService
}

func NewService(
	vehicles VehicleService,
	devices DeviceService,
	telemetryService TelemetryService,
	alerts AlertService,
) Service {
	return &service{
		vehicles:  vehicles,
		devices:   devices,
		telemetry: telemetryService,
		alerts:    alerts,
	}
}

func (s *service) GetByVehicleID(
	ctx context.Context,
	vehicleID string,
) (VehicleStatus, error) {
	if !identifier.IsUUID(vehicleID) {
		return VehicleStatus{}, ErrInvalidVehicleID
	}

	vehicleItem, err := s.vehicles.GetByID(ctx, vehicleID)
	if errors.Is(err, vehicle.ErrNotFound) {
		return VehicleStatus{}, ErrVehicleNotFound
	}
	if err != nil {
		return VehicleStatus{}, err
	}

	result := VehicleStatus{
		Vehicle:       vehicleItem,
		ActiveAlerts:  make([]alert.Alert, 0),
		OverallStatus: "normal",
	}

	deviceItem, err := s.devices.GetByVehicleID(ctx, vehicleID)
	if err == nil {
		result.Device = &deviceItem
	} else if !errors.Is(err, device.ErrNotFound) {
		return VehicleStatus{}, err
	}

	telemetryItem, err := s.telemetry.LatestByVehicle(ctx, vehicleID)
	if err == nil {
		result.LatestTelemetry = &telemetryItem
	} else if !errors.Is(err, telemetry.ErrNotFound) {
		return VehicleStatus{}, err
	}

	activeAlerts, err := s.alerts.ListActiveByVehicle(ctx, vehicleID)
	if err != nil {
		return VehicleStatus{}, err
	}
	result.ActiveAlerts = activeAlerts
	if result.LatestTelemetry == nil && len(activeAlerts) == 0 {
		result.OverallStatus = "unknown"
	} else {
		result.OverallStatus = calculateOverallStatus(activeAlerts)
	}

	return result, nil
}

func calculateOverallStatus(alerts []alert.Alert) string {
	overallStatus := "normal"

	for _, item := range alerts {
		severity := item.Severity
		if item.CurrentSeverity != nil {
			severity = *item.CurrentSeverity
		}
		switch severity {
		case "critical":
			return "critical"
		case "warning":
			overallStatus = "warning"
		}
	}

	return overallStatus
}
