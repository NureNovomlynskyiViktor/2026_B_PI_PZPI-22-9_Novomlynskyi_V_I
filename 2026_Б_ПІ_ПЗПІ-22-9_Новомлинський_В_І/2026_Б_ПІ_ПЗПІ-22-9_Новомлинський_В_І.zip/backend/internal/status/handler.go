package status

import (
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) GetByVehicleID(w http.ResponseWriter, r *http.Request) {
	vehicleID := r.PathValue("vehicle_id")

	currentStatus, err := h.service.GetByVehicleID(r.Context(), vehicleID)
	if errors.Is(err, ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, ErrVehicleNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get vehicle status",
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, currentStatus)
}
