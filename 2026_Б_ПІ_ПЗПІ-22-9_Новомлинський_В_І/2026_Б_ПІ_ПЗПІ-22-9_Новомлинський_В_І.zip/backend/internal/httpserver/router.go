package httpserver

import (
	"log/slog"
	"net/http"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/admin"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminaudit"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminuser"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alertevaluation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/api"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/config"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/health"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/owneralert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerdevice"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownermaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownernotification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownertelemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerthreshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownervehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistalert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistmaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistvehicle"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetryingestion"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicleactivation"
)

type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (r *statusRecorder) WriteHeader(status int) {
	r.status = status
	r.ResponseWriter.WriteHeader(status)
}

func NewRouter(
	healthHandler *health.Handler,
	vehicleHandler *vehicle.Handler,
	deviceHandler *device.Handler,
	telemetryHandler *telemetry.Handler,
	alertHandler *alert.Handler,
	statusHandler *vehiclestatus.Handler,
	alertEvaluationHandler *alertevaluation.Handler,
	telemetryIngestionHandler *telemetryingestion.Handler,
	authHandler *auth.Handler,
	vehicleActivationHandler *vehicleactivation.Handler,
	ownerVehicleHandler *ownervehicle.Handler,
	ownerDeviceHandler *ownerdevice.Handler,
	ownerTelemetryHandler *ownertelemetry.Handler,
	ownerAlertHandler *owneralert.Handler,
	ownerThresholdHandler *ownerthreshold.Handler,
	ownerMaintenanceHandler *ownermaintenance.Handler,
	ownerNotificationHandler *ownernotification.Handler,
	ownerServiceRequestHandler *ownerservicerequest.Handler,
	ownerSpecialistHandler *ownerspecialist.Handler,
	specialistAlertHandler *specialistalert.Handler,
	specialistMaintenanceHandler *specialistmaintenance.Handler,
	specialistServiceRequestHandler *specialistservicerequest.Handler,
	specialistVehicleHandler *specialistvehicle.Handler,
	adminServiceRequestHandler *adminservicerequest.Handler,
	adminSpecialistHandler *adminspecialist.Handler,
	adminUserHandler *adminuser.Handler,
	adminAuditHandler *adminaudit.Handler,
	adminHandler *admin.Handler,
	authService auth.Service,
	corsConfig config.CORSConfig,
	logger *slog.Logger,
) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /health", healthHandler.Health)
	mux.HandleFunc("GET /ready", healthHandler.Ready)
	api.RegisterRoutes(
		mux,
		vehicleHandler,
		deviceHandler,
		telemetryHandler,
		alertHandler,
		statusHandler,
		alertEvaluationHandler,
		telemetryIngestionHandler,
		authHandler,
		vehicleActivationHandler,
		ownerVehicleHandler,
		ownerDeviceHandler,
		ownerTelemetryHandler,
		ownerAlertHandler,
		ownerThresholdHandler,
		ownerMaintenanceHandler,
		ownerNotificationHandler,
		ownerServiceRequestHandler,
		ownerSpecialistHandler,
		specialistAlertHandler,
		specialistMaintenanceHandler,
		specialistServiceRequestHandler,
		specialistVehicleHandler,
		adminServiceRequestHandler,
		adminSpecialistHandler,
		adminUserHandler,
		adminAuditHandler,
		adminHandler,
		authService,
		logger,
	)

	return requestLogger(withCORS(mux, corsConfig), logger)
}

func requestLogger(next http.Handler, logger *slog.Logger) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		startedAt := time.Now()
		recorder := &statusRecorder{
			ResponseWriter: w,
			status:         http.StatusOK,
		}

		next.ServeHTTP(recorder, r)

		logger.Info(
			"HTTP request completed",
			"method", r.Method,
			"path", r.URL.Path,
			"status", recorder.status,
			"duration_ms", time.Since(startedAt).Milliseconds(),
		)
	})
}
