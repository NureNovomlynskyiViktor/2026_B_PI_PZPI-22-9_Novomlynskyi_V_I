import type { Locale, LocaleMessages, StructuredLabelKey } from '../i18n/types';

const languageModeStorageKey = 'autonexis_web_language_mode';

const timestampOptions: Intl.DateTimeFormatOptions = {
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  month: 'short',
  year: 'numeric',
};

const enStructuredLabels: Record<StructuredLabelKey, string> = {
  active: 'Active',
  administrator: 'Administrator',
  assigned: 'Assigned',
  battery_and_electrical: 'Battery and electrical systems',
  battery_voltage: 'Battery voltage',
  battery_voltage_critical: 'Battery voltage critical',
  battery_voltage_warning: 'Battery voltage warning',
  cancelled: 'Cancelled',
  cleared: 'Cleared',
  completed: 'Completed',
  critical: 'Critical',
  engine_diagnostics: 'Engine diagnostics',
  engine_temperature: 'Engine temperature',
  engine_temperature_critical: 'Engine temperature critical',
  engine_temperature_warning: 'Engine temperature warning',
  fuel_level: 'Fuel level',
  fuel_level_critical: 'Fuel level critical',
  fuel_level_warning: 'Fuel level warning',
  fuel_system: 'Fuel system',
  general_maintenance: 'General maintenance',
  high: 'High',
  in_progress: 'In progress',
  iot_device_setup: 'IoT device setup',
  low: 'Low',
  normal: 'Normal',
  pending: 'Pending',
  resolved: 'Resolved',
  rpm: 'RPM',
  rpm_critical: 'RPM critical',
  rpm_warning: 'RPM warning',
  speed: 'Speed',
  technical_specialist: 'Technical specialist',
  vehicle_owner: 'Vehicle owner',
  vibration_analysis: 'Vibration analysis',
  vibration_level: 'Vibration level',
  vibration_level_critical: 'Vibration level critical',
  vibration_level_warning: 'Vibration level warning',
  warning: 'Warning',
};

const ukStructuredLabels: Record<StructuredLabelKey, string> = {
  active: 'Активний',
  administrator: 'Адміністратор',
  assigned: 'Призначено',
  battery_and_electrical: 'Акумулятор та електросистеми',
  battery_voltage: 'Напруга акумулятора',
  battery_voltage_critical: 'Критична напруга акумулятора',
  battery_voltage_warning: 'Попередження напруги акумулятора',
  cancelled: 'Скасовано',
  cleared: 'Стабілізовано',
  completed: 'Завершено',
  critical: 'Критичний',
  engine_diagnostics: 'Діагностика двигуна',
  engine_temperature: 'Температура двигуна',
  engine_temperature_critical: 'Критична температура двигуна',
  engine_temperature_warning: 'Попередження температури двигуна',
  fuel_level: 'Рівень пального',
  fuel_level_critical: 'Критичний рівень пального',
  fuel_level_warning: 'Попередження рівня пального',
  fuel_system: 'Паливна система',
  general_maintenance: 'Загальне обслуговування',
  high: 'Високий',
  in_progress: 'У роботі',
  iot_device_setup: 'Налаштування IoT-пристрою',
  low: 'Низький',
  normal: 'Середній',
  pending: 'Очікує',
  resolved: 'Вирішено',
  rpm: '\u041E\u0431\u0435\u0440\u0442\u0438 \u0434\u0432\u0438\u0433\u0443\u043D\u0430',
  rpm_critical: 'Критичні оберти двигуна',
  rpm_warning: 'Попередження обертів двигуна',
  speed: 'Швидкість',
  technical_specialist: 'Технічний спеціаліст',
  vehicle_owner: 'Власник авто',
  vibration_analysis: 'Аналіз вібрації',
  vibration_level: 'Рівень вібрації',
  vibration_level_critical: 'Критичний рівень вібрації',
  vibration_level_warning: 'Попередження рівня вібрації',
  warning: 'Попередження',
};

function resolveCurrentLocale(locale?: Locale): Locale {
  if (locale) {
    return locale;
  }

  if (typeof window === 'undefined') {
    return 'en';
  }

  const languageMode = window.localStorage.getItem(languageModeStorageKey);
  if (languageMode === 'en' || languageMode === 'uk') {
    return languageMode;
  }

  return navigator.language.toLowerCase().startsWith('uk') ? 'uk' : 'en';
}

function labelsForLocale(locale?: Locale) {
  return resolveCurrentLocale(locale) === 'uk' ? ukStructuredLabels : enStructuredLabels;
}

const structuredLabelAliases: Record<string, StructuredLabelKey> = {
  'battery voltage': 'battery_voltage',
  battery: 'battery_voltage',
  'engine temperature': 'engine_temperature',
  temperature: 'engine_temperature',
  'engine rpm': 'rpm',
  rpm: 'rpm',
  'engine speed': 'rpm',
  'vibration level': 'vibration_level',
  vibration: 'vibration_level',
  speed: 'speed',
  'fuel level': 'fuel_level',
};

export function structuredLabelKeyForValue(value?: string | null): StructuredLabelKey | null {
  if (!value?.trim()) {
    return null;
  }

  const labelKey = normalizeStructuredLabelKey(value);
  return labelKey in enStructuredLabels ? (labelKey as StructuredLabelKey) : null;
}

const knownThresholdDescriptions: Record<Locale, Record<string, string>> = {
  en: {
    battery_voltage_warning: 'Warning lower limit for battery voltage.',
    battery_voltage_critical: 'Critical lower limit for battery voltage.',
    engine_temperature_warning: 'Warning threshold for engine temperature.',
    engine_temperature_critical: 'Critical threshold for engine temperature.',
    rpm_warning: 'Warning threshold for engine RPM.',
    rpm_critical: 'Critical threshold for engine RPM.',
    vibration_level_warning: 'Warning threshold for vibration level.',
    vibration_level_critical: 'Critical threshold for vibration level.',
    speed_warning: 'Warning threshold for vehicle speed.',
    speed_critical: 'Critical threshold for vehicle speed.',
    fuel_level_warning: 'Warning lower limit for fuel level.',
    fuel_level_critical: 'Critical lower limit for fuel level.',
  },
  uk: {
    battery_voltage_warning: '\u041D\u0438\u0436\u043D\u0456\u0439 \u043F\u043E\u043F\u0435\u0440\u0435\u0434\u0436\u0443\u0432\u0430\u043B\u044C\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u043D\u0430\u043F\u0440\u0443\u0433\u0438 \u0430\u043A\u0443\u043C\u0443\u043B\u044F\u0442\u043E\u0440\u0430.',
    battery_voltage_critical: '\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u0438\u0439 \u043D\u0438\u0436\u043D\u0456\u0439 \u043F\u043E\u0440\u0456\u0433 \u043D\u0430\u043F\u0440\u0443\u0433\u0438 \u0430\u043A\u0443\u043C\u0443\u043B\u044F\u0442\u043E\u0440\u0430.',
    engine_temperature_warning: '\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u0436\u0443\u0432\u0430\u043B\u044C\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0442\u0435\u043C\u043F\u0435\u0440\u0430\u0442\u0443\u0440\u0438 \u0434\u0432\u0438\u0433\u0443\u043D\u0430.',
    engine_temperature_critical: '\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0442\u0435\u043C\u043F\u0435\u0440\u0430\u0442\u0443\u0440\u0438 \u0434\u0432\u0438\u0433\u0443\u043D\u0430.',
    rpm_warning: '\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u0436\u0443\u0432\u0430\u043B\u044C\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u043E\u0431\u0435\u0440\u0442\u0456\u0432 \u0434\u0432\u0438\u0433\u0443\u043D\u0430.',
    rpm_critical: '\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u043E\u0431\u0435\u0440\u0442\u0456\u0432 \u0434\u0432\u0438\u0433\u0443\u043D\u0430.',
    vibration_level_warning: '\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u0436\u0443\u0432\u0430\u043B\u044C\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0440\u0456\u0432\u043D\u044F \u0432\u0456\u0431\u0440\u0430\u0446\u0456\u0457.',
    vibration_level_critical: '\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0440\u0456\u0432\u043D\u044F \u0432\u0456\u0431\u0440\u0430\u0446\u0456\u0457.',
    speed_warning: '\u041F\u043E\u043F\u0435\u0440\u0435\u0434\u0436\u0443\u0432\u0430\u043B\u044C\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0448\u0432\u0438\u0434\u043A\u043E\u0441\u0442\u0456 \u0430\u0432\u0442\u043E.',
    speed_critical: '\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0448\u0432\u0438\u0434\u043A\u043E\u0441\u0442\u0456 \u0430\u0432\u0442\u043E.',
    fuel_level_warning: '\u041D\u0438\u0436\u043D\u0456\u0439 \u043F\u043E\u043F\u0435\u0440\u0435\u0434\u0436\u0443\u0432\u0430\u043B\u044C\u043D\u0438\u0439 \u043F\u043E\u0440\u0456\u0433 \u0440\u0456\u0432\u043D\u044F \u043F\u0430\u043B\u044C\u043D\u043E\u0433\u043E.',
    fuel_level_critical: '\u041A\u0440\u0438\u0442\u0438\u0447\u043D\u0438\u0439 \u043D\u0438\u0436\u043D\u0456\u0439 \u043F\u043E\u0440\u0456\u0433 \u0440\u0456\u0432\u043D\u044F \u043F\u0430\u043B\u044C\u043D\u043E\u0433\u043E.',
  },
};

const thresholdDescriptionAliases: Record<string, string> = {
  vibration_warning: 'vibration_level_warning',
  vibration_critical: 'vibration_level_critical',
  'warning limit for engine temperature': 'engine_temperature_warning',
  'critical limit for engine temperature': 'engine_temperature_critical',
  'warning threshold for engine temperature': 'engine_temperature_warning',
  'critical threshold for engine temperature': 'engine_temperature_critical',
  'warning lower limit for battery voltage': 'battery_voltage_warning',
  'critical lower limit for battery voltage': 'battery_voltage_critical',
  'warning limit for vibration level': 'vibration_level_warning',
  'critical limit for vibration level': 'vibration_level_critical',
  'warning threshold for vibration level': 'vibration_level_warning',
  'critical threshold for vibration level': 'vibration_level_critical',
  'warning limit for engine speed': 'rpm_warning',
  'critical limit for engine speed': 'rpm_critical',
  'warning threshold for engine rpm': 'rpm_warning',
  'critical threshold for engine rpm': 'rpm_critical',
  'warning limit for vehicle speed': 'speed_warning',
  'critical limit for vehicle speed': 'speed_critical',
  'warning lower limit for fuel level': 'fuel_level_warning',
  'critical lower limit for fuel level': 'fuel_level_critical',
};

function normalizeThresholdDescriptionKey(value?: string | null): string | null {
  if (!value?.trim()) {
    return null;
  }

  const raw = value.trim().toLowerCase();
  const structuredKey = normalizeStructuredLabelKey(value);
  if (knownThresholdDescriptions.en[structuredKey]) {
    return structuredKey;
  }

  if (thresholdDescriptionAliases[raw]) {
    return thresholdDescriptionAliases[raw];
  }

  const compact = raw
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[._-]+/g, ' ')
    .replace(/[^\p{L}\p{N}\s]+/gu, '')
    .replace(/\s+/g, ' ')
    .trim();

  return thresholdDescriptionAliases[compact] ?? null;
}

export function formatThresholdDescription(
  ruleType?: string | null,
  description?: string | null,
  locale?: Locale,
) {
  const key = normalizeThresholdDescriptionKey(ruleType) ?? normalizeThresholdDescriptionKey(description);
  if (!key) {
    return description?.trim() ?? '';
  }

  const localizedDescription = knownThresholdDescriptions[resolveCurrentLocale(locale)][key];
  return localizedDescription ?? description?.trim() ?? '';
}

function normalizeStructuredLabelKey(value: string): string {
  const compact = value
    .trim()
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[._-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .toLowerCase();

  return structuredLabelAliases[compact] ?? value.trim();
}

export function formatTimestamp(
  value?: string | null,
  fallback = 'Not recorded',
  locale?: Locale,
) {
  if (!value?.trim()) {
    return fallback;
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return fallback;
  }

  const formatterLocale = resolveCurrentLocale(locale) === 'uk' ? 'uk-UA' : 'en-US';
  return new Intl.DateTimeFormat(formatterLocale, timestampOptions).format(date);
}

export type MetricUnit = 'temperature' | 'voltage' | 'rpm' | 'speed' | 'percent' | 'level' | 'none';

export type TelemetryMetricKey =
  | 'engine_temperature'
  | 'battery_voltage'
  | 'vibration_level'
  | 'rpm'
  | 'speed'
  | 'fuel_level';

const metricUnits: Record<TelemetryMetricKey, MetricUnit> = {
  engine_temperature: 'temperature',
  battery_voltage: 'voltage',
  vibration_level: 'none',
  rpm: 'rpm',
  speed: 'speed',
  fuel_level: 'percent',
};

const metricFractionDigits: Record<TelemetryMetricKey, number> = {
  engine_temperature: 1,
  battery_voltage: 1,
  vibration_level: 1,
  rpm: 0,
  speed: 1,
  fuel_level: 1,
};

function normalizeMetricUnit(unit: string): MetricUnit | string {
  const normalized = unit.trim().toLowerCase();
  if (!normalized) {
    return 'none';
  }

  if (normalized === 'deg c' || normalized === 'c' || normalized === '\u00b0c') {
    return 'temperature';
  }

  if (normalized === 'v') {
    return 'voltage';
  }

  if (normalized === 'rpm') {
    return 'rpm';
  }

  if (normalized === 'km/h' || normalized === 'kph') {
    return 'speed';
  }

  if (normalized === '%' || normalized === 'percent') {
    return 'percent';
  }

  if (normalized === 'level') {
    return 'level';
  }

  return unit;
}

export function formatMetricUnit(unit: string | MetricUnit, locale?: Locale): string {
  const normalized = normalizeMetricUnit(unit);
  const resolvedLocale = resolveCurrentLocale(locale);

  if (normalized === 'temperature') {
    return '\u00b0C';
  }

  if (normalized === 'voltage') {
    return resolvedLocale === 'uk' ? '\u0412' : 'V';
  }

  if (normalized === 'rpm') {
    return resolvedLocale === 'uk' ? '\u043E\u0431/\u0445\u0432' : 'rpm';
  }

  if (normalized === 'speed') {
    return resolvedLocale === 'uk' ? '\u043A\u043C/\u0433\u043E\u0434' : 'km/h';
  }

  if (normalized === 'percent') {
    return '%';
  }

  if (normalized === 'level') {
    return resolvedLocale === 'uk' ? '\u0440\u0456\u0432\u0435\u043D\u044C' : 'level';
  }

  if (normalized === 'none') {
    return '';
  }

  return normalized;
}

export function formatNumberWithUnit(
  value: number,
  unit: string | MetricUnit,
  fractionDigits = 1,
  locale?: Locale,
) {
  const displayUnit = formatMetricUnit(unit, locale);
  const formattedValue = value.toFixed(fractionDigits);

  return displayUnit ? formattedValue + ' ' + displayUnit : formattedValue;
}

export function formatTelemetryMetricValue(
  metric: TelemetryMetricKey,
  value: number,
  locale?: Locale,
  fractionDigits = metricFractionDigits[metric],
) {
  return formatNumberWithUnit(value, metricUnits[metric], fractionDigits, locale);
}

export function formatTelemetryMetricDelta(
  metric: TelemetryMetricKey,
  delta: number,
  locale?: Locale,
  fractionDigits = metricFractionDigits[metric],
) {
  const sign = delta > 0 ? '+' : '-';
  return sign + formatTelemetryMetricValue(metric, Math.abs(delta), locale, fractionDigits);
}

export function telemetryMetricUnit(metric: TelemetryMetricKey): MetricUnit {
  return metricUnits[metric];
}

export function formatStructuredLabel(
  value?: string | null,
  fallback = 'Not reported',
  labels?: Partial<Record<string, string>>,
  locale?: Locale,
) {
  if (!value?.trim()) {
    return fallback;
  }

  const normalized = value.trim();
  const labelKey = normalizeStructuredLabelKey(normalized);
  const localizedLabels: Partial<Record<string, string>> = labels ?? labelsForLocale(locale);
  return localizedLabels[normalized] ?? localizedLabels[labelKey] ?? enStructuredLabels[labelKey as StructuredLabelKey] ?? normalized
    .split('_')
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

export function formatRoleLabel(
  role?: string | null,
  labels?: Partial<Record<string, string>>,
  locale?: Locale,
) {
  return formatStructuredLabel(role, 'Unknown role', labels, locale);
}

export function structuredLabelsForLocale(locale?: Locale): LocaleMessages['structuredLabels'] {
  return labelsForLocale(locale);
}
