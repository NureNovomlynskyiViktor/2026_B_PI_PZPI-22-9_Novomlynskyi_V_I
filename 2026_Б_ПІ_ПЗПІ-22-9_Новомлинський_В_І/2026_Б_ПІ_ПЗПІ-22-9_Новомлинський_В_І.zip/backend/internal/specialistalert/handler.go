package specialistalert

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

const maximumSpecialistAlertBodySize = 1 << 20

type AlertService interface {
	ResolveBySpecialist(ctx context.Context, request alert.SpecialistResolution) (alert.Alert, error)
}

type Handler struct {
	alerts AlertService
	logger *slog.Logger
}

func NewHandler(alerts AlertService, logger *slog.Logger) *Handler {
	return &Handler{
		alerts: alerts,
		logger: logger,
	}
}

func (h *Handler) Resolve(w http.ResponseWriter, r *http.Request) {
	user, ok := specialistUser(w, r)
	if !ok {
		return
	}

	alertID := r.PathValue("alert_id")
	if !identifier.IsUUID(alertID) {
		response.Error(w, http.StatusBadRequest, "invalid alert_id")
		return
	}

	var request resolveRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	item, err := h.alerts.ResolveBySpecialist(
		r.Context(),
		alert.SpecialistResolution{
			AlertID:          alertID,
			SpecialistID:     user.ID,
			ResolutionNote:   request.ResolutionNote,
			ServiceRequestID: request.ServiceRequestID,
		},
	)
	if errors.Is(err, alert.ErrInvalidAlertID) {
		response.Error(w, http.StatusBadRequest, "invalid alert_id")
		return
	}
	if errors.Is(err, alert.ErrInvalidResolutionNote) {
		response.Error(w, http.StatusBadRequest, "resolution_note must be 10 to 2000 characters")
		return
	}
	if errors.Is(err, alert.ErrInvalidResolutionServiceRequest) {
		response.Error(w, http.StatusBadRequest, "service_request_id must reference a completed linked service request assigned to this specialist")
		return
	}
	if errors.Is(err, alert.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "alert not found")
		return
	}
	if errors.Is(err, alert.ErrActiveNotResolved) {
		response.Error(w, http.StatusConflict, "only cleared alerts can be resolved")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to resolve specialist alert",
			"specialist_id", user.ID,
			"alert_id", alertID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

type resolveRequest struct {
	ResolutionNote   string  `json:"resolution_note"`
	ServiceRequestID *string `json:"service_request_id"`
}

func specialistUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.TechnicalSpecialistRoleCode {
		response.Error(w, http.StatusForbidden, "technical specialist role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumSpecialistAlertBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
