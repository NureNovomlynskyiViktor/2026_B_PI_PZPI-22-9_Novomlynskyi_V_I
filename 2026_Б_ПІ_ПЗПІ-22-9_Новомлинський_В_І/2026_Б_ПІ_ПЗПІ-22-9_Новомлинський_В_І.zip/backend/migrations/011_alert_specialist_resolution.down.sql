BEGIN;

DROP INDEX IF EXISTS alerts_resolution_service_request_idx;
DROP INDEX IF EXISTS alerts_resolved_by_user_idx;

ALTER TABLE alerts
	DROP CONSTRAINT IF EXISTS alerts_resolution_note_length_check,
	DROP COLUMN IF EXISTS resolution_service_request_id,
	DROP COLUMN IF EXISTS resolution_note,
	DROP COLUMN IF EXISTS resolved_by_user_id;

COMMIT;
