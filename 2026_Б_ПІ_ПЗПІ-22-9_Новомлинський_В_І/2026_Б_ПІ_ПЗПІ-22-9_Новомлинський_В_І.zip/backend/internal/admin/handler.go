package admin

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistrecommendation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumAdminRequestBodySize = 1 << 20

type VehicleService interface {
	List(ctx context.Context) ([]vehicle.Vehicle, error)
	GetByID(ctx context.Context, id string) (vehicle.Vehicle, error)
}

type AssignmentService interface {
	AssignByEmail(ctx context.Context, vehicleID string, email string, assignedBy string) (specialistassignment.Assignment, error)
	AssignByID(ctx context.Context, vehicleID string, specialistID string, assignedBy string) (specialistassignment.Assignment, error)
	ListByVehicle(ctx context.Context, vehicleID string) ([]specialistassignment.Assignment, error)
	ListSpecialists(ctx context.Context) ([]auth.User, error)
	Remove(ctx context.Context, vehicleID string, specialistID string) error
}

type CompetencyService interface {
	List(ctx context.Context, specialistID string) ([]specialistcompetency.Competency, error)
	Replace(ctx context.Context, specialistID string, codes []string) ([]specialistcompetency.Competency, error)
}

type RecommendationService interface {
	Recommend(ctx context.Context, vehicleID string) ([]specialistrecommendation.Recommendation, error)
}

type Handler struct {
	vehicles        VehicleService
	assignments     AssignmentService
	competencies    CompetencyService
	recommendations RecommendationService
	logger          *slog.Logger
}

func NewHandler(
	vehicles VehicleService,
	assignments AssignmentService,
	competencies CompetencyService,
	recommendations RecommendationService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		vehicles:        vehicles,
		assignments:     assignments,
		competencies:    competencies,
		recommendations: recommendations,
		logger:          logger,
	}
}

func (h *Handler) ListVehicles(w http.ResponseWriter, r *http.Request) {
	user, ok := adminUser(w, r)
	if !ok {
		return
	}

	vehicles, err := h.vehicles.List(r.Context())
	if err != nil {
		h.logger.Error("failed to list admin vehicles", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, vehicles)
}

func (h *Handler) ListSpecialists(w http.ResponseWriter, r *http.Request) {
	user, ok := adminUser(w, r)
	if !ok {
		return
	}

	specialists, err := h.assignments.ListSpecialists(r.Context())
	if err != nil {
		h.logger.Error("failed to list specialists", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, specialists)
}

func (h *Handler) ListVehicleSpecialists(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.adminVehicle(w, r)
	if !ok {
		return
	}

	assignments, err := h.assignments.ListByVehicle(r.Context(), vehicleID)
	if errors.Is(err, specialistassignment.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list admin vehicle specialists",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, assignments)
}

func (h *Handler) ListRecommendedSpecialists(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.adminVehicle(w, r)
	if !ok {
		return
	}

	recommendations, err := h.recommendations.Recommend(r.Context(), vehicleID)
	if err != nil {
		h.logger.Error(
			"failed to list recommended specialists",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, recommendations)
}

func (h *Handler) AssignVehicleSpecialist(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.adminVehicle(w, r)
	if !ok {
		return
	}

	var request specialistassignment.AdminAssignRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	var (
		assignment specialistassignment.Assignment
		err        error
	)
	if request.SpecialistID != "" {
		assignment, err = h.assignments.AssignByID(
			r.Context(),
			vehicleID,
			request.SpecialistID,
			user.ID,
		)
	} else {
		assignment, err = h.assignments.AssignByEmail(
			r.Context(),
			vehicleID,
			request.Email,
			user.ID,
		)
	}
	if errors.Is(err, specialistassignment.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid specialist assignment")
		return
	}
	if errors.Is(err, specialistassignment.ErrUserNotFound) {
		response.Error(w, http.StatusNotFound, "technical specialist not found")
		return
	}
	if errors.Is(err, specialistassignment.ErrInvalidRole) {
		response.Error(w, http.StatusBadRequest, "user is not a technical specialist")
		return
	}
	if errors.Is(err, specialistassignment.ErrDuplicate) {
		response.Error(w, http.StatusConflict, "specialist already assigned")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to assign admin vehicle specialist",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, assignment)
}

func (h *Handler) RemoveVehicleSpecialist(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.adminVehicle(w, r)
	if !ok {
		return
	}

	specialistID := r.PathValue("specialist_id")
	if !identifier.IsUUID(specialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist_id")
		return
	}

	err := h.assignments.Remove(r.Context(), vehicleID, specialistID)
	if errors.Is(err, specialistassignment.ErrInvalidVehicleID) ||
		errors.Is(err, specialistassignment.ErrInvalidSpecialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist assignment")
		return
	}
	if errors.Is(err, specialistassignment.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "specialist assignment not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to remove admin vehicle specialist",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"specialist_id", specialistID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

func (h *Handler) ListSpecialistCompetencies(w http.ResponseWriter, r *http.Request) {
	user, specialistID, ok := adminSpecialistID(w, r)
	if !ok {
		return
	}

	competencies, err := h.competencies.List(r.Context(), specialistID)
	if errors.Is(err, specialistcompetency.ErrInvalidSpecialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist_id")
		return
	}
	if errors.Is(err, specialistcompetency.ErrSpecialistNotFound) {
		response.Error(w, http.StatusNotFound, "technical specialist not found")
		return
	}
	if errors.Is(err, specialistcompetency.ErrInvalidSpecialistRole) {
		response.Error(w, http.StatusBadRequest, "user is not a technical specialist")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list specialist competencies",
			"user_id", user.ID,
			"specialist_id", specialistID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, competencies)
}

func (h *Handler) ReplaceSpecialistCompetencies(w http.ResponseWriter, r *http.Request) {
	user, specialistID, ok := adminSpecialistID(w, r)
	if !ok {
		return
	}

	var request specialistcompetency.ReplaceRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	competencies, err := h.competencies.Replace(
		r.Context(),
		specialistID,
		request.Codes,
	)
	if errors.Is(err, specialistcompetency.ErrInvalidSpecialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist_id")
		return
	}
	if errors.Is(err, specialistcompetency.ErrInvalidCompetencyCode) {
		response.Error(w, http.StatusBadRequest, "invalid competency code")
		return
	}
	if errors.Is(err, specialistcompetency.ErrSpecialistNotFound) {
		response.Error(w, http.StatusNotFound, "technical specialist not found")
		return
	}
	if errors.Is(err, specialistcompetency.ErrInvalidSpecialistRole) {
		response.Error(w, http.StatusBadRequest, "user is not a technical specialist")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to replace specialist competencies",
			"user_id", user.ID,
			"specialist_id", specialistID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, competencies)
}

func (h *Handler) adminVehicle(
	w http.ResponseWriter,
	r *http.Request,
) (auth.User, string, bool) {
	user, ok := adminUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return auth.User{}, "", false
	}

	if _, err := h.vehicles.GetByID(r.Context(), vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return auth.User{}, "", false
		}
		h.logger.Error(
			"failed to get admin vehicle",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return auth.User{}, "", false
	}

	return user, vehicleID, true
}

func adminSpecialistID(w http.ResponseWriter, r *http.Request) (auth.User, string, bool) {
	user, ok := adminUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	specialistID := r.PathValue("specialist_id")
	if !identifier.IsUUID(specialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist_id")
		return auth.User{}, "", false
	}

	return user, specialistID, true
}

func adminUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.AdministratorRoleCode {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumAdminRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
