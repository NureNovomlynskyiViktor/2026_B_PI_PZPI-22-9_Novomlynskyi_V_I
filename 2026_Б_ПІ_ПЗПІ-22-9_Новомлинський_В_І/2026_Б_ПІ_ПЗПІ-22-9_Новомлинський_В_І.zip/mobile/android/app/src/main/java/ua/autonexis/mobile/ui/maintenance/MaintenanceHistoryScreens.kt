package ua.autonexis.mobile.ui.maintenance

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.MaintenanceRecord
import ua.autonexis.mobile.R
import ua.autonexis.mobile.ui.owner.OwnerNavigationBar
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets

@Composable
internal fun MaintenanceHistoryRoot(
    state: MaintenanceHistoryUiState,
    notificationUnreadCount: Int,
    onBackToVehicleDetails: () -> Unit,
    onRefresh: () -> Unit,
    onRetry: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
) {
    val isBusy = state.isLoading || state.isRefreshing
    BackHandler(onBack = onBackToVehicleDetails)

    Scaffold(
        topBar = {
            MaintenanceHistoryTopBar(
                vehicleLabel = state.vehicleLabel,
                isBusy = isBusy,
                onBack = onBackToVehicleDetails,
                onRefresh = onRefresh,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = OwnerNavigationTab.VEHICLES,
                notificationUnreadCount = notificationUnreadCount,
                onVehicles = onBackToVehicleDetails,
                onRequests = onRequests,
                onNotifications = onNotifications,
            onAccount = onAccount,
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.records.isEmpty() -> BrandedLoadingState(
                    message = state.message ?: stringResource(R.string.loading_maintenance_history),
                )
                state.isError && state.records.isEmpty() -> InitialErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_maintenance_history_message),
                    onRetry = onRetry,
                    onBack = onBackToVehicleDetails,
                )
                else -> MaintenanceHistoryContent(state)
            }
        }
    }
}

@Composable
private fun localizedMaintenanceValue(value: String): String {
    return when (value) {
        MaintenanceHistoryPresentation.DATE_UNKNOWN -> stringResource(R.string.date_unknown)
        MaintenanceHistoryPresentation.MAINTENANCE_RECORD_FALLBACK -> stringResource(R.string.maintenance_record)
        else -> value
    }
}
@Composable
private fun MaintenanceHistoryTopBar(
    vehicleLabel: String,
    isBusy: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack, enabled = !isBusy) { Text(stringResource(R.string.back)) }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.maintenance_history),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = vehicleLabel,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            TextButton(onClick = onRefresh, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
        }
    }
}

@Composable
private fun MaintenanceHistoryContent(state: MaintenanceHistoryUiState) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        MaintenanceHistoryPresentation.summary(state.records)?.let { summary ->
            item { OverviewCard(summary) }
        }
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_maintenance_history)) }
        }
        if (state.records.isEmpty()) {
            item { EmptyMaintenanceState() }
        } else {
            item {
                TimelineCard(
                    sections = MaintenanceHistoryPresentation.timelineSections(state.records),
                )
            }
        }
    }
}

@Composable
private fun OverviewCard(summary: MaintenanceSummary) {
    InfoCard {
        Text(stringResource(R.string.service_overview), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
            OverviewTile(stringResource(R.string.records), summary.totalRecords.toString(), Modifier.weight(1f))
            OverviewTile(stringResource(R.string.latest_date), localizedMaintenanceValue(summary.latestServiceDate), Modifier.weight(1f))
        }
        OverviewTile(stringResource(R.string.latest_service), localizedMaintenanceValue(summary.latestServiceTitle), Modifier.fillMaxWidth())
        summary.currentYearCount?.let { count ->
            OverviewTile(
                stringResource(R.string.this_year),
                pluralStringResource(R.plurals.records_count, count, count),
                Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun OverviewTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun TimelineCard(sections: List<MaintenanceTimelineSection>) {
    InfoCard {
        Text(stringResource(R.string.service_timeline), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        sections.forEach { section ->
            Text(
                text = localizedMaintenanceValue(section.label),
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            section.records.forEachIndexed { index, record ->
                TimelineItem(
                    record = record,
                    isLastInSection = index == section.records.lastIndex,
                )
            }
        }
    }
}

@Composable
private fun TimelineItem(record: MaintenanceRecord, isLastInSection: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape),
            )
            if (!isLastInSection) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(84.dp)
                        .background(MaterialTheme.colorScheme.outline),
                )
            }
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
        ) {
            Text(
                text = MaintenanceHistoryPresentation.serviceDateLabel(record),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = record.title.ifBlank { stringResource(R.string.maintenance_record) },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            if (record.description.isNotBlank()) {
                Text(record.description, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (record.createdAt.isNotBlank()) {
                Text(
                    text = stringResource(R.string.created_colon_label, MaintenanceHistoryPresentation.createdAtLabel(record)),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun BrandedLoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.autonexis_emblem),
            contentDescription = stringResource(R.string.brand_name),
            modifier = Modifier.size(72.dp),
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InitialErrorState(message: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = stringResource(R.string.could_not_load_maintenance_history),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onBack) { Text(stringResource(R.string.back_to_vehicle_details)) }
    }
}

@Composable
private fun EmptyMaintenanceState() {
    InfoCard {
        Text(stringResource(R.string.no_maintenance_records), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            text = stringResource(R.string.no_maintenance_records_message),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            content = content,
        )
    }
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
