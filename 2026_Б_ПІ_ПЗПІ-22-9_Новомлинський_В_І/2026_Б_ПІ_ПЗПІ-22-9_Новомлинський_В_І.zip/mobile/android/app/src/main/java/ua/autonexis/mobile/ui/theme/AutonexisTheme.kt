﻿package ua.autonexis.mobile.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import ua.autonexis.mobile.AppearanceMode
import ua.autonexis.mobile.AppearanceStore

object AutonexisColors {
    val DeepNavy = Color(0xFF0B132B)
    val ElectricBlue = Color(0xFF2563EB)
    val LightBlue = Color(0xFF38BDF8)
    val EmeraldGreen = Color(0xFF10B981)
    val Amber = Color(0xFFF59E0B)
    val CriticalRed = Color(0xFFEF4444)
    val LightGray = Color(0xFFF2F4F7)
    val White = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF5B6475)
    val Border = Color(0xFFD6DCE8)
    val DarkBackground = Color(0xFF07111F)
    val DarkSurface = Color(0xFF0E1B33)
    val DarkSurfaceElevated = Color(0xFF132544)
    val DarkTextSecondary = Color(0xFFA9B7CC)
    val DarkOutline = Color(0xFF2C4265)
}

object AutonexisSpacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

private val AutonexisLightColorScheme = lightColorScheme(
    primary = AutonexisColors.ElectricBlue,
    onPrimary = AutonexisColors.White,
    primaryContainer = Color(0xFFDCEBFF),
    onPrimaryContainer = AutonexisColors.DeepNavy,
    secondary = AutonexisColors.DeepNavy,
    onSecondary = AutonexisColors.White,
    secondaryContainer = Color(0xFFE8EEF8),
    onSecondaryContainer = AutonexisColors.DeepNavy,
    tertiary = AutonexisColors.LightBlue,
    onTertiary = AutonexisColors.DeepNavy,
    background = AutonexisColors.LightGray,
    onBackground = AutonexisColors.DeepNavy,
    surface = AutonexisColors.White,
    onSurface = AutonexisColors.DeepNavy,
    surfaceVariant = Color(0xFFE8EEF8),
    onSurfaceVariant = AutonexisColors.TextSecondary,
    outline = AutonexisColors.Border,
    error = AutonexisColors.CriticalRed,
    onError = AutonexisColors.White,
)

private val AutonexisDarkColorScheme = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF061226),
    primaryContainer = Color(0xFF12386F),
    onPrimaryContainer = Color(0xFFD9E8FF),
    secondary = Color(0xFF9CC9FF),
    onSecondary = Color(0xFF07111F),
    secondaryContainer = Color(0xFF1A3156),
    onSecondaryContainer = Color(0xFFE4EEFF),
    tertiary = Color(0xFF67E8F9),
    onTertiary = Color(0xFF06222C),
    background = AutonexisColors.DarkBackground,
    onBackground = Color(0xFFE6EDF7),
    surface = AutonexisColors.DarkSurface,
    onSurface = Color(0xFFE6EDF7),
    surfaceVariant = AutonexisColors.DarkSurfaceElevated,
    onSurfaceVariant = AutonexisColors.DarkTextSecondary,
    outline = AutonexisColors.DarkOutline,
    error = Color(0xFFF87171),
    onError = Color(0xFF330B0B),
)

private val AutonexisTypography = Typography(
    headlineLarge = Typography().headlineLarge.copy(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 36.sp,
    ),
    headlineMedium = Typography().headlineMedium.copy(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
    ),
    titleLarge = Typography().titleLarge.copy(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
    ),
    bodyLarge = Typography().bodyLarge.copy(fontFamily = FontFamily.SansSerif),
    bodyMedium = Typography().bodyMedium.copy(fontFamily = FontFamily.SansSerif),
    labelLarge = Typography().labelLarge.copy(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
    ),
)

private val AutonexisShapes = Shapes(
    small = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
)

@Composable
fun AutonexisTheme(
    appearanceMode: AppearanceMode = AppearanceMode.SYSTEM,
    content: @Composable () -> Unit,
) {
    val darkTheme = AppearanceStore.resolveDarkTheme(appearanceMode, isSystemInDarkTheme())
    val colorScheme = if (darkTheme) AutonexisDarkColorScheme else AutonexisLightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colorScheme.surface.toArgb()
            window.navigationBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AutonexisTypography,
        shapes = AutonexisShapes,
        content = content,
    )
}
