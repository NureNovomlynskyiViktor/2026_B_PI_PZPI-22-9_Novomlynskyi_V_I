package alert

import (
	"context"
	"testing"
)

type stubRepository struct {
	alerts       []Alert
	alert        Alert
	resolution   SpecialistResolution
	status       string
	statusLimit  int
	statusCalled bool
	err          error
}

func (s *stubRepository) ListByVehicle(
	context.Context,
	string,
	int,
) ([]Alert, error) {
	return s.alerts, s.err
}

func (s *stubRepository) ListByVehicleStatus(
	_ context.Context,
	_ string,
	status string,
	limit int,
) ([]Alert, error) {
	s.status = status
	s.statusLimit = limit
	s.statusCalled = true
	return s.alerts, s.err
}

func (s *stubRepository) ListActiveByVehicle(
	context.Context,
	string,
) ([]Alert, error) {
	return s.alerts, s.err
}

func (s *stubRepository) GetByID(context.Context, string) (Alert, error) {
	return s.alert, s.err
}

func (s *stubRepository) ResolveBySpecialist(
	_ context.Context,
	request SpecialistResolution,
) (Alert, error) {
	s.resolution = request
	return s.alert, s.err
}

func TestParseLimit(t *testing.T) {
	tests := []struct {
		name    string
		raw     string
		want    int
		wantErr bool
	}{
		{name: "default", raw: "", want: DefaultLimit},
		{name: "valid", raw: "100", want: 100},
		{name: "maximum", raw: "200", want: MaxLimit},
		{name: "zero", raw: "0", wantErr: true},
		{name: "negative", raw: "-1", wantErr: true},
		{name: "too large", raw: "201", wantErr: true},
		{name: "not a number", raw: "many", wantErr: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseLimit(tt.raw)
			if (err != nil) != tt.wantErr {
				t.Fatalf("ParseLimit() error = %v, wantErr %v", err, tt.wantErr)
			}
			if got != tt.want {
				t.Fatalf("ParseLimit() = %d, want %d", got, tt.want)
			}
		})
	}
}

func TestParseStatus(t *testing.T) {
	tests := []struct {
		name    string
		raw     string
		want    string
		wantErr bool
	}{
		{name: "default", raw: "", want: StatusAll},
		{name: "all", raw: StatusAll, want: StatusAll},
		{name: "active", raw: StatusActive, want: StatusActive},
		{name: "cleared", raw: StatusCleared, want: StatusCleared},
		{name: "resolved", raw: StatusResolved, want: StatusResolved},
		{name: "invalid", raw: "open", wantErr: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseStatus(tt.raw)
			if (err != nil) != tt.wantErr {
				t.Fatalf("ParseStatus() error = %v, wantErr %v", err, tt.wantErr)
			}
			if got != tt.want {
				t.Fatalf("ParseStatus() = %q, want %q", got, tt.want)
			}
		})
	}
}

func TestServiceRejectsInvalidIDs(t *testing.T) {
	service := NewService(&stubRepository{})

	if _, err := service.ListByVehicle(context.Background(), "invalid", DefaultLimit); err != ErrInvalidVehicleID {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}
	if _, err := service.ListByVehicleStatus(context.Background(), "invalid", StatusAll, DefaultLimit); err != ErrInvalidVehicleID {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}
	if _, err := service.ListActiveByVehicle(context.Background(), "invalid"); err != ErrInvalidVehicleID {
		t.Fatalf("expected ErrInvalidVehicleID, got %v", err)
	}
	if _, err := service.GetByID(context.Background(), "123"); err != ErrInvalidAlertID {
		t.Fatalf("expected ErrInvalidAlertID, got %v", err)
	}
	if _, err := service.ResolveBySpecialist(context.Background(), SpecialistResolution{
		AlertID:        "123",
		SpecialistID:   testVehicleID,
		ResolutionNote: "Confirmed after inspection.",
	}); err != ErrInvalidAlertID {
		t.Fatalf("expected ErrInvalidAlertID, got %v", err)
	}
}

func TestServiceListByVehicleStatusValidation(t *testing.T) {
	service := NewService(&stubRepository{})

	if _, err := service.ListByVehicleStatus(context.Background(), testVehicleID, "open", DefaultLimit); err != ErrInvalidStatus {
		t.Fatalf("expected ErrInvalidStatus, got %v", err)
	}
	if _, err := service.ListByVehicleStatus(context.Background(), testVehicleID, StatusActive, 0); err != ErrInvalidLimit {
		t.Fatalf("expected ErrInvalidLimit, got %v", err)
	}
}

func TestServiceListByVehicleStatusUsesStatusFilter(t *testing.T) {
	repository := &stubRepository{}
	service := NewService(repository)

	if _, err := service.ListByVehicleStatus(context.Background(), testVehicleID, StatusResolved, 25); err != nil {
		t.Fatalf("ListByVehicleStatus returned error: %v", err)
	}
	if !repository.statusCalled {
		t.Fatal("expected status-specific repository method to be called")
	}
	if repository.status != StatusResolved || repository.statusLimit != 25 {
		t.Fatalf("unexpected status query values: status=%q limit=%d", repository.status, repository.statusLimit)
	}
}

func TestServiceResolveBySpecialistValidation(t *testing.T) {
	service := NewService(&stubRepository{})

	if _, err := service.ResolveBySpecialist(context.Background(), SpecialistResolution{
		AlertID:        testAlertID,
		SpecialistID:   testVehicleID,
		ResolutionNote: "short",
	}); err != ErrInvalidResolutionNote {
		t.Fatalf("expected ErrInvalidResolutionNote, got %v", err)
	}

	invalidServiceRequestID := "not-a-uuid"
	if _, err := service.ResolveBySpecialist(context.Background(), SpecialistResolution{
		AlertID:          testAlertID,
		SpecialistID:     testVehicleID,
		ResolutionNote:   "Confirmed after inspection.",
		ServiceRequestID: &invalidServiceRequestID,
	}); err != ErrInvalidResolutionServiceRequest {
		t.Fatalf("expected ErrInvalidResolutionServiceRequest, got %v", err)
	}
}

func TestServiceResolveBySpecialistTrimsInput(t *testing.T) {
	repository := &stubRepository{}
	service := NewService(repository)
	serviceRequestID := "55555555-5555-5555-5555-555555555555"

	if _, err := service.ResolveBySpecialist(context.Background(), SpecialistResolution{
		AlertID:          " " + testAlertID + " ",
		SpecialistID:     " " + testVehicleID + " ",
		ResolutionNote:   "  Confirmed after inspection.  ",
		ServiceRequestID: &serviceRequestID,
	}); err != nil {
		t.Fatalf("ResolveBySpecialist returned error: %v", err)
	}

	if repository.resolution.AlertID != testAlertID ||
		repository.resolution.SpecialistID != testVehicleID ||
		repository.resolution.ResolutionNote != "Confirmed after inspection." {
		t.Fatalf("request was not normalized: %#v", repository.resolution)
	}
	if repository.resolution.ServiceRequestID == nil ||
		*repository.resolution.ServiceRequestID != serviceRequestID {
		t.Fatalf("service request ID was not preserved: %#v", repository.resolution.ServiceRequestID)
	}
}
