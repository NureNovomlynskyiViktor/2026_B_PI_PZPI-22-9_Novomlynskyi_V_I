package alert

import (
	"context"
	"database/sql"
	"errors"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
)

func TestResolutionAuditMetadata(t *testing.T) {
	writer := &capturingAuditWriter{}
	repository := &PostgresRepository{audits: writer}
	clearedAt := time.Date(2026, 6, 19, 10, 0, 0, 0, time.UTC)
	resolvedAt := time.Date(2026, 6, 19, 11, 0, 0, 0, time.UTC)
	serviceRequestID := "66666666-6666-6666-6666-666666666666"

	err := repository.writeResolutionAudit(
		context.Background(),
		nil,
		SpecialistResolution{
			SpecialistID:     "55555555-5555-5555-5555-555555555555",
			ResolutionNote:   "Cooling system repaired and verified.",
			ServiceRequestID: &serviceRequestID,
		},
		Alert{ID: testAlertID, Status: StatusCleared},
		Alert{
			ID:              testAlertID,
			VehicleID:       testVehicleID,
			Type:            "engine_temperature",
			Severity:        "critical",
			Status:          StatusResolved,
			OccurrenceCount: 2,
			ClearedAt:       &clearedAt,
			ResolvedAt:      &resolvedAt,
		},
	)
	if err != nil {
		t.Fatalf("writeResolutionAudit returned error: %v", err)
	}

	if writer.entry.Action != ActionAlertResolutionConfirmed ||
		writer.entry.EntityType != EntityTypeAlert ||
		writer.entry.EntityID != testAlertID {
		t.Fatalf("unexpected audit entry: %#v", writer.entry)
	}
	metadata, ok := writer.entry.Metadata.(map[string]any)
	if !ok {
		t.Fatalf("expected metadata map, got %#v", writer.entry.Metadata)
	}
	requestID, ok := metadata["resolution_service_request_id"].(*string)
	if !ok || requestID == nil || *requestID != serviceRequestID {
		t.Fatalf("unexpected service request metadata: %#v", metadata["resolution_service_request_id"])
	}
	if metadata["severity"] != "critical" ||
		metadata["occurrence_count"] != 2 ||
		metadata["resolution_note_length"] != len([]rune("Cooling system repaired and verified.")) {
		t.Fatalf("unexpected audit metadata: %#v", metadata)
	}
}

func TestResolutionAuditFailurePropagates(t *testing.T) {
	expected := auditlog.ErrWriteFailed
	repository := &PostgresRepository{audits: &capturingAuditWriter{err: expected}}

	err := repository.writeResolutionAudit(
		context.Background(),
		nil,
		SpecialistResolution{SpecialistID: testVehicleID, ResolutionNote: "Confirmed after inspection."},
		Alert{ID: testAlertID, Status: StatusCleared},
		Alert{ID: testAlertID, Status: StatusResolved},
	)

	if !errors.Is(err, expected) {
		t.Fatalf("expected audit failure, got %v", err)
	}
}

func TestResolutionNotificationInput(t *testing.T) {
	writer := &capturingNotificationWriter{}
	repository := &PostgresRepository{notifications: writer}

	err := repository.createResolutionNotification(
		context.Background(),
		nil,
		testVehicleID,
		Alert{ID: testAlertID, Type: "engine_temperature"},
		"Cooling system repaired and verified.",
	)
	if err != nil {
		t.Fatalf("createResolutionNotification returned error: %v", err)
	}

	if writer.input.UserID != testVehicleID ||
		writer.input.AlertID == nil ||
		*writer.input.AlertID != testAlertID ||
		writer.input.NotificationType != notification.TypeVehicleAlert ||
		writer.input.Title != "Alert resolution confirmed" {
		t.Fatalf("unexpected notification input: %#v", writer.input)
	}
	if writer.input.ServiceRequestID != nil {
		t.Fatalf("did not expect service request reference in vehicle-alert notification")
	}
}

func TestResolutionNotificationFailurePropagates(t *testing.T) {
	expected := errors.New("notification failed")
	repository := &PostgresRepository{notifications: &capturingNotificationWriter{err: expected}}

	err := repository.createResolutionNotification(
		context.Background(),
		nil,
		testVehicleID,
		Alert{ID: testAlertID, Type: "battery_voltage"},
		"Battery terminal repaired.",
	)

	if !errors.Is(err, expected) {
		t.Fatalf("expected notification failure, got %v", err)
	}
}

func TestResolutionServiceRequestEligibility(t *testing.T) {
	serviceRequestID := "66666666-6666-6666-6666-666666666666"
	request := SpecialistResolution{
		SpecialistID:     "55555555-5555-5555-5555-555555555555",
		ServiceRequestID: &serviceRequestID,
	}
	item := Alert{ID: testAlertID, VehicleID: testVehicleID}
	validSnapshot := resolutionServiceRequestSnapshot{
		VehicleID:            testVehicleID,
		SourceAlertID:        sql.NullString{String: testAlertID, Valid: true},
		AssignedSpecialistID: sql.NullString{String: request.SpecialistID, Valid: true},
		Status:               "completed",
	}

	tests := []struct {
		name     string
		snapshot resolutionServiceRequestSnapshot
		want     bool
	}{
		{name: "valid", snapshot: validSnapshot, want: true},
		{
			name: "mismatched vehicle",
			snapshot: resolutionServiceRequestSnapshot{
				VehicleID:            "99999999-9999-9999-9999-999999999999",
				SourceAlertID:        validSnapshot.SourceAlertID,
				AssignedSpecialistID: validSnapshot.AssignedSpecialistID,
				Status:               "completed",
			},
		},
		{
			name: "mismatched alert",
			snapshot: resolutionServiceRequestSnapshot{
				VehicleID:            testVehicleID,
				SourceAlertID:        sql.NullString{String: "99999999-9999-9999-9999-999999999999", Valid: true},
				AssignedSpecialistID: validSnapshot.AssignedSpecialistID,
				Status:               "completed",
			},
		},
		{
			name: "unassigned specialist",
			snapshot: resolutionServiceRequestSnapshot{
				VehicleID:            testVehicleID,
				SourceAlertID:        validSnapshot.SourceAlertID,
				AssignedSpecialistID: sql.NullString{String: "99999999-9999-9999-9999-999999999999", Valid: true},
				Status:               "completed",
			},
		},
		{
			name: "unfinished",
			snapshot: resolutionServiceRequestSnapshot{
				VehicleID:            testVehicleID,
				SourceAlertID:        validSnapshot.SourceAlertID,
				AssignedSpecialistID: validSnapshot.AssignedSpecialistID,
				Status:               "in_progress",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := isValidResolutionServiceRequest(request, item, tt.snapshot)
			if got != tt.want {
				t.Fatalf("isValidResolutionServiceRequest() = %v, want %v", got, tt.want)
			}
		})
	}
}

type capturingAuditWriter struct {
	entry auditlog.Entry
	err   error
}

func (w *capturingAuditWriter) Write(
	_ context.Context,
	_ auditlog.Executor,
	entry auditlog.Entry,
) error {
	if w.err != nil {
		return w.err
	}
	w.entry = entry
	return nil
}

type capturingNotificationWriter struct {
	input notification.NewNotification
	err   error
}

func (w *capturingNotificationWriter) Create(
	_ context.Context,
	_ notification.Executor,
	input notification.NewNotification,
) (notification.Notification, error) {
	if w.err != nil {
		return notification.Notification{}, w.err
	}
	w.input = input
	return notification.Notification{ID: "77777777-7777-7777-7777-777777777777"}, nil
}
