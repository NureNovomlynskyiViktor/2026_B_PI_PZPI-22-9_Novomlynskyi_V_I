package config

import (
	"strings"
	"testing"
)

func TestLoadFromEnvironment(t *testing.T) {
	t.Setenv("APP_ENV", "test")
	t.Setenv("HTTP_HOST", "127.0.0.1")
	t.Setenv("HTTP_PORT", "9090")
	t.Setenv("POSTGRES_HOST", "postgres")
	t.Setenv("POSTGRES_PORT", "5433")
	t.Setenv("POSTGRES_DB", "autonexis_test")
	t.Setenv("POSTGRES_USER", "autonexis")
	t.Setenv("POSTGRES_PASSWORD", "secret")
	t.Setenv("POSTGRES_SSLMODE", "require")
	t.Setenv("MQTT_ENABLED", "true")
	t.Setenv("MQTT_BROKER_HOST", "mosquitto")
	t.Setenv("MQTT_BROKER_PORT", "1884")
	t.Setenv("MQTT_CLIENT_ID", "autonexis-test")
	t.Setenv("MQTT_TELEMETRY_TOPIC", "autonexis/devices/+/telemetry")
	t.Setenv("JWT_SECRET", "test-secret")
	t.Setenv("JWT_ACCESS_TOKEN_TTL", "30m")
	t.Setenv("CORS_ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load() returned an error: %v", err)
	}

	if cfg.AppEnv != "test" {
		t.Fatalf("expected APP_ENV test, got %s", cfg.AppEnv)
	}
	if cfg.HTTP.Address() != "127.0.0.1:9090" {
		t.Fatalf("expected HTTP address 127.0.0.1:9090, got %s", cfg.HTTP.Address())
	}
	if cfg.Database.Host != "postgres" || cfg.Database.Port != 5433 {
		t.Fatalf(
			"expected PostgreSQL address postgres:5433, got %s:%d",
			cfg.Database.Host,
			cfg.Database.Port,
		)
	}
	if !strings.Contains(cfg.Database.DSN(), "autonexis_test") {
		t.Fatalf("expected database name in DSN, got %s", cfg.Database.DSN())
	}
	if !strings.Contains(cfg.Database.DSN(), "sslmode=require") {
		t.Fatalf("expected SSL mode in DSN, got %s", cfg.Database.DSN())
	}
	if !cfg.MQTT.Enabled {
		t.Fatal("expected MQTT to be enabled")
	}
	if cfg.MQTT.BrokerURL() != "tcp://mosquitto:1884" {
		t.Fatalf("unexpected MQTT broker URL: %s", cfg.MQTT.BrokerURL())
	}
	if cfg.MQTT.ClientID != "autonexis-test" {
		t.Fatalf("unexpected MQTT client ID: %s", cfg.MQTT.ClientID)
	}
	if cfg.JWT.Secret != "test-secret" {
		t.Fatal("unexpected JWT secret")
	}
	if cfg.JWT.AccessTokenTTL.String() != "30m0s" {
		t.Fatalf("unexpected JWT access token TTL: %s", cfg.JWT.AccessTokenTTL)
	}
	if len(cfg.CORS.AllowedOrigins) != 2 {
		t.Fatalf("expected two CORS origins, got %+v", cfg.CORS.AllowedOrigins)
	}
	if cfg.CORS.AllowedOrigins[0] != "http://localhost:5173" {
		t.Fatalf("unexpected CORS origins: %+v", cfg.CORS.AllowedOrigins)
	}
}

func TestLoadRejectsInvalidPort(t *testing.T) {
	t.Setenv("HTTP_PORT", "invalid")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error for invalid HTTP_PORT")
	}
}

func TestLoadDefaultsMQTTToDisabled(t *testing.T) {
	t.Setenv("MQTT_ENABLED", "false")

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load() returned an error: %v", err)
	}
	if cfg.MQTT.Enabled {
		t.Fatal("expected MQTT to be disabled by default")
	}
	if cfg.MQTT.TelemetryTopic != defaultMQTTTopic {
		t.Fatalf("unexpected default MQTT topic: %s", cfg.MQTT.TelemetryTopic)
	}
}

func TestLoadRejectsInvalidMQTTEnabled(t *testing.T) {
	t.Setenv("MQTT_ENABLED", "sometimes")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error for invalid MQTT_ENABLED")
	}
}

func TestLoadRejectsInvalidJWTAccessTokenTTL(t *testing.T) {
	t.Setenv("JWT_ACCESS_TOKEN_TTL", "soon")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error for invalid JWT_ACCESS_TOKEN_TTL")
	}
}

func TestLoadRejectsEmptyCORSOrigins(t *testing.T) {
	t.Setenv("CORS_ALLOWED_ORIGINS", " , ")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error for empty CORS origins")
	}
}

func TestLoadGoogleAuthDefaultsToDisabled(t *testing.T) {
	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load() returned an error: %v", err)
	}
	if cfg.GoogleAuth.Enabled {
		t.Fatal("expected Google auth to be disabled by default")
	}
	if len(cfg.GoogleAuth.ClientIDs) != 0 {
		t.Fatalf("expected no default Google client IDs, got %+v", cfg.GoogleAuth.ClientIDs)
	}
}

func TestLoadGoogleAuthEnabledWithMultipleClientIDs(t *testing.T) {
	t.Setenv("GOOGLE_AUTH_ENABLED", "true")
	t.Setenv("GOOGLE_OAUTH_CLIENT_IDS", " web-client.apps.googleusercontent.com , android-client.apps.googleusercontent.com ")

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load() returned an error: %v", err)
	}
	if !cfg.GoogleAuth.Enabled {
		t.Fatal("expected Google auth to be enabled")
	}
	if len(cfg.GoogleAuth.ClientIDs) != 2 {
		t.Fatalf("expected two Google client IDs, got %+v", cfg.GoogleAuth.ClientIDs)
	}
	if cfg.GoogleAuth.ClientIDs[0] != "web-client.apps.googleusercontent.com" {
		t.Fatalf("unexpected first Google client ID: %+v", cfg.GoogleAuth.ClientIDs)
	}
}

func TestLoadRejectsGoogleAuthEnabledWithoutClientIDs(t *testing.T) {
	t.Setenv("GOOGLE_AUTH_ENABLED", "true")
	t.Setenv("GOOGLE_OAUTH_CLIENT_IDS", " ")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error when Google auth is enabled without client IDs")
	}
}

func TestLoadRejectsInvalidGoogleAuthEnabled(t *testing.T) {
	t.Setenv("GOOGLE_AUTH_ENABLED", "sometimes")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error for invalid GOOGLE_AUTH_ENABLED")
	}
}

func TestLoadRejectsEmptyGoogleClientIDEntries(t *testing.T) {
	t.Setenv("GOOGLE_OAUTH_CLIENT_IDS", "web-client,,android-client")

	if _, err := Load(); err == nil {
		t.Fatal("expected an error for empty Google client ID entry")
	}
}
