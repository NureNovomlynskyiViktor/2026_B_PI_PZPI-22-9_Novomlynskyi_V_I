package adminaudit

import (
	"errors"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := adminUser(w, r)
	if !ok {
		return
	}

	filters, ok := queryFilters(w, r)
	if !ok {
		return
	}

	result, err := h.service.List(r.Context(), filters)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid audit log filters")
		return
	}
	if err != nil {
		h.logger.Error("failed to list audit logs", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, result)
}

func queryFilters(w http.ResponseWriter, r *http.Request) (ListFilters, bool) {
	query := r.URL.Query()
	filters := ListFilters{
		Action:      query.Get("action"),
		ActorID:     query.Get("actor_id"),
		ActorSearch: query.Get("actor_search"),
		EntityType:  query.Get("entity_type"),
		EntityID:    query.Get("entity_id"),
		Limit:       DefaultLimit,
		Offset:      0,
	}

	if raw := query.Get("date_from"); raw != "" {
		value, err := time.Parse(time.RFC3339, raw)
		if err != nil {
			response.Error(w, http.StatusBadRequest, "invalid date_from")
			return ListFilters{}, false
		}
		filters.DateFrom = &value
	}
	if raw := query.Get("date_to"); raw != "" {
		value, err := time.Parse(time.RFC3339, raw)
		if err != nil {
			response.Error(w, http.StatusBadRequest, "invalid date_to")
			return ListFilters{}, false
		}
		filters.DateTo = &value
	}
	if raw := query.Get("limit"); raw != "" {
		value, err := strconv.Atoi(raw)
		if err != nil {
			response.Error(w, http.StatusBadRequest, "invalid limit")
			return ListFilters{}, false
		}
		filters.Limit = value
		filters.LimitSet = true
	}
	if raw := query.Get("offset"); raw != "" {
		value, err := strconv.Atoi(raw)
		if err != nil {
			response.Error(w, http.StatusBadRequest, "invalid offset")
			return ListFilters{}, false
		}
		filters.Offset = value
	}

	return filters, true
}

func adminUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.AdministratorRoleCode {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return auth.User{}, false
	}

	return user, true
}
