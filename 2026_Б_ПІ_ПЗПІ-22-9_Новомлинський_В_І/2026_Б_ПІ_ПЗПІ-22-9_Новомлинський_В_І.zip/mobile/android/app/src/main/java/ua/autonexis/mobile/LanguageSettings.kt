package ua.autonexis.mobile

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat
import java.util.Locale

enum class LanguageMode {
    SYSTEM,
    ENGLISH,
    UKRAINIAN,
}

interface LanguagePreferenceStorage {
    var rawLanguageMode: String?
    var restoreAccountAfterLanguageChange: Boolean
}

class LanguageController(private val store: LanguageStore) {
    var mode by mutableStateOf(store.mode)
        private set

    fun select(mode: LanguageMode) {
        store.mode = mode
        this.mode = store.mode
        AppCompatDelegate.setApplicationLocales(LanguageStore.localeListFor(this.mode))
    }
}

class SharedPreferencesLanguagePreferenceStorage(context: Context) : LanguagePreferenceStorage {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    override var rawLanguageMode: String?
        get() = preferences.getString(KEY_LANGUAGE_MODE, null)
        set(value) {
            preferences.edit().putString(KEY_LANGUAGE_MODE, value).apply()
        }

    override var restoreAccountAfterLanguageChange: Boolean
        get() = preferences.getBoolean(KEY_RESTORE_ACCOUNT_AFTER_LANGUAGE_CHANGE, false)
        set(value) {
            preferences.edit().putBoolean(KEY_RESTORE_ACCOUNT_AFTER_LANGUAGE_CHANGE, value).apply()
        }

    private companion object {
        const val PREFERENCES_NAME = "autonexis_language"
        const val KEY_LANGUAGE_MODE = "language_mode"
        const val KEY_RESTORE_ACCOUNT_AFTER_LANGUAGE_CHANGE = "restore_account_after_language_change"
    }
}

class LanguageStore(private val storage: LanguagePreferenceStorage) {
    var mode: LanguageMode
        get() = parseMode(storage.rawLanguageMode)
        set(value) {
            storage.rawLanguageMode = value.name
        }

    var restoreAccountAfterLanguageChange: Boolean
        get() = storage.restoreAccountAfterLanguageChange
        set(value) {
            storage.restoreAccountAfterLanguageChange = value
        }

    companion object {
        fun parseMode(rawValue: String?): LanguageMode {
            return LanguageMode.entries.firstOrNull { it.name == rawValue?.trim()?.uppercase(Locale.US) }
                ?: LanguageMode.SYSTEM
        }

        fun localeTagFor(mode: LanguageMode): String {
            return when (mode) {
                LanguageMode.SYSTEM -> ""
                LanguageMode.ENGLISH -> "en"
                LanguageMode.UKRAINIAN -> "uk"
            }
        }

        fun localeListFor(mode: LanguageMode): LocaleListCompat {
            return LocaleListCompat.forLanguageTags(localeTagFor(mode))
        }
    }
}
