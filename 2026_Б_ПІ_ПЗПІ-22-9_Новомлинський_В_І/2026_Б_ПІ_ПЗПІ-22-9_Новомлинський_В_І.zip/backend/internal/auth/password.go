package auth

import "golang.org/x/crypto/bcrypt"

const bcryptCost = 12

type PasswordHasher interface {
	Hash(password string) (string, error)
	Verify(hash string, password string) bool
}

type BcryptHasher struct{}

func (BcryptHasher) Hash(password string) (string, error) {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcryptCost)
	if err != nil {
		return "", err
	}

	return string(hash), nil
}

func (BcryptHasher) Verify(hash string, password string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)) == nil
}
