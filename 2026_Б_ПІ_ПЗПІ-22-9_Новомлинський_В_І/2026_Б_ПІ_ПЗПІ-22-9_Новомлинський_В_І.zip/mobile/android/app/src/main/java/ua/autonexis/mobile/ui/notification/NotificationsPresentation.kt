package ua.autonexis.mobile.ui.notification

import ua.autonexis.mobile.OwnerNotification

internal object NotificationsPresentation {
    fun newestFirst(items: List<OwnerNotification>): List<OwnerNotification> {
        return items.sortedWith(
            compareByDescending<OwnerNotification> { it.createdAt }
                .thenByDescending { it.id },
        )
    }

    fun displayTimestamp(value: String): String {
        return value
            .replace("T", " ")
            .removeSuffix("Z")
            .substringBefore(".")
            .ifBlank { "n/a" }
    }
}
