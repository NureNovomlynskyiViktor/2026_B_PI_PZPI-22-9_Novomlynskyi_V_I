package ownerservicerequest

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumOwnerServiceRequestBodySize = 1 << 20

type ServiceRequestService interface {
	Create(ctx context.Context, request servicerequest.CreateRequest) (servicerequest.Request, error)
	ListForOwner(ctx context.Context, ownerID string) ([]servicerequest.Request, error)
	GetForOwner(ctx context.Context, ownerID string, requestID string) (servicerequest.Request, error)
	CancelByOwner(ctx context.Context, ownerID string, requestID string) (servicerequest.Request, error)
}

type AlertService interface {
	GetByID(ctx context.Context, id string) (alert.Alert, error)
}

type VehicleService interface {
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
}

type Handler struct {
	requests ServiceRequestService
	vehicles VehicleService
	alerts   AlertService
	logger   *slog.Logger
}

func NewHandler(
	requests ServiceRequestService,
	vehicles VehicleService,
	alerts AlertService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		requests: requests,
		vehicles: vehicles,
		alerts:   alerts,
		logger:   logger,
	}
}

func (h *Handler) Create(w http.ResponseWriter, r *http.Request) {
	user, ok := ownerUser(w, r)
	if !ok {
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if _, err := h.vehicles.GetByIDForOwner(r.Context(), user.ID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return
		}
		h.logger.Error(
			"failed to verify owner service request vehicle",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	var request createRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	sourceAlertID, ok := h.validateSourceAlert(
		w,
		r,
		vehicleID,
		request.SourceAlertID,
	)
	if !ok {
		return
	}

	item, err := h.requests.Create(r.Context(), servicerequest.CreateRequest{
		VehicleID:     vehicleID,
		OwnerID:       user.ID,
		Title:         request.Title,
		Description:   request.Description,
		Priority:      request.Priority,
		SourceAlertID: sourceAlertID,
	})
	if errors.Is(err, servicerequest.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid service request data")
		return
	}
	if errors.Is(err, servicerequest.ErrDuplicateOpenAlertRequest) {
		response.Error(w, http.StatusConflict, "open service request already exists for alert")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to create owner service request",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, item)
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := ownerUser(w, r)
	if !ok {
		return
	}

	items, err := h.requests.ListForOwner(r.Context(), user.ID)
	if errors.Is(err, servicerequest.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid owner request")
		return
	}
	if err != nil {
		h.logger.Error("failed to list owner service requests", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, items)
}

func (h *Handler) Get(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := ownerRequestID(w, r)
	if !ok {
		return
	}

	item, err := h.requests.GetForOwner(r.Context(), user.ID, requestID)
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get owner service request",
			"user_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Cancel(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := ownerRequestID(w, r)
	if !ok {
		return
	}

	item, err := h.requests.CancelByOwner(r.Context(), user.ID, requestID)
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if errors.Is(err, servicerequest.ErrInvalidTransition) {
		response.Error(w, http.StatusConflict, "only pending service requests can be cancelled by owner")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to cancel owner service request",
			"user_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

type createRequest struct {
	Title         string `json:"title"`
	Description   string `json:"description"`
	Priority      string `json:"priority"`
	SourceAlertID string `json:"source_alert_id"`
}

func (h *Handler) validateSourceAlert(
	w http.ResponseWriter,
	r *http.Request,
	vehicleID string,
	rawSourceAlertID string,
) (*string, bool) {
	sourceAlertID := strings.TrimSpace(rawSourceAlertID)
	if sourceAlertID == "" {
		return nil, true
	}
	if !identifier.IsUUID(sourceAlertID) {
		response.Error(w, http.StatusBadRequest, "invalid source_alert_id")
		return nil, false
	}

	sourceAlert, err := h.alerts.GetByID(r.Context(), sourceAlertID)
	if errors.Is(err, alert.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "alert not found")
		return nil, false
	}
	if errors.Is(err, alert.ErrInvalidAlertID) {
		response.Error(w, http.StatusBadRequest, "invalid source_alert_id")
		return nil, false
	}
	if err != nil {
		h.logger.Error(
			"failed to verify source alert",
			"vehicle_id", vehicleID,
			"source_alert_id", sourceAlertID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return nil, false
	}
	if sourceAlert.VehicleID != vehicleID {
		response.Error(w, http.StatusNotFound, "alert not found")
		return nil, false
	}
	if sourceAlert.Status != "active" ||
		(sourceAlert.Severity != "warning" && sourceAlert.Severity != "critical") {
		response.Error(w, http.StatusBadRequest, "source alert is not eligible for a service request")
		return nil, false
	}

	return &sourceAlertID, true
}

func ownerRequestID(w http.ResponseWriter, r *http.Request) (auth.User, string, bool) {
	user, ok := ownerUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	requestID := r.PathValue("request_id")
	if !identifier.IsUUID(requestID) {
		response.Error(w, http.StatusBadRequest, "invalid request_id")
		return auth.User{}, "", false
	}

	return user, requestID, true
}

func ownerUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.DefaultRoleCode {
		response.Error(w, http.StatusForbidden, "vehicle owner role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumOwnerServiceRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
