package telemetry

import "time"

type Record struct {
	ID                int64     `json:"id"`
	VehicleID         string    `json:"vehicle_id"`
	DeviceID          string    `json:"device_id"`
	MeasuredAt        time.Time `json:"measured_at"`
	ReceivedAt        time.Time `json:"received_at"`
	EngineTemperature float64   `json:"engine_temperature"`
	BatteryVoltage    float64   `json:"battery_voltage"`
	VibrationLevel    float64   `json:"vibration_level"`
	RPM               int       `json:"rpm"`
	Speed             float64   `json:"speed"`
	FuelLevel         float64   `json:"fuel_level"`
}

type NewRecord struct {
	VehicleID         string
	DeviceID          string
	MeasuredAt        time.Time
	ReceivedAt        time.Time
	EngineTemperature float64
	BatteryVoltage    float64
	VibrationLevel    float64
	RPM               int
	Speed             float64
	FuelLevel         float64
}
