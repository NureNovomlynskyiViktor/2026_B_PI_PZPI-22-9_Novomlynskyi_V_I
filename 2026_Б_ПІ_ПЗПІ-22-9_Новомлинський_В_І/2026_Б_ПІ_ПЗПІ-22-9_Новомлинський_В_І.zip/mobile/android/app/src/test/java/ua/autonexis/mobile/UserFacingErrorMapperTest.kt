package ua.autonexis.mobile

import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse

class UserFacingErrorMapperTest {
    @Test
    fun mapsConnectionRefusedToSafeMessage() {
        val message = UserFacingErrorMapper.messageFor(
            ConnectException("failed to connect to /10.0.2.2 (port 8080) from /10.0.2.15 after 10000ms"),
        )

        assertEquals(
            "Cannot reach the Autonexis server. Check the backend connection and try again.",
            message,
        )
        assertSafeNetworkMessage(message)
    }

    @Test
    fun mapsTimeoutToSafeMessage() {
        val message = UserFacingErrorMapper.messageFor(
            SocketTimeoutException("timeout after 10000ms for token eyJhbGciOi.fake.signature"),
        )

        assertEquals("The server is taking too long to respond. Try again.", message)
        assertSafeNetworkMessage(message)
    }

    @Test
    fun mapsUnknownHostAndUnavailableNetworkToSafeMessage() {
        val unknownHost = UserFacingErrorMapper.messageFor(
            UnknownHostException("Unable to resolve host 10.0.2.2"),
        )
        val unavailableNetwork = UserFacingErrorMapper.messageFor(
            NoRouteToHostException("No route to host 10.0.2.2 port 8080"),
        )
        val socket = UserFacingErrorMapper.messageFor(
            SocketException("Network is unreachable for /10.0.2.2:8080"),
        )

        val expected = "Network connection is unavailable. Check your connection and try again."
        assertEquals(expected, unknownHost)
        assertEquals(expected, unavailableNetwork)
        assertEquals(expected, socket)
        listOf(unknownHost, unavailableNetwork, socket).forEach(::assertSafeNetworkMessage)
    }

    @Test
    fun preservesBackendApiErrors() {
        assertEquals(
            "invalid credentials",
            UserFacingErrorMapper.messageFor(ApiException(401, "invalid credentials")),
        )
    }

    private fun assertSafeNetworkMessage(message: String) {
        assertFalse(message.contains("10.0.2.2"))
        assertFalse(message.contains("port", ignoreCase = true))
        assertFalse(message.contains("ConnectException"))
        assertFalse(message.contains("SocketTimeoutException"))
        assertFalse(message.contains("UnknownHostException"))
        assertFalse(message.contains("eyJ"))
    }
}
