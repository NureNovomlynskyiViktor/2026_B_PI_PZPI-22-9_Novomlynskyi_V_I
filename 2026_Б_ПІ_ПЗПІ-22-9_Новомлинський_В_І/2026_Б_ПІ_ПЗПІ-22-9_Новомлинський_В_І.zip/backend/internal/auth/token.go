package auth

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"strings"
	"time"
)

var ErrInvalidToken = errors.New("invalid token")

type TokenManager interface {
	Generate(user User) (string, time.Time, error)
	Validate(token string) (TokenClaims, error)
}

type JWTManager struct {
	secret []byte
	ttl    time.Duration
	now    func() time.Time
}

func NewJWTManager(secret string, ttl time.Duration) *JWTManager {
	return &JWTManager{
		secret: []byte(secret),
		ttl:    ttl,
		now:    time.Now,
	}
}

func (m *JWTManager) Generate(user User) (string, time.Time, error) {
	issuedAt := m.now().UTC()
	expiresAt := issuedAt.Add(m.ttl)

	header := map[string]string{
		"alg": "HS256",
		"typ": "JWT",
	}
	payload := map[string]any{
		"sub":   user.ID,
		"email": user.Email,
		"role":  user.Role,
		"iat":   issuedAt.Unix(),
		"exp":   expiresAt.Unix(),
	}

	headerPart, err := encodeJSON(header)
	if err != nil {
		return "", time.Time{}, err
	}
	payloadPart, err := encodeJSON(payload)
	if err != nil {
		return "", time.Time{}, err
	}

	unsigned := headerPart + "." + payloadPart
	signature := sign(unsigned, m.secret)

	return unsigned + "." + signature, expiresAt, nil
}

func (m *JWTManager) Validate(token string) (TokenClaims, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return TokenClaims{}, ErrInvalidToken
	}

	unsigned := parts[0] + "." + parts[1]
	if !hmac.Equal([]byte(sign(unsigned, m.secret)), []byte(parts[2])) {
		return TokenClaims{}, ErrInvalidToken
	}

	var payload struct {
		Subject string `json:"sub"`
		Email   string `json:"email"`
		Role    string `json:"role"`
		Issued  int64  `json:"iat"`
		Expires int64  `json:"exp"`
	}
	payloadBytes, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return TokenClaims{}, ErrInvalidToken
	}
	if err := json.Unmarshal(payloadBytes, &payload); err != nil {
		return TokenClaims{}, ErrInvalidToken
	}
	if payload.Subject == "" || payload.Email == "" || payload.Role == "" {
		return TokenClaims{}, ErrInvalidToken
	}

	expiresAt := time.Unix(payload.Expires, 0).UTC()
	if !expiresAt.After(m.now().UTC()) {
		return TokenClaims{}, ErrInvalidToken
	}

	return TokenClaims{
		Subject:   payload.Subject,
		Email:     payload.Email,
		Role:      payload.Role,
		IssuedAt:  time.Unix(payload.Issued, 0).UTC(),
		ExpiresAt: expiresAt,
	}, nil
}

func encodeJSON(value any) (string, error) {
	data, err := json.Marshal(value)
	if err != nil {
		return "", err
	}

	return base64.RawURLEncoding.EncodeToString(data), nil
}

func sign(value string, secret []byte) string {
	mac := hmac.New(sha256.New, secret)
	mac.Write([]byte(value))
	return base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
}
