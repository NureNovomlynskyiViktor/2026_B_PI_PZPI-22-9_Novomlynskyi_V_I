package ua.autonexis.mobile

import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

internal object UserFacingErrorMapper {
    private const val cannotConnect =
        "Cannot reach the Autonexis server. Check the backend connection and try again."
    private const val timeout =
        "The server is taking too long to respond. Try again."
    private const val unavailableNetwork =
        "Network connection is unavailable. Check your connection and try again."

    fun messageFor(error: Exception): String {
        return when (error) {
            is ApiException -> error.message ?: "Request failed."
            is SocketTimeoutException -> timeout
            is UnknownHostException,
            is NoRouteToHostException -> unavailableNetwork
            is ConnectException -> cannotConnect
            is SocketException -> unavailableNetwork
            else -> error.message?.takeIf { it.isNotBlank() } ?: "Unexpected error"
        }
    }
}
