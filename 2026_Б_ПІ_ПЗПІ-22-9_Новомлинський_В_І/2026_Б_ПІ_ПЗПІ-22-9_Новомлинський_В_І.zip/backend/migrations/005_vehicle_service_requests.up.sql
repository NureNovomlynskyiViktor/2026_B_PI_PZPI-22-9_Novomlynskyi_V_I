BEGIN;

CREATE TABLE vehicle_service_requests (
	id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
	vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
	owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
	assigned_specialist_id UUID REFERENCES users(id) ON DELETE SET NULL,
	assigned_by UUID REFERENCES users(id) ON DELETE SET NULL,
	title VARCHAR(255) NOT NULL,
	description TEXT NOT NULL,
	priority VARCHAR(32) NOT NULL DEFAULT 'normal',
	status VARCHAR(32) NOT NULL DEFAULT 'pending',
	result_summary TEXT,
	created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	assigned_at TIMESTAMPTZ,
	started_at TIMESTAMPTZ,
	completed_at TIMESTAMPTZ,
	cancelled_at TIMESTAMPTZ,
	CONSTRAINT vehicle_service_requests_priority_check
		CHECK (priority IN ('low', 'normal', 'high')),
	CONSTRAINT vehicle_service_requests_status_check
		CHECK (status IN ('pending', 'assigned', 'in_progress', 'completed', 'cancelled')),
	CONSTRAINT vehicle_service_requests_completed_result_check
		CHECK (
			status <> 'completed'
			OR (result_summary IS NOT NULL AND btrim(result_summary) <> '')
		),
	CONSTRAINT vehicle_service_requests_assignment_check
		CHECK (
			(
				status = 'pending'
				AND assigned_specialist_id IS NULL
				AND assigned_by IS NULL
				AND assigned_at IS NULL
			)
			OR status = 'cancelled'
			OR (
				assigned_specialist_id IS NOT NULL
				AND assigned_by IS NOT NULL
				AND assigned_at IS NOT NULL
			)
		)
);

CREATE INDEX vehicle_service_requests_owner_created_idx
	ON vehicle_service_requests(owner_id, created_at DESC, id DESC);

CREATE INDEX vehicle_service_requests_status_created_idx
	ON vehicle_service_requests(status, created_at DESC, id DESC);

CREATE INDEX vehicle_service_requests_specialist_status_idx
	ON vehicle_service_requests(assigned_specialist_id, status, created_at DESC);

CREATE INDEX vehicle_service_requests_vehicle_created_idx
	ON vehicle_service_requests(vehicle_id, created_at DESC, id DESC);

COMMIT;
