﻿package ua.autonexis.mobile

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class AppearanceMode {
    SYSTEM,
    LIGHT,
    DARK,
}

interface AppearancePreferenceStorage {
    var rawAppearanceMode: String?
}

class AppearanceController(private val store: AppearanceStore) {
    var mode by mutableStateOf(store.mode)
        private set

    fun select(mode: AppearanceMode) {
        store.mode = mode
        this.mode = store.mode
    }
}

class SharedPreferencesAppearancePreferenceStorage(context: Context) : AppearancePreferenceStorage {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    override var rawAppearanceMode: String?
        get() = preferences.getString(KEY_APPEARANCE_MODE, null)
        set(value) {
            preferences.edit().putString(KEY_APPEARANCE_MODE, value).apply()
        }

    private companion object {
        const val PREFERENCES_NAME = "autonexis_appearance"
        const val KEY_APPEARANCE_MODE = "appearance_mode"
    }
}

class AppearanceStore(private val storage: AppearancePreferenceStorage) {
    var mode: AppearanceMode
        get() = parseMode(storage.rawAppearanceMode)
        set(value) {
            storage.rawAppearanceMode = value.name
        }

    companion object {
        fun parseMode(rawValue: String?): AppearanceMode {
            return AppearanceMode.entries.firstOrNull { it.name == rawValue?.trim()?.uppercase() }
                ?: AppearanceMode.SYSTEM
        }

        fun resolveDarkTheme(mode: AppearanceMode, systemInDarkTheme: Boolean): Boolean {
            return when (mode) {
                AppearanceMode.SYSTEM -> systemInDarkTheme
                AppearanceMode.LIGHT -> false
                AppearanceMode.DARK -> true
            }
        }
    }
}

