import type {
  AdminAuditFilters,
  AdminAuditListResponse,
  AdminUserFilters,
  Alert,
  AuthenticationMethods,
  AuthResponse,
  CompleteServiceRequestRequest,
  CreateAdminSpecialistRequest,
  CreateAdminSpecialistResponse,
  CreateMaintenanceRecordRequest,
  CreateVehicleActivationRequest,
  DeactivateUserRequest,
  GoogleLinkRequest,
  GoogleLoginRequest,
  LoginRequest,
  MaintenanceRecord,
  RegisterRequest,
  ResolveSpecialistAlertRequest,
  ServiceRequest,
  SpecialistAssignment,
  SpecialistCompetency,
  SpecialistRecommendation,
  TelemetryRecord,
  ThresholdRule,
  User,
  Vehicle,
  VehicleActivationResponse,
  VehicleStatus,
} from './types';

const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL?.replace(/\/$/, '') ?? 'http://localhost:8080';

type ApiErrorBody = {
  error?: string;
};

export class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

export function isUnauthorizedError(error: unknown) {
  return error instanceof ApiError && error.status === 401;
}

export function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

async function apiRequest<T>(
  path: string,
  options: RequestInit = {},
  token?: string,
): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set('Accept', 'application/json');
  if (options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let message = `Request failed with status ${response.status}`;
    try {
      const body = (await response.json()) as ApiErrorBody;
      if (body.error) {
        message = body.error;
      }
    } catch {
      // Keep the status-based fallback.
    }

    throw new ApiError(response.status, message);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return (await response.json()) as T;
}

function buildAdminUserQuery(filters: AdminUserFilters = {}) {
  const params = new URLSearchParams();

  if (filters.role) {
    params.set('role', filters.role);
  }

  if (filters.is_active !== undefined) {
    params.set('is_active', String(filters.is_active));
  }

  if (filters.search?.trim()) {
    params.set('search', filters.search.trim());
  }

  const query = params.toString();
  return query ? `?${query}` : '';
}

function buildAdminAuditQuery(filters: AdminAuditFilters = {}) {
  const params = new URLSearchParams();
  const stringFilters: Array<keyof Pick<
    AdminAuditFilters,
    | 'action'
    | 'actor_id'
    | 'actor_search'
    | 'entity_type'
    | 'entity_id'
    | 'date_from'
    | 'date_to'
  >> = [
    'action',
    'actor_id',
    'actor_search',
    'entity_type',
    'entity_id',
    'date_from',
    'date_to',
  ];

  stringFilters.forEach((key) => {
    const value = filters[key];
    if (typeof value === 'string' && value.trim()) {
      params.set(key, value.trim());
    }
  });

  if (filters.limit !== undefined) {
    params.set('limit', String(filters.limit));
  }
  if (filters.offset !== undefined) {
    params.set('offset', String(filters.offset));
  }

  const query = params.toString();
  return query ? `?${query}` : '';
}

export const api = {
  register(request: RegisterRequest): Promise<AuthResponse> {
    return apiRequest<AuthResponse>('/api/v1/auth/register', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  },

  login(request: LoginRequest): Promise<AuthResponse> {
    return apiRequest<AuthResponse>('/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  },

  googleLogin(request: GoogleLoginRequest): Promise<AuthResponse> {
    return apiRequest<AuthResponse>('/api/v1/auth/google', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  },

  me(token: string): Promise<User> {
    return apiRequest<User>('/api/v1/auth/me', {}, token);
  },

  getAuthenticationMethods(token: string): Promise<AuthenticationMethods> {
    return apiRequest<AuthenticationMethods>('/api/v1/auth/methods', {}, token);
  },

  linkGoogleAccount(
    token: string,
    request: GoogleLinkRequest,
  ): Promise<AuthenticationMethods> {
    return apiRequest<AuthenticationMethods>(
      '/api/v1/auth/google/link',
      {
        method: 'POST',
        body: JSON.stringify(request),
      },
      token,
    );
  },

  listSpecialistVehicles(token: string): Promise<Vehicle[]> {
    return apiRequest<Vehicle[]>('/api/v1/specialist/vehicles', {}, token);
  },

  getSpecialistVehicleStatus(
    token: string,
    vehicleID: string,
  ): Promise<VehicleStatus> {
    return apiRequest<VehicleStatus>(
      `/api/v1/specialist/vehicles/${vehicleID}/status`,
      {},
      token,
    );
  },

  listSpecialistVehicleThresholds(
    token: string,
    vehicleID: string,
  ): Promise<ThresholdRule[]> {
    return apiRequest<ThresholdRule[]>(
      `/api/v1/specialist/vehicles/${vehicleID}/thresholds`,
      {},
      token,
    );
  },

  listSpecialistVehicleTelemetry(
    token: string,
    vehicleID: string,
    limit = 50,
  ): Promise<TelemetryRecord[]> {
    return apiRequest<TelemetryRecord[]>(
      `/api/v1/specialist/vehicles/${vehicleID}/telemetry?limit=${limit}`,
      {},
      token,
    );
  },

  listSpecialistVehicleAlerts(
    token: string,
    vehicleID: string,
    status = 'all',
    limit = 50,
  ): Promise<Alert[]> {
    return apiRequest<Alert[]>(
      `/api/v1/specialist/vehicles/${vehicleID}/alerts?status=${encodeURIComponent(status)}&limit=${limit}`,
      {},
      token,
    );
  },

  resolveSpecialistAlert(
    token: string,
    alertID: string,
    request: ResolveSpecialistAlertRequest,
  ): Promise<Alert> {
    return apiRequest<Alert>(
      `/api/v1/specialist/alerts/${alertID}/resolve`,
      {
        method: 'PATCH',
        body: JSON.stringify(request),
      },
      token,
    );
  },

  createSpecialistMaintenanceRecord(
    token: string,
    vehicleID: string,
    request: CreateMaintenanceRecordRequest,
  ): Promise<MaintenanceRecord> {
    return apiRequest<MaintenanceRecord>(
      `/api/v1/specialist/vehicles/${vehicleID}/maintenance-records`,
      {
        method: 'POST',
        body: JSON.stringify(request),
      },
      token,
    );
  },

  listAdminVehicles(token: string): Promise<Vehicle[]> {
    return apiRequest<Vehicle[]>('/api/v1/admin/vehicles', {}, token);
  },

  createVehicleActivation(
    token: string,
    request: CreateVehicleActivationRequest,
  ): Promise<VehicleActivationResponse> {
    return apiRequest<VehicleActivationResponse>(
      '/api/v1/admin/vehicle-activations',
      {
        method: 'POST',
        body: JSON.stringify(request),
      },
      token,
    );
  },

  listAdminSpecialists(token: string): Promise<User[]> {
    return apiRequest<User[]>('/api/v1/admin/specialists', {}, token);
  },

  createAdminSpecialist(
    token: string,
    request: CreateAdminSpecialistRequest,
  ): Promise<CreateAdminSpecialistResponse> {
    return apiRequest<CreateAdminSpecialistResponse>(
      '/api/v1/admin/specialists',
      {
        method: 'POST',
        body: JSON.stringify(request),
      },
      token,
    );
  },

  listAdminUsers(
    token: string,
    filters: AdminUserFilters = {},
  ): Promise<User[]> {
    return apiRequest<User[]>(
      `/api/v1/admin/users${buildAdminUserQuery(filters)}`,
      {},
      token,
    );
  },

  getAdminUser(token: string, userID: string): Promise<User> {
    return apiRequest<User>(`/api/v1/admin/users/${userID}`, {}, token);
  },

  deactivateAdminUser(
    token: string,
    userID: string,
    request: DeactivateUserRequest = {},
  ): Promise<User> {
    return apiRequest<User>(
      `/api/v1/admin/users/${userID}/deactivate`,
      {
        method: 'PATCH',
        body: JSON.stringify(request),
      },
      token,
    );
  },

  reactivateAdminUser(token: string, userID: string): Promise<User> {
    return apiRequest<User>(
      `/api/v1/admin/users/${userID}/reactivate`,
      {
        method: 'PATCH',
      },
      token,
    );
  },

  listAdminAuditLogs(
    token: string,
    filters: AdminAuditFilters = {},
  ): Promise<AdminAuditListResponse> {
    return apiRequest<AdminAuditListResponse>(
      `/api/v1/admin/audit-logs${buildAdminAuditQuery(filters)}`,
      {},
      token,
    );
  },

  listAdminVehicleSpecialists(
    token: string,
    vehicleID: string,
  ): Promise<SpecialistAssignment[]> {
    return apiRequest<SpecialistAssignment[]>(
      `/api/v1/admin/vehicles/${vehicleID}/specialists`,
      {},
      token,
    );
  },

  listAdminRecommendedSpecialists(
    token: string,
    vehicleID: string,
  ): Promise<SpecialistRecommendation[]> {
    return apiRequest<SpecialistRecommendation[]>(
      `/api/v1/admin/vehicles/${vehicleID}/recommended-specialists`,
      {},
      token,
    );
  },

  assignAdminVehicleSpecialist(
    token: string,
    vehicleID: string,
    specialistID: string,
  ): Promise<SpecialistAssignment> {
    return apiRequest<SpecialistAssignment>(
      `/api/v1/admin/vehicles/${vehicleID}/specialists`,
      {
        method: 'POST',
        body: JSON.stringify({ specialist_id: specialistID }),
      },
      token,
    );
  },

  removeAdminVehicleSpecialist(
    token: string,
    vehicleID: string,
    specialistID: string,
  ): Promise<void> {
    return apiRequest<void>(
      `/api/v1/admin/vehicles/${vehicleID}/specialists/${specialistID}`,
      {
        method: 'DELETE',
      },
      token,
    );
  },

  listAdminSpecialistCompetencies(
    token: string,
    specialistID: string,
  ): Promise<SpecialistCompetency[]> {
    return apiRequest<SpecialistCompetency[]>(
      `/api/v1/admin/specialists/${specialistID}/competencies`,
      {},
      token,
    );
  },

  replaceAdminSpecialistCompetencies(
    token: string,
    specialistID: string,
    codes: string[],
  ): Promise<SpecialistCompetency[]> {
    return apiRequest<SpecialistCompetency[]>(
      `/api/v1/admin/specialists/${specialistID}/competencies`,
      {
        method: 'PUT',
        body: JSON.stringify({ codes }),
      },
      token,
    );
  },

  listAdminServiceRequests(
    token: string,
    status?: string,
  ): Promise<ServiceRequest[]> {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    return apiRequest<ServiceRequest[]>(
      `/api/v1/admin/service-requests${query}`,
      {},
      token,
    );
  },

  assignAdminServiceRequest(
    token: string,
    requestID: string,
    specialistID: string,
  ): Promise<ServiceRequest> {
    return apiRequest<ServiceRequest>(
      `/api/v1/admin/service-requests/${requestID}/assign`,
      {
        method: 'PATCH',
        body: JSON.stringify({ specialist_id: specialistID }),
      },
      token,
    );
  },

  cancelAdminServiceRequest(
    token: string,
    requestID: string,
  ): Promise<ServiceRequest> {
    return apiRequest<ServiceRequest>(
      `/api/v1/admin/service-requests/${requestID}/cancel`,
      {
        method: 'PATCH',
      },
      token,
    );
  },

  listSpecialistServiceRequests(token: string): Promise<ServiceRequest[]> {
    return apiRequest<ServiceRequest[]>(
      '/api/v1/specialist/service-requests',
      {},
      token,
    );
  },

  startSpecialistServiceRequest(
    token: string,
    requestID: string,
  ): Promise<ServiceRequest> {
    return apiRequest<ServiceRequest>(
      `/api/v1/specialist/service-requests/${requestID}/start`,
      {
        method: 'PATCH',
      },
      token,
    );
  },

  completeSpecialistServiceRequest(
    token: string,
    requestID: string,
    request: CompleteServiceRequestRequest,
  ): Promise<ServiceRequest> {
    return apiRequest<ServiceRequest>(
      `/api/v1/specialist/service-requests/${requestID}/complete`,
      {
        method: 'PATCH',
        body: JSON.stringify(request),
      },
      token,
    );
  },

};
