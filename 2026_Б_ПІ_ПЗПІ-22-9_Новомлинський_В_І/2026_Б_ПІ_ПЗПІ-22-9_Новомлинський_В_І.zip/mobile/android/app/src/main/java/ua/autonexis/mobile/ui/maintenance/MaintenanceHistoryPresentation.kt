package ua.autonexis.mobile.ui.maintenance

import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.Year
import java.time.ZoneOffset
import ua.autonexis.mobile.AlertLifecyclePresentation
import ua.autonexis.mobile.MaintenanceRecord

internal data class MaintenanceSummary(
    val totalRecords: Int,
    val latestServiceDate: String,
    val latestServiceTitle: String,
    val currentYearCount: Int?,
)

internal data class MaintenanceTimelineSection(
    val label: String,
    val records: List<MaintenanceRecord>,
)

internal object MaintenanceHistoryPresentation {
    const val DATE_UNKNOWN = "__date_unknown__"
    const val MAINTENANCE_RECORD_FALLBACK = "__maintenance_record__"
    fun newestFirst(records: List<MaintenanceRecord>): List<MaintenanceRecord> {
        return records.sortedWith(
            compareByDescending<MaintenanceRecord> { serviceDateSortValue(it.serviceDate) }
                .thenByDescending { createdAtSortValue(it.createdAt) }
                .thenByDescending { it.id },
        )
    }

    fun summary(records: List<MaintenanceRecord>): MaintenanceSummary? {
        if (records.isEmpty()) {
            return null
        }

        val ordered = newestFirst(records)
        val latest = ordered.first()
        val parsedDates = records.mapNotNull { parseServiceDate(it.serviceDate) }
        val currentYear = Year.now(ZoneOffset.UTC).value

        return MaintenanceSummary(
            totalRecords = records.size,
            latestServiceDate = serviceDateLabel(latest),
            latestServiceTitle = latest.title.ifBlank { MAINTENANCE_RECORD_FALLBACK },
            currentYearCount = parsedDates
                .takeIf { it.isNotEmpty() }
                ?.count { it.year == currentYear },
        )
    }

    fun timelineSections(records: List<MaintenanceRecord>): List<MaintenanceTimelineSection> {
        return newestFirst(records)
            .groupBy { record ->
                parseServiceDate(record.serviceDate)?.year?.toString() ?: DATE_UNKNOWN
            }
            .map { (label, sectionRecords) ->
                MaintenanceTimelineSection(label = label, records = sectionRecords)
            }
    }

    fun serviceDateLabel(record: MaintenanceRecord): String {
        return parseServiceDate(record.serviceDate)?.toString()
            ?: record.serviceDate.takeIf { it.isNotBlank() }
            ?: DATE_UNKNOWN
    }

    fun createdAtLabel(record: MaintenanceRecord): String {
        return AlertLifecyclePresentation.displayTimestamp(record.createdAt)
    }

    internal fun parseServiceDate(value: String): LocalDate? {
        if (value.isBlank()) {
            return null
        }

        return runCatching { LocalDate.parse(value) }.getOrNull()
            ?: runCatching { OffsetDateTime.parse(value).toLocalDate() }.getOrNull()
            ?: runCatching { Instant.parse(value).atOffset(ZoneOffset.UTC).toLocalDate() }.getOrNull()
    }

    private fun serviceDateSortValue(value: String): Long {
        return parseServiceDate(value)?.toEpochDay() ?: Long.MIN_VALUE
    }

    private fun createdAtSortValue(value: String): Long {
        if (value.isBlank()) {
            return Long.MIN_VALUE
        }

        return runCatching { Instant.parse(value).toEpochMilli() }.getOrNull()
            ?: runCatching { OffsetDateTime.parse(value).toInstant().toEpochMilli() }.getOrNull()
            ?: Long.MIN_VALUE
    }
}
