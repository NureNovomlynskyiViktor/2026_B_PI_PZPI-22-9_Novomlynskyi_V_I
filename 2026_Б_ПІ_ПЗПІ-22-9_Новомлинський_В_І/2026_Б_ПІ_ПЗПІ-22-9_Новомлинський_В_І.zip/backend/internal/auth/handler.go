package auth

import (
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

const maximumAuthRequestBodySize = 1 << 20

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) Register(w http.ResponseWriter, r *http.Request) {
	var request RegisterRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	result, err := h.service.Register(r.Context(), request)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid registration data")
		return
	}
	if errors.Is(err, ErrEmailAlreadyExists) {
		response.Error(w, http.StatusConflict, "email already exists")
		return
	}
	if err != nil {
		h.logger.Error("failed to register user", "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, result)
}

func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
	var request LoginRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	result, err := h.service.Login(r.Context(), request)
	if errors.Is(err, ErrInvalidCredentials) {
		response.Error(w, http.StatusUnauthorized, "invalid credentials")
		return
	}
	if err != nil {
		h.logger.Error("failed to login user", "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, result)
}

func (h *Handler) Google(w http.ResponseWriter, r *http.Request) {
	var request GoogleLoginRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	result, err := h.service.GoogleLogin(r.Context(), request)
	switch {
	case errors.Is(err, ErrInvalidInput):
		response.Error(w, http.StatusBadRequest, "invalid Google sign-in request")
		return
	case errors.Is(err, ErrInvalidGoogleToken):
		response.Error(w, http.StatusUnauthorized, "invalid Google identity token")
		return
	case errors.Is(err, ErrInactiveUser):
		response.Error(w, http.StatusForbidden, "user account is inactive")
		return
	case errors.Is(err, ErrGoogleEmailRequiresLinking):
		response.Error(w, http.StatusConflict, "an account with this email already exists; sign in with the existing method before linking Google in a future account-linking flow")
		return
	case errors.Is(err, ErrGoogleAuthUnavailable):
		response.Error(w, http.StatusServiceUnavailable, "Google sign-in is not available")
		return
	case err != nil:
		h.logger.Error("failed to authenticate with Google", "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, result)
}

func (h *Handler) Methods(w http.ResponseWriter, r *http.Request) {
	user, ok := UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	status, err := h.service.AuthMethods(r.Context(), user)
	switch {
	case errors.Is(err, ErrUnauthorized):
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	case errors.Is(err, ErrInactiveUser):
		response.Error(w, http.StatusForbidden, "user account is inactive")
		return
	case err != nil:
		h.logger.Error("failed to get authentication methods", "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, status)
}

func (h *Handler) LinkGoogle(w http.ResponseWriter, r *http.Request) {
	user, ok := UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	var request GoogleLinkRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	status, err := h.service.LinkGoogle(r.Context(), user, request)
	switch {
	case errors.Is(err, ErrInvalidInput):
		response.Error(w, http.StatusBadRequest, "invalid Google linking request")
		return
	case errors.Is(err, ErrInvalidGoogleToken):
		response.Error(w, http.StatusUnauthorized, "invalid Google identity token")
		return
	case errors.Is(err, ErrUnauthorized):
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	case errors.Is(err, ErrInactiveUser):
		response.Error(w, http.StatusForbidden, "user account is inactive")
		return
	case errors.Is(err, ErrGoogleAuthUnavailable):
		response.Error(w, http.StatusServiceUnavailable, "Google sign-in is not available")
		return
	case errors.Is(err, ErrGoogleEmailMismatch):
		response.Error(w, http.StatusConflict, "Google account email must match the current Autonexis account email")
		return
	case errors.Is(err, ErrGoogleIdentityLinkedToOtherUser):
		response.Error(w, http.StatusConflict, "this Google account is already linked to another Autonexis account")
		return
	case errors.Is(err, ErrUserLinkedToDifferentGoogle):
		response.Error(w, http.StatusConflict, "this Autonexis account is already linked to a different Google account")
		return
	case err != nil:
		h.logger.Error("failed to link Google account", "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, status)
}
func (h *Handler) Me(w http.ResponseWriter, r *http.Request) {
	token, ok := bearerToken(r.Header.Get("Authorization"))
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	user, err := h.service.CurrentUser(r.Context(), token)
	if errors.Is(err, ErrUnauthorized) {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}
	if err != nil {
		h.logger.Error("failed to get current user", "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, user)
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumAuthRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}

func bearerToken(header string) (string, bool) {
	const prefix = "Bearer "
	if !strings.HasPrefix(header, prefix) {
		return "", false
	}

	token := strings.TrimSpace(strings.TrimPrefix(header, prefix))
	return token, token != ""
}
