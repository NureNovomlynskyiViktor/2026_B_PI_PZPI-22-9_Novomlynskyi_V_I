package adminservicerequest

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
)

const maximumAdminServiceRequestBodySize = 1 << 20

type ServiceRequestService interface {
	ListForAdmin(ctx context.Context, status string) ([]servicerequest.Request, error)
	GetForAdmin(ctx context.Context, requestID string) (servicerequest.Request, error)
	Assign(ctx context.Context, request servicerequest.AssignRequest) (servicerequest.Request, error)
	CancelByAdmin(ctx context.Context, request servicerequest.AdminCancelRequest) (servicerequest.Request, error)
}

type Handler struct {
	requests ServiceRequestService
	logger   *slog.Logger
}

func NewHandler(requests ServiceRequestService, logger *slog.Logger) *Handler {
	return &Handler{
		requests: requests,
		logger:   logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := adminUser(w, r)
	if !ok {
		return
	}

	items, err := h.requests.ListForAdmin(r.Context(), r.URL.Query().Get("status"))
	if errors.Is(err, servicerequest.ErrInvalidStatus) {
		response.Error(w, http.StatusBadRequest, "invalid status")
		return
	}
	if err != nil {
		h.logger.Error("failed to list admin service requests", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, items)
}

func (h *Handler) Get(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := adminRequestID(w, r)
	if !ok {
		return
	}

	item, err := h.requests.GetForAdmin(r.Context(), requestID)
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to get admin service request",
			"user_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Assign(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := adminRequestID(w, r)
	if !ok {
		return
	}

	var request assignRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	item, err := h.requests.Assign(r.Context(), servicerequest.AssignRequest{
		RequestID:    requestID,
		SpecialistID: request.SpecialistID,
		AdminID:      user.ID,
	})
	if errors.Is(err, servicerequest.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid service request assignment")
		return
	}
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if errors.Is(err, servicerequest.ErrSpecialistUnavailable) {
		response.Error(w, http.StatusNotFound, "active technical specialist not found")
		return
	}
	if errors.Is(err, servicerequest.ErrInvalidTransition) {
		response.Error(w, http.StatusConflict, "service request cannot be assigned in its current status")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to assign service request",
			"user_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

func (h *Handler) Cancel(w http.ResponseWriter, r *http.Request) {
	user, requestID, ok := adminRequestID(w, r)
	if !ok {
		return
	}

	item, err := h.requests.CancelByAdmin(r.Context(), servicerequest.AdminCancelRequest{
		RequestID: requestID,
		AdminID:   user.ID,
	})
	if errors.Is(err, servicerequest.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "service request not found")
		return
	}
	if errors.Is(err, servicerequest.ErrInvalidTransition) {
		response.Error(w, http.StatusConflict, "only pending or assigned service requests can be cancelled")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to cancel admin service request",
			"user_id", user.ID,
			"request_id", requestID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}

type assignRequest struct {
	SpecialistID string `json:"specialist_id"`
}

func adminRequestID(w http.ResponseWriter, r *http.Request) (auth.User, string, bool) {
	user, ok := adminUser(w, r)
	if !ok {
		return auth.User{}, "", false
	}

	requestID := r.PathValue("request_id")
	if !identifier.IsUUID(requestID) {
		response.Error(w, http.StatusBadRequest, "invalid request_id")
		return auth.User{}, "", false
	}

	return user, requestID, true
}

func adminUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.AdministratorRoleCode {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumAdminServiceRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
