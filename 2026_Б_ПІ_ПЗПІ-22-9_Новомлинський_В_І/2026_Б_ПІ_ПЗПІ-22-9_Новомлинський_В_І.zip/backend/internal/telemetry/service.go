package telemetry

import (
	"context"
	"errors"
	"strconv"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

const (
	DefaultLimit = 50
	MaxLimit     = 200
)

var (
	ErrInvalidVehicleID = errors.New("invalid vehicle ID")
	ErrInvalidLimit     = errors.New("invalid telemetry limit")
)

type Service interface {
	ListByVehicle(ctx context.Context, vehicleID string, limit int) ([]Record, error)
	LatestByVehicle(ctx context.Context, vehicleID string) (Record, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) ListByVehicle(
	ctx context.Context,
	vehicleID string,
	limit int,
) ([]Record, error) {
	if !identifier.IsUUID(vehicleID) {
		return nil, ErrInvalidVehicleID
	}
	if limit < 1 || limit > MaxLimit {
		return nil, ErrInvalidLimit
	}

	return s.repository.ListByVehicle(ctx, vehicleID, limit)
}

func (s *service) LatestByVehicle(
	ctx context.Context,
	vehicleID string,
) (Record, error) {
	if !identifier.IsUUID(vehicleID) {
		return Record{}, ErrInvalidVehicleID
	}

	return s.repository.LatestByVehicle(ctx, vehicleID)
}

func ParseLimit(raw string) (int, error) {
	if raw == "" {
		return DefaultLimit, nil
	}

	limit, err := strconv.Atoi(raw)
	if err != nil || limit < 1 || limit > MaxLimit {
		return 0, ErrInvalidLimit
	}

	return limit, nil
}
