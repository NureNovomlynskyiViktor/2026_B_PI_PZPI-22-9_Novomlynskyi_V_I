package auditlog

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"
)

func TestPostgresWriterWritesParameterizedAuditLog(t *testing.T) {
	executor := &fakeExecutor{}
	writer := NewPostgresWriter()

	err := writer.Write(context.Background(), executor, Entry{
		ActorID:    "11111111-1111-1111-1111-111111111111",
		Action:     "user.deactivated",
		EntityType: "user",
		EntityID:   "22222222-2222-2222-2222-222222222222",
		Metadata: map[string]any{
			"reason": "Administrative decision",
		},
	})
	if err != nil {
		t.Fatalf("Write returned error: %v", err)
	}
	if !strings.Contains(executor.query, "INSERT INTO audit_logs") {
		t.Fatalf("expected audit insert query, got %q", executor.query)
	}
	if len(executor.args) != 5 {
		t.Fatalf("expected 5 query arguments, got %d", len(executor.args))
	}
	if string(executor.args[4].([]byte)) != `{"reason":"Administrative decision"}` {
		t.Fatalf("unexpected metadata payload: %s", executor.args[4])
	}
}

func TestPostgresWriterWrapsInsertAndMetadataErrors(t *testing.T) {
	expected := errors.New("database unavailable")
	writer := NewPostgresWriter()

	err := writer.Write(context.Background(), &fakeExecutor{err: expected}, Entry{
		ActorID:    "11111111-1111-1111-1111-111111111111",
		Action:     "user.deactivated",
		EntityType: "user",
		EntityID:   "22222222-2222-2222-2222-222222222222",
		Metadata:   map[string]any{},
	})
	if !errors.Is(err, ErrWriteFailed) {
		t.Fatalf("expected ErrWriteFailed for insert error, got %v", err)
	}

	err = writer.Write(context.Background(), &fakeExecutor{}, Entry{
		ActorID:    "11111111-1111-1111-1111-111111111111",
		Action:     "user.deactivated",
		EntityType: "user",
		EntityID:   "22222222-2222-2222-2222-222222222222",
		Metadata:   map[string]any{"bad": make(chan struct{})},
	})
	if !errors.Is(err, ErrWriteFailed) {
		t.Fatalf("expected ErrWriteFailed for metadata error, got %v", err)
	}
}

type fakeExecutor struct {
	query string
	args  []any
	err   error
}

func (e *fakeExecutor) ExecContext(
	_ context.Context,
	query string,
	args ...any,
) (sql.Result, error) {
	e.query = query
	e.args = args
	return fakeResult{}, e.err
}

type fakeResult struct{}

func (fakeResult) LastInsertId() (int64, error) {
	return 0, nil
}

func (fakeResult) RowsAffected() (int64, error) {
	return 1, nil
}
