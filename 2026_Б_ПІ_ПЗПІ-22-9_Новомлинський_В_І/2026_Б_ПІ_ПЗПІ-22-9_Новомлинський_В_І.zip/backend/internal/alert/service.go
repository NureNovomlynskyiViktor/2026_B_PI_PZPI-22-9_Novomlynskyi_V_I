package alert

import (
	"context"
	"errors"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

const (
	DefaultLimit = 50
	MaxLimit     = 200

	StatusAll      = "all"
	StatusActive   = "active"
	StatusCleared  = "cleared"
	StatusResolved = "resolved"
)

var (
	ErrInvalidVehicleID                = errors.New("invalid vehicle ID")
	ErrInvalidAlertID                  = errors.New("invalid alert ID")
	ErrInvalidLimit                    = errors.New("invalid alert limit")
	ErrInvalidStatus                   = errors.New("invalid alert status")
	ErrActiveNotResolved               = errors.New("active alert cannot be manually resolved")
	ErrInvalidResolutionNote           = errors.New("invalid alert resolution note")
	ErrInvalidResolutionServiceRequest = errors.New("invalid alert resolution service request")
)

type Service interface {
	ListByVehicle(ctx context.Context, vehicleID string, limit int) ([]Alert, error)
	ListByVehicleStatus(ctx context.Context, vehicleID string, status string, limit int) ([]Alert, error)
	ListActiveByVehicle(ctx context.Context, vehicleID string) ([]Alert, error)
	GetByID(ctx context.Context, id string) (Alert, error)
	ResolveBySpecialist(ctx context.Context, request SpecialistResolution) (Alert, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) ListByVehicle(
	ctx context.Context,
	vehicleID string,
	limit int,
) ([]Alert, error) {
	if !identifier.IsUUID(vehicleID) {
		return nil, ErrInvalidVehicleID
	}
	if limit < 1 || limit > MaxLimit {
		return nil, ErrInvalidLimit
	}

	return s.repository.ListByVehicle(ctx, vehicleID, limit)
}

func (s *service) ListByVehicleStatus(
	ctx context.Context,
	vehicleID string,
	status string,
	limit int,
) ([]Alert, error) {
	if !identifier.IsUUID(vehicleID) {
		return nil, ErrInvalidVehicleID
	}
	if !IsValidStatusFilter(status) {
		return nil, ErrInvalidStatus
	}
	if limit < 1 || limit > MaxLimit {
		return nil, ErrInvalidLimit
	}
	if status == StatusAll {
		return s.repository.ListByVehicle(ctx, vehicleID, limit)
	}

	return s.repository.ListByVehicleStatus(ctx, vehicleID, status, limit)
}

func (s *service) ListActiveByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Alert, error) {
	if !identifier.IsUUID(vehicleID) {
		return nil, ErrInvalidVehicleID
	}

	return s.repository.ListActiveByVehicle(ctx, vehicleID)
}

func (s *service) GetByID(ctx context.Context, id string) (Alert, error) {
	if !identifier.IsUUID(id) {
		return Alert{}, ErrInvalidAlertID
	}

	return s.repository.GetByID(ctx, id)
}

func (s *service) ResolveBySpecialist(
	ctx context.Context,
	request SpecialistResolution,
) (Alert, error) {
	request.AlertID = strings.TrimSpace(request.AlertID)
	request.SpecialistID = strings.TrimSpace(request.SpecialistID)
	request.ResolutionNote = strings.TrimSpace(request.ResolutionNote)
	request.ServiceRequestID = normalizeOptionalUUID(request.ServiceRequestID)

	if !identifier.IsUUID(request.AlertID) || !identifier.IsUUID(request.SpecialistID) {
		return Alert{}, ErrInvalidAlertID
	}
	if runeCount := utf8.RuneCountInString(request.ResolutionNote); runeCount < 10 || runeCount > 2000 {
		return Alert{}, ErrInvalidResolutionNote
	}
	if request.ServiceRequestID != nil && !identifier.IsUUID(*request.ServiceRequestID) {
		return Alert{}, ErrInvalidResolutionServiceRequest
	}

	return s.repository.ResolveBySpecialist(ctx, request)
}

func ParseLimit(raw string) (int, error) {
	if raw == "" {
		return DefaultLimit, nil
	}

	limit, err := strconv.Atoi(raw)
	if err != nil || limit < 1 || limit > MaxLimit {
		return 0, ErrInvalidLimit
	}

	return limit, nil
}

func ParseStatus(raw string) (string, error) {
	if raw == "" {
		return StatusAll, nil
	}
	if !IsValidStatusFilter(raw) {
		return "", ErrInvalidStatus
	}

	return raw, nil
}

func IsValidStatusFilter(status string) bool {
	switch status {
	case StatusAll, StatusActive, StatusCleared, StatusResolved:
		return true
	default:
		return false
	}
}

func normalizeOptionalUUID(value *string) *string {
	if value == nil {
		return nil
	}
	trimmed := strings.TrimSpace(*value)
	if trimmed == "" {
		return nil
	}

	return &trimmed
}
