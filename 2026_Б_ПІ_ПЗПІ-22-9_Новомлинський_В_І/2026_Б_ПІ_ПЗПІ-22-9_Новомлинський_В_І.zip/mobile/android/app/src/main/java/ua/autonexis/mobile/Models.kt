package ua.autonexis.mobile

data class User(
    val id: String,
    val email: String,
    val role: String,
    val fullName: String,
)

data class AuthResult(
    val user: User,
    val accessToken: String,
)

data class AuthMethods(
    val passwordEnabled: Boolean,
    val googleLinked: Boolean,
)

data class Vehicle(
    val id: String,
    val brand: String,
    val model: String,
    val year: Int?,
    val licensePlate: String?,
)

data class Device(
    val id: String,
    val deviceUid: String,
    val name: String?,
    val status: String,
    val lastSeenAt: String?,
)

data class TelemetryRecord(
    val measuredAt: String,
    val engineTemperature: Double,
    val batteryVoltage: Double,
    val vibrationLevel: Double,
    val rpm: Int,
    val speed: Int,
    val fuelLevel: Double,
)

data class Alert(
    val id: String,
    val type: String,
    val severity: String,
    val currentSeverity: String?,
    val status: String,
    val occurrenceCount: Int,
    val recoveryStreak: Int,
    val lastTriggeredAt: String?,
    val message: String,
    val recommendation: String?,
    val createdAt: String,
    val clearedAt: String?,
    val resolvedAt: String?,
    val resolvedByUserId: String? = null,
    val resolutionNote: String? = null,
    val resolutionServiceRequestId: String? = null,
)

data class ThresholdRule(
    val metric: String,
    val severity: String,
    val value: Double,
    val unit: String,
    val description: String,
)

data class MaintenanceRecord(
    val id: String,
    val title: String,
    val description: String,
    val serviceDate: String,
    val createdAt: String,
)

data class ServiceRequest(
    val id: String,
    val vehicleId: String,
    val ownerId: String,
    val sourceAlertId: String?,
    val assignedSpecialistId: String?,
    val assignedBy: String?,
    val title: String,
    val description: String,
    val priority: String,
    val status: String,
    val resultSummary: String?,
    val createdAt: String,
    val updatedAt: String,
    val assignedAt: String?,
    val startedAt: String?,
    val completedAt: String?,
    val cancelledAt: String?,
)

data class ServiceRequestDraft(
    val title: String,
    val description: String,
    val priority: String,
    val sourceAlertId: String? = null,
)

data class OwnerNotification(
    val id: String,
    val alertId: String?,
    val serviceRequestId: String?,
    val notificationType: String,
    val title: String,
    val message: String,
    val isRead: Boolean,
    val createdAt: String,
)

data class VehicleStatus(
    val vehicle: Vehicle,
    val device: Device?,
    val latestTelemetry: TelemetryRecord?,
    val activeAlerts: List<Alert>,
    val overallStatus: String,
)
