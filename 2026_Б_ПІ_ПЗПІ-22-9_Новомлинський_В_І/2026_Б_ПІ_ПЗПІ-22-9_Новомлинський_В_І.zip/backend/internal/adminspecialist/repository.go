package adminspecialist

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auditlog"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

var (
	ErrDuplicateEmail     = errors.New("email already exists")
	ErrAuditInsertFailed  = auditlog.ErrWriteFailed
	ErrSpecialistRoleMiss = errors.New("technical specialist role not found")
)

type PostgresRepository struct {
	db     *sql.DB
	audits auditlog.Writer
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{
		db:     db,
		audits: auditlog.NewPostgresWriter(),
	}
}

func (r *PostgresRepository) Create(
	ctx context.Context,
	input CreateInput,
) (CreateResult, error) {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return CreateResult{}, fmt.Errorf("begin specialist creation transaction: %w", err)
	}
	defer tx.Rollback()

	roleID, err := technicalSpecialistRoleID(ctx, tx)
	if err != nil {
		return CreateResult{}, err
	}

	user, err := insertSpecialistUser(ctx, tx, roleID, input)
	if err != nil {
		return CreateResult{}, err
	}

	competencies, err := insertCompetencies(ctx, tx, user.ID, input.Competencies)
	if err != nil {
		return CreateResult{}, err
	}

	if err := r.writeAudit(ctx, tx, input.ActorID, user, input.Competencies); err != nil {
		return CreateResult{}, err
	}

	if err := tx.Commit(); err != nil {
		return CreateResult{}, fmt.Errorf("commit specialist creation transaction: %w", err)
	}

	return CreateResult{User: user, Competencies: competencies}, nil
}

func technicalSpecialistRoleID(ctx context.Context, tx *sql.Tx) (string, error) {
	const query = `
		SELECT id
		FROM roles
		WHERE code = $1
	`

	var roleID string
	if err := tx.QueryRowContext(ctx, query, auth.TechnicalSpecialistRoleCode).Scan(&roleID); errors.Is(err, sql.ErrNoRows) {
		return "", ErrSpecialistRoleMiss
	} else if err != nil {
		return "", fmt.Errorf("query technical specialist role: %w", err)
	}

	return roleID, nil
}

func insertSpecialistUser(
	ctx context.Context,
	tx *sql.Tx,
	roleID string,
	input CreateInput,
) (auth.User, error) {
	const query = `
		INSERT INTO users (
			role_id,
			email,
			password_hash,
			full_name
		)
		VALUES ($1, $2, $3, $4)
		RETURNING
			id,
			role_id,
			$5::varchar,
			email,
			full_name,
			is_active,
			created_at,
			updated_at
	`

	user, err := scanUser(tx.QueryRowContext(
		ctx,
		query,
		roleID,
		input.Email,
		input.PasswordHash,
		input.FullName,
		auth.TechnicalSpecialistRoleCode,
	))
	if err != nil {
		if isUniqueEmailError(err) {
			return auth.User{}, ErrDuplicateEmail
		}
		return auth.User{}, fmt.Errorf("insert technical specialist user: %w", err)
	}

	return user, nil
}

func insertCompetencies(
	ctx context.Context,
	tx *sql.Tx,
	specialistID string,
	competencies []specialistcompetency.SupportedCompetency,
) ([]specialistcompetency.Competency, error) {
	items := make([]specialistcompetency.Competency, 0, len(competencies))
	for _, competency := range competencies {
		const query = `
			INSERT INTO specialist_competencies (specialist_id, code, name)
			VALUES ($1, $2, $3)
			RETURNING id, specialist_id, code, name, created_at
		`

		var item specialistcompetency.Competency
		if err := tx.QueryRowContext(
			ctx,
			query,
			specialistID,
			competency.Code,
			competency.Name,
		).Scan(
			&item.ID,
			&item.SpecialistID,
			&item.Code,
			&item.Name,
			&item.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("insert initial specialist competency: %w", err)
		}
		items = append(items, item)
	}

	return items, nil
}

func (r *PostgresRepository) writeAudit(
	ctx context.Context,
	tx *sql.Tx,
	actorID string,
	user auth.User,
	competencies []specialistcompetency.SupportedCompetency,
) error {
	writer := r.audits
	if writer == nil {
		writer = auditlog.NewPostgresWriter()
	}
	if err := writer.Write(ctx, tx, technicalSpecialistCreatedAuditEntry(actorID, user, competencies)); err != nil {
		return fmt.Errorf("write specialist creation audit: %w", err)
	}

	return nil
}

func technicalSpecialistCreatedAuditEntry(
	actorID string,
	user auth.User,
	competencies []specialistcompetency.SupportedCompetency,
) auditlog.Entry {
	codes := make([]string, 0, len(competencies))
	for _, competency := range competencies {
		codes = append(codes, competency.Code)
	}

	return auditlog.Entry{
		ActorID:    actorID,
		Action:     ActionTechnicalSpecialistCreated,
		EntityType: EntityTypeUser,
		EntityID:   user.ID,
		Metadata: map[string]any{
			"created_user_id":    user.ID,
			"email":              user.Email,
			"role":               user.Role,
			"competencies_count": len(codes),
			"competencies":       codes,
		},
	}
}

type scanner interface {
	Scan(dest ...any) error
}

func scanUser(row scanner) (auth.User, error) {
	var user auth.User
	if err := row.Scan(
		&user.ID,
		&user.RoleID,
		&user.Role,
		&user.Email,
		&user.FullName,
		&user.IsActive,
		&user.CreatedAt,
		&user.UpdatedAt,
	); err != nil {
		return auth.User{}, err
	}

	return user, nil
}

func isUniqueEmailError(err error) bool {
	message := err.Error()
	return strings.Contains(message, "users_email_key") ||
		strings.Contains(message, "duplicate key")
}
