package ownermaintenance

import (
	"context"
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/maintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type MaintenanceService interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]maintenance.Record, error)
}

type VehicleService interface {
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
}

type Handler struct {
	maintenance MaintenanceService
	vehicles    VehicleService
	logger      *slog.Logger
}

func NewHandler(
	maintenanceService MaintenanceService,
	vehicles VehicleService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		maintenance: maintenanceService,
		vehicles:    vehicles,
		logger:      logger,
	}
}

func (h *Handler) ListByVehicle(w http.ResponseWriter, r *http.Request) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}

	if _, err := h.vehicles.GetByIDForOwner(r.Context(), user.ID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return
		}
		h.logger.Error(
			"failed to verify owner vehicle for maintenance records",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	records, err := h.maintenance.ListByVehicle(r.Context(), vehicleID)
	if err != nil {
		h.logger.Error(
			"failed to list owner maintenance records",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, records)
}
