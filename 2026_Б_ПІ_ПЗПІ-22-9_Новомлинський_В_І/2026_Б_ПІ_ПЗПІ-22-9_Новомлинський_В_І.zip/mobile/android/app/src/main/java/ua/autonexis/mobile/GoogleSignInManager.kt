package ua.autonexis.mobile

import android.app.Activity
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

open class GoogleSignInException(message: String) : Exception(message)

class MissingGoogleClientIdException : GoogleSignInException(
    "Google sign-in is not configured.",
)

class GoogleSignInCancelledException : GoogleSignInException(
    "Google sign-in was cancelled.",
)

class NoGoogleCredentialAvailableException : GoogleSignInException(
    "No Google account is available. Add an account to the device or use email and password.",
)

class InvalidGoogleCredentialException : GoogleSignInException(
    "Google did not return a valid sign-in credential. Please try again.",
)

class GoogleCredentialUnavailableException : GoogleSignInException(
    "Google sign-in is temporarily unavailable. You can still use email and password.",
)

class GoogleSignInManager(activity: Activity) {
    private val credentialManager = CredentialManager.create(activity)

    suspend fun signIn(activity: Activity, serverClientId: String): String {
        val normalizedClientId = normalizeGoogleWebClientId(serverClientId)
        val googleOption = GetSignInWithGoogleOption.Builder(
            serverClientId = normalizedClientId,
        ).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption)
            .build()

        val response = try {
            credentialManager.getCredential(
                context = activity,
                request = request,
            )
        } catch (_: GetCredentialCancellationException) {
            throw GoogleSignInCancelledException()
        } catch (_: NoCredentialException) {
            throw NoGoogleCredentialAvailableException()
        } catch (_: GetCredentialException) {
            throw GoogleCredentialUnavailableException()
        }

        val credential = response.credential as? CustomCredential
            ?: throw InvalidGoogleCredentialException()

        return extractGoogleIdToken(credential.type) {
            GoogleIdTokenCredential.createFrom(credential.data).idToken
        }
    }

    suspend fun clearCredentialState() {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
    }
}

internal fun normalizeGoogleWebClientId(value: String): String {
    val normalized = value.trim()
    if (normalized.isBlank()) {
        throw MissingGoogleClientIdException()
    }
    return normalized
}

internal fun extractGoogleIdToken(
    credentialType: String,
    parseToken: () -> String,
): String {
    if (credentialType != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        throw InvalidGoogleCredentialException()
    }

    val idToken = try {
        parseToken().trim()
    } catch (_: Exception) {
        throw InvalidGoogleCredentialException()
    }

    if (idToken.isBlank()) {
        throw InvalidGoogleCredentialException()
    }
    return idToken
}