package auth

import (
	"context"
	"errors"
	"net/mail"
	"strings"
	"unicode"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var (
	ErrInvalidInput               = errors.New("invalid auth input")
	ErrInvalidCredentials         = errors.New("invalid credentials")
	ErrUnauthorized               = errors.New("unauthorized")
	ErrInactiveUser               = errors.New("inactive user")
	ErrGoogleAuthUnavailable      = errors.New("google auth unavailable")
	ErrGoogleEmailRequiresLinking = errors.New("google email requires explicit linking")
	ErrGoogleEmailMismatch        = errors.New("google email mismatch")
)

type Service interface {
	Register(ctx context.Context, request RegisterRequest) (AuthResponse, error)
	Login(ctx context.Context, request LoginRequest) (AuthResponse, error)
	GoogleLogin(ctx context.Context, request GoogleLoginRequest) (AuthResponse, error)
	AuthMethods(ctx context.Context, user User) (AuthMethodStatus, error)
	LinkGoogle(ctx context.Context, user User, request GoogleLinkRequest) (AuthMethodStatus, error)
	CurrentUser(ctx context.Context, token string) (User, error)
}

type service struct {
	repository     Repository
	hasher         PasswordHasher
	tokens         TokenManager
	googleEnabled  bool
	googleVerifier GoogleTokenVerifier
}

func NewService(
	repository Repository,
	hasher PasswordHasher,
	tokens TokenManager,
) Service {
	return &service{
		repository: repository,
		hasher:     hasher,
		tokens:     tokens,
	}
}

func NewServiceWithGoogle(
	repository Repository,
	hasher PasswordHasher,
	tokens TokenManager,
	googleVerifier GoogleTokenVerifier,
	googleEnabled bool,
) Service {
	return &service{
		repository:     repository,
		hasher:         hasher,
		tokens:         tokens,
		googleVerifier: googleVerifier,
		googleEnabled:  googleEnabled,
	}
}

func (s *service) Register(
	ctx context.Context,
	request RegisterRequest,
) (AuthResponse, error) {
	email := NormalizeEmail(request.Email)
	fullName := normalizeFullName(request)
	if !IsEmail(email) || fullName == "" || !IsStrongPassword(request.Password) {
		return AuthResponse{}, ErrInvalidInput
	}

	role, err := s.repository.GetRoleByCode(ctx, DefaultRoleCode)
	if err != nil {
		return AuthResponse{}, err
	}

	passwordHash, err := s.hasher.Hash(request.Password)
	if err != nil {
		return AuthResponse{}, err
	}

	user, err := s.repository.CreateUser(ctx, role.ID, email, passwordHash, fullName)
	if err != nil {
		return AuthResponse{}, err
	}

	return s.authResponse(user)
}

func (s *service) Login(
	ctx context.Context,
	request LoginRequest,
) (AuthResponse, error) {
	email := NormalizeEmail(request.Email)
	if !IsEmail(email) || request.Password == "" {
		return AuthResponse{}, ErrInvalidCredentials
	}

	user, err := s.repository.GetUserByEmail(ctx, email)
	if errors.Is(err, ErrUserNotFound) {
		return AuthResponse{}, ErrInvalidCredentials
	}
	if err != nil {
		return AuthResponse{}, err
	}
	if !user.IsActive || user.PasswordHash == nil {
		return AuthResponse{}, ErrInvalidCredentials
	}
	if !s.hasher.Verify(*user.PasswordHash, request.Password) {
		return AuthResponse{}, ErrInvalidCredentials
	}

	return s.authResponse(user.User)
}

func (s *service) GoogleLogin(
	ctx context.Context,
	request GoogleLoginRequest,
) (AuthResponse, error) {
	idToken := strings.TrimSpace(request.IDToken)
	if idToken == "" {
		return AuthResponse{}, ErrInvalidInput
	}
	if !s.googleEnabled || s.googleVerifier == nil {
		return AuthResponse{}, ErrGoogleAuthUnavailable
	}

	identity, err := s.googleVerifier.Verify(ctx, idToken)
	if errors.Is(err, ErrInvalidGoogleToken) {
		return AuthResponse{}, ErrInvalidGoogleToken
	}
	if err != nil {
		return AuthResponse{}, err
	}

	identity.Subject = strings.TrimSpace(identity.Subject)
	identity.Email = NormalizeEmail(identity.Email)
	identity.FullName = strings.TrimSpace(identity.FullName)
	if identity.Subject == "" || !identity.EmailVerified || !IsEmail(identity.Email) {
		return AuthResponse{}, ErrInvalidGoogleToken
	}

	linkedUser, err := s.repository.GetUserByOAuthAccount(ctx, GoogleProvider, identity.Subject)
	if err == nil {
		if !linkedUser.IsActive {
			return AuthResponse{}, ErrInactiveUser
		}
		return s.authResponse(linkedUser)
	}
	if !errors.Is(err, ErrUserNotFound) {
		return AuthResponse{}, err
	}

	if _, err := s.repository.GetUserByEmail(ctx, identity.Email); err == nil {
		return AuthResponse{}, ErrGoogleEmailRequiresLinking
	} else if !errors.Is(err, ErrUserNotFound) {
		return AuthResponse{}, err
	}

	role, err := s.repository.GetRoleByCode(ctx, DefaultRoleCode)
	if err != nil {
		return AuthResponse{}, err
	}

	user, err := s.repository.CreateOAuthUser(
		ctx,
		role.ID,
		identity.Email,
		googleFullName(identity),
		GoogleProvider,
		identity.Subject,
	)
	if err != nil {
		if errors.Is(err, ErrOAuthAccountAlreadyExists) || errors.Is(err, ErrEmailAlreadyExists) {
			linkedUser, lookupErr := s.repository.GetUserByOAuthAccount(ctx, GoogleProvider, identity.Subject)
			if lookupErr == nil {
				if !linkedUser.IsActive {
					return AuthResponse{}, ErrInactiveUser
				}
				return s.authResponse(linkedUser)
			}
			if errors.Is(err, ErrEmailAlreadyExists) {
				return AuthResponse{}, ErrGoogleEmailRequiresLinking
			}
			return AuthResponse{}, lookupErr
		}
		return AuthResponse{}, err
	}

	return s.authResponse(user)
}

func (s *service) AuthMethods(ctx context.Context, user User) (AuthMethodStatus, error) {
	if strings.TrimSpace(user.ID) == "" {
		return AuthMethodStatus{}, ErrUnauthorized
	}
	if !user.IsActive {
		return AuthMethodStatus{}, ErrInactiveUser
	}

	return s.repository.GetAuthMethodStatus(ctx, user.ID)
}

func (s *service) LinkGoogle(
	ctx context.Context,
	user User,
	request GoogleLinkRequest,
) (AuthMethodStatus, error) {
	if strings.TrimSpace(user.ID) == "" {
		return AuthMethodStatus{}, ErrUnauthorized
	}
	if !user.IsActive {
		return AuthMethodStatus{}, ErrInactiveUser
	}

	idToken := strings.TrimSpace(request.IDToken)
	if idToken == "" {
		return AuthMethodStatus{}, ErrInvalidInput
	}
	if !s.googleEnabled || s.googleVerifier == nil {
		return AuthMethodStatus{}, ErrGoogleAuthUnavailable
	}

	identity, err := s.googleVerifier.Verify(ctx, idToken)
	if errors.Is(err, ErrInvalidGoogleToken) {
		return AuthMethodStatus{}, ErrInvalidGoogleToken
	}
	if err != nil {
		return AuthMethodStatus{}, err
	}

	identity.Subject = strings.TrimSpace(identity.Subject)
	identity.Email = NormalizeEmail(identity.Email)
	if identity.Subject == "" || !identity.EmailVerified || !IsEmail(identity.Email) {
		return AuthMethodStatus{}, ErrInvalidGoogleToken
	}
	if identity.Email != NormalizeEmail(user.Email) {
		return AuthMethodStatus{}, ErrGoogleEmailMismatch
	}

	return s.repository.LinkGoogleAccount(ctx, user.ID, identity.Subject)
}

func (s *service) CurrentUser(ctx context.Context, token string) (User, error) {
	claims, err := s.tokens.Validate(token)
	if err != nil {
		return User{}, ErrUnauthorized
	}
	if !identifier.IsUUID(claims.Subject) {
		return User{}, ErrUnauthorized
	}

	user, err := s.repository.GetUserByID(ctx, claims.Subject)
	if errors.Is(err, ErrUserNotFound) {
		return User{}, ErrUnauthorized
	}
	if err != nil {
		return User{}, err
	}
	if !user.IsActive {
		return User{}, ErrUnauthorized
	}

	return user, nil
}

func (s *service) authResponse(user User) (AuthResponse, error) {
	token, expiresAt, err := s.tokens.Generate(user)
	if err != nil {
		return AuthResponse{}, err
	}

	return AuthResponse{
		User:        user,
		AccessToken: token,
		TokenType:   "Bearer",
		ExpiresAt:   expiresAt.Unix(),
	}, nil
}

func NormalizeEmail(email string) string {
	return strings.ToLower(strings.TrimSpace(email))
}

func normalizeFullName(request RegisterRequest) string {
	if strings.TrimSpace(request.FullName) != "" {
		return strings.TrimSpace(request.FullName)
	}

	return strings.TrimSpace(
		strings.TrimSpace(request.FirstName) + " " + strings.TrimSpace(request.LastName),
	)
}

func googleFullName(identity GoogleIdentity) string {
	if strings.TrimSpace(identity.FullName) != "" {
		return strings.TrimSpace(identity.FullName)
	}

	localPart := identity.Email
	if at := strings.Index(localPart, "@"); at >= 0 {
		localPart = localPart[:at]
	}
	localPart = strings.Map(func(r rune) rune {
		switch r {
		case '.', '_', '-', '+':
			return ' '
		default:
			return r
		}
	}, localPart)
	fallback := strings.Join(strings.Fields(localPart), " ")
	if fallback == "" {
		return "Google user"
	}

	return fallback
}

func IsEmail(email string) bool {
	address, err := mail.ParseAddress(email)
	return err == nil && address.Address == email
}

func IsStrongPassword(password string) bool {
	if len(password) < 8 {
		return false
	}

	var hasUpper, hasLower, hasDigit, hasSpecial bool
	for _, character := range password {
		switch {
		case unicode.IsUpper(character):
			hasUpper = true
		case unicode.IsLower(character):
			hasLower = true
		case unicode.IsDigit(character):
			hasDigit = true
		case unicode.IsPunct(character) || unicode.IsSymbol(character):
			hasSpecial = true
		}
	}

	return hasUpper && hasLower && hasDigit && hasSpecial
}
