package vehicleactivation

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"math/big"
	"strings"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	activationCodeTTL = 24 * time.Hour
	codeAlphabet      = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
)

var defaultThresholds = []DefaultThreshold{
	{Parameter: "engine_temperature", WarningValue: 90, CriticalValue: 105, RecoveryMargin: 3, RecoverySamples: 3},
	{Parameter: "battery_voltage", WarningValue: 12.2, CriticalValue: 11.5, RecoveryMargin: 0.2, RecoverySamples: 3},
	{Parameter: "vibration_level", WarningValue: 1.5, CriticalValue: 1.8, RecoveryMargin: 0.2, RecoverySamples: 3},
	{Parameter: "rpm", WarningValue: 2200, CriticalValue: 3500, RecoveryMargin: 200, RecoverySamples: 3},
}

var (
	ErrInvalidInput     = errors.New("invalid vehicle activation input")
	ErrDuplicateVIN     = errors.New("vehicle VIN already exists")
	ErrDuplicateDevice  = errors.New("device UID already exists")
	ErrInvalidCode      = errors.New("invalid activation code")
	ErrExpiredCode      = errors.New("activation code expired")
	ErrAlreadyClaimed   = errors.New("activation code already claimed")
	ErrVehicleClaimed   = errors.New("vehicle already claimed")
	ErrActivationFailed = errors.New("vehicle activation failed")
)

type CodeHasher interface {
	Hash(password string) (string, error)
	Verify(hash string, password string) bool
}

type Repository interface {
	CreateUnclaimed(ctx context.Context, input CreateInput) (CreateResult, error)
	Claim(
		ctx context.Context,
		ownerID string,
		normalizedCode string,
		verify func(hash string) bool,
		now time.Time,
	) (vehicle.Vehicle, error)
}

type Service interface {
	Create(ctx context.Context, admin auth.User, request AdminCreateRequest) (AdminCreateResponse, error)
	Claim(ctx context.Context, owner auth.User, request ClaimRequest) (vehicle.Vehicle, error)
}

type service struct {
	repository Repository
	hasher     CodeHasher
	now        func() time.Time
	generate   func() (string, error)
}

func NewService(repository Repository, hasher CodeHasher) Service {
	return &service{
		repository: repository,
		hasher:     hasher,
		now:        time.Now,
		generate:   generateActivationCode,
	}
}

func (s *service) Create(
	ctx context.Context,
	admin auth.User,
	request AdminCreateRequest,
) (AdminCreateResponse, error) {
	if admin.Role != auth.AdministratorRoleCode {
		return AdminCreateResponse{}, auth.ErrUnauthorized
	}

	normalized := normalizeCreateRequest(request)
	if !isValidCreateRequest(normalized) || !identifier.IsUUID(admin.ID) {
		return AdminCreateResponse{}, ErrInvalidInput
	}

	code, err := s.generate()
	if err != nil {
		return AdminCreateResponse{}, err
	}
	normalizedCode := NormalizeCode(code)
	codeHash, err := s.hasher.Hash(normalizedCode)
	if err != nil {
		return AdminCreateResponse{}, err
	}

	expiresAt := s.now().UTC().Add(activationCodeTTL)
	result, err := s.repository.CreateUnclaimed(
		ctx,
		CreateInput{
			Request:      normalized,
			CreatedBy:    admin.ID,
			CodeHash:     codeHash,
			ExpiresAt:    expiresAt,
			DefaultRules: defaultThresholds,
		},
	)
	if err != nil {
		return AdminCreateResponse{}, err
	}

	return AdminCreateResponse{
		Vehicle:        result.Vehicle,
		Device:         result.Device,
		ActivationCode: normalizedCode,
		ActivationURI:  ActivationURI(normalizedCode),
		ExpiresAt:      result.Activation.ExpiresAt,
	}, nil
}

func (s *service) Claim(
	ctx context.Context,
	owner auth.User,
	request ClaimRequest,
) (vehicle.Vehicle, error) {
	if owner.Role != auth.DefaultRoleCode {
		return vehicle.Vehicle{}, auth.ErrUnauthorized
	}
	if !identifier.IsUUID(owner.ID) {
		return vehicle.Vehicle{}, ErrInvalidInput
	}

	normalizedCode := NormalizeCode(request.ActivationCode)
	if !isValidActivationCode(normalizedCode) {
		return vehicle.Vehicle{}, ErrInvalidCode
	}

	return s.repository.Claim(
		ctx,
		owner.ID,
		normalizedCode,
		func(hash string) bool {
			return s.hasher.Verify(hash, normalizedCode)
		},
		s.now().UTC(),
	)
}

func normalizeCreateRequest(request AdminCreateRequest) AdminCreateRequest {
	return AdminCreateRequest{
		VIN:          strings.TrimSpace(strings.ToUpper(request.VIN)),
		Brand:        strings.TrimSpace(request.Brand),
		Model:        strings.TrimSpace(request.Model),
		Year:         request.Year,
		LicensePlate: strings.TrimSpace(strings.ToUpper(request.LicensePlate)),
		DeviceUID:    strings.TrimSpace(request.DeviceUID),
		DeviceName:   strings.TrimSpace(request.DeviceName),
	}
}

func isValidCreateRequest(request AdminCreateRequest) bool {
	return request.VIN != "" &&
		len(request.VIN) <= 17 &&
		request.Brand != "" &&
		request.Model != "" &&
		request.LicensePlate != "" &&
		request.Year >= 1886 &&
		request.Year <= 2100 &&
		identifier.IsDeviceUID(request.DeviceUID) &&
		request.DeviceName != "" &&
		len(request.DeviceName) <= 128
}

func NormalizeCode(value string) string {
	normalized := strings.ToUpper(strings.TrimSpace(value))
	normalized = strings.ReplaceAll(normalized, " ", "")
	normalized = strings.ReplaceAll(normalized, "-", "")
	if len(normalized) <= 4 {
		return normalized
	}
	return normalized[:4] + "-" + normalized[4:]
}

func ActivationURI(normalizedCode string) string {
	return "autonexis://vehicle-activation?code=" + normalizedCode
}

func isValidActivationCode(value string) bool {
	if len(value) != 9 || value[4] != '-' {
		return false
	}
	for index, character := range value {
		if index == 4 {
			continue
		}
		if !strings.ContainsRune(codeAlphabet, character) {
			return false
		}
	}
	return true
}

func generateActivationCode() (string, error) {
	characters := make([]byte, 8)
	for index := range characters {
		position, err := rand.Int(rand.Reader, big.NewInt(int64(len(codeAlphabet))))
		if err != nil {
			return "", fmt.Errorf("generate activation code: %w", err)
		}
		characters[index] = codeAlphabet[position.Int64()]
	}

	return string(characters[:4]) + "-" + string(characters[4:]), nil
}

var _ CodeHasher = auth.BcryptHasher{}
