package ua.autonexis.mobile

object NotificationPresentation {
    const val TYPE_VEHICLE_ALERT = "vehicle_alert"
    const val TYPE_SERVICE_REQUEST_ASSIGNED = "service_request_assigned"
    const val TYPE_SERVICE_REQUEST_STARTED = "service_request_started"
    const val TYPE_SERVICE_REQUEST_COMPLETED = "service_request_completed"

    fun typeLabel(notificationType: String): String {
        return when (notificationType) {
            TYPE_VEHICLE_ALERT -> "Vehicle alert"
            TYPE_SERVICE_REQUEST_ASSIGNED -> "Service request assigned"
            TYPE_SERVICE_REQUEST_STARTED -> "Service work started"
            TYPE_SERVICE_REQUEST_COMPLETED -> "Service request completed"
            else -> notificationType
                .replace('_', ' ')
                .replaceFirstChar { first -> first.uppercase() }
                .ifBlank { "Notification" }
        }
    }

    fun shouldShowSeverity(notification: OwnerNotification): Boolean {
        return notification.notificationType == TYPE_VEHICLE_ALERT
    }

    fun severityLabel(notification: OwnerNotification): String? {
        if (!shouldShowSeverity(notification)) {
            return null
        }

        val text = "${notification.title} ${notification.message}".uppercase()
        return when {
            "CRITICAL" in text -> "CRITICAL"
            "WARNING" in text -> "WARNING"
            else -> null
        }
    }

    fun canViewServiceRequest(notification: OwnerNotification): Boolean {
        return !notification.serviceRequestId.isNullOrBlank()
    }
}
