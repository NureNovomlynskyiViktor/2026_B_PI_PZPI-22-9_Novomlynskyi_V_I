package ownertelemetry

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
)

type stubTelemetryService struct {
	records       []telemetry.Record
	err           error
	called        bool
	calledVehicle string
	calledLimit   int
}

func (s *stubTelemetryService) ListByVehicle(
	_ context.Context,
	vehicleID string,
	limit int,
) ([]telemetry.Record, error) {
	s.called = true
	s.calledVehicle = vehicleID
	s.calledLimit = limit
	return s.records, s.err
}

type stubVehicleService struct {
	err           error
	called        bool
	calledOwner   string
	calledVehicle string
}

func (s *stubVehicleService) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) (vehicle.Vehicle, error) {
	s.called = true
	s.calledOwner = ownerID
	s.calledVehicle = vehicleID
	if s.err != nil {
		return vehicle.Vehicle{}, s.err
	}
	return vehicle.Vehicle{ID: vehicleID, OwnerID: ownerID}, nil
}

func TestListByVehicleRequiresAuthenticatedUser(t *testing.T) {
	handler := NewHandler(
		&stubTelemetryService{},
		&stubVehicleService{},
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/telemetry",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestListByVehicleRejectsInvalidVehicleID(t *testing.T) {
	handler := NewHandler(
		&stubTelemetryService{},
		&stubVehicleService{},
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
	request := requestWithUser("/api/v1/me/vehicles/not-a-uuid/telemetry")
	request.SetPathValue("vehicle_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListByVehicleReturnsNotFoundForOtherUserVehicle(t *testing.T) {
	telemetryService := &stubTelemetryService{}
	vehicleService := &stubVehicleService{err: vehicle.ErrNotFound}
	handler := NewHandler(
		telemetryService,
		vehicleService,
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
	request := requestWithUser("/api/v1/me/vehicles/" + testVehicleID + "/telemetry")
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
	if telemetryService.called {
		t.Fatal("expected telemetry service not to be called")
	}
}

func TestListByVehicleUsesOwnerAndLimit(t *testing.T) {
	measuredAt := time.Date(2026, 6, 16, 10, 30, 0, 0, time.UTC)
	telemetryService := &stubTelemetryService{
		records: []telemetry.Record{
			{
				ID:                7,
				VehicleID:         testVehicleID,
				MeasuredAt:        measuredAt,
				EngineTemperature: 96.5,
				BatteryVoltage:    13.6,
				VibrationLevel:    2.1,
				RPM:               2600,
				Speed:             72,
				FuelLevel:         63.5,
			},
		},
	}
	vehicleService := &stubVehicleService{}
	handler := NewHandler(
		telemetryService,
		vehicleService,
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
	request := requestWithUser(
		"/api/v1/me/vehicles/" + testVehicleID + "/telemetry?limit=25",
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if vehicleService.calledOwner != testOwnerID {
		t.Fatalf("expected owner %q, got %q", testOwnerID, vehicleService.calledOwner)
	}
	if vehicleService.calledVehicle != testVehicleID {
		t.Fatalf(
			"expected owner check vehicle %q, got %q",
			testVehicleID,
			vehicleService.calledVehicle,
		)
	}
	if telemetryService.calledVehicle != testVehicleID {
		t.Fatalf(
			"expected telemetry vehicle %q, got %q",
			testVehicleID,
			telemetryService.calledVehicle,
		)
	}
	if telemetryService.calledLimit != 25 {
		t.Fatalf("expected limit 25, got %d", telemetryService.calledLimit)
	}
}

func requestWithUser(target string) *http.Request {
	request := httptest.NewRequest(http.MethodGet, target, nil)
	ctx := auth.WithUser(
		request.Context(),
		auth.User{
			ID:    testOwnerID,
			Email: "owner@example.com",
			Role:  "vehicle_owner",
		},
	)
	return request.WithContext(ctx)
}
