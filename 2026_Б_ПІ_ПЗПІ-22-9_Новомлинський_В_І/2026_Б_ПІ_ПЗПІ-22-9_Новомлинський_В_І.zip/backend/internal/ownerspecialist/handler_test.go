package ownerspecialist

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID      = "11111111-1111-1111-1111-111111111111"
	testVehicleID    = "22222222-2222-2222-2222-222222222222"
	testSpecialistID = "33333333-3333-3333-3333-333333333333"
)

type stubAssignmentService struct {
	err error
}

func (s *stubAssignmentService) AssignByEmail(
	context.Context,
	string,
	string,
	string,
) (specialistassignment.Assignment, error) {
	return specialistassignment.Assignment{
		ID:           "44444444-4444-4444-4444-444444444444",
		VehicleID:    testVehicleID,
		SpecialistID: testSpecialistID,
		Specialist: auth.User{
			ID:    testSpecialistID,
			Email: "specialist@example.com",
			Role:  auth.TechnicalSpecialistRoleCode,
		},
	}, s.err
}

func (s *stubAssignmentService) ListByVehicle(
	context.Context,
	string,
) ([]specialistassignment.Assignment, error) {
	return []specialistassignment.Assignment{}, s.err
}

func (s *stubAssignmentService) Remove(context.Context, string, string) error {
	return s.err
}

type stubVehicleService struct {
	err error
}

func (s *stubVehicleService) GetByIDForOwner(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testVehicleID, OwnerID: testOwnerID}, s.err
}

func TestAssignRequiresToken(t *testing.T) {
	handler := NewHandler(
		&stubAssignmentService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/me/vehicles/"+testVehicleID+"/specialists",
		strings.NewReader(`{"email":"specialist@example.com"}`),
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Assign(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestAssignDuplicateReturnsConflict(t *testing.T) {
	handler := NewHandler(
		&stubAssignmentService{err: specialistassignment.ErrDuplicate},
		&stubVehicleService{},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodPost,
		"/api/v1/me/vehicles/"+testVehicleID+"/specialists",
		strings.NewReader(`{"email":"specialist@example.com"}`),
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Assign(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func TestAssignNonSpecialistReturnsBadRequest(t *testing.T) {
	handler := NewHandler(
		&stubAssignmentService{err: specialistassignment.ErrInvalidRole},
		&stubVehicleService{},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodPost,
		"/api/v1/me/vehicles/"+testVehicleID+"/specialists",
		strings.NewReader(`{"email":"owner@example.com"}`),
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.Assign(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestListAnotherUsersVehicleReturnsNotFound(t *testing.T) {
	handler := NewHandler(
		&stubAssignmentService{},
		&stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodGet,
		"/api/v1/me/vehicles/"+testVehicleID+"/specialists",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.List(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestRemoveRejectsInvalidSpecialistID(t *testing.T) {
	handler := NewHandler(
		&stubAssignmentService{},
		&stubVehicleService{},
		testLogger(),
	)
	request := authenticatedRequest(
		http.MethodDelete,
		"/api/v1/me/vehicles/"+testVehicleID+"/specialists/not-a-uuid",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	request.SetPathValue("specialist_id", "not-a-uuid")
	recorder := httptest.NewRecorder()

	handler.Remove(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func authenticatedRequest(method string, target string, body io.Reader) *http.Request {
	request := httptest.NewRequest(method, target, body)
	return request.WithContext(auth.WithUser(
		request.Context(),
		auth.User{ID: testOwnerID, Email: "owner@example.com", Role: auth.DefaultRoleCode},
	))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
