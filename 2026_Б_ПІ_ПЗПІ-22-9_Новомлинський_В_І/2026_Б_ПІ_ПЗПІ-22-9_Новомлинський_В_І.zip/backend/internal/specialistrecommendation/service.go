package specialistrecommendation

import (
	"context"
	"sort"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

const (
	matchScore           = 50
	fallbackScore        = 20
	assignmentPenalty    = 5
	maxAssignmentPenalty = 25
)

type AlertService interface {
	ListActiveByVehicle(ctx context.Context, vehicleID string) ([]alert.Alert, error)
}

type AssignmentService interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]specialistassignment.Assignment, error)
	ListSpecialists(ctx context.Context) ([]auth.User, error)
	CountBySpecialist(ctx context.Context) (map[string]int, error)
}

type CompetencyService interface {
	ListAll(ctx context.Context) ([]specialistcompetency.Competency, error)
}

type Service interface {
	Recommend(ctx context.Context, vehicleID string) ([]Recommendation, error)
}

type service struct {
	alerts       AlertService
	assignments  AssignmentService
	competencies CompetencyService
}

func NewService(
	alerts AlertService,
	assignments AssignmentService,
	competencies CompetencyService,
) Service {
	return &service{
		alerts:       alerts,
		assignments:  assignments,
		competencies: competencies,
	}
}

func (s *service) Recommend(
	ctx context.Context,
	vehicleID string,
) ([]Recommendation, error) {
	if !identifier.IsUUID(vehicleID) {
		return nil, alert.ErrInvalidVehicleID
	}

	activeAlerts, err := s.alerts.ListActiveByVehicle(ctx, vehicleID)
	if err != nil {
		return nil, err
	}

	specialists, err := s.assignments.ListSpecialists(ctx)
	if err != nil {
		return nil, err
	}

	assignments, err := s.assignments.ListByVehicle(ctx, vehicleID)
	if err != nil {
		return nil, err
	}
	assignmentCounts, err := s.assignments.CountBySpecialist(ctx)
	if err != nil {
		return nil, err
	}

	competencies, err := s.competencies.ListAll(ctx)
	if err != nil {
		return nil, err
	}

	assigned := assignedSpecialists(assignments)
	competenciesBySpecialist := groupCompetencies(competencies)
	requiredCompetencies := requiredCompetenciesByAlert(activeAlerts)

	recommendations := make([]Recommendation, 0, len(specialists))
	for _, specialist := range specialists {
		specialistCompetencies := competenciesBySpecialist[specialist.ID]
		score, matched, reasons := scoreSpecialist(
			specialistCompetencies,
			requiredCompetencies,
			len(activeAlerts) == 0,
		)

		count := assignmentCounts[specialist.ID]
		score -= assignmentPenaltyFor(count)
		if score < 0 {
			score = 0
		}

		recommendations = append(recommendations, Recommendation{
			Specialist:            specialist,
			Competencies:          specialistCompetencies,
			Score:                 score,
			MatchedCompetencies:   matched,
			Reasons:               reasons,
			ActiveAssignmentCount: count,
			AlreadyAssigned:       assigned[specialist.ID],
		})
	}

	sort.SliceStable(recommendations, func(i, j int) bool {
		if recommendations[i].Score != recommendations[j].Score {
			return recommendations[i].Score > recommendations[j].Score
		}
		if recommendations[i].ActiveAssignmentCount != recommendations[j].ActiveAssignmentCount {
			return recommendations[i].ActiveAssignmentCount < recommendations[j].ActiveAssignmentCount
		}

		return recommendations[i].Specialist.Email < recommendations[j].Specialist.Email
	})

	return recommendations, nil
}

func assignedSpecialists(assignments []specialistassignment.Assignment) map[string]bool {
	assigned := make(map[string]bool, len(assignments))
	for _, assignment := range assignments {
		assigned[assignment.SpecialistID] = true
	}

	return assigned
}

func groupCompetencies(
	competencies []specialistcompetency.Competency,
) map[string][]specialistcompetency.Competency {
	grouped := make(map[string][]specialistcompetency.Competency)
	for _, competency := range competencies {
		grouped[competency.SpecialistID] = append(grouped[competency.SpecialistID], competency)
	}

	return grouped
}

func requiredCompetenciesByAlert(
	alerts []alert.Alert,
) map[string][]string {
	required := make(map[string][]string)
	for _, item := range alerts {
		code := competencyForAlertType(item.Type)
		required[code] = append(required[code], reasonForAlert(item, code))
	}

	return required
}

func scoreSpecialist(
	competencies []specialistcompetency.Competency,
	required map[string][]string,
	noActiveAlerts bool,
) (int, []string, []string) {
	score := 0
	matched := make([]string, 0)
	reasons := make([]string, 0)

	for _, competency := range competencies {
		alertReasons, ok := required[competency.Code]
		if ok {
			score += matchScore * len(alertReasons)
			matched = append(matched, competency.Code)
			reasons = append(reasons, alertReasons...)
			continue
		}

		if noActiveAlerts && isFallbackCompetency(competency.Code) {
			score += fallbackScore
			matched = append(matched, competency.Code)
			reasons = append(reasons, "Useful general competency when there are no active alerts")
		}
	}

	sort.Strings(matched)

	return score, uniqueStrings(matched), uniqueStrings(reasons)
}

func competencyForAlertType(alertType string) string {
	normalizedType := strings.ToLower(strings.TrimSpace(alertType))

	switch {
	case normalizedType == "engine_temperature",
		normalizedType == "coolant_temperature",
		normalizedType == "rpm":
		return specialistcompetency.CodeEngineDiagnostics
	case normalizedType == "battery_voltage":
		return specialistcompetency.CodeBatteryElectrical
	case normalizedType == "vibration_level":
		return specialistcompetency.CodeVibrationAnalysis
	case normalizedType == "fuel_level":
		return specialistcompetency.CodeFuelSystem
	case strings.Contains(normalizedType, "device"),
		strings.Contains(normalizedType, "offline"),
		strings.Contains(normalizedType, "sensor"):
		return specialistcompetency.CodeIoTDeviceSetup
	default:
		return specialistcompetency.CodeGeneralMaintenance
	}
}

func reasonForAlert(item alert.Alert, code string) string {
	switch code {
	case specialistcompetency.CodeEngineDiagnostics:
		return "Matches active " + readableAlertType(item.Type) + " alert"
	case specialistcompetency.CodeBatteryElectrical:
		return "Matches active battery voltage alert"
	case specialistcompetency.CodeVibrationAnalysis:
		return "Matches active vibration alert"
	case specialistcompetency.CodeFuelSystem:
		return "Matches active fuel level alert"
	case specialistcompetency.CodeIoTDeviceSetup:
		return "Matches active device or sensor alert"
	default:
		return "Matches active general maintenance alert"
	}
}

func readableAlertType(alertType string) string {
	return strings.ReplaceAll(alertType, "_", " ")
}

func isFallbackCompetency(code string) bool {
	return code == specialistcompetency.CodeGeneralMaintenance ||
		code == specialistcompetency.CodeIoTDeviceSetup
}

func assignmentPenaltyFor(count int) int {
	penalty := count * assignmentPenalty
	if penalty > maxAssignmentPenalty {
		return maxAssignmentPenalty
	}

	return penalty
}

func uniqueStrings(values []string) []string {
	seen := make(map[string]struct{}, len(values))
	unique := make([]string, 0, len(values))
	for _, value := range values {
		if _, exists := seen[value]; exists {
			continue
		}
		seen[value] = struct{}{}
		unique = append(unique, value)
	}

	return unique
}
