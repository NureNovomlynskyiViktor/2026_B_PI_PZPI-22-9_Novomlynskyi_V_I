package adminspecialist

import (
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

const maximumAdminSpecialistRequestBodySize = 1 << 20

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{service: service, logger: logger}
}

func (h *Handler) Create(w http.ResponseWriter, r *http.Request) {
	user, ok := adminUser(w, r)
	if !ok {
		return
	}

	var request CreateRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	result, err := h.service.Create(r.Context(), user, request)
	if errors.Is(err, ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid specialist creation request")
		return
	}
	if errors.Is(err, specialistcompetency.ErrInvalidCompetencyCode) {
		response.Error(w, http.StatusBadRequest, "invalid competency code")
		return
	}
	if errors.Is(err, ErrDuplicateEmail) || errors.Is(err, auth.ErrEmailAlreadyExists) {
		response.Error(w, http.StatusConflict, "email already exists")
		return
	}
	if err != nil {
		h.logger.Error("failed to create technical specialist", "user_id", user.ID, "error", err)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, result)
}

func adminUser(w http.ResponseWriter, r *http.Request) (auth.User, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, false
	}
	if user.Role != auth.AdministratorRoleCode {
		response.Error(w, http.StatusForbidden, "administrator role required")
		return auth.User{}, false
	}

	return user, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumAdminSpecialistRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
