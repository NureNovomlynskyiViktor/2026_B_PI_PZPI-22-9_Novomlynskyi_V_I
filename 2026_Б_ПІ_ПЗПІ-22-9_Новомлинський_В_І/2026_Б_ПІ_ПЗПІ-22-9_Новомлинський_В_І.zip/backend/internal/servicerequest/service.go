package servicerequest

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
)

var (
	ErrInvalidInput          = errors.New("invalid service request input")
	ErrInvalidStatus         = errors.New("invalid service request status")
	ErrInvalidTransition     = errors.New("invalid service request status transition")
	ErrSpecialistUnavailable = errors.New("active technical specialist not found")
)

type AssignmentService interface {
	AssignByID(ctx context.Context, vehicleID string, specialistID string, assignedBy string) (specialistassignment.Assignment, error)
	ListSpecialists(ctx context.Context) ([]auth.User, error)
}

type Service interface {
	Create(ctx context.Context, request CreateRequest) (Request, error)
	ListForOwner(ctx context.Context, ownerID string) ([]Request, error)
	GetForOwner(ctx context.Context, ownerID string, requestID string) (Request, error)
	CancelByOwner(ctx context.Context, ownerID string, requestID string) (Request, error)
	ListForAdmin(ctx context.Context, status string) ([]Request, error)
	GetForAdmin(ctx context.Context, requestID string) (Request, error)
	Assign(ctx context.Context, request AssignRequest) (Request, error)
	CancelByAdmin(ctx context.Context, request AdminCancelRequest) (Request, error)
	ListForSpecialist(ctx context.Context, specialistID string) ([]Request, error)
	GetForSpecialist(ctx context.Context, specialistID string, requestID string) (Request, error)
	Start(ctx context.Context, specialistID string, requestID string) (Request, error)
	Complete(ctx context.Context, specialistID string, requestID string, resultSummary string) (Request, error)
}

type service struct {
	repository  Repository
	assignments AssignmentService
}

func NewService(repository Repository, assignments AssignmentService) Service {
	return &service{
		repository:  repository,
		assignments: assignments,
	}
}

func (s *service) Create(ctx context.Context, request CreateRequest) (Request, error) {
	request = normalizeCreateRequest(request)
	if !identifier.IsUUID(request.VehicleID) ||
		!identifier.IsUUID(request.OwnerID) ||
		request.Title == "" ||
		request.Description == "" ||
		!isValidPriority(request.Priority) ||
		(request.SourceAlertID != nil && !identifier.IsUUID(*request.SourceAlertID)) {
		return Request{}, ErrInvalidInput
	}

	return s.repository.Create(ctx, request)
}

func (s *service) ListForOwner(ctx context.Context, ownerID string) ([]Request, error) {
	if !identifier.IsUUID(ownerID) {
		return nil, ErrInvalidInput
	}

	return s.repository.ListForOwner(ctx, ownerID)
}

func (s *service) GetForOwner(
	ctx context.Context,
	ownerID string,
	requestID string,
) (Request, error) {
	if !identifier.IsUUID(ownerID) || !identifier.IsUUID(requestID) {
		return Request{}, ErrNotFound
	}

	return s.repository.GetForOwner(ctx, ownerID, requestID)
}

func (s *service) CancelByOwner(
	ctx context.Context,
	ownerID string,
	requestID string,
) (Request, error) {
	if !identifier.IsUUID(ownerID) || !identifier.IsUUID(requestID) {
		return Request{}, ErrNotFound
	}

	current, err := s.repository.GetForOwner(ctx, ownerID, requestID)
	if err != nil {
		return Request{}, err
	}
	if current.Status != StatusPending {
		return Request{}, ErrInvalidTransition
	}

	return s.repository.CancelByOwner(ctx, ownerID, requestID)
}

func (s *service) ListForAdmin(ctx context.Context, status string) ([]Request, error) {
	status = strings.TrimSpace(status)
	if status != "" && !isValidStatus(status) {
		return nil, ErrInvalidStatus
	}

	return s.repository.ListForAdmin(ctx, status)
}

func (s *service) GetForAdmin(ctx context.Context, requestID string) (Request, error) {
	if !identifier.IsUUID(requestID) {
		return Request{}, ErrNotFound
	}

	return s.repository.GetByID(ctx, requestID)
}

func (s *service) Assign(ctx context.Context, request AssignRequest) (Request, error) {
	if !identifier.IsUUID(request.RequestID) ||
		!identifier.IsUUID(request.SpecialistID) ||
		!identifier.IsUUID(request.AdminID) {
		return Request{}, ErrInvalidInput
	}

	current, err := s.repository.GetByID(ctx, request.RequestID)
	if err != nil {
		return Request{}, err
	}
	if current.Status != StatusPending && current.Status != StatusAssigned {
		return Request{}, ErrInvalidTransition
	}

	if err := s.ensureActiveSpecialist(ctx, request.SpecialistID); err != nil {
		return Request{}, err
	}

	if _, err := s.assignments.AssignByID(
		ctx,
		current.VehicleID,
		request.SpecialistID,
		request.AdminID,
	); err != nil && !errors.Is(err, specialistassignment.ErrDuplicate) {
		if errors.Is(err, specialistassignment.ErrUserNotFound) ||
			errors.Is(err, specialistassignment.ErrInvalidRole) {
			return Request{}, ErrSpecialistUnavailable
		}
		if errors.Is(err, specialistassignment.ErrInvalidInput) {
			return Request{}, ErrInvalidInput
		}
		return Request{}, err
	}

	return s.repository.Assign(
		ctx,
		request.RequestID,
		request.SpecialistID,
		request.AdminID,
	)
}

func (s *service) CancelByAdmin(
	ctx context.Context,
	request AdminCancelRequest,
) (Request, error) {
	if !identifier.IsUUID(request.RequestID) || !identifier.IsUUID(request.AdminID) {
		return Request{}, ErrNotFound
	}

	current, err := s.repository.GetByID(ctx, request.RequestID)
	if err != nil {
		return Request{}, err
	}
	if current.Status != StatusPending && current.Status != StatusAssigned {
		return Request{}, ErrInvalidTransition
	}

	return s.repository.CancelByAdmin(ctx, request.AdminID, request.RequestID)
}

func (s *service) ListForSpecialist(
	ctx context.Context,
	specialistID string,
) ([]Request, error) {
	if !identifier.IsUUID(specialistID) {
		return nil, ErrInvalidInput
	}

	return s.repository.ListForSpecialist(ctx, specialistID)
}

func (s *service) GetForSpecialist(
	ctx context.Context,
	specialistID string,
	requestID string,
) (Request, error) {
	if !identifier.IsUUID(specialistID) || !identifier.IsUUID(requestID) {
		return Request{}, ErrNotFound
	}

	return s.repository.GetForSpecialist(ctx, specialistID, requestID)
}

func (s *service) Start(
	ctx context.Context,
	specialistID string,
	requestID string,
) (Request, error) {
	if !identifier.IsUUID(specialistID) || !identifier.IsUUID(requestID) {
		return Request{}, ErrNotFound
	}

	current, err := s.repository.GetForSpecialist(ctx, specialistID, requestID)
	if err != nil {
		return Request{}, err
	}
	if current.Status != StatusAssigned {
		return Request{}, ErrInvalidTransition
	}

	return s.repository.Start(ctx, specialistID, requestID)
}

func (s *service) Complete(
	ctx context.Context,
	specialistID string,
	requestID string,
	resultSummary string,
) (Request, error) {
	resultSummary = strings.TrimSpace(resultSummary)
	if !identifier.IsUUID(specialistID) ||
		!identifier.IsUUID(requestID) ||
		resultSummary == "" {
		return Request{}, ErrInvalidInput
	}

	current, err := s.repository.GetForSpecialist(ctx, specialistID, requestID)
	if err != nil {
		return Request{}, err
	}
	if current.Status != StatusInProgress {
		return Request{}, ErrInvalidTransition
	}

	return s.repository.Complete(ctx, specialistID, requestID, resultSummary)
}

func (s *service) ensureActiveSpecialist(ctx context.Context, specialistID string) error {
	specialists, err := s.assignments.ListSpecialists(ctx)
	if err != nil {
		return err
	}
	for _, specialist := range specialists {
		if specialist.ID == specialistID &&
			specialist.Role == auth.TechnicalSpecialistRoleCode &&
			specialist.IsActive {
			return nil
		}
	}

	return ErrSpecialistUnavailable
}

func normalizeCreateRequest(request CreateRequest) CreateRequest {
	priority := strings.TrimSpace(request.Priority)
	if priority == "" {
		priority = PriorityNormal
	}

	return CreateRequest{
		VehicleID:     strings.TrimSpace(request.VehicleID),
		OwnerID:       strings.TrimSpace(request.OwnerID),
		Title:         strings.TrimSpace(request.Title),
		Description:   strings.TrimSpace(request.Description),
		Priority:      priority,
		SourceAlertID: normalizeOptionalUUID(request.SourceAlertID),
	}
}

func normalizeOptionalUUID(value *string) *string {
	if value == nil {
		return nil
	}
	trimmed := strings.TrimSpace(*value)
	if trimmed == "" {
		return nil
	}

	return &trimmed
}

func isValidPriority(priority string) bool {
	return priority == PriorityLow ||
		priority == PriorityNormal ||
		priority == PriorityHigh
}

func isValidStatus(status string) bool {
	return status == StatusPending ||
		status == StatusAssigned ||
		status == StatusInProgress ||
		status == StatusCompleted ||
		status == StatusCancelled
}
