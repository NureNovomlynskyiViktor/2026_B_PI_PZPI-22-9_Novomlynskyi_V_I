package ownerspecialist

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const maximumSpecialistRequestBodySize = 1 << 20

type AssignmentService interface {
	AssignByEmail(ctx context.Context, vehicleID string, email string, assignedBy string) (specialistassignment.Assignment, error)
	ListByVehicle(ctx context.Context, vehicleID string) ([]specialistassignment.Assignment, error)
	Remove(ctx context.Context, vehicleID string, specialistID string) error
}

type VehicleService interface {
	GetByIDForOwner(ctx context.Context, ownerID string, vehicleID string) (vehicle.Vehicle, error)
}

type Handler struct {
	assignments AssignmentService
	vehicles    VehicleService
	logger      *slog.Logger
}

func NewHandler(
	assignments AssignmentService,
	vehicles VehicleService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		assignments: assignments,
		vehicles:    vehicles,
		logger:      logger,
	}
}

func (h *Handler) Assign(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.currentOwnerVehicle(w, r)
	if !ok {
		return
	}

	var request specialistassignment.AssignRequest
	if !decodeJSON(w, r, &request) {
		return
	}

	assignment, err := h.assignments.AssignByEmail(
		r.Context(),
		vehicleID,
		request.Email,
		user.ID,
	)
	if errors.Is(err, specialistassignment.ErrInvalidInput) {
		response.Error(w, http.StatusBadRequest, "invalid specialist email")
		return
	}
	if errors.Is(err, specialistassignment.ErrUserNotFound) {
		response.Error(w, http.StatusNotFound, "technical specialist not found")
		return
	}
	if errors.Is(err, specialistassignment.ErrInvalidRole) {
		response.Error(w, http.StatusBadRequest, "user is not a technical specialist")
		return
	}
	if errors.Is(err, specialistassignment.ErrDuplicate) {
		response.Error(w, http.StatusConflict, "specialist already assigned")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to assign specialist",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusCreated, assignment)
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.currentOwnerVehicle(w, r)
	if !ok {
		return
	}

	assignments, err := h.assignments.ListByVehicle(r.Context(), vehicleID)
	if errors.Is(err, specialistassignment.ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list vehicle specialists",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, assignments)
}

func (h *Handler) Remove(w http.ResponseWriter, r *http.Request) {
	user, vehicleID, ok := h.currentOwnerVehicle(w, r)
	if !ok {
		return
	}

	specialistID := r.PathValue("specialist_id")
	if !identifier.IsUUID(specialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist_id")
		return
	}

	err := h.assignments.Remove(r.Context(), vehicleID, specialistID)
	if errors.Is(err, specialistassignment.ErrInvalidVehicleID) ||
		errors.Is(err, specialistassignment.ErrInvalidSpecialistID) {
		response.Error(w, http.StatusBadRequest, "invalid specialist assignment")
		return
	}
	if errors.Is(err, specialistassignment.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "specialist assignment not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to remove specialist assignment",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"specialist_id", specialistID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

func (h *Handler) currentOwnerVehicle(
	w http.ResponseWriter,
	r *http.Request,
) (auth.User, string, bool) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return auth.User{}, "", false
	}

	vehicleID := r.PathValue("vehicle_id")
	if !identifier.IsUUID(vehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return auth.User{}, "", false
	}

	if _, err := h.vehicles.GetByIDForOwner(r.Context(), user.ID, vehicleID); err != nil {
		if errors.Is(err, vehicle.ErrNotFound) {
			response.Error(w, http.StatusNotFound, "vehicle not found")
			return auth.User{}, "", false
		}
		h.logger.Error(
			"failed to verify owner vehicle for specialist assignment",
			"user_id", user.ID,
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return auth.User{}, "", false
	}

	return user, vehicleID, true
}

func decodeJSON(w http.ResponseWriter, r *http.Request, target any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maximumSpecialistRequestBodySize)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}
	if err := decoder.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		response.Error(w, http.StatusBadRequest, "invalid JSON body")
		return false
	}

	return true
}
