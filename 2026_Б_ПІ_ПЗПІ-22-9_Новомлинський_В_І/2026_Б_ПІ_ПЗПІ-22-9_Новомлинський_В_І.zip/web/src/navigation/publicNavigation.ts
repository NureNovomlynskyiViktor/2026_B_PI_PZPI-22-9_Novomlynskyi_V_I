export type PublicPath = '/' | '/login';

export function getCurrentPublicPath(): PublicPath {
  return window.location.pathname === '/login' ? '/login' : '/';
}

export function navigatePublic(path: PublicPath, options: { replace?: boolean } = {}) {
  if (window.location.pathname === path) {
    return;
  }

  if (options.replace) {
    window.history.replaceState({}, '', path);
  } else {
    window.history.pushState({}, '', path);
  }

  window.dispatchEvent(new PopStateEvent('popstate'));
}

export function normalizePublicPath() {
  if (window.location.pathname !== '/' && window.location.pathname !== '/login') {
    window.history.replaceState({}, '', '/');
  }
}