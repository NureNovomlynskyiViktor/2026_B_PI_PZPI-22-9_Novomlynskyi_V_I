package ua.autonexis.mobile.ui.service

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.ServiceRequest
import ua.autonexis.mobile.ServiceRequestDraft

internal enum class ServiceRequestsDestination {
    LIST,
    DETAILS,
    CREATE,
}

internal enum class ServiceRequestFormOrigin {
    VEHICLE_DETAILS,
    LIST,
    DETAILS,
}

internal enum class ServiceRequestDetailsOrigin {
    LIST,
    GLOBAL_LIST,
    NOTIFICATIONS,
}

internal enum class ServiceRequestsMode {
    VEHICLE,
    GLOBAL,
}

internal data class ServiceRequestsUiState(
    val vehicleId: String = "",
    val vehicleLabel: String = "Selected vehicle",
    val mode: ServiceRequestsMode = ServiceRequestsMode.VEHICLE,
    val vehicleLabels: Map<String, String> = emptyMap(),
    val destination: ServiceRequestsDestination = ServiceRequestsDestination.LIST,
    val requests: List<ServiceRequest> = emptyList(),
    val selectedRequestId: String? = null,
    val detailsOrigin: ServiceRequestDetailsOrigin = ServiceRequestDetailsOrigin.LIST,
    val draft: ServiceRequestDraft = ServiceRequestDraft(title = "", description = "", priority = "normal"),
    val formOrigin: ServiceRequestFormOrigin = ServiceRequestFormOrigin.VEHICLE_DETAILS,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val isSubmitting: Boolean = false,
    val cancellingRequestId: String? = null,
    val pendingCancelRequestId: String? = null,
    val message: String? = null,
    val isError: Boolean = false,
)

internal class ServiceRequestsViewModel {
    var uiState by mutableStateOf(ServiceRequestsUiState())
        private set

    fun showInitialLoading(
        vehicleId: String,
        vehicleLabel: String,
        mode: ServiceRequestsMode = ServiceRequestsMode.VEHICLE,
        vehicleLabels: Map<String, String> = uiState.vehicleLabels,
    ) {
        uiState = ServiceRequestsUiState(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            mode = mode,
            vehicleLabels = vehicleLabels,
            isLoading = true,
            message = "Loading service requests...",
        )
    }

    fun showList(
        vehicleId: String = uiState.vehicleId,
        vehicleLabel: String = uiState.vehicleLabel,
        requests: List<ServiceRequest> = uiState.requests,
        mode: ServiceRequestsMode = uiState.mode,
        vehicleLabels: Map<String, String> = uiState.vehicleLabels,
        message: String? = null,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            mode = mode,
            vehicleLabels = vehicleLabels,
            destination = ServiceRequestsDestination.LIST,
            requests = ServiceRequestsPresentation.newestFirst(requests),
            selectedRequestId = null,
            isLoading = false,
            isRefreshing = false,
            isSubmitting = false,
            cancellingRequestId = null,
            pendingCancelRequestId = null,
            message = message,
            isError = isError,
        )
    }

    fun failInitialLoad(
        vehicleId: String,
        vehicleLabel: String,
        message: String,
        mode: ServiceRequestsMode = ServiceRequestsMode.VEHICLE,
        vehicleLabels: Map<String, String> = uiState.vehicleLabels,
    ) {
        uiState = ServiceRequestsUiState(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            mode = mode,
            vehicleLabels = vehicleLabels,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isSubmitting || uiState.cancellingRequestId != null) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing service requests...",
            isError = false,
        )
        return true
    }

    fun finishRefresh(requests: List<ServiceRequest>, message: String? = null) {
        uiState = uiState.copy(
            requests = ServiceRequestsPresentation.newestFirst(requests),
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = false,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = true,
        )
    }

    fun openDetails(requestId: String, origin: ServiceRequestDetailsOrigin = ServiceRequestDetailsOrigin.LIST) {
        uiState = uiState.copy(
            destination = ServiceRequestsDestination.DETAILS,
            selectedRequestId = requestId,
            detailsOrigin = origin,
            message = null,
            isError = false,
        )
    }

    fun openCreate(
        vehicleId: String = uiState.vehicleId,
        vehicleLabel: String = uiState.vehicleLabel,
        draft: ServiceRequestDraft,
        origin: ServiceRequestFormOrigin,
        message: String? = null,
        isError: Boolean = false,
    ) {
        uiState = uiState.copy(
            vehicleId = vehicleId,
            vehicleLabel = vehicleLabel,
            destination = ServiceRequestsDestination.CREATE,
            draft = draft.copy(priority = ServiceRequestsPresentation.normalizedPriority(draft.priority)),
            formOrigin = origin,
            isLoading = false,
            isRefreshing = false,
            isSubmitting = false,
            message = message,
            isError = isError,
        )
    }

    fun backFromCreate(): ServiceRequestFormOrigin {
        val origin = uiState.formOrigin
        uiState = when (origin) {
            ServiceRequestFormOrigin.DETAILS -> uiState.copy(
                destination = ServiceRequestsDestination.DETAILS,
                message = null,
                isError = false,
            )
            ServiceRequestFormOrigin.LIST -> uiState.copy(
                destination = ServiceRequestsDestination.LIST,
                selectedRequestId = null,
                message = null,
                isError = false,
            )
            ServiceRequestFormOrigin.VEHICLE_DETAILS -> uiState.copy(message = null, isError = false)
        }
        return origin
    }

    fun backToList() {
        uiState = uiState.copy(
            destination = ServiceRequestsDestination.LIST,
            selectedRequestId = null,
            message = null,
            isError = false,
        )
    }

    fun updateDraftTitle(value: String) {
        uiState = uiState.copy(draft = uiState.draft.copy(title = value), message = null, isError = false)
    }

    fun updateDraftDescription(value: String) {
        uiState = uiState.copy(draft = uiState.draft.copy(description = value), message = null, isError = false)
    }

    fun updateDraftPriority(value: String) {
        uiState = uiState.copy(
            draft = uiState.draft.copy(priority = ServiceRequestsPresentation.normalizedPriority(value)),
            message = null,
            isError = false,
        )
    }

    fun startCreate(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isSubmitting || uiState.cancellingRequestId != null) {
            return false
        }
        uiState = uiState.copy(
            isSubmitting = true,
            message = "Creating service request...",
            isError = false,
        )
        return true
    }

    fun finishCreate(requests: List<ServiceRequest>, message: String = "Service request created.") {
        uiState = uiState.copy(
            destination = ServiceRequestsDestination.LIST,
            requests = ServiceRequestsPresentation.newestFirst(requests),
            selectedRequestId = null,
            draft = ServiceRequestDraft(title = "", description = "", priority = "normal"),
            formOrigin = ServiceRequestFormOrigin.LIST,
            isSubmitting = false,
            message = message,
            isError = false,
        )
    }

    fun failCreate(message: String) {
        uiState = uiState.copy(
            isSubmitting = false,
            message = message,
            isError = true,
        )
    }

    fun requestCancel(requestId: String) {
        uiState = uiState.copy(pendingCancelRequestId = requestId, message = null, isError = false)
    }

    fun dismissCancel() {
        uiState = uiState.copy(pendingCancelRequestId = null)
    }

    fun startCancel(requestId: String): Boolean {
        if (uiState.isLoading || uiState.isRefreshing || uiState.isSubmitting || uiState.cancellingRequestId != null) {
            return false
        }
        uiState = uiState.copy(
            cancellingRequestId = requestId,
            pendingCancelRequestId = null,
            message = "Cancelling service request...",
            isError = false,
        )
        return true
    }

    fun finishCancel(updatedRequest: ServiceRequest, message: String = "Service request cancelled.") {
        val updatedRequests = uiState.requests.map { request ->
            if (request.id == updatedRequest.id) updatedRequest else request
        }
        uiState = uiState.copy(
            requests = ServiceRequestsPresentation.newestFirst(updatedRequests),
            cancellingRequestId = null,
            message = message,
            isError = false,
        )
    }

    fun failCancel(message: String) {
        uiState = uiState.copy(
            cancellingRequestId = null,
            message = message,
            isError = true,
        )
    }

    fun selectedRequest(): ServiceRequest? {
        val selectedId = uiState.selectedRequestId ?: return null
        return uiState.requests.firstOrNull { it.id == selectedId }
    }
}
