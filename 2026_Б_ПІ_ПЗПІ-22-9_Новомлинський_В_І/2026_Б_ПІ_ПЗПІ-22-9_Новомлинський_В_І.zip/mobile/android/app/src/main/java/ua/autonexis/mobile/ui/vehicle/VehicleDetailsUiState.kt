package ua.autonexis.mobile.ui.vehicle

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ua.autonexis.mobile.Alert
import ua.autonexis.mobile.ServiceRequest
import ua.autonexis.mobile.ThresholdRule
import ua.autonexis.mobile.VehicleStatus

internal enum class VehicleDetailsDestination {
    OVERVIEW,
    RESOLVED_HISTORY,
}

internal data class VehicleDetailsData(
    val status: VehicleStatus,
    val thresholds: List<ThresholdRule>,
    val alerts: List<Alert>,
    val serviceRequests: List<ServiceRequest>,
)

internal data class VehicleDetailsUiState(
    val vehicleId: String = "",
    val data: VehicleDetailsData? = null,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
    val destination: VehicleDetailsDestination = VehicleDetailsDestination.OVERVIEW,
)

internal class VehicleDetailsViewModel {
    var uiState by mutableStateOf(VehicleDetailsUiState())
        private set

    fun showInitialLoading(vehicleId: String, message: String = "Loading vehicle status...") {
        uiState = VehicleDetailsUiState(
            vehicleId = vehicleId,
            isLoading = true,
            message = message,
        )
    }

    fun showDetails(vehicleId: String, data: VehicleDetailsData, message: String? = null) {
        uiState = uiState.copy(
            vehicleId = vehicleId,
            data = data,
            isLoading = false,
            isRefreshing = false,
            message = message,
            isError = false,
        )
    }

    fun startRefresh(): Boolean {
        if (uiState.isLoading || uiState.isRefreshing) {
            return false
        }
        uiState = uiState.copy(
            isRefreshing = true,
            message = "Refreshing status...",
            isError = false,
        )
        return true
    }

    fun failInitialLoad(vehicleId: String, message: String) {
        uiState = VehicleDetailsUiState(
            vehicleId = vehicleId,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun failRefresh(message: String) {
        uiState = uiState.copy(
            isRefreshing = false,
            isLoading = false,
            message = message,
            isError = true,
        )
    }

    fun canNavigate(): Boolean = !uiState.isLoading

    fun showOverview() {
        uiState = uiState.copy(destination = VehicleDetailsDestination.OVERVIEW)
    }

    fun showResolvedHistory() {
        uiState = uiState.copy(destination = VehicleDetailsDestination.RESOLVED_HISTORY)
    }
}