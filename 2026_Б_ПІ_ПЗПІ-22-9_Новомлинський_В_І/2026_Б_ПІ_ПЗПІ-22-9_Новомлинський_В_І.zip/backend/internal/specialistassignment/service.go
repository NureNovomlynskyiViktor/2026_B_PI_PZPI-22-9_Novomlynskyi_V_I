package specialistassignment

import (
	"context"
	"errors"
	"net/mail"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

var (
	ErrInvalidInput        = errors.New("invalid specialist assignment input")
	ErrInvalidVehicleID    = errors.New("invalid vehicle ID")
	ErrInvalidSpecialistID = errors.New("invalid specialist ID")
	ErrForbiddenRole       = errors.New("forbidden role")
)

type Service interface {
	AssignByEmail(ctx context.Context, vehicleID string, email string, assignedBy string) (Assignment, error)
	AssignByID(ctx context.Context, vehicleID string, specialistID string, assignedBy string) (Assignment, error)
	ListByVehicle(ctx context.Context, vehicleID string) ([]Assignment, error)
	ListSpecialists(ctx context.Context) ([]auth.User, error)
	CountBySpecialist(ctx context.Context) (map[string]int, error)
	Remove(ctx context.Context, vehicleID string, specialistID string) error
	ListVehiclesForSpecialist(ctx context.Context, specialistID string) ([]vehicle.Vehicle, error)
	GetAssignedVehicle(ctx context.Context, specialistID string, vehicleID string) (vehicle.Vehicle, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) AssignByEmail(
	ctx context.Context,
	vehicleID string,
	email string,
	assignedBy string,
) (Assignment, error) {
	normalizedEmail := normalizeEmail(email)
	if !identifier.IsUUID(vehicleID) || !identifier.IsUUID(assignedBy) || !isEmail(normalizedEmail) {
		return Assignment{}, ErrInvalidInput
	}

	specialist, err := s.repository.GetUserByEmail(ctx, normalizedEmail)
	if err != nil {
		return Assignment{}, err
	}
	if specialist.Role != auth.TechnicalSpecialistRoleCode {
		return Assignment{}, ErrInvalidRole
	}
	if !specialist.IsActive {
		return Assignment{}, ErrUserNotFound
	}

	return s.repository.Create(ctx, vehicleID, specialist, assignedBy)
}

func (s *service) AssignByID(
	ctx context.Context,
	vehicleID string,
	specialistID string,
	assignedBy string,
) (Assignment, error) {
	if !identifier.IsUUID(vehicleID) ||
		!identifier.IsUUID(specialistID) ||
		!identifier.IsUUID(assignedBy) {
		return Assignment{}, ErrInvalidInput
	}

	specialist, err := s.repository.GetUserByID(ctx, specialistID)
	if err != nil {
		return Assignment{}, err
	}
	if specialist.Role != auth.TechnicalSpecialistRoleCode {
		return Assignment{}, ErrInvalidRole
	}
	if !specialist.IsActive {
		return Assignment{}, ErrUserNotFound
	}

	return s.repository.Create(ctx, vehicleID, specialist, assignedBy)
}

func (s *service) ListByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Assignment, error) {
	if !identifier.IsUUID(vehicleID) {
		return nil, ErrInvalidVehicleID
	}

	return s.repository.ListByVehicle(ctx, vehicleID)
}

func (s *service) ListSpecialists(ctx context.Context) ([]auth.User, error) {
	return s.repository.ListSpecialists(ctx)
}

func (s *service) CountBySpecialist(ctx context.Context) (map[string]int, error) {
	return s.repository.CountBySpecialist(ctx)
}

func (s *service) Remove(
	ctx context.Context,
	vehicleID string,
	specialistID string,
) error {
	if !identifier.IsUUID(vehicleID) {
		return ErrInvalidVehicleID
	}
	if !identifier.IsUUID(specialistID) {
		return ErrInvalidSpecialistID
	}

	return s.repository.Delete(ctx, vehicleID, specialistID)
}

func (s *service) ListVehiclesForSpecialist(
	ctx context.Context,
	specialistID string,
) ([]vehicle.Vehicle, error) {
	if !identifier.IsUUID(specialistID) {
		return nil, ErrInvalidSpecialistID
	}

	return s.repository.ListVehiclesForSpecialist(ctx, specialistID)
}

func (s *service) GetAssignedVehicle(
	ctx context.Context,
	specialistID string,
	vehicleID string,
) (vehicle.Vehicle, error) {
	if !identifier.IsUUID(specialistID) {
		return vehicle.Vehicle{}, ErrInvalidSpecialistID
	}
	if !identifier.IsUUID(vehicleID) {
		return vehicle.Vehicle{}, ErrInvalidVehicleID
	}

	return s.repository.GetAssignedVehicle(ctx, specialistID, vehicleID)
}

func normalizeEmail(email string) string {
	return strings.ToLower(strings.TrimSpace(email))
}

func isEmail(email string) bool {
	address, err := mail.ParseAddress(email)
	return err == nil && address.Address == email
}
