package maintenance

import (
	"context"
	"database/sql"
	"fmt"
)

type Repository interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]Record, error)
	Create(ctx context.Context, request CreateRequest) (Record, error)
}

type PostgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{db: db}
}

func (r *PostgresRepository) ListByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Record, error) {
	const query = `
		SELECT
			id,
			vehicle_id,
			created_by,
			title,
			description,
			service_date,
			created_at
		FROM maintenance_records
		WHERE vehicle_id = $1
		ORDER BY service_date DESC, created_at DESC, id DESC
	`

	rows, err := r.db.QueryContext(ctx, query, vehicleID)
	if err != nil {
		return nil, fmt.Errorf("query maintenance records: %w", err)
	}
	defer rows.Close()

	records := make([]Record, 0)
	for rows.Next() {
		var record Record
		var createdBy sql.NullString
		if err := rows.Scan(
			&record.ID,
			&record.VehicleID,
			&createdBy,
			&record.Title,
			&record.Description,
			&record.ServiceDate,
			&record.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan maintenance record: %w", err)
		}
		if createdBy.Valid {
			value := createdBy.String
			record.CreatedBy = &value
		}
		records = append(records, record)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate maintenance records: %w", err)
	}

	return records, nil
}

func (r *PostgresRepository) Create(
	ctx context.Context,
	request CreateRequest,
) (Record, error) {
	const query = `
		INSERT INTO maintenance_records (
			vehicle_id,
			created_by,
			title,
			description,
			service_date
		)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING
			id,
			vehicle_id,
			created_by,
			title,
			description,
			service_date,
			created_at
	`

	return scanRecord(r.db.QueryRowContext(
		ctx,
		query,
		request.VehicleID,
		request.CreatedBy,
		request.Title,
		request.Description,
		request.ServiceDate,
	))
}

type scanner interface {
	Scan(dest ...any) error
}

func scanRecord(row scanner) (Record, error) {
	var record Record
	var createdBy sql.NullString

	if err := row.Scan(
		&record.ID,
		&record.VehicleID,
		&createdBy,
		&record.Title,
		&record.Description,
		&record.ServiceDate,
		&record.CreatedAt,
	); err != nil {
		return Record{}, err
	}
	if createdBy.Valid {
		value := createdBy.String
		record.CreatedBy = &value
	}

	return record, nil
}
