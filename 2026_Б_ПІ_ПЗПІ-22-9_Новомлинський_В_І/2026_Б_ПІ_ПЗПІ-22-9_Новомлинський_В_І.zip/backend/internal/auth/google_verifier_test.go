package auth

import (
	"context"
	"errors"
	"strings"
	"testing"

	"google.golang.org/api/idtoken"
)

type fakeNetworkError struct {
	message string
}

func (e fakeNetworkError) Error() string { return e.message }
func (e fakeNetworkError) Timeout() bool { return true }
func (e fakeNetworkError) Temporary() bool {
	return true
}

func TestGoogleIDTokenVerifierRejectsBlankToken(t *testing.T) {
	calls := 0
	verifier := newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com"},
		func(context.Context, string, string) (*idtoken.Payload, error) {
			calls++
			return validGooglePayload(), nil
		},
	)

	if _, err := verifier.Verify(context.Background(), " "); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken for blank token, got %v", err)
	}
	if calls != 0 {
		t.Fatalf("expected validator not to be called for blank token, got %d calls", calls)
	}
}

func TestGoogleIDTokenVerifierRejectsMissingClientIDs(t *testing.T) {
	calls := 0
	verifier := newGoogleIDTokenVerifier(
		nil,
		func(context.Context, string, string) (*idtoken.Payload, error) {
			calls++
			return validGooglePayload(), nil
		},
	)

	if _, err := verifier.Verify(context.Background(), "token"); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken for missing audience, got %v", err)
	}
	if calls != 0 {
		t.Fatalf("expected validator not to be called without audiences, got %d calls", calls)
	}
}

func TestGoogleIDTokenVerifierTriesConfiguredAudiencesUntilSuccess(t *testing.T) {
	var audiences []string
	verifier := newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com", "android-client.apps.googleusercontent.com"},
		func(_ context.Context, _ string, audience string) (*idtoken.Payload, error) {
			audiences = append(audiences, audience)
			if audience == "web-client.apps.googleusercontent.com" {
				return nil, errors.New("wrong audience")
			}
			return validGooglePayload(), nil
		},
	)

	identity, err := verifier.Verify(context.Background(), " token ")
	if err != nil {
		t.Fatalf("Verify() returned an error: %v", err)
	}
	if identity.Subject != "google-sub" || identity.Email != "user@example.com" {
		t.Fatalf("unexpected identity: %#v", identity)
	}
	if strings.Join(audiences, ",") != "web-client.apps.googleusercontent.com,android-client.apps.googleusercontent.com" {
		t.Fatalf("unexpected audience attempts: %#v", audiences)
	}
}

func TestGoogleIDTokenVerifierReturnsInvalidWhenAllAudiencesFailValidation(t *testing.T) {
	verifier := newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com", "android-client.apps.googleusercontent.com"},
		func(context.Context, string, string) (*idtoken.Payload, error) {
			return nil, errors.New("invalid token")
		},
	)

	if _, err := verifier.Verify(context.Background(), "token"); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken, got %v", err)
	}
}

func TestGoogleIDTokenVerifierRejectsWrongIssuer(t *testing.T) {
	verifier := verifierWithPayload(func(payload *idtoken.Payload) {
		payload.Issuer = "https://issuer.example.com"
	})

	if _, err := verifier.Verify(context.Background(), "token"); !errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("expected ErrInvalidGoogleToken for wrong issuer, got %v", err)
	}
}

func TestGoogleIDTokenVerifierAcceptsGoogleIssuers(t *testing.T) {
	for _, issuer := range []string{"accounts.google.com", "https://accounts.google.com"} {
		t.Run(issuer, func(t *testing.T) {
			verifier := verifierWithPayload(func(payload *idtoken.Payload) {
				payload.Issuer = issuer
			})

			identity, err := verifier.Verify(context.Background(), "token")
			if err != nil {
				t.Fatalf("Verify() returned an error: %v", err)
			}
			if identity.Subject != "google-sub" {
				t.Fatalf("unexpected identity: %#v", identity)
			}
		})
	}
}

func TestGoogleIDTokenVerifierRejectsInvalidClaims(t *testing.T) {
	tests := []struct {
		name   string
		mutate func(*idtoken.Payload)
	}{
		{
			name: "empty subject",
			mutate: func(payload *idtoken.Payload) {
				payload.Subject = " "
			},
		},
		{
			name: "empty email",
			mutate: func(payload *idtoken.Payload) {
				payload.Claims["email"] = " "
			},
		},
		{
			name: "missing email_verified",
			mutate: func(payload *idtoken.Payload) {
				delete(payload.Claims, "email_verified")
			},
		},
		{
			name: "false email_verified",
			mutate: func(payload *idtoken.Payload) {
				payload.Claims["email_verified"] = false
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			verifier := verifierWithPayload(tc.mutate)

			if _, err := verifier.Verify(context.Background(), "token"); !errors.Is(err, ErrInvalidGoogleToken) {
				t.Fatalf("expected ErrInvalidGoogleToken, got %v", err)
			}
		})
	}
}

func TestGoogleIDTokenVerifierReturnsTrimmedIdentity(t *testing.T) {
	verifier := verifierWithPayload(func(payload *idtoken.Payload) {
		payload.Subject = " google-sub "
		payload.Claims["email"] = " user@example.com "
		payload.Claims["name"] = " New Owner "
	})

	identity, err := verifier.Verify(context.Background(), "token")
	if err != nil {
		t.Fatalf("Verify() returned an error: %v", err)
	}
	if identity.Subject != "google-sub" || identity.Email != "user@example.com" || identity.FullName != "New Owner" || !identity.EmailVerified {
		t.Fatalf("unexpected identity: %#v", identity)
	}
}

func TestGoogleIDTokenVerifierDistinguishesNetworkFailure(t *testing.T) {
	verifier := newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com"},
		func(context.Context, string, string) (*idtoken.Payload, error) {
			return nil, fakeNetworkError{message: "certificate fetch failed"}
		},
	)

	_, err := verifier.Verify(context.Background(), "token")
	if !errors.Is(err, ErrGoogleVerificationUnavailable) {
		t.Fatalf("expected ErrGoogleVerificationUnavailable, got %v", err)
	}
	if errors.Is(err, ErrInvalidGoogleToken) {
		t.Fatalf("network failure must not be classified as invalid token: %v", err)
	}
}

func TestGoogleIDTokenVerifierDoesNotReturnRawIDTokenInErrors(t *testing.T) {
	const rawToken = "raw-secret-id-token"

	invalidVerifier := newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com"},
		func(context.Context, string, string) (*idtoken.Payload, error) {
			return nil, errors.New("invalid token contains " + rawToken)
		},
	)
	_, err := invalidVerifier.Verify(context.Background(), rawToken)
	if err == nil || strings.Contains(err.Error(), rawToken) {
		t.Fatalf("invalid-token error exposed raw token: %v", err)
	}

	unavailableVerifier := newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com"},
		func(context.Context, string, string) (*idtoken.Payload, error) {
			return nil, fakeNetworkError{message: "network error contains " + rawToken}
		},
	)
	_, err = unavailableVerifier.Verify(context.Background(), rawToken)
	if err == nil || strings.Contains(err.Error(), rawToken) {
		t.Fatalf("infrastructure error exposed raw token: %v", err)
	}
}

func verifierWithPayload(mutate func(*idtoken.Payload)) *GoogleIDTokenVerifier {
	return newGoogleIDTokenVerifier(
		[]string{"web-client.apps.googleusercontent.com"},
		func(context.Context, string, string) (*idtoken.Payload, error) {
			payload := validGooglePayload()
			if mutate != nil {
				mutate(payload)
			}
			return payload, nil
		},
	)
}

func validGooglePayload() *idtoken.Payload {
	return &idtoken.Payload{
		Issuer:  "https://accounts.google.com",
		Subject: "google-sub",
		Claims: map[string]interface{}{
			"email":          "user@example.com",
			"name":           "New Owner",
			"email_verified": true,
		},
	}
}
