BEGIN;

DROP TABLE IF EXISTS maintenance_records;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS threshold_settings;
DROP TABLE IF EXISTS telemetry_records;
DROP TABLE IF EXISTS devices;
DROP TABLE IF EXISTS vehicles;
DROP TABLE IF EXISTS oauth_accounts;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;

COMMIT;