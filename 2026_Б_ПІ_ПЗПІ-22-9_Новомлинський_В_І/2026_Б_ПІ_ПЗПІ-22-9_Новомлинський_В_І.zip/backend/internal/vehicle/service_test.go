package vehicle

import (
	"context"
	"testing"
)

const (
	serviceOwnerID   = "11111111-1111-1111-1111-111111111111"
	serviceVehicleID = "22222222-2222-2222-2222-222222222222"
)

type repositoryStub struct {
	capturedOwnerID   string
	capturedVehicleID string
	capturedRequest   CreateRequest
}

func (r *repositoryStub) List(context.Context) ([]Vehicle, error) {
	return []Vehicle{}, nil
}

func (r *repositoryStub) GetByID(context.Context, string) (Vehicle, error) {
	return Vehicle{}, nil
}

func (r *repositoryStub) ListByOwner(_ context.Context, ownerID string) ([]Vehicle, error) {
	r.capturedOwnerID = ownerID
	return []Vehicle{{ID: serviceVehicleID, OwnerID: ownerID}}, nil
}

func (r *repositoryStub) GetByIDForOwner(
	_ context.Context,
	ownerID string,
	vehicleID string,
) (Vehicle, error) {
	r.capturedOwnerID = ownerID
	r.capturedVehicleID = vehicleID
	return Vehicle{ID: vehicleID, OwnerID: ownerID}, nil
}

func (r *repositoryStub) CreateForOwner(
	_ context.Context,
	ownerID string,
	request CreateRequest,
) (Vehicle, error) {
	r.capturedOwnerID = ownerID
	r.capturedRequest = request
	return Vehicle{ID: serviceVehicleID, OwnerID: ownerID, Brand: request.Brand}, nil
}

func TestServiceListByOwnerPassesOwnerID(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	vehicles, err := service.ListByOwner(context.Background(), serviceOwnerID)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if repository.capturedOwnerID != serviceOwnerID {
		t.Fatalf("expected owner %s, got %s", serviceOwnerID, repository.capturedOwnerID)
	}
	if len(vehicles) != 1 || vehicles[0].OwnerID != serviceOwnerID {
		t.Fatalf("expected only owner vehicles, got %+v", vehicles)
	}
}

func TestServiceCreateForOwnerAssignsOwnerID(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	_, err := service.CreateForOwner(context.Background(), serviceOwnerID, CreateRequest{
		VIN:          " TESTVIN0000000001 ",
		Brand:        " Toyota ",
		Model:        " Corolla ",
		Year:         2020,
		LicensePlate: " AA1234BB ",
	})
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if repository.capturedOwnerID != serviceOwnerID {
		t.Fatalf("expected owner %s, got %s", serviceOwnerID, repository.capturedOwnerID)
	}
	if repository.capturedRequest.Brand != "Toyota" {
		t.Fatalf("expected normalized request, got %+v", repository.capturedRequest)
	}
}

func TestServiceCreateForOwnerRejectsInvalidYear(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	_, err := service.CreateForOwner(context.Background(), serviceOwnerID, CreateRequest{
		VIN:          "TESTVIN0000000001",
		Brand:        "Toyota",
		Model:        "Corolla",
		Year:         1800,
		LicensePlate: "AA1234BB",
	})

	if err != ErrInvalidInput {
		t.Fatalf("expected ErrInvalidInput, got %v", err)
	}
	if repository.capturedOwnerID != "" {
		t.Fatal("expected invalid input to be rejected before repository call")
	}
}

func TestServiceGetByIDForOwnerPassesOwnerAndVehicleID(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)

	_, err := service.GetByIDForOwner(
		context.Background(),
		serviceOwnerID,
		serviceVehicleID,
	)
	if err != nil {
		t.Fatalf("expected no error, got %v", err)
	}
	if repository.capturedOwnerID != serviceOwnerID {
		t.Fatalf("expected owner %s, got %s", serviceOwnerID, repository.capturedOwnerID)
	}
	if repository.capturedVehicleID != serviceVehicleID {
		t.Fatalf("expected vehicle %s, got %s", serviceVehicleID, repository.capturedVehicleID)
	}
}
