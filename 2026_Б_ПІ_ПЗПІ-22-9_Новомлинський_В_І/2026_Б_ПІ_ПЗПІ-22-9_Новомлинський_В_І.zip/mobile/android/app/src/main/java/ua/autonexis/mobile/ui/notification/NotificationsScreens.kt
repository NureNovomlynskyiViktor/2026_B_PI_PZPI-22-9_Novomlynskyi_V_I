﻿package ua.autonexis.mobile.ui.notification

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.NotificationPresentation
import ua.autonexis.mobile.OwnerNotification
import ua.autonexis.mobile.R
import ua.autonexis.mobile.ui.UiStringResources
import ua.autonexis.mobile.ui.owner.OwnerNavigationBar
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets

@Composable
internal fun NotificationsRoot(
    state: NotificationsUiState,
    onBackToVehicles: () -> Unit,
    onRequests: () -> Unit,
    onRefresh: () -> Unit,
    onAccount: () -> Unit,
    onRetry: () -> Unit,
    onToggleUnreadOnly: () -> Unit,
    onMarkRead: (String) -> Unit,
    onViewServiceRequest: (String) -> Unit,
) {
    val isBusy = state.isLoading || state.isRefreshing
    BackHandler(onBack = onBackToVehicles)

    Scaffold(
        topBar = {
            NotificationsTopBar(
                isBusy = isBusy,
                onBackToVehicles = onBackToVehicles,
                onRefresh = onRefresh,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = OwnerNavigationTab.NOTIFICATIONS,
                notificationUnreadCount = state.unreadCount,
                onVehicles = onBackToVehicles,
                onRequests = onRequests,
                onNotifications = {},
            onAccount = onAccount,
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.items.isEmpty() -> BrandedLoadingState(
                    message = state.message ?: stringResource(R.string.loading_notifications),
                )
                state.isError && state.items.isEmpty() -> InitialErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_notifications_message),
                    onRetry = onRetry,
                    onBackToVehicles = onBackToVehicles,
                )
                else -> NotificationsContent(
                    state = state,
                    onToggleUnreadOnly = onToggleUnreadOnly,
                    onMarkRead = onMarkRead,
                    onViewServiceRequest = onViewServiceRequest,
                )
            }
        }
    }
}

@Composable
private fun localizedNotificationType(notificationType: String): String {
    return UiStringResources.notificationTypeLabelRes(notificationType)?.let { stringResource(it) }
        ?: NotificationPresentation.typeLabel(notificationType)
}

@Composable
private fun localizedSeverityLabel(severity: String): String {
    return UiStringResources.statusLabelRes(severity.lowercase())?.let { stringResource(it) }
        ?: severity
}

@Composable
private fun NotificationsTopBar(
    isBusy: Boolean,
    onBackToVehicles: () -> Unit,
    onRefresh: () -> Unit,
) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBackToVehicles, enabled = !isBusy) { Text(stringResource(R.string.nav_vehicles)) }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.notifications_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.notifications_subtitle),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            TextButton(onClick = onRefresh, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
        }
    }
}

@Composable
private fun NotificationsContent(
    state: NotificationsUiState,
    onToggleUnreadOnly: () -> Unit,
    onMarkRead: (String) -> Unit,
    onViewServiceRequest: (String) -> Unit,
) {
    val visibleItems = state.visibleItems
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        item {
            SummaryCard(
                unreadCount = state.unreadCount,
                totalCount = state.items.size,
                showUnreadOnly = state.showUnreadOnly,
                onToggleUnreadOnly = onToggleUnreadOnly,
            )
        }
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_notifications)) }
        }
        if (visibleItems.isEmpty()) {
            item { EmptyNotificationsState(state.showUnreadOnly) }
        } else {
            items(visibleItems, key = { it.id }) { notification ->
                NotificationCard(
                    notification = notification,
                    isMarkingRead = notification.id in state.markingReadIds,
                    onMarkRead = onMarkRead,
                    onViewServiceRequest = onViewServiceRequest,
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(
    unreadCount: Int,
    totalCount: Int,
    showUnreadOnly: Boolean,
    onToggleUnreadOnly: () -> Unit,
) {
    InfoCard {
        Text(stringResource(R.string.notification_center), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            text = pluralStringResource(R.plurals.notification_summary_count, unreadCount, unreadCount, totalCount),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(
            onClick = onToggleUnreadOnly,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
        ) {
            Text(if (showUnreadOnly) stringResource(R.string.show_all_notifications) else stringResource(R.string.hide_read_notifications))
        }
    }
}

@Composable
private fun NotificationCard(
    notification: OwnerNotification,
    isMarkingRead: Boolean,
    onMarkRead: (String) -> Unit,
    onViewServiceRequest: (String) -> Unit,
) {
    val isUnread = !notification.isRead
    val borderColor = if (isUnread) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUnread) 2.dp else 1.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(AutonexisSpacing.lg),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        ) {
            Box(
                modifier = Modifier
                    .size(width = 4.dp, height = 64.dp)
                    .background(
                        color = if (isUnread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        shape = RoundedCornerShape(999.dp),
                    ),
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = if (isUnread) stringResource(R.string.unread) else stringResource(R.string.read),
                        color = if (isUnread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelLarge,
                    )
                    Text(
                        text = "- ${localizedNotificationType(notification.notificationType)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    text = notification.title.ifBlank { stringResource(R.string.notification_fallback_title) },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                NotificationPresentation.severityLabel(notification)?.let { severity ->
                    Pill(stringResource(R.string.severity_label, localizedSeverityLabel(severity)), severityTone(severity))
                }
                Text(notification.message)
                Text(
                    text = stringResource(R.string.created_colon_label, NotificationsPresentation.displayTimestamp(notification.createdAt)),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (NotificationPresentation.canViewServiceRequest(notification)) {
                    OutlinedButton(
                        onClick = { onViewServiceRequest(notification.serviceRequestId.orEmpty()) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                    ) {
                        Text(stringResource(R.string.view_service_request))
                    }
                }
                if (isUnread) {
                    Button(
                        onClick = { onMarkRead(notification.id) },
                        enabled = !isMarkingRead,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                    ) {
                        Text(if (isMarkingRead) stringResource(R.string.marking) else stringResource(R.string.mark_as_read))
                    }
                }
            }
        }
    }
}

@Composable
private fun BrandedLoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.autonexis_emblem),
            contentDescription = stringResource(R.string.brand_name),
            modifier = Modifier.size(72.dp),
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InitialErrorState(
    message: String,
    onRetry: () -> Unit,
    onBackToVehicles: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(stringResource(R.string.could_not_load_notifications), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onBackToVehicles) { Text(stringResource(R.string.back_to_vehicles)) }
    }
}

@Composable
private fun EmptyNotificationsState(showUnreadOnly: Boolean) {
    InfoCard {
        Text(
            text = if (showUnreadOnly) stringResource(R.string.no_unread_notifications) else stringResource(R.string.no_notifications_yet),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = if (showUnreadOnly) {
                stringResource(R.string.read_notifications_hidden)
            } else {
                stringResource(R.string.notifications_empty_message)
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            content = content,
        )
    }
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Pill(label: String, color: Color) {
    Text(
        text = label,
        color = color,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(999.dp))
            .padding(horizontal = AutonexisSpacing.sm, vertical = AutonexisSpacing.xs),
    )
}

@Composable
private fun severityTone(severity: String): Color {
    return when (severity.lowercase()) {
        "warning" -> AutonexisColors.Amber
        "critical" -> AutonexisColors.CriticalRed
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}
