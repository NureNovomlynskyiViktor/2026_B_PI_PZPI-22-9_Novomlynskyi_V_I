package auth

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestRequireUserRejectsMissingToken(t *testing.T) {
	handler := RequireUser(
		&serviceStub{user: User{ID: testUserID}},
		testLogger(),
		func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusNoContent)
		},
	)
	request := httptest.NewRequest(http.MethodGet, "/api/v1/me/vehicles", nil)
	recorder := httptest.NewRecorder()

	handler(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}

func TestRequireUserAddsUserToContext(t *testing.T) {
	handler := RequireUser(
		&serviceStub{user: User{ID: testUserID, Email: "user@example.com"}},
		testLogger(),
		func(w http.ResponseWriter, r *http.Request) {
			user, ok := UserFromContext(r.Context())
			if !ok {
				t.Fatal("expected user in request context")
			}
			if user.ID != testUserID {
				t.Fatalf("expected user %s, got %s", testUserID, user.ID)
			}
			w.WriteHeader(http.StatusNoContent)
		},
	)
	request := httptest.NewRequest(http.MethodGet, "/api/v1/me/vehicles", nil)
	request.Header.Set("Authorization", "Bearer jwt")
	recorder := httptest.NewRecorder()

	handler(recorder, request)

	if recorder.Code != http.StatusNoContent {
		t.Fatalf("expected status %d, got %d", http.StatusNoContent, recorder.Code)
	}
}

func TestRequireUserRejectsInvalidToken(t *testing.T) {
	handler := RequireUser(
		&serviceStub{err: ErrUnauthorized},
		testLogger(),
		func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusNoContent)
		},
	)
	request := httptest.NewRequest(http.MethodGet, "/api/v1/me/vehicles", nil)
	request.Header.Set("Authorization", "Bearer invalid")
	recorder := httptest.NewRecorder()

	handler(recorder, request)

	if recorder.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, recorder.Code)
	}
}
