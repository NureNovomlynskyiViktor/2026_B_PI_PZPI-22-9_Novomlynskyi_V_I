package specialistmaintenance

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/maintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testSpecialistID = "33333333-3333-3333-3333-333333333333"
	testVehicleID    = "22222222-2222-2222-2222-222222222222"
)

type stubMaintenanceService struct {
	created maintenance.Record
	err     error
	request maintenance.CreateRequest
	called  bool
}

func (s *stubMaintenanceService) Create(
	_ context.Context,
	request maintenance.CreateRequest,
) (maintenance.Record, error) {
	s.request = request
	s.called = true
	if s.err != nil {
		return maintenance.Record{}, s.err
	}
	if s.created.ID == "" {
		s.created = maintenance.Record{
			ID:          "66666666-6666-6666-6666-666666666661",
			VehicleID:   request.VehicleID,
			CreatedBy:   &request.CreatedBy,
			Title:       request.Title,
			Description: request.Description,
			ServiceDate: request.ServiceDate,
		}
	}
	return s.created, nil
}

type stubAssignmentService struct {
	err error
}

func (s stubAssignmentService) GetAssignedVehicle(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	if s.err != nil {
		return vehicle.Vehicle{}, s.err
	}
	return vehicle.Vehicle{ID: testVehicleID}, nil
}

type stubVehicleService struct {
	err error
}

func (s stubVehicleService) GetByID(context.Context, string) (vehicle.Vehicle, error) {
	if s.err != nil {
		return vehicle.Vehicle{}, s.err
	}
	return vehicle.Vehicle{ID: testVehicleID}, nil
}

func TestCreateByAssignedSpecialist(t *testing.T) {
	maintenanceService := &stubMaintenanceService{}
	handler := NewHandler(
		maintenanceService,
		stubAssignmentService{},
		stubVehicleService{},
		testLogger(),
	)
	request := requestWithUser(
		`{"title":"Oil service","description":"Changed oil and filter.","service_date":"2026-06-17"}`,
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if !maintenanceService.called {
		t.Fatal("expected maintenance service to be called")
	}
	if maintenanceService.request.VehicleID != testVehicleID {
		t.Fatalf("expected vehicle %q, got %q", testVehicleID, maintenanceService.request.VehicleID)
	}
	if maintenanceService.request.CreatedBy != testSpecialistID {
		t.Fatalf("expected creator %q, got %q", testSpecialistID, maintenanceService.request.CreatedBy)
	}
	if maintenanceService.request.Title != "Oil service" {
		t.Fatalf("expected trimmed title, got %q", maintenanceService.request.Title)
	}
	expectedDate := time.Date(2026, 6, 17, 0, 0, 0, 0, time.UTC)
	if !maintenanceService.request.ServiceDate.Equal(expectedDate) {
		t.Fatalf("expected service date %s, got %s", expectedDate, maintenanceService.request.ServiceDate)
	}
}

func TestCreateRejectsUnassignedSpecialist(t *testing.T) {
	maintenanceService := &stubMaintenanceService{}
	handler := NewHandler(
		maintenanceService,
		stubAssignmentService{err: vehicle.ErrNotFound},
		stubVehicleService{},
		testLogger(),
	)
	request := requestWithUser(
		`{"title":"Oil service","description":"Changed oil and filter.","service_date":"2026-06-17"}`,
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
	if maintenanceService.called {
		t.Fatal("expected maintenance service not to be called")
	}
}

func TestCreateRejectsInvalidRequest(t *testing.T) {
	maintenanceService := &stubMaintenanceService{}
	handler := NewHandler(
		maintenanceService,
		stubAssignmentService{},
		stubVehicleService{},
		testLogger(),
	)
	request := requestWithUser(
		`{"title":" ","description":"Changed oil and filter.","service_date":"not-a-date"}`,
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
	if maintenanceService.called {
		t.Fatal("expected maintenance service not to be called")
	}
}

func TestCreateReturnsNotFoundForMissingVehicle(t *testing.T) {
	maintenanceService := &stubMaintenanceService{}
	handler := NewHandler(
		maintenanceService,
		stubAssignmentService{},
		stubVehicleService{err: vehicle.ErrNotFound},
		testLogger(),
	)
	request := requestWithUser(
		`{"title":"Oil service","description":"Changed oil and filter.","service_date":"2026-06-17"}`,
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
	if maintenanceService.called {
		t.Fatal("expected maintenance service not to be called")
	}
}

func requestWithUser(body string) *http.Request {
	request := httptest.NewRequest(
		http.MethodPost,
		"/api/v1/specialist/vehicles/"+testVehicleID+"/maintenance-records",
		strings.NewReader(body),
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	return request.WithContext(auth.WithUser(
		request.Context(),
		auth.User{
			ID:    testSpecialistID,
			Email: "specialist@example.com",
			Role:  auth.TechnicalSpecialistRoleCode,
		},
	))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
