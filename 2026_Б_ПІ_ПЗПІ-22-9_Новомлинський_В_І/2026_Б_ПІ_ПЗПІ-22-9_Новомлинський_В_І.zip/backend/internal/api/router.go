package api

import (
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/admin"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminaudit"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminuser"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alertevaluation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/owneralert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerdevice"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownermaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownernotification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownertelemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerthreshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownervehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistalert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistmaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistvehicle"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetryingestion"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicleactivation"
)

func RegisterRoutes(
	mux *http.ServeMux,
	vehicleHandler *vehicle.Handler,
	deviceHandler *device.Handler,
	telemetryHandler *telemetry.Handler,
	alertHandler *alert.Handler,
	statusHandler *vehiclestatus.Handler,
	alertEvaluationHandler *alertevaluation.Handler,
	telemetryIngestionHandler *telemetryingestion.Handler,
	authHandler *auth.Handler,
	vehicleActivationHandler *vehicleactivation.Handler,
	ownerVehicleHandler *ownervehicle.Handler,
	ownerDeviceHandler *ownerdevice.Handler,
	ownerTelemetryHandler *ownertelemetry.Handler,
	ownerAlertHandler *owneralert.Handler,
	ownerThresholdHandler *ownerthreshold.Handler,
	ownerMaintenanceHandler *ownermaintenance.Handler,
	ownerNotificationHandler *ownernotification.Handler,
	ownerServiceRequestHandler *ownerservicerequest.Handler,
	ownerSpecialistHandler *ownerspecialist.Handler,
	specialistAlertHandler *specialistalert.Handler,
	specialistMaintenanceHandler *specialistmaintenance.Handler,
	specialistServiceRequestHandler *specialistservicerequest.Handler,
	specialistVehicleHandler *specialistvehicle.Handler,
	adminServiceRequestHandler *adminservicerequest.Handler,
	adminSpecialistHandler *adminspecialist.Handler,
	adminUserHandler *adminuser.Handler,
	adminAuditHandler *adminaudit.Handler,
	adminHandler *admin.Handler,
	authService auth.Service,
	logger *slog.Logger,
) {
	mux.HandleFunc("POST /api/v1/auth/register", authHandler.Register)
	mux.HandleFunc("POST /api/v1/auth/login", authHandler.Login)
	mux.HandleFunc("POST /api/v1/auth/google", authHandler.Google)
	mux.HandleFunc(
		"GET /api/v1/auth/methods",
		auth.RequireUser(authService, logger, authHandler.Methods),
	)
	mux.HandleFunc(
		"POST /api/v1/auth/google/link",
		auth.RequireUser(authService, logger, authHandler.LinkGoogle),
	)
	mux.HandleFunc("GET /api/v1/auth/me", authHandler.Me)
	mux.HandleFunc(
		"POST /api/v1/me/vehicle-activations/claim",
		auth.RequireUser(authService, logger, vehicleActivationHandler.Claim),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles",
		auth.RequireUser(authService, logger, ownerVehicleHandler.List),
	)
	mux.HandleFunc(
		"POST /api/v1/me/vehicles",
		auth.RequireUser(authService, logger, ownerVehicleHandler.Create),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}",
		auth.RequireUser(authService, logger, ownerVehicleHandler.GetByID),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/status",
		auth.RequireUser(authService, logger, ownerVehicleHandler.Status),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/devices",
		auth.RequireUser(authService, logger, ownerDeviceHandler.ListByVehicle),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/telemetry",
		auth.RequireUser(authService, logger, ownerTelemetryHandler.ListByVehicle),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/alerts",
		auth.RequireUser(authService, logger, ownerAlertHandler.ListByVehicle),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/alerts/active",
		auth.RequireUser(authService, logger, ownerAlertHandler.ListActiveByVehicle),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/thresholds",
		auth.RequireUser(authService, logger, ownerThresholdHandler.ListByVehicle),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/maintenance-records",
		auth.RequireUser(authService, logger, ownerMaintenanceHandler.ListByVehicle),
	)
	mux.HandleFunc(
		"POST /api/v1/me/vehicles/{vehicle_id}/service-requests",
		auth.RequireUser(authService, logger, ownerServiceRequestHandler.Create),
	)
	mux.HandleFunc(
		"GET /api/v1/me/service-requests",
		auth.RequireUser(authService, logger, ownerServiceRequestHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/me/service-requests/{request_id}",
		auth.RequireUser(authService, logger, ownerServiceRequestHandler.Get),
	)
	mux.HandleFunc(
		"PATCH /api/v1/me/service-requests/{request_id}/cancel",
		auth.RequireUser(authService, logger, ownerServiceRequestHandler.Cancel),
	)
	mux.HandleFunc(
		"GET /api/v1/me/vehicles/{vehicle_id}/specialists",
		auth.RequireUser(authService, logger, ownerSpecialistHandler.List),
	)
	mux.HandleFunc(
		"POST /api/v1/me/vehicles/{vehicle_id}/specialists",
		auth.RequireUser(authService, logger, ownerSpecialistHandler.Assign),
	)
	mux.HandleFunc(
		"DELETE /api/v1/me/vehicles/{vehicle_id}/specialists/{specialist_id}",
		auth.RequireUser(authService, logger, ownerSpecialistHandler.Remove),
	)
	mux.HandleFunc(
		"POST /api/v1/me/vehicles/{vehicle_id}/devices",
		auth.RequireUser(authService, logger, ownerDeviceHandler.CreateForVehicle),
	)
	mux.HandleFunc(
		"GET /api/v1/me/devices",
		auth.RequireUser(authService, logger, ownerDeviceHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/me/devices/{device_id}",
		auth.RequireUser(authService, logger, ownerDeviceHandler.GetByID),
	)
	mux.HandleFunc(
		"GET /api/v1/me/notifications",
		auth.RequireUser(authService, logger, ownerNotificationHandler.List),
	)
	mux.HandleFunc(
		"PATCH /api/v1/me/notifications/{notification_id}/read",
		auth.RequireUser(authService, logger, ownerNotificationHandler.MarkRead),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/vehicles",
		auth.RequireUser(authService, logger, specialistVehicleHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/vehicles/{vehicle_id}/status",
		auth.RequireUser(authService, logger, specialistVehicleHandler.Status),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/vehicles/{vehicle_id}/thresholds",
		auth.RequireUser(authService, logger, specialistVehicleHandler.Thresholds),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/vehicles/{vehicle_id}/telemetry",
		auth.RequireUser(authService, logger, specialistVehicleHandler.Telemetry),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/vehicles/{vehicle_id}/alerts",
		auth.RequireUser(authService, logger, specialistVehicleHandler.Alerts),
	)
	mux.HandleFunc(
		"PATCH /api/v1/specialist/alerts/{alert_id}/resolve",
		auth.RequireUser(authService, logger, specialistAlertHandler.Resolve),
	)
	mux.HandleFunc(
		"POST /api/v1/specialist/vehicles/{vehicle_id}/maintenance-records",
		auth.RequireUser(authService, logger, specialistMaintenanceHandler.Create),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/service-requests",
		auth.RequireUser(authService, logger, specialistServiceRequestHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/specialist/service-requests/{request_id}",
		auth.RequireUser(authService, logger, specialistServiceRequestHandler.Get),
	)
	mux.HandleFunc(
		"PATCH /api/v1/specialist/service-requests/{request_id}/start",
		auth.RequireUser(authService, logger, specialistServiceRequestHandler.Start),
	)
	mux.HandleFunc(
		"PATCH /api/v1/specialist/service-requests/{request_id}/complete",
		auth.RequireUser(authService, logger, specialistServiceRequestHandler.Complete),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/vehicles",
		auth.RequireUser(authService, logger, adminHandler.ListVehicles),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/users",
		auth.RequireUser(authService, logger, adminUserHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/users/{user_id}",
		auth.RequireUser(authService, logger, adminUserHandler.Get),
	)
	mux.HandleFunc(
		"PATCH /api/v1/admin/users/{user_id}/deactivate",
		auth.RequireUser(authService, logger, adminUserHandler.Deactivate),
	)
	mux.HandleFunc(
		"PATCH /api/v1/admin/users/{user_id}/reactivate",
		auth.RequireUser(authService, logger, adminUserHandler.Reactivate),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/audit-logs",
		auth.RequireUser(authService, logger, adminAuditHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/service-requests",
		auth.RequireUser(authService, logger, adminServiceRequestHandler.List),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/service-requests/{request_id}",
		auth.RequireUser(authService, logger, adminServiceRequestHandler.Get),
	)
	mux.HandleFunc(
		"PATCH /api/v1/admin/service-requests/{request_id}/assign",
		auth.RequireUser(authService, logger, adminServiceRequestHandler.Assign),
	)
	mux.HandleFunc(
		"PATCH /api/v1/admin/service-requests/{request_id}/cancel",
		auth.RequireUser(authService, logger, adminServiceRequestHandler.Cancel),
	)
	mux.HandleFunc(
		"POST /api/v1/admin/vehicle-activations",
		auth.RequireUser(authService, logger, vehicleActivationHandler.Create),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/specialists",
		auth.RequireUser(authService, logger, adminHandler.ListSpecialists),
	)
	mux.HandleFunc(
		"POST /api/v1/admin/specialists",
		auth.RequireUser(authService, logger, adminSpecialistHandler.Create),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/specialists/{specialist_id}/competencies",
		auth.RequireUser(authService, logger, adminHandler.ListSpecialistCompetencies),
	)
	mux.HandleFunc(
		"PUT /api/v1/admin/specialists/{specialist_id}/competencies",
		auth.RequireUser(authService, logger, adminHandler.ReplaceSpecialistCompetencies),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/vehicles/{vehicle_id}/specialists",
		auth.RequireUser(authService, logger, adminHandler.ListVehicleSpecialists),
	)
	mux.HandleFunc(
		"GET /api/v1/admin/vehicles/{vehicle_id}/recommended-specialists",
		auth.RequireUser(authService, logger, adminHandler.ListRecommendedSpecialists),
	)
	mux.HandleFunc(
		"POST /api/v1/admin/vehicles/{vehicle_id}/specialists",
		auth.RequireUser(authService, logger, adminHandler.AssignVehicleSpecialist),
	)
	mux.HandleFunc(
		"DELETE /api/v1/admin/vehicles/{vehicle_id}/specialists/{specialist_id}",
		auth.RequireUser(authService, logger, adminHandler.RemoveVehicleSpecialist),
	)
	mux.HandleFunc("GET /api/v1/vehicles", vehicleHandler.List)
	mux.HandleFunc("GET /api/v1/vehicles/{id}", vehicleHandler.GetByID)
	mux.HandleFunc("GET /api/v1/devices", deviceHandler.List)
	mux.HandleFunc("GET /api/v1/devices/{id}", deviceHandler.GetByID)
	mux.HandleFunc(
		"GET /api/v1/vehicles/{vehicle_id}/telemetry",
		telemetryHandler.ListByVehicle,
	)
	mux.HandleFunc(
		"GET /api/v1/vehicles/{vehicle_id}/telemetry/latest",
		telemetryHandler.LatestByVehicle,
	)
	mux.HandleFunc(
		"GET /api/v1/vehicles/{vehicle_id}/alerts",
		alertHandler.ListByVehicle,
	)
	mux.HandleFunc(
		"GET /api/v1/vehicles/{vehicle_id}/alerts/active",
		alertHandler.ListActiveByVehicle,
	)
	mux.HandleFunc("GET /api/v1/alerts/{id}", alertHandler.GetByID)
	mux.HandleFunc(
		"GET /api/v1/vehicles/{vehicle_id}/status",
		statusHandler.GetByVehicleID,
	)
	mux.HandleFunc(
		"POST /api/v1/vehicles/{vehicle_id}/alerts/evaluate",
		alertEvaluationHandler.Evaluate,
	)
	mux.HandleFunc(
		"POST /api/v1/devices/{device_uid}/telemetry",
		telemetryIngestionHandler.Ingest,
	)
}
