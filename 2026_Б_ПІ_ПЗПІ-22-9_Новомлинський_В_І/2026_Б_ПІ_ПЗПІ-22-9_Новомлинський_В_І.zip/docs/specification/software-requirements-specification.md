# Специфікація вимог до програмного забезпечення Autonexis

Назва проєкту: Autonexis  
Тема: Програмна система моніторингу технічного стану автомобіля з використанням IoT  
Тип документа: Software Requirements Specification, SRS  
Версія: 1.0  
Статус: Markdown-джерело для подальшого експорту в DOCX  
Дата оновлення: 2026-06-28

## Історія версій

| Версія | Дата | Опис змін | Автор |
|---|---|---|---|
| 1.0 | 2026-06-28 | Перша розширена версія специфікації вимог для дипломної документації | Autonexis |

## Зміст

Зміст формується автоматично під час експорту Markdown-документа у DOCX або інший фінальний формат. Структура документа побудована за класичним підходом SRS: вступ, загальний опис, конкретні вимоги та додаткові матеріали.

## 1. Вступ

### 1.1 Призначення документа

Цей документ визначає функціональні та нефункціональні вимоги до програмної системи Autonexis. Він є джерельною специфікацією для дипломної документації, демонстраційних матеріалів, тестування та подальшого експорту у формат DOCX.

Документ описує поточний MVP системи без додавання можливостей, які не реалізовані в репозиторії. Він фіксує ролі користувачів, межі продукту, основні сценарії, інтерфейси, вимоги до даних, безпеки, надійності та супровідності. Специфікація також допомагає розробникам і тестувальникам узгодити очікувану поведінку backend, web, Android та IoT-демо компонентів.

### 1.2 Область застосування

Autonexis призначена для моніторингу технічного стану автомобіля з використанням IoT-телеметрії. Система приймає показники від ESP32/Wokwi-симулятора або іншого сумісного пристрою, передає їх через MQTT або REST API, зберігає у PostgreSQL, оцінює порогові правила, формує попередження, створює in-app сповіщення та підтримує сервісні процеси.

Поточна продуктова модель має такі межі:

- власник автомобіля використовує Android-застосунок як основний щоденний інтерфейс;
- вебзастосунок використовується адміністратором і технічним спеціалістом як робочий простір;
- публічна вебсторінка для власника використовується лише для ознайомлення, завантаження Android APK у локальній демонстрації та пояснення активації автомобіля;
- активація автомобіля виконується через одноразовий код або QR-код, виданий адміністратором після реєстрації автомобіля та IoT-модуля;
- система орієнтована на дипломну MVP-демонстрацію, а не на повномасштабне production-розгортання.

До поточного обсягу не входять білінг, публікація в Google Play, зовнішні push-сповіщення, email-flow для відновлення пароля, динамічний каталог компетенцій та складні WebSocket/live-update сценарії.

### 1.3 Цільова аудиторія

Документ призначений для таких груп:

- розробник системи, який підтримує backend, web, Android та IoT-демо;
- керівник дипломної роботи, який оцінює відповідність реалізації поставленій темі;
- рецензенти та члени комісії, яким потрібен стислий, але повний опис вимог;
- тестувальники, які перевіряють відповідність реалізації очікуваним сценаріям;
- майбутні розробники, які можуть продовжити систему після MVP.

Кожна група може використовувати документ по-різному: розробник як технічну основу, тестувальник як джерело критеріїв перевірки, а рецензент як опис меж і призначення системи.

### 1.4 Терміни, скорочення та абревіатури

| Термін | Пояснення |
|---|---|
| Autonexis | Програмна система моніторингу технічного стану автомобіля з використанням IoT |
| IoT | Internet of Things, підхід до підключення фізичних пристроїв до програмних систем |
| ESP32 | Мікроконтролер, який використовується як модель IoT-пристрою в демонстрації |
| Wokwi | Онлайн-середовище симуляції ESP32 та підключених компонентів |
| MQTT | Протокол обміну повідомленнями, який використовується для передавання телеметрії |
| REST API | HTTP API серверної частини для клієнтських застосунків і тестової телеметрії |
| JWT | JSON Web Token для автентифікації захищених запитів |
| OAuth | Протокол авторизації, який використовується у Google Sign-In та Google OAuth інтеграції |
| SRS | Software Requirements Specification, специфікація вимог до програмного забезпечення |
| MVP | Мінімально достатня функціональна версія системи для демонстрації |
| APK | Android application package, пакет Android-застосунку |
| VIN | Ідентифікаційний номер автомобіля |
| Device UID | Унікальний ідентифікатор IoT-пристрою, який використовується у MQTT topic |
| In-app сповіщення | Запис сповіщення всередині системи, доступний у клієнтському застосунку |

### 1.5 Огляд документа

Розділ 1 пояснює призначення, область застосування, аудиторію та терміни. Розділ 2 описує продуктову перспективу, функції, користувачів, обмеження, припущення та зовнішні залежності. Розділ 3 містить конкретні вимоги до інтерфейсів, функцій, якості та бази даних. Розділ 4 надає посилання на додаткові матеріали репозиторію: діаграми, схему бази даних, MQTT payload, сценарії демонстрації та інші специфікації.

## 2. Загальний опис

### 2.1 Перспектива продукту

Autonexis є модульною програмною системою, що об'єднує backend, базу даних, вебінтерфейс, Android-застосунок і IoT-демо. Архітектура побудована навколо Go modular monolith backend, який містить доменні модулі для автентифікації, користувачів, автомобілів, телеметрії, попереджень, сервісних заявок, компетенцій, сповіщень, аудиту та MQTT-споживача.

Основні компоненти системи:

- Go backend modular monolith, який надає REST API, виконує бізнес-правила та приймає MQTT-телеметрію;
- PostgreSQL, що зберігає користувачів, ролі, автомобілі, пристрої, телеметрію, пороги, попередження, заявки, сповіщення, записи обслуговування та аудит;
- MQTT consumer у складі backend, який підписується на telemetry topic і передає повідомлення у спільний workflow обробки телеметрії;
- ESP32/Wokwi-симулятор, який генерує демонстраційну телеметрію автомобіля;
- web app для адміністратора і технічного спеціаліста;
- Android app для власника автомобіля;
- публічна web onboarding сторінка для пояснення Android-доступу та активації.

Backend є центральним компонентом. Він має запускати HTTP API незалежно від тимчасової недоступності MQTT-брокера. Якщо MQTT увімкнений, але broker тимчасово недоступний, система має продовжувати запуск HTTP API та повторювати підключення до MQTT у фоновому режимі.

### 2.2 Функціональність продукту

Поточна версія Autonexis підтримує такі функціональні блоки:

- автентифікацію через email/password;
- Google Sign-In та Google OAuth foundation для входу або прив'язування Google-акаунта;
- самореєстрацію власника автомобіля з роллю `vehicle_owner`;
- адміністративне створення технічних спеціалістів із початковими компетенціями;
- деактивацію і реактивацію користувачів без фізичного видалення історії;
- створення неактивованих автомобілів і пристроїв адміністратором;
- генерацію одноразового activation code та activation URI для QR-коду;
- підключення автомобіля власником через Android-застосунок;
- приймання телеметрії через MQTT topic `autonexis/devices/+/telemetry`;
- приймання телеметрії через REST API для сумісних сценаріїв;
- оцінювання порогів warning і critical;
- стабілізований життєвий цикл попереджень зі станами `active`, `cleared`, `resolved`;
- in-app сповіщення для власника про важливі події;
- створення і супровід сервісних заявок;
- призначення технічного спеціаліста на автомобіль або заявку;
- ведення записів технічного обслуговування;
- підтвердження вирішення інцидентів технічним спеціалістом;
- адміністративний audit log;
- українську та англійську локалізацію;
- світлу, темну та системну тему інтерфейсу.

### 2.3 Характеристики користувачів

| Роль | Характеристика | Основний інтерфейс |
|---|---|---|
| Адміністратор | Керує користувачами, автомобілями, активаціями, технічними спеціалістами, сервісними заявками та аудитом | Web workspace |
| Технічний спеціаліст | Аналізує призначені автомобілі, телеметрію, попередження, заявки, записи обслуговування та підтверджує вирішення інцидентів | Web workspace |
| Власник автомобіля | Підключає автомобіль, переглядає статус, телеметрію, попередження, сповіщення, сервісні заявки та історію обслуговування | Android app |

Адміністратор повинен розуміти процеси реєстрації автомобіля, видачі activation QR, керування спеціалістами та перегляду аудиту. Технічний спеціаліст повинен працювати з діагностичними даними і сервісними заявками. Власник автомобіля повинен отримувати зрозумілий мобільний інтерфейс без необхідності користуватися вебробочим простором.

### 2.4 Загальні обмеження

Система має такі обмеження MVP:

- не реалізовується білінг, тарифікація або платіжна логіка;
- Android-застосунок не публікується в Google Play у межах поточної демонстрації;
- зовнішні push-сповіщення не входять до поточного обсягу;
- відновлення пароля через email не реалізовується;
- каталог компетенцій технічних спеціалістів є фіксованим і не редагується динамічно через UI;
- складні WebSocket/live-update сценарії не входять до MVP;
- демонстраційна IoT-частина базується на ESP32/Wokwi, а не на серійному автомобільному обладнанні;
- локальні файли конфігурації, APK, відео, логи та build outputs не мають потрапляти до репозиторію;
- система не повинна розкривати секрети, паролі, JWT, Google ID tokens або activation code hashes у відповідях API, логах чи документації.

### 2.5 Припущення та залежності

Для коректної роботи системи припускається таке:

- PostgreSQL доступний, а backend migrations застосовані у правильному порядку;
- seed-дані для демонстрації можуть бути відновлені з `backend/seeds/dev_seed.sql`;
- MQTT-брокер доступний для повного IoT-сценарію, але його тимчасова недоступність не блокує HTTP API;
- ESP32/Wokwi публікує повідомлення у topic, що відповідає `autonexis/devices/{DEVICE_UID}/telemetry`;
- `DEVICE_UID` у Wokwi відповідає зареєстрованому пристрою;
- Android-пристрій або емулятор має доступ до backend URL;
- Google Sign-In працює лише за наявності коректно налаштованих Google OAuth client IDs;
- користувачі з ролями адміністратора і технічного спеціаліста використовують web app, а власники автомобілів використовують Android app;
- системні дата і час мають бути достатньо коректними для перевірки JWT, expiration time, telemetry timestamps та activation code validity.

## 3. Конкретні вимоги

### 3.1 Вимоги до зовнішніх інтерфейсів

#### 3.1.1 Інтерфейси користувача

Система має надавати окремі інтерфейси для різних ролей і сценаріїв. Інтерфейси не повинні змішувати адміністративні, спеціалістські та власницькі функції.

Вебінтерфейс має включати:

- публічну landing/onboarding сторінку з поясненням призначення Autonexis, Android-застосунку, APK download QR для demo-середовища та відмінності між APK QR і vehicle activation QR;
- екран автентифікації з email/password входом, реєстрацією власника та Google Sign-In, якщо він налаштований;
- робочий простір адміністратора з розділами огляду, активації автомобілів, сервісних заявок, призначень спеціалістів, користувачів і audit log;
- робочий простір технічного спеціаліста з розділами призначених автомобілів, діагностики, сервісних заявок, обслуговування та підтвердження вирішення інцидентів;
- account/sign-in methods panel з мовою, appearance mode та Google account linking.

Android-застосунок має включати:

- екран входу і реєстрації власника;
- власницьку навігацію для автомобілів, сервісних заявок, сповіщень і профілю;
- підключення автомобіля вручну або через QR-код активації;
- перегляд деталей автомобіля, стану, телеметрії, попереджень, сервісних заявок, сповіщень і записів обслуговування;
- підтримку української та англійської мов;
- підтримку світлої, темної та системної теми.

Усі клієнтські інтерфейси мають показувати безпечні повідомлення про помилки. Технічні відповіді backend, зокрема raw authentication errors, не повинні показуватися користувачу напряму.

#### 3.1.2 Апаратні інтерфейси

Демонстраційний апаратний рівень представлений ESP32/Wokwi-симулятором. Симулятор має моделювати пристрій, що надсилає телеметрію автомобіля. Значення телеметрії мають відповідати очікуваним структурованим полям:

- `engine_temperature`;
- `battery_voltage`;
- `vibration_level`;
- `rpm`;
- `speed`;
- `fuel_level`;
- `timestamp`.

Wokwi sketch має використовувати один конфігураційний `DEVICE_UID`, на основі якого формується MQTT topic і MQTT client ID. Це забезпечує просту зміну симульованого пристрою без зміни payload, topic templates або backend logic.

#### 3.1.3 Програмні інтерфейси

Backend має надавати REST API для таких груп клієнтів:

- публічні endpoints для login, register і Google Sign-In;
- захищені owner endpoints для Android-застосунку;
- захищені administrator endpoints для web workspace;
- захищені technical specialist endpoints для web workspace;
- telemetry ingestion endpoints для сумісних REST-сценаріїв.

Захищені endpoints мають використовувати JWT Bearer token. Backend має перевіряти активність користувача в базі даних під час поточної user validation, щоб деактивовані користувачі не могли продовжувати роботу з раніше виданими токенами.

Відповіді API мають використовувати JSON. Поля, що є nullable в базі даних, мають передаватися як JSON null, а не як порожній рядок або текстове значення `null`.

#### 3.1.4 Комунікаційні інтерфейси

MQTT telemetry consumer має підписуватися на topic filter:

```text
autonexis/devices/+/telemetry
```

Сегмент `+` відповідає `device_uid`. Приклад topic для demo-пристрою:

```text
autonexis/devices/esp32-demo-002/telemetry
```

MQTT payload має відповідати формату, описаному в `docs/specification/telemetry-payload.md`. Некоректні payload не повинні зупиняти backend. Unknown device telemetry має відхилятися або логуватися без створення неконсистентних записів.

REST і MQTT ingestion мають використовувати спільний workflow обробки телеметрії, щоб threshold evaluation, alert lifecycle і notification creation поводилися однаково незалежно від каналу надходження даних.

### 3.2 Функціональні вимоги

#### FR-01 Authentication and session handling

Опис: система має підтримувати автентифікацію через email/password, Google Sign-In та Google OAuth account linking.

Первинний актор або компонент: власник автомобіля, адміністратор, технічний спеціаліст, auth backend, web app, Android app.

Очікувана поведінка:

- користувач може увійти за email/password, якщо обліковий запис активний;
- власник може зареєструватися самостійно, а новий обліковий запис отримує роль `vehicle_owner`;
- Google Sign-In створює або використовує зв'язаний Google OAuth account без автоматичного злиття за email;
- Google account linking доступний автентифікованому користувачу згідно з правилами безпеки;
- клієнти мають зберігати JWT безпечно відповідно до платформи;
- HTTP 401 для автентифікованих запитів має очищати недійсний токен і повертати користувача до входу з локалізованим повідомленням.

Валідація і правила доступу:

- password не повертається і не логується;
- inactive users не можуть увійти;
- реєстрація не приймає роль від клієнта;
- Google ID token не повинен потрапляти у логи або повідомлення помилок;
- network failures і HTTP 5xx не повинні примусово очищати session state.

#### FR-02 Role-based access control

Опис: система має розмежовувати доступ за ролями `administrator`, `technical_specialist` і `vehicle_owner`.

Первинний актор або компонент: backend authorization middleware, web app, Android app.

Очікувана поведінка:

- administrator має доступ до адміністративних endpoints;
- technical specialist має доступ лише до призначених автомобілів, заявок, діагностики та інцидентів;
- vehicle owner має доступ лише до власних автомобілів, заявок, сповіщень і записів;
- web role routing відкриває administrator workspace або technical specialist workspace;
- vehicle owner після входу у web бачить onboarding/download/activation guidance, а щоденна робота виконується в Android app.

Валідація і правила доступу:

- non-admin запити до admin endpoints мають повертати 403;
- доступ до чужих vehicles, notifications, service requests і alerts має бути заборонений;
- невідомі або недоступні ресурси для поточного користувача мають повертати безпечні 404 або 403 відповідно до існуючих правил.

#### FR-03 Vehicle owner registration

Опис: система має дозволяти створення власника автомобіля через публічну реєстрацію.

Первинний актор або компонент: vehicle owner, auth backend, Android app, web auth screen.

Очікувана поведінка:

- користувач вводить full name, email, password і confirm password;
- backend нормалізує email так само, як під час login;
- створюється active user з роллю `vehicle_owner`;
- після успішної реєстрації користувач отримує auth response у тій самій формі, що й login;
- новий власник без автомобіля бачить empty state і може підключити автомобіль через activation code або QR.

Валідація і правила доступу:

- duplicate normalized email повертає 409;
- invalid full name, email або password повертає 400;
- password hash зберігається замість plaintext password;
- inactive email залишається зарезервованим і не може бути зареєстрований повторно.

#### FR-04 Vehicle activation by QR/code

Опис: система має підтримувати одноразову активацію автомобіля власником через код або QR payload.

Первинний актор або компонент: administrator, vehicle owner, backend, Android app, web admin workspace.

Очікувана поведінка:

- administrator створює unclaimed vehicle, inactive device, default thresholds і одноразовий activation code;
- plaintext activation code повертається один раз у response;
- backend також формує activation URI у форматі `autonexis://vehicle-activation?code={ACTIVATION_CODE}`;
- web admin workspace показує activation code, expiration і QR code;
- Android app дозволяє ручне введення коду або сканування QR;
- після успішного claim vehicle отримує owner_id, device активується, а activation record позначається claimed.

Валідація і правила доступу:

- plaintext activation code не зберігається у PostgreSQL;
- зберігається лише hash activation code;
- expired, invalid або used code має бути відхилений;
- repeated або concurrent claims не повинні призначати один автомобіль двом власникам;
- APK download QR і vehicle activation QR мають пояснюватися як різні QR-коди.

#### FR-05 Vehicle and device management

Опис: система має підтримувати створення та облік автомобілів, пристроїв і default threshold settings.

Первинний актор або компонент: administrator, backend repository/service, PostgreSQL.

Очікувана поведінка:

- administrator створює автомобіль із VIN, brand, model, year, license plate, device UID і device name;
- unclaimed vehicle може мати nullable owner_id;
- device створюється зі статусом `inactive` до claim;
- під час активації device переходить у active state;
- default thresholds створюються для основних параметрів автомобіля.

Валідація і правила доступу:

- duplicate VIN або device UID повертає 409;
- year, VIN і device UID мають проходити валідацію;
- vehicle, device, thresholds, activation і audit entry створюються атомарно;
- device last seen і latest telemetry мають відображатися без raw ISO timestamp у користувацькому UI.

#### FR-06 MQTT telemetry ingestion

Опис: backend має приймати телеметрію з MQTT topic і передавати її у спільний workflow обробки.

Первинний актор або компонент: ESP32/Wokwi, MQTT broker, MQTT consumer, telemetry service.

Очікувана поведінка:

- MQTT consumer підписується на `autonexis/devices/+/telemetry`;
- device UID з topic використовується для пошуку зареєстрованого пристрою;
- valid payload створює telemetry record;
- після збереження telemetry record виконується threshold evaluation;
- MQTT startup не блокує HTTP API, якщо broker тимчасово недоступний;
- retry supervisor повторює спроби підключення з bounded backoff до успіху або shutdown.

Валідація і правила доступу:

- invalid static MQTT configuration може зупинити startup;
- connection або subscription failures не повинні завершувати процес backend;
- invalid payload не повинен створювати telemetry record;
- unknown device telemetry не повинна створювати записи для неіснуючого пристрою;
- shutdown має зупиняти retry loop без витоку goroutines.

#### FR-07 REST telemetry ingestion

Опис: система має підтримувати REST telemetry ingestion для сумісних тестових або інтеграційних сценаріїв.

Первинний актор або компонент: backend API, telemetry service, threshold evaluation service.

Очікувана поведінка:

- REST request може передати telemetry payload для відомого device або vehicle context відповідно до існуючих endpoints;
- telemetry record зберігається у PostgreSQL;
- threshold evaluation запускається так само, як для MQTT;
- створення alerts і notifications не залежить від каналу надходження телеметрії.

Валідація і правила доступу:

- некоректний payload повертає 400;
- unknown або inactive device обробляється згідно з backend rules;
- timestamp має коректно оброблятися або замінюватися server-side time за правилами реалізації;
- telemetry values мають відповідати очікуваним numeric constraints.

#### FR-08 Threshold evaluation and alert creation

Опис: система має оцінювати telemetry values за threshold settings і керувати життєвим циклом попереджень.

Первинний актор або компонент: alertevaluation service, alert repository, notification writer.

Очікувана поведінка:

- warning або critical violation створює новий active alert, якщо немає non-resolved incident для цього vehicle і parameter;
- repeated sample того самого рівня не створює duplicate alert;
- warning to critical escalation оновлює active alert і створює escalation notification;
- critical to warning змінює `current_severity` на warning, але не зменшує максимальну `severity`;
- recovery zone з урахуванням recovery margin і recovery samples переводить alert у `cleared`;
- recurrence після `cleared` відкриває той самий incident і збільшує occurrence_count;
- `resolved` incident є terminal, тому новий violation створює новий alert.

Валідація і правила доступу:

- status може бути `active`, `cleared` або `resolved`;
- максимальна `severity` не повинна зменшуватися;
- vehicle current overall status має враховувати лише active alerts і `current_severity`;
- active alert не може бути manual resolved власником;
- specialist-confirmed resolution допускається лише для cleared alerts.

#### FR-09 Notifications

Опис: система має створювати provider-neutral in-app notifications для власника.

Первинний актор або компонент: notification writer, alert lifecycle, service request lifecycle, owner Android app.

Очікувана поведінка:

- alert lifecycle створює notifications для created, escalated, reopened і cleared transitions, якщо це передбачено поточною реалізацією;
- service request lifecycle створює notifications для assignment, start і completion;
- notification records зберігаються у PostgreSQL як authoritative in-app notifications;
- owner може переглядати власні notifications і позначати їх як read;
- notifications можуть мати nullable `alert_id` або nullable `service_request_id` залежно від типу.

Валідація і правила доступу:

- notification належить лише request owner або vehicle owner;
- failed lifecycle transition не створює notification;
- notification insertion має бути атомарною з відповідною business transition, якщо вона створюється в межах цієї транзакції;
- зовнішні push-сповіщення не входять до MVP;
- система не повинна виконувати external provider calls всередині database transaction.

#### FR-10 Service requests

Опис: система має підтримувати сервісні заявки від власника до технічного спеціаліста.

Первинний актор або компонент: vehicle owner, administrator, technical specialist, service request service.

Очікувана поведінка:

- owner створює manual request для власного vehicle;
- owner може створити request, пов'язаний з active або cleared alert, якщо правила backend це дозволяють;
- administrator переглядає pending requests і призначає technical specialist;
- specialist переводить request у `in_progress` і `completed`;
- completion вимагає nonblank result summary;
- owner бачить status і result summary в Android app.

Валідація і правила доступу:

- owner має доступ лише до заявок власних vehicles;
- administrator може cancel pending або assigned requests;
- owner може cancel лише pending requests;
- specialist має доступ лише до assigned requests;
- duplicate open request для одного source alert має повертати 409;
- status transitions мають бути строго валідовані.

#### FR-11 Technical specialist assignment

Опис: система має підтримувати призначення спеціаліста на сервісну заявку та автомобіль.

Первинний актор або компонент: administrator, specialist assignment repository, service request service.

Очікувана поведінка:

- administrator призначає active technical specialist на pending service request;
- assignment створює або повторно використовує existing vehicle specialist assignment;
- reassignment допускається лише для request у статусі `assigned`;
- service request assignment і owner notification виконуються атомарно;
- assignment audit event створюється у межах тієї самої транзакції.

Валідація і правила доступу:

- inactive technical specialists не повинні з'являтися у списках для нових призначень;
- specialist з active assigned або in_progress work не може бути деактивований;
- administrator не може призначити неіснуючого або неактивного specialist;
- direct specialist assignment endpoints мають залишатися сумісними з існуючими сценаріями.

#### FR-12 Specialist competencies

Опис: система має підтримувати curated competency model для рекомендацій спеціалістів.

Первинний актор або компонент: administrator, competency service, recommendation logic.

Очікувана поведінка:

- administrator може створити technical specialist з початковими competencies;
- administrator може оновлювати competencies існуючого specialist;
- recommendation logic використовує competencies для підбору specialist під vehicle або alert context;
- web UI має показувати human-readable labels для competency codes.

Валідація і правила доступу:

- невідомий competency code відхиляється;
- динамічне створення нових competency types не входить до MVP;
- competencies не повинні змінювати role або authentication behavior;
- recommendation scoring не повинен змінюватися під час presentation-only змін.

#### FR-13 Audit log

Опис: система має записувати адміністративно важливі дії у read-only audit log.

Первинний актор або компонент: administrator, audit writer, admin audit API.

Очікувана поведінка:

- user deactivation/reactivation створює audit events;
- service request assignment, reassignment і administrator cancellation створюють audit events;
- vehicle activation creation створює audit event без sensitive values;
- specialist-confirmed alert resolution створює audit event;
- administrator може читати audit log з фільтрами action, actor, entity, date range, limit і offset.

Валідація і правила доступу:

- audit metadata не повинна містити password, password hash, activation code, code hash, JWT або Google ID token;
- audit write failure має rollback відповідної business transaction, якщо audit є частиною цієї транзакції;
- non-admin користувачі не мають доступу до audit log;
- API має повертати pagination з total і has_more.

#### FR-14 Android owner app

Опис: Android app є основним daily workspace для власника автомобіля.

Первинний актор або компонент: vehicle owner, Android app, owner REST API.

Очікувана поведінка:

- owner може увійти через email/password або Google, якщо Google Sign-In налаштований;
- owner може зареєструватися;
- owner може підключити vehicle через activation code або QR;
- app показує vehicles, vehicle details, telemetry, alert lifecycle, service requests, notifications, maintenance history і account settings;
- app підтримує unread notification count, read/unread notifications і service request navigation;
- app підтримує українську та англійську мови, світлу, темну та системну тему.

Валідація і правила доступу:

- Android app має очищати лише invalid Autonexis JWT при expired session;
- network failures не повинні примусово logout користувача;
- active і cleared alerts можуть ініціювати service request, але owner не має action для specialist-confirmed resolution;
- raw backend timestamps мають форматуватися у зрозумілий локалізований вигляд.

#### FR-15 Web admin/specialist workspace

Опис: web app має бути робочим середовищем для administrator і technical specialist.

Первинний актор або компонент: administrator, technical specialist, web app, backend REST API.

Очікувана поведінка:

- administrator workspace надає overview, vehicle onboarding, service requests, specialist assignments, users і audit log;
- specialist workspace надає assigned vehicles, diagnostics, service requests, maintenance і incident resolution;
- specialist diagnostics показує status, thresholds, telemetry history, alert incidents і compact telemetry trend charts;
- account panel дозволяє керувати мовою, appearance mode і sign-in methods;
- manual logout повертає на public landing page, а expired session повертає на login з повідомленням.

Валідація і правила доступу:

- owner login у web відкриває onboarding/download/activation guidance, а не робочий dashboard;
- admin і specialist UI не повинні показувати actions, які не дозволені ролі;
- invalid JWT у authenticated API calls має централізовано очищати session і redirect to login;
- network і business errors не повинні автоматично logout користувача.

#### FR-16 Localization and appearance mode

Опис: клієнтські застосунки мають підтримувати українську та англійську мови, а web і Android мають підтримувати appearance modes.

Первинний актор або компонент: web app, Android app, presentation helpers.

Очікувана поведінка:

- language mode може бути system, English або Ukrainian;
- appearance mode може бути system, light або dark;
- структуровані labels, statuses, priorities, severities, metric names і units мають локалізуватися;
- backend free-form text, зокрема alert recommendations, request descriptions, maintenance notes і audit metadata JSON, не перекладається автоматично;
- timestamps мають форматуватися локалізовано і без raw nanoseconds або timezone suffix у user-facing UI.

Валідація і правила доступу:

- language і appearance preferences не повинні очищатися під час logout або expired session cleanup;
- українські labels мають поміщатися у responsive layout без горизонтального overflow;
- темна тема має зберігати контрастність для cards, buttons, inputs, status badges, QR frames і tables.

### 3.3 Атрибути програмного продукту

#### 3.3.1 Надійність

NFR-01 Reliability

Опис: система має стабільно працювати під час локальної демонстрації і не припиняти основну роботу через ізольовані помилки в optional runtime dependencies.

Вимоги:

- HTTP API має запускатися навіть тоді, коли MQTT broker тимчасово недоступний;
- MQTT consumer має повторювати підключення у фоновому режимі з bounded backoff;
- некоректні MQTT payload не повинні зупиняти backend;
- невідомий device UID не повинен створювати неконсистентні telemetry records;
- database transaction має гарантувати атомарність business change, notification і audit event там, де вони є частиною одного lifecycle переходу;
- Android і web клієнти мають розрізняти expired session, network failure і server-side помилки.

Критерії перевірки:

- `go test ./...` проходить без регресій;
- при недоступному MQTT broker HTTP server залишається доступним;
- failed notification або audit write у транзакційних сценаріях не залишає частково застосовану business зміну.

#### 3.3.2 Доступність

NFR-02 Availability

Опис: система має залишатися доступною для основних API і UI сценаріїв у локальному demo-середовищі, якщо критичні залежності працюють.

Вимоги:

- backend має health/readiness endpoints для перевірки стану;
- web app має показувати зрозумілі loading, empty, retry і error states;
- Android app має зберігати існуючі дані на екрані під час refresh failure, якщо це можливо;
- best-effort unread notification sync не повинен блокувати owner dashboard, але 401 у цьому запиті має оброблятися як expired session;
- manual refresh у web і Android має бути доступний у контекстних розділах.

Критерії перевірки:

- network failure не очищає session;
- HTTP 5xx не переводить користувача на login;
- UI не показує raw backend authentication messages.

#### 3.3.3 Безпека

NFR-03 Security

Опис: система має захищати облікові записи, ролі, токени, activation codes і персональні дані від випадкового розкриття.

Вимоги:

- passwords мають зберігатися лише у hashed form;
- JWT використовується для захищених REST запитів;
- inactive users не можуть увійти і не можуть використовувати раніше видані токени;
- self-registration завжди створює роль `vehicle_owner`;
- administrator-created specialist endpoint не може створювати administrator або owner;
- activation code зберігається лише як hash;
- plaintext activation code і QR payload показуються лише один раз після створення activation;
- Google ID tokens не логуються і не повертаються у помилках;
- audit metadata не містить secrets;
- Android має очищати тільки invalid Autonexis JWT, не видаляючи appearance, language або backend URL preferences.

Критерії перевірки:

- duplicate email відхиляється;
- unauthorized role access повертає 403;
- чужі ресурси власника або спеціаліста недоступні;
- expired token приводить користувача до login з безпечним повідомленням.

#### 3.3.4 Супровідність

NFR-04 Maintainability

Опис: система має залишатися зрозумілою для супроводу в межах дипломного проєкту і подальшого розвитку.

Вимоги:

- backend має бути організований як modular monolith з доменними пакетами;
- database schema має змінюватися через numbered migrations;
- seed data має бути окремо від migrations;
- reusable writer/service abstractions мають використовуватися для audit і notifications там, де це потрібно транзакційно;
- web presentation helpers мають централізувати timestamp, structured labels і unit formatting;
- Android presentation helpers мають повертати string resource IDs або semantic values замість hardcoded translated strings;
- документація має зберігатися у Markdown, а діаграми у Mermaid source files.

Критерії перевірки:

- application code не дублює критичну бізнес-логіку між MQTT і REST ingestion;
- web і Android localization files мають parity для client-owned strings;
- SRS посилається на authoritative repo docs замість дублювання всіх деталей схеми.

#### 3.3.5 Переносимість

NFR-05 Portability

Опис: система має запускатися у типовому локальному середовищі розробника і демонстрації.

Вимоги:

- backend має запускатися на Windows за наявності Go і PostgreSQL;
- web app має збиратися через npm/Vite без додаткових UI dependencies;
- Android app має збиратися через Gradle і запускатися на емуляторі або фізичному пристрої;
- Wokwi demo має відтворюватися з файлів `iot/wokwi-esp32/sketch.ino`, `diagram.json` і `libraries.txt`;
- backend URL для Android має конфігуруватися через BuildConfig або local properties без коміту локальних файлів;
- demo APK link у web має бути optional environment variable, а сам APK не має додаватися до репозиторію.

Критерії перевірки:

- `npm run build` проходить у web;
- Android `assembleDebug` проходить у mobile/android;
- backend tests і vet проходять у backend;
- `git status --short` не містить локальних build artifacts після валідації.

#### 3.3.6 Продуктивність

NFR-06 Performance

Опис: MVP має забезпечувати достатню продуктивність для локальної демонстрації, роботи з історією телеметрії та основними адміністративними списками.

Вимоги:

- telemetry list endpoints мають підтримувати limit і повертати newest records first;
- alert list endpoints мають підтримувати status filter і limit;
- audit log має підтримувати pagination з total і has_more;
- web specialist diagnostics має використовувати наявну telemetryHistory для trend charts без додаткових API calls;
- Android refresh має використовувати locking, щоб уникати дубльованих одночасних запитів;
- API має використовувати індекси бази даних для основних фільтрів і сортувань, визначені у migrations.

Критерії перевірки:

- UI залишається responsive на типових demo data;
- polling у specialist diagnostics не створює дубльованих stale updates після перемикання vehicle;
- pagination і limit validation не дозволяють необмежені важкі запити.

### 3.4 Вимоги до бази даних

Система має використовувати PostgreSQL як основне сховище. Авторитетним джерелом структури бази даних є backend migrations у каталозі `backend/migrations`. Документ `docs/specification/database-schema.md` містить опис схеми у зручній для документації формі, але у разі розбіжностей першочерговими є migrations.

Основні домени даних:

- користувачі, ролі, password hash, OAuth accounts і active/deactivated state;
- автомобілі, пристрої, vehicle activation records і default threshold settings;
- telemetry records із показниками `engine_temperature`, `battery_voltage`, `vibration_level`, `rpm`, `speed`, `fuel_level` і timestamp;
- threshold settings з warning/critical values, recovery margin і recovery samples;
- alerts з maximum severity, current severity, status, occurrence count, recovery streak, lifecycle timestamps і specialist resolution metadata;
- owner notifications з nullable references на alert або service request;
- vehicle service requests з lifecycle timestamps, priority, status, result summary і optional source alert link;
- vehicle specialist assignments;
- specialist competencies і recommendation-related data;
- maintenance records;
- audit logs з actor, action, entity, metadata і timestamp.

Вимоги до збереження даних:

- primary keys мають бути стабільними UUID або іншим існуючим типом, визначеним migrations;
- foreign keys мають зберігати посилальну цілісність між users, vehicles, devices, alerts, notifications, service requests і audit logs;
- activation code plaintext не має зберігатися;
- password plaintext не має зберігатися;
- audit logs не мають містити sensitive values;
- migrations мають мати up/down файли, якщо схема змінюється;
- seed data має залишатися у `backend/seeds/dev_seed.sql` і не повинна підміняти migrations;
- nullable database fields мають коректно серіалізуватися у JSON як null.

Додаткові джерела:

- `docs/specification/database-schema.md` для детального опису таблиць;
- `backend/migrations` для фактичних SQL-змін;
- `backend/seeds/dev_seed.sql` для демонстраційних даних;
- `docs/diagrams/database/01-autonexis-erd-notes.md` для пояснення ERD-підходу без вигадування додаткових таблиць.

### 3.5 Інші вимоги

Репозиторій має залишатися придатним для перевірки і демонстрації. До нього не мають додаватися локальні secrets, generated APK, відео, PDF/DOCX експорти, build outputs, логи або локальні env файли.

Документація має посилатися на наявні джерела замість дублювання нестабільних деталей. Якщо змінюється API, database schema або поведінка клієнтів, відповідні Markdown-документи мають оновлюватися разом із реалізацією.

Вимоги до demo readiness:

- DEMO.md має описувати практичний порядок запуску і демонстрації;
- docs/screenshots може містити фінальні знімки для дипломної роботи, але screenshots не створюються автоматично у межах цього SRS;
- docs/diagrams має містити Mermaid sources, які можна експортувати у SVG або PNG для презентації;
- локальні Google client IDs, JWT, паролі та Wi-Fi details не повинні потрапляти у документацію.

## 4. Додаткові матеріали

### 4.1 Архітектурні діаграми

Архітектурні Mermaid-діаграми розміщені у `docs/diagrams/architecture`. Вони використовуються для пояснення системного контексту та локального demo deployment.

Рекомендовані джерела:

- `docs/diagrams/architecture/01-system-context.mmd` для загальної взаємодії Android app, web app, backend, PostgreSQL, MQTT broker і Wokwi/ESP32;
- `docs/diagrams/architecture/02-local-demo-deployment.mmd` для демонстраційного розгортання з локальним backend, PostgreSQL, web app, Android phone, MQTT broker і APK download guidance.

Діаграми не мають містити secrets, реальні email, JWT, Google client IDs або локальні приватні мережеві дані.

### 4.2 Схема бази даних

Детальна схема бази даних описана у `docs/specification/database-schema.md`. Фактичні зміни схеми визначаються SQL migrations у `backend/migrations`. Примітки для ERD розміщені у `docs/diagrams/database/01-autonexis-erd-notes.md`.

Під час підготовки DOCX або презентації допускається експорт ERD у зображення, але зображення має відповідати реальним migrations і не повинно вигадувати таблиці або зв'язки, яких немає у backend schema.

### 4.3 MQTT-взаємодія

Формат telemetry payload описано у `docs/specification/telemetry-payload.md`. Wokwi-симулятор розміщено у `iot/wokwi-esp32` і використовує один `DEVICE_UID` для формування topic:

```text
autonexis/devices/{DEVICE_UID}/telemetry
```

Backend MQTT consumer підписується на:

```text
autonexis/devices/+/telemetry
```

Для demo-сценарію можуть використовуватися HiveMQ broker або локальний MQTT broker, якщо це відповідає поточній конфігурації. Недоступність broker не повинна блокувати HTTP API.

### 4.4 Потоки активації, сервісних заявок і попереджень

Бізнес-потоки розміщені у `docs/diagrams/flows`:

- `docs/diagrams/flows/01-vehicle-activation-flow.mmd` описує створення автомобіля адміністратором, видачу activation code/QR та claim у Android app;
- `docs/diagrams/flows/02-service-request-lifecycle.mmd` описує створення заявки власником, призначення адміністратором, роботу спеціаліста і завершення;
- `docs/diagrams/flows/03-alert-lifecycle.mmd` описує active, cleared, resolved, escalation, recurrence і specialist-confirmed resolution.

Додаткові джерела для підготовки дипломних матеріалів:

- `docs/specification/functional-version-scope.md` для меж MVP;
- `docs/specification/telemetry-payload.md` для payload і полів телеметрії;
- `docs/screenshots` для фінальних screenshots, якщо вони додані окремо;
- `DEMO.md` для практичного сценарію запуску і показу системи.
