package threshold

import "context"

type Service interface {
	ListByVehicle(ctx context.Context, vehicleID string) ([]Setting, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) ListByVehicle(
	ctx context.Context,
	vehicleID string,
) ([]Setting, error) {
	return s.repository.ListByVehicle(ctx, vehicleID)
}
