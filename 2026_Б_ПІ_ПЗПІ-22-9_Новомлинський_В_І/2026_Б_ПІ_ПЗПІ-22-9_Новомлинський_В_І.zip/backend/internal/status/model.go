package status

import (
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type VehicleStatus struct {
	Vehicle         vehicle.Vehicle   `json:"vehicle"`
	Device          *device.Device    `json:"device"`
	LatestTelemetry *telemetry.Record `json:"latest_telemetry"`
	ActiveAlerts    []alert.Alert     `json:"active_alerts"`
	OverallStatus   string            `json:"overall_status"`
}
