package notification

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var ErrInvalidInput = errors.New("invalid notification input")

type Service interface {
	Create(ctx context.Context, input NewNotification) (Notification, error)
	ListByUser(ctx context.Context, userID string) ([]Notification, error)
	MarkReadForUser(
		ctx context.Context,
		userID string,
		notificationID string,
	) (Notification, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) Create(
	ctx context.Context,
	input NewNotification,
) (Notification, error) {
	input.Title = strings.TrimSpace(input.Title)
	input.Message = strings.TrimSpace(input.Message)
	input.NotificationType = strings.TrimSpace(input.NotificationType)
	if input.NotificationType == "" {
		input.NotificationType = TypeVehicleAlert
	}

	if !identifier.IsUUID(input.UserID) ||
		(input.AlertID != nil && !identifier.IsUUID(*input.AlertID)) ||
		(input.ServiceRequestID != nil && !identifier.IsUUID(*input.ServiceRequestID)) ||
		!isValidType(input.NotificationType) ||
		!hasReferenceForType(input) ||
		input.Title == "" ||
		input.Message == "" {
		return Notification{}, ErrInvalidInput
	}

	return s.repository.Create(ctx, input)
}

func isValidType(value string) bool {
	return value == TypeVehicleAlert ||
		value == TypeServiceRequestAssigned ||
		value == TypeServiceRequestStarted ||
		value == TypeServiceRequestCompleted
}

func hasReferenceForType(input NewNotification) bool {
	if input.NotificationType == TypeVehicleAlert {
		return input.AlertID != nil
	}

	return input.ServiceRequestID != nil
}

func (s *service) ListByUser(
	ctx context.Context,
	userID string,
) ([]Notification, error) {
	if !identifier.IsUUID(userID) {
		return nil, ErrNotFound
	}

	return s.repository.ListByUser(ctx, userID)
}

func (s *service) MarkReadForUser(
	ctx context.Context,
	userID string,
	notificationID string,
) (Notification, error) {
	if !identifier.IsUUID(userID) || !identifier.IsUUID(notificationID) {
		return Notification{}, ErrNotFound
	}

	return s.repository.MarkReadForUser(ctx, userID, notificationID)
}
