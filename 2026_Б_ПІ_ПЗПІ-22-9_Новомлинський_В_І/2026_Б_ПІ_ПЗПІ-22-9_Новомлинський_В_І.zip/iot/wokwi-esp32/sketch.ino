/*
  Autonexis ESP32/Wokwi telemetry simulator.

  This sketch represents the IoT layer in the monitoring architecture:
  ESP32/Wokwi -> MQTT broker -> Go backend MQTT consumer -> PostgreSQL.

  Wokwi can connect to public or otherwise reachable MQTT brokers over WiFi.
  A local Docker broker on "localhost" is normally not reachable from Wokwi.
*/

#include <WiFi.h>
#include <PubSubClient.h>

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// For Wokwi demo mode, use a public or otherwise reachable broker.
// For local Docker validation, use backend README instructions with mosquitto_pub.
const char* MQTT_SERVER = "broker.hivemq.com";
const int MQTT_PORT = 1883;

const char* DEVICE_UID = "esp32-demo-002";

const unsigned long PUBLISH_INTERVAL_MS = 5000;

const int ENGINE_TEMPERATURE_PIN = 34;
const int BATTERY_VOLTAGE_PIN = 35;
const int VIBRATION_LEVEL_PIN = 32;
const int RPM_PIN = 33;
const int ADC_MAX_VALUE = 4095;

WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);

char mqttTopic[96];
unsigned long lastPublishAt = 0;
unsigned long messageCounter = 0;

void setup() {
  Serial.begin(115200);
  delay(200);

  snprintf(mqttTopic, sizeof(mqttTopic), "autonexis/devices/%s/telemetry", DEVICE_UID);

  Serial.println("Autonexis ESP32 telemetry simulator starting...");
  Serial.print("Device UID: ");
  Serial.println(DEVICE_UID);
  Serial.print("Topic: ");
  Serial.println(mqttTopic);
  analogReadResolution(12);
  connectWiFi();

  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  connectMQTT();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  if (!mqttClient.connected()) {
    connectMQTT();
  }

  mqttClient.loop();

  unsigned long now = millis();
  if (now - lastPublishAt >= PUBLISH_INTERVAL_MS) {
    lastPublishAt = now;
    publishTelemetry();
  }
}

void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print("WiFi connected, IP address: ");
  Serial.println(WiFi.localIP());
}

void connectMQTT() {
  while (!mqttClient.connected()) {
    Serial.print("Connecting to MQTT broker ");
    Serial.print(MQTT_SERVER);
    Serial.print(":");
    Serial.print(MQTT_PORT);
    Serial.print(" ... ");

    char clientId[96];
    snprintf(
      clientId,
      sizeof(clientId),
      "autonexis-wokwi-%s-%04lx",
      DEVICE_UID,
      (unsigned long)random(0xffff)
    );

    if (mqttClient.connect(clientId)) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println("; retrying in 2 seconds");
      delay(2000);
    }
  }
}

void publishTelemetry() {
  messageCounter++;

  int rawEngineTemperature = analogRead(ENGINE_TEMPERATURE_PIN);
  int rawBatteryVoltage = analogRead(BATTERY_VOLTAGE_PIN);
  int rawVibrationLevel = analogRead(VIBRATION_LEVEL_PIN);
  int rawRPM = analogRead(RPM_PIN);

  float engineTemperature = mapADC(rawEngineTemperature, 60.0, 120.0);
  float batteryVoltage = mapADC(rawBatteryVoltage, 10.5, 14.8);
  float vibrationLevel = mapADC(rawVibrationLevel, 0.0, 3.0);
  int rpm = (int)(mapADC(rawRPM, 600.0, 4500.0) + 0.5);
  float speed = 55.0 + (messageCounter % 9) * 3.5;
  float fuelLevel = 70.0 - (messageCounter % 20) * 0.6;

  char payload[384];
  snprintf(
    payload,
    sizeof(payload),
    "{\"engine_temperature\":%.1f,\"battery_voltage\":%.1f,\"vibration_level\":%.1f,\"rpm\":%d,\"speed\":%d,\"fuel_level\":%.1f}",
    engineTemperature,
    batteryVoltage,
    vibrationLevel,
    rpm,
    (int)speed,
    fuelLevel
  );

  bool published = mqttClient.publish(mqttTopic, payload);

  Serial.print("Device UID: ");
  Serial.println(DEVICE_UID);
  Serial.print("Raw ADC readings - temperature: ");
  Serial.print(rawEngineTemperature);
  Serial.print(", battery: ");
  Serial.print(rawBatteryVoltage);
  Serial.print(", vibration: ");
  Serial.print(rawVibrationLevel);
  Serial.print(", rpm: ");
  Serial.println(rawRPM);
  Serial.print("Mapped telemetry - engine_temperature: ");
  Serial.print(engineTemperature, 1);
  Serial.print(" C, battery_voltage: ");
  Serial.print(batteryVoltage, 1);
  Serial.print(" V, vibration_level: ");
  Serial.print(vibrationLevel, 1);
  Serial.print(", rpm: ");
  Serial.println(rpm);
  Serial.print("Topic: ");
  Serial.println(mqttTopic);
  Serial.print("Payload: ");
  Serial.println(payload);
  Serial.print("Publish result: ");
  Serial.println(published ? "success" : "failed");
  Serial.println();
}

float mapADC(int rawValue, float minimum, float maximum) {
  int constrainedRaw = constrain(rawValue, 0, ADC_MAX_VALUE);
  return minimum + (maximum - minimum) * ((float)constrainedRaw / ADC_MAX_VALUE);
}
