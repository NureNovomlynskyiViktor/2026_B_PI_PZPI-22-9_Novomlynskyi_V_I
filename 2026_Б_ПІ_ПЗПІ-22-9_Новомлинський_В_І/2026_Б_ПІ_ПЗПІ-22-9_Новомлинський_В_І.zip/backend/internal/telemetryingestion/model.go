package telemetryingestion

import (
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
)

type Input struct {
	MeasuredAt        *time.Time `json:"measured_at"`
	EngineTemperature *float64   `json:"engine_temperature"`
	BatteryVoltage    *float64   `json:"battery_voltage"`
	VibrationLevel    *float64   `json:"vibration_level"`
	RPM               *int       `json:"rpm"`
	Speed             *float64   `json:"speed"`
	FuelLevel         *float64   `json:"fuel_level"`
}

type Result struct {
	Telemetry      telemetry.Record `json:"telemetry"`
	CreatedAlerts  []alert.Alert    `json:"created_alerts"`
	ExistingAlerts []alert.Alert    `json:"existing_alerts"`
	UpdatedAlerts  []alert.Alert    `json:"updated_alerts"`
	ResolvedAlerts []alert.Alert    `json:"resolved_alerts"`
	OverallResult  string           `json:"overall_result"`
}
