package ua.autonexis.mobile.ui.vehicle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.Alert
import ua.autonexis.mobile.R
import ua.autonexis.mobile.AlertLifecyclePresentation
import ua.autonexis.mobile.AlertLifecycleGroups
import ua.autonexis.mobile.ServiceRequest
import ua.autonexis.mobile.ServiceRequestDefaults
import ua.autonexis.mobile.ServiceRequestDraft
import ua.autonexis.mobile.TelemetryRecord
import ua.autonexis.mobile.ThresholdRule
import ua.autonexis.mobile.VehicleStatus
import ua.autonexis.mobile.ui.UiStringResources
import ua.autonexis.mobile.ui.owner.OwnerNavigationBar
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets

private enum class VehicleAlertSection {
    ACTIVE,
    CLEARED,
    RESOLVED,
    OTHER,
}

@Composable
internal fun VehicleDetailsRoot(
    state: VehicleDetailsUiState,
    notificationUnreadCount: Int,
    onBackToVehicles: () -> Unit,
    onRefresh: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
    onRecentTelemetry: (String) -> Unit,
    onMaintenanceHistory: (String) -> Unit,
    onServiceRequests: (String) -> Unit,
    onCreateManualServiceRequest: (String, ServiceRequestDraft) -> Unit,
    onCreateServiceRequestForAlert: (String, ServiceRequestDraft) -> Unit,
    onShowResolvedHistory: () -> Unit,
    onBackToOverview: () -> Unit,
) {
    val data = state.data
    val backAction = if (state.destination == VehicleDetailsDestination.RESOLVED_HISTORY) onBackToOverview else onBackToVehicles
    BackHandler(onBack = backAction)

    Scaffold(
        topBar = {
            VehicleTopBar(
                title = if (state.destination == VehicleDetailsDestination.RESOLVED_HISTORY) {
                    stringResource(R.string.resolved_incidents)
                } else {
                    data?.status?.vehicle?.let { "${it.brand} ${it.model}".trim() } ?: stringResource(R.string.vehicle_details)
                },
                isBusy = state.isLoading || state.isRefreshing,
                onBack = backAction,
                onRefresh = onRefresh,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = OwnerNavigationTab.VEHICLES,
                notificationUnreadCount = notificationUnreadCount,
                onVehicles = onBackToVehicles,
                onRequests = onRequests,
                onNotifications = onNotifications,
            onAccount = onAccount,
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && data == null -> VehicleLoadingState(state.message ?: stringResource(R.string.loading_vehicle_status))
                state.isError && data == null -> VehicleInitialErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_vehicle_details_message),
                    onRetry = onRefresh,
                    onBack = onBackToVehicles,
                )
                data != null -> {
                    if (state.destination == VehicleDetailsDestination.RESOLVED_HISTORY) {
                        ResolvedHistoryContent(
                            data = data,
                            onBackToOverview = onBackToOverview,
                        )
                    } else {
                        VehicleDetailsContent(
                            state = state,
                            data = data,
                            onRecentTelemetry = onRecentTelemetry,
                            onMaintenanceHistory = onMaintenanceHistory,
                            onServiceRequests = onServiceRequests,
                            onCreateManualServiceRequest = onCreateManualServiceRequest,
                            onCreateServiceRequestForAlert = onCreateServiceRequestForAlert,
                            onShowResolvedHistory = onShowResolvedHistory,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VehicleDetailsContent(
    state: VehicleDetailsUiState,
    data: VehicleDetailsData,
    onRecentTelemetry: (String) -> Unit,
    onMaintenanceHistory: (String) -> Unit,
    onServiceRequests: (String) -> Unit,
    onCreateManualServiceRequest: (String, ServiceRequestDraft) -> Unit,
    onCreateServiceRequestForAlert: (String, ServiceRequestDraft) -> Unit,
    onShowResolvedHistory: () -> Unit,
) {
    val status = data.status
    val vehicleId = status.vehicle.id
    val groups = AlertLifecyclePresentation.group(data.alerts)
    val inspectionAlert = AlertLifecyclePresentation.latestClearedCriticalWhenInspectionRecommended(
        status.overallStatus,
        data.alerts,
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 96.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        item { VehicleSummaryHeroCard(status) }
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_status)) }
        }
        inspectionAlert?.let { alert ->
            item { InspectionRecommendedBanner(alert) }
        }
        item { LatestTelemetryCard(status.latestTelemetry, onRecentTelemetry = { onRecentTelemetry(vehicleId) }) }
        item { AssignedDeviceCard(status) }
        item {
            QuickActionsCard(
                onMaintenanceHistory = { onMaintenanceHistory(vehicleId) },
                onServiceRequests = { onServiceRequests(vehicleId) },
                onCreateManualServiceRequest = {
                    onCreateManualServiceRequest(
                        vehicleId,
                        ServiceRequestDraft(title = "", description = "", priority = "normal"),
                    )
                },
            )
        }
        item {
            AlertSectionCard(
                title = stringResource(R.string.active_conditions),
                description = stringResource(R.string.active_conditions_description),
                alerts = groups.active,
                emptyMessage = stringResource(R.string.active_conditions_empty),
                section = VehicleAlertSection.ACTIVE,
                serviceRequests = data.serviceRequests,
                vehicleId = vehicleId,
                onCreateServiceRequestForAlert = onCreateServiceRequestForAlert,
            )
        }
        item {
            AlertSectionCard(
                title = stringResource(R.string.cleared_awaiting_inspection),
                description = stringResource(R.string.cleared_awaiting_inspection_description),
                alerts = groups.cleared,
                emptyMessage = stringResource(R.string.cleared_awaiting_inspection_empty),
                section = VehicleAlertSection.CLEARED,
                serviceRequests = data.serviceRequests,
                vehicleId = vehicleId,
                onCreateServiceRequestForAlert = onCreateServiceRequestForAlert,
            )
        }
        item {
            ResolvedOverviewCard(
                resolvedAlerts = groups.resolved,
                onShowResolvedHistory = onShowResolvedHistory,
            )
        }
        if (groups.historicalOther.isNotEmpty()) {
            item {
                AlertSectionCard(
                    title = stringResource(R.string.other_incidents),
                    description = stringResource(R.string.other_incidents_description),
                    alerts = groups.historicalOther,
                    emptyMessage = stringResource(R.string.other_incidents_empty),
                    section = VehicleAlertSection.OTHER,
                    serviceRequests = data.serviceRequests,
                    vehicleId = vehicleId,
                    onCreateServiceRequestForAlert = onCreateServiceRequestForAlert,
                )
            }
        }
        item { ThresholdsCard(data.thresholds) }
    }
}

@Composable
private fun localizedMetricLabel(metric: String): String {
    return UiStringResources.metricLabelRes(metric)?.let { stringResource(it) }
        ?: metric.replace('_', ' ').replaceFirstChar { char -> if (char.isLowerCase()) char.titlecase() else char.toString() }
}

@Composable
private fun localizedStatusLabel(status: String?): String {
    val raw = status.orEmpty()
    return UiStringResources.statusLabelRes(raw)?.let { stringResource(it) }
        ?: raw.replace('_', ' ').replaceFirstChar { char -> if (char.isLowerCase()) char.titlecase() else char.toString() }.ifBlank { stringResource(R.string.unknown) }
}

@Composable
private fun localizedTelemetryMetrics(telemetry: TelemetryRecord): List<Pair<String, String>> {
    val values = VehicleDetailsPresentation.telemetryMetrics(telemetry)
    val keys = listOf("engine_temperature", "battery_voltage", "vibration_level", "rpm", "speed", "fuel_level")
    return values.mapIndexed { index, metric ->
        val label = keys.getOrNull(index)?.let { localizedMetricLabel(it) } ?: metric.first
        label to metric.second
    }
}

@Composable
private fun VehicleTopBar(title: String, isBusy: Boolean, onBack: () -> Unit, onRefresh: () -> Unit) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack, enabled = !isBusy) { Text(stringResource(R.string.back)) }
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            TextButton(onClick = onRefresh, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
        }
    }
}

@Composable
private fun VehicleSummaryHeroCard(status: VehicleStatus) {
    val vehicle = status.vehicle
    val label = localizedStatusLabel(status.overallStatus)
    val tone = statusTone(label)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_owner_vehicle),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(30.dp),
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
                ) {
                    Text(
                        text = "${vehicle.brand} ${vehicle.model}".trim().ifBlank { "Vehicle" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    VehicleDetailsPresentation.vehicleMetadata(
                        vehicle.year,
                        vehicle.licensePlate,
                    )?.let { details ->
                        Text(details, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(tone.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
                    .padding(AutonexisSpacing.md),
                verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
            ) {
                Text(stringResource(R.string.overall_technical_status), style = MaterialTheme.typography.labelLarge)
                Text(
                    text = label,
                    color = tone,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
                if (VehicleDetailsPresentation.statusLabel(status.overallStatus) == "UNKNOWN") {
                    Text(stringResource(R.string.waiting_first_telemetry_reading), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun InspectionRecommendedBanner(alert: Alert) {
    Card(colors = CardDefaults.cardColors(containerColor = AutonexisColors.Amber.copy(alpha = 0.12f))) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
        ) {
            Text(
                text = stringResource(R.string.inspection_recommended_title),
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(stringResource(R.string.incident_label, localizedMetricLabel(alert.type)))
            Text(stringResource(R.string.occurrences_label, alert.occurrenceCount))
            Text(stringResource(R.string.last_triggered_label, AlertLifecyclePresentation.displayTimestamp(alert.lastTriggeredAt)))
            Text(stringResource(R.string.cleared_label, AlertLifecyclePresentation.displayTimestamp(alert.clearedAt)))
        }
    }
}

@Composable
private fun LatestTelemetryCard(telemetry: TelemetryRecord?, onRecentTelemetry: () -> Unit) {
    InfoCard {
        SectionHeader(stringResource(R.string.latest_telemetry))
        if (telemetry == null) {
            EmptyText(stringResource(R.string.no_latest_telemetry))
        } else {
            Text(
                text = stringResource(R.string.measured_at_label, AlertLifecyclePresentation.displayTimestamp(telemetry.measuredAt)),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            localizedTelemetryMetrics(telemetry).chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
                    row.forEach { metric ->
                        MetricTile(metric.first, metric.second, modifier = Modifier.weight(1f))
                    }
                    if (row.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
        Button(
            onClick = onRecentTelemetry,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
        ) { Text(stringResource(R.string.view_recent_telemetry)) }
    }
}

@Composable
private fun AssignedDeviceCard(status: VehicleStatus) {
    InfoCard {
        SectionHeader(stringResource(R.string.assigned_device))
        val device = status.device
        if (device == null) {
            EmptyText(stringResource(R.string.no_monitoring_device))
        } else {
            Text(device.name ?: stringResource(R.string.unnamed_device), fontWeight = FontWeight.Bold)
            DetailLine(stringResource(R.string.device_uid), device.deviceUid)
            Text(stringResource(R.string.status_label, localizedStatusLabel(device.status)), color = MaterialTheme.colorScheme.onSurfaceVariant)
            DetailLine(
                stringResource(R.string.last_seen),
                AlertLifecyclePresentation.displayTimestamp(device.lastSeenAt, fallback = stringResource(R.string.na)),
            )
        }
    }
}

@Composable
private fun QuickActionsCard(
    onMaintenanceHistory: () -> Unit,
    onServiceRequests: () -> Unit,
    onCreateManualServiceRequest: () -> Unit,
) {
    InfoCard {
        SectionHeader(stringResource(R.string.vehicle_actions))
        VehicleDetailsPresentation.quickActions().forEach { action ->
            when (action) {
                VehicleQuickAction.MAINTENANCE_HISTORY -> ActionButton(stringResource(R.string.maintenance_history), onMaintenanceHistory)
                VehicleQuickAction.SERVICE_REQUESTS -> ActionButton(stringResource(R.string.service_requests), onServiceRequests)
                VehicleQuickAction.CREATE_MANUAL_SERVICE_REQUEST -> ActionButton(
                    stringResource(R.string.create_manual_service_request),
                    onCreateManualServiceRequest,
                )
            }
        }
    }
}

@Composable
private fun ResolvedOverviewCard(
    resolvedAlerts: List<Alert>,
    onShowResolvedHistory: () -> Unit,
) {
    val sorted = VehicleDetailsPresentation.resolvedIncidentsNewestFirst(resolvedAlerts)
    val previews = VehicleDetailsPresentation.resolvedIncidentOverviewItems(sorted)
    InfoCard {
        SectionHeader(stringResource(R.string.resolved_incidents))
        Text(
            text = pluralStringResource(R.plurals.resolved_incident_count, resolvedAlerts.size, resolvedAlerts.size),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (previews.isEmpty()) {
            EmptyText(stringResource(R.string.no_resolved_incidents))
        } else {
            previews.forEach { preview ->
                ResolvedPreviewCard(preview)
            }
            if (resolvedAlerts.size > previews.size) {
                Button(
                    onClick = onShowResolvedHistory,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) { Text(stringResource(R.string.view_all_resolved_incidents)) }
            }
        }
    }
}

@Composable
private fun ResolvedPreviewCard(preview: ResolvedIncidentPreview) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
        ) {
            Text(localizedMetricLabel(preview.parameter), fontWeight = FontWeight.Bold)
            Badge(stringResource(R.string.max_label, preview.maximumSeverity), severityTone(preview.maximumSeverity))
            DetailLine(stringResource(R.string.resolved_label), preview.resolvedTimestamp)
            Text(stringResource(R.string.occurrence_count_label, preview.occurrenceCount))
            Text(stringResource(preview.resolutionLabelRes), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ResolvedHistoryContent(
    data: VehicleDetailsData,
    onBackToOverview: () -> Unit,
) {
    val resolvedAlerts = VehicleDetailsPresentation.resolvedIncidentsNewestFirst(
        AlertLifecyclePresentation.group(data.alerts).resolved,
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 96.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
    ) {
        item {
            InfoCard {
                SectionHeader(stringResource(R.string.resolved_incident_history))
                Text(
                    text = stringResource(R.string.resolved_history_readonly),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(
                    onClick = onBackToOverview,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) { Text(stringResource(R.string.back_to_vehicle_details)) }
            }
        }
        if (resolvedAlerts.isEmpty()) {
            item {
                InfoCard { EmptyText(stringResource(R.string.no_resolved_incidents)) }
            }
        } else {
            items(resolvedAlerts, key = { it.id }) { alert ->
                IncidentCard(
                    alert = alert,
                    section = VehicleAlertSection.RESOLVED,
                    serviceRequests = data.serviceRequests,
                    onCreateServiceRequest = {},
                )
            }
        }
    }
}
@Composable
private fun AlertSectionCard(
    title: String,
    description: String,
    alerts: List<Alert>,
    emptyMessage: String,
    section: VehicleAlertSection,
    serviceRequests: List<ServiceRequest>,
    vehicleId: String,
    onCreateServiceRequestForAlert: (String, ServiceRequestDraft) -> Unit,
) {
    InfoCard {
        SectionHeader(title)
        Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (alerts.isEmpty()) {
            EmptyText(emptyMessage)
        } else {
            alerts.forEach { alert ->
                val requestTitle = stringResource(R.string.alert_request_title, localizedMetricLabel(alert.type))
                val recommendationLabel = stringResource(R.string.recommendation)
                IncidentCard(
                    alert = alert,
                    section = section,
                    serviceRequests = serviceRequests,
                    onCreateServiceRequest = {
                        onCreateServiceRequestForAlert(
                            vehicleId,
                            ServiceRequestDefaults.fromAlert(
                                alert = alert,
                                title = requestTitle,
                                recommendationLabel = recommendationLabel,
                            ),
                        )
                    },
                )
            }
        }
    }
}

@Composable
private fun IncidentCard(
    alert: Alert,
    section: VehicleAlertSection,
    serviceRequests: List<ServiceRequest>,
    onCreateServiceRequest: () -> Unit,
) {
    val maxSeverity = alert.severity.uppercase()
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        ) {
            Text(localizedMetricLabel(alert.type), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
                Badge(stringResource(R.string.status_label, localizedStatusLabel(alert.status)), MaterialTheme.colorScheme.onSurfaceVariant)
                Badge(stringResource(R.string.max_label, localizedStatusLabel(alert.severity).uppercase()), severityTone(alert.severity))
            }
            if (section == VehicleAlertSection.ACTIVE && VehicleDetailsPresentation.shouldShowCurrentSeverity(alert)) {
                Badge(stringResource(R.string.current_label, localizedStatusLabel(alert.currentSeverity).uppercase()), severityTone(alert.currentSeverity))
            }
            Text(stringResource(R.string.occurrence_count_label, alert.occurrenceCount))
            Text(alert.message)
            alert.recommendation?.takeIf { it.isNotBlank() }?.let { recommendation ->
                Text(stringResource(R.string.recommendation_label, recommendation), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DetailLine(stringResource(R.string.created_label), AlertLifecyclePresentation.displayTimestamp(alert.createdAt))
            DetailLine(stringResource(R.string.last_seen), AlertLifecyclePresentation.displayTimestamp(alert.lastTriggeredAt))
            if (section == VehicleAlertSection.CLEARED || section == VehicleAlertSection.RESOLVED || section == VehicleAlertSection.OTHER) {
                alert.clearedAt?.let { Text(stringResource(R.string.cleared_label, AlertLifecyclePresentation.displayTimestamp(it)), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            if (section == VehicleAlertSection.RESOLVED || section == VehicleAlertSection.OTHER) {
                alert.resolvedAt?.let { DetailLine(stringResource(R.string.resolved_label), AlertLifecyclePresentation.displayTimestamp(it)) }
            }
            if (alert.recoveryStreak > 0) {
                Text(
                    text = stringResource(R.string.stabilization_progress, alert.recoveryStreak),
                    color = AutonexisColors.EmeraldGreen,
                )
            }
            if (section == VehicleAlertSection.CLEARED) {
                Text(
                    text = stringResource(R.string.cleared_awaiting_inspection_description),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (section == VehicleAlertSection.ACTIVE || section == VehicleAlertSection.CLEARED) {
                if (AlertLifecyclePresentation.isWarningOrCritical(alert)) {
                    val openRequest = AlertLifecyclePresentation.openLinkedServiceRequest(alert, serviceRequests)
                    if (openRequest == null) {
                        Button(
                            onClick = onCreateServiceRequest,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                        ) { Text(stringResource(R.string.create_service_request)) }
                    } else {
                        Text(stringResource(R.string.open_linked_request_status, localizedStatusLabel(openRequest.status)))
                    }
                }
            }
            if (section == VehicleAlertSection.RESOLVED) {
                Text(stringResource(AlertLifecyclePresentation.resolvedHistoryLabelRes(alert)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                alert.resolutionNote?.takeIf { it.isNotBlank() }?.let { note ->
                    Text(stringResource(R.string.resolution_note_label, note))
                }
                AlertLifecyclePresentation.linkedResolutionServiceRequest(alert, serviceRequests)?.let { request ->
                    Text(stringResource(R.string.linked_request_label, request.title))
                    Text(stringResource(R.string.request_status_label, localizedStatusLabel(request.status)))
                    request.resultSummary?.takeIf { it.isNotBlank() }?.let { result ->
                        Text(stringResource(R.string.result_label, result))
                    }
                }
            }
        }
    }
}

@Composable
private fun ThresholdsCard(thresholds: List<ThresholdRule>) {
    InfoCard {
        SectionHeader(stringResource(R.string.technical_thresholds))
        Text(stringResource(R.string.thresholds_readonly), color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (thresholds.isEmpty()) {
            EmptyText(stringResource(R.string.no_thresholds))
        } else {
            thresholds.forEach { threshold ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))) {
                    Column(
                        modifier = Modifier.padding(AutonexisSpacing.md),
                        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
                    ) {
                        Text(
                            text = "${localizedMetricLabel(threshold.metric)} / ${threshold.severity.uppercase()}",
                            fontWeight = FontWeight.Bold,
                        )
                        Text("${threshold.value} ${threshold.unit}")
                        threshold.description.takeIf { it.isNotBlank() }?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        }
    }
}

@Composable
private fun VehicleLoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun VehicleInitialErrorState(message: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(stringResource(R.string.could_not_load_vehicle_details), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onBack) { Text(stringResource(R.string.back_to_vehicles)) }
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            content = content,
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable
private fun MetricTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
    ) { Text(label) }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Text("$label: $value", color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun EmptyText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
    )
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Badge(label: String, color: Color) {
    Text(
        text = label,
        color = color,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(999.dp))
            .padding(horizontal = AutonexisSpacing.sm, vertical = AutonexisSpacing.xs),
    )
}

@Composable
private fun statusTone(label: String): Color {
    return when (label) {
        "NORMAL" -> AutonexisColors.EmeraldGreen
        "WARNING" -> AutonexisColors.Amber
        "CRITICAL" -> AutonexisColors.CriticalRed
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}

@Composable
private fun severityTone(severity: String?): Color {
    return when (severity?.lowercase()) {
        "warning" -> AutonexisColors.Amber
        "critical" -> AutonexisColors.CriticalRed
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}
