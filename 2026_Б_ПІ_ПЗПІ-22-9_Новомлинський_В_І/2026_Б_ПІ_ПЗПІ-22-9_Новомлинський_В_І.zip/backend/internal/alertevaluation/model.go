package alertevaluation

import "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"

type Result struct {
	VehicleID         string        `json:"vehicle_id"`
	TelemetryRecordID int64         `json:"telemetry_record_id"`
	EvaluatedRules    int           `json:"evaluated_rules"`
	CreatedAlerts     []alert.Alert `json:"created_alerts"`
	ExistingAlerts    []alert.Alert `json:"existing_alerts"`
	UpdatedAlerts     []alert.Alert `json:"updated_alerts"`
	ResolvedAlerts    []alert.Alert `json:"resolved_alerts"`
	OverallResult     string        `json:"overall_result"`
}
