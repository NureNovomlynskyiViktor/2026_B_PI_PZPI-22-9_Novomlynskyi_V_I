﻿import { useId } from 'react';
import { useLocale, type LanguageMode } from '../../i18n';

type Props = {
  className?: string;
};

export function LanguageSelector({ className = '' }: Props) {
  const selectID = useId();
  const { languageMode, messages, setLanguageMode } = useLocale();
  const t = messages.language;

  return (
    <label className={className ? `language-selector ${className}` : 'language-selector'} htmlFor={selectID}>
      <span>{t.label}</span>
      <select
        id={selectID}
        value={languageMode}
        onChange={(event) => setLanguageMode(event.target.value as LanguageMode)}
      >
        <option value="system">{t.system}</option>
        <option value="en">{t.english}</option>
        <option value="uk">{t.ukrainian}</option>
      </select>
    </label>
  );
}
