package auditlog

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
)

var ErrWriteFailed = errors.New("audit write failed")

type Executor interface {
	ExecContext(ctx context.Context, query string, args ...any) (sql.Result, error)
}

type Entry struct {
	ActorID    string
	Action     string
	EntityType string
	EntityID   string
	Metadata   any
}

type Writer interface {
	Write(ctx context.Context, executor Executor, entry Entry) error
}

type PostgresWriter struct{}

func NewPostgresWriter() PostgresWriter {
	return PostgresWriter{}
}

func (PostgresWriter) Write(
	ctx context.Context,
	executor Executor,
	entry Entry,
) error {
	payload, err := json.Marshal(entry.Metadata)
	if err != nil {
		return fmt.Errorf("%w: encode metadata: %v", ErrWriteFailed, err)
	}
	if len(payload) == 0 || string(payload) == "null" {
		payload = []byte(`{}`)
	}

	const query = `
		INSERT INTO audit_logs (
			user_id,
			action,
			entity_type,
			entity_id,
			metadata
		)
		VALUES ($1, $2, $3, $4, $5)
	`

	if _, err := executor.ExecContext(
		ctx,
		query,
		entry.ActorID,
		entry.Action,
		entry.EntityType,
		entry.EntityID,
		payload,
	); err != nil {
		return fmt.Errorf("%w: %v", ErrWriteFailed, err)
	}

	return nil
}
