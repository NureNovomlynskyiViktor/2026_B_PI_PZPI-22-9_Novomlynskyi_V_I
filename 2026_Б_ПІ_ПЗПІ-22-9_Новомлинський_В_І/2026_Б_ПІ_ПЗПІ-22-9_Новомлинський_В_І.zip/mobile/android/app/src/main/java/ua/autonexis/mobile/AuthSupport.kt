package ua.autonexis.mobile

internal fun googleLoginRequestBody(idToken: String): String {
    return "{\"id_token\":\"${jsonEscape(idToken)}\"}"
}

private fun jsonEscape(value: String): String {
    return buildString {
        value.forEach { character ->
            when (character) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(character)
            }
        }
    }
}

internal data class AuthenticationSuccess(
    val baseUrl: String,
    val accessToken: String,
    val user: User,
    val opensOwnerDashboard: Boolean,
)

internal fun authenticationSuccess(baseUrl: String, result: AuthResult): AuthenticationSuccess {
    return AuthenticationSuccess(
        baseUrl = baseUrl.trim().trimEnd('/'),
        accessToken = result.accessToken,
        user = result.user,
        opensOwnerDashboard = result.user.role == "vehicle_owner",
    )
}