package notification

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
)

var ErrNotFound = errors.New("notification not found")

type Repository interface {
	Create(ctx context.Context, input NewNotification) (Notification, error)
	ListByUser(ctx context.Context, userID string) ([]Notification, error)
	MarkReadForUser(
		ctx context.Context,
		userID string,
		notificationID string,
	) (Notification, error)
}

type Executor interface {
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

type Writer interface {
	Create(ctx context.Context, executor Executor, input NewNotification) (Notification, error)
}

type PostgresRepository struct {
	db     *sql.DB
	writer Writer
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
	return &PostgresRepository{
		db:     db,
		writer: PostgresWriter{},
	}
}

func (r *PostgresRepository) Create(
	ctx context.Context,
	input NewNotification,
) (Notification, error) {
	return r.writer.Create(ctx, r.db, input)
}

type PostgresWriter struct{}

func NewPostgresWriter() PostgresWriter {
	return PostgresWriter{}
}

func (PostgresWriter) Create(
	ctx context.Context,
	executor Executor,
	input NewNotification,
) (Notification, error) {
	const query = `
		INSERT INTO notifications (
			user_id,
			alert_id,
			service_request_id,
			notification_type,
			title,
			message
		)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING
			id,
			user_id,
			alert_id,
			service_request_id,
			notification_type,
			title,
			message,
			is_read,
			created_at
	`

	item, err := scanNotification(executor.QueryRowContext(
		ctx,
		query,
		input.UserID,
		input.AlertID,
		input.ServiceRequestID,
		input.NotificationType,
		input.Title,
		input.Message,
	))
	if err != nil {
		return Notification{}, fmt.Errorf("insert notification: %w", err)
	}

	return item, nil
}

func (r *PostgresRepository) ListByUser(
	ctx context.Context,
	userID string,
) ([]Notification, error) {
	const query = `
		SELECT
			id,
			user_id,
			alert_id,
			service_request_id,
			notification_type,
			title,
			message,
			is_read,
			created_at
		FROM notifications
		WHERE user_id = $1
		ORDER BY created_at DESC, id DESC
	`

	rows, err := r.db.QueryContext(ctx, query, userID)
	if err != nil {
		return nil, fmt.Errorf("query notifications: %w", err)
	}
	defer rows.Close()

	items := make([]Notification, 0)
	for rows.Next() {
		item, err := scanNotification(rows)
		if err != nil {
			return nil, fmt.Errorf("scan notification: %w", err)
		}
		items = append(items, item)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate notifications: %w", err)
	}

	return items, nil
}

func (r *PostgresRepository) MarkReadForUser(
	ctx context.Context,
	userID string,
	notificationID string,
) (Notification, error) {
	const query = `
		UPDATE notifications
		SET is_read = TRUE
		WHERE id = $1
		  AND user_id = $2
		RETURNING
			id,
			user_id,
			alert_id,
			service_request_id,
			notification_type,
			title,
			message,
			is_read,
			created_at
	`

	item, err := scanNotification(r.db.QueryRowContext(
		ctx,
		query,
		notificationID,
		userID,
	))
	if errors.Is(err, sql.ErrNoRows) {
		return Notification{}, ErrNotFound
	}
	if err != nil {
		return Notification{}, fmt.Errorf("mark notification read: %w", err)
	}

	return item, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanNotification(row scanner) (Notification, error) {
	var item Notification
	var alertID sql.NullString
	var serviceRequestID sql.NullString
	if err := row.Scan(
		&item.ID,
		&item.UserID,
		&alertID,
		&serviceRequestID,
		&item.NotificationType,
		&item.Title,
		&item.Message,
		&item.IsRead,
		&item.CreatedAt,
	); err != nil {
		return Notification{}, err
	}

	if alertID.Valid {
		item.AlertID = &alertID.String
	}
	if serviceRequestID.Valid {
		item.ServiceRequestID = &serviceRequestID.String
	}

	return item, nil
}
