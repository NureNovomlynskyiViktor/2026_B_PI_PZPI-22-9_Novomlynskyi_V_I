package adminuser

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

const maxReasonLength = 500

var (
	ErrInvalidInput     = errors.New("invalid admin user input")
	ErrSelfDeactivation = errors.New("administrator cannot deactivate own account")
)

type Service interface {
	List(ctx context.Context, filters ListFilters) ([]User, error)
	Get(ctx context.Context, userID string) (User, error)
	Deactivate(ctx context.Context, actor auth.User, userID string, request DeactivateRequest) (User, error)
	Reactivate(ctx context.Context, actor auth.User, userID string) (User, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) List(ctx context.Context, filters ListFilters) ([]User, error) {
	filters.Role = strings.TrimSpace(filters.Role)
	filters.Search = strings.TrimSpace(filters.Search)
	if filters.Role != "" && !isValidRole(filters.Role) {
		return nil, ErrInvalidInput
	}

	return s.repository.List(ctx, filters)
}

func (s *service) Get(ctx context.Context, userID string) (User, error) {
	if !identifier.IsUUID(userID) {
		return User{}, ErrInvalidInput
	}

	return s.repository.GetByID(ctx, userID)
}

func (s *service) Deactivate(
	ctx context.Context,
	actor auth.User,
	userID string,
	request DeactivateRequest,
) (User, error) {
	if !identifier.IsUUID(actor.ID) || !identifier.IsUUID(userID) {
		return User{}, ErrInvalidInput
	}
	if actor.ID == userID {
		return User{}, ErrSelfDeactivation
	}

	reason, err := normalizeReason(request.Reason)
	if err != nil {
		return User{}, err
	}

	return s.repository.Deactivate(ctx, actor.ID, userID, reason)
}

func (s *service) Reactivate(
	ctx context.Context,
	actor auth.User,
	userID string,
) (User, error) {
	if !identifier.IsUUID(actor.ID) || !identifier.IsUUID(userID) {
		return User{}, ErrInvalidInput
	}

	return s.repository.Reactivate(ctx, actor.ID, userID)
}

func normalizeReason(value string) (*string, error) {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return nil, nil
	}
	if len([]rune(trimmed)) > maxReasonLength {
		return nil, ErrInvalidInput
	}

	return &trimmed, nil
}

func isValidRole(role string) bool {
	return role == auth.DefaultRoleCode ||
		role == auth.TechnicalSpecialistRoleCode ||
		role == auth.AdministratorRoleCode
}
