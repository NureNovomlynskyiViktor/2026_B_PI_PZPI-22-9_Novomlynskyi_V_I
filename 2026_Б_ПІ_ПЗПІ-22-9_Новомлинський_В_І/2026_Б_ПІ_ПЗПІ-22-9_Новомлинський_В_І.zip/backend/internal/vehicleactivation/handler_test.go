package vehicleactivation

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

type serviceStub struct {
	createResponse AdminCreateResponse
	claimVehicle   vehicle.Vehicle
	err            error
	createRequest  AdminCreateRequest
	claimRequest   ClaimRequest
}

func (s *serviceStub) Create(
	_ context.Context,
	_ auth.User,
	request AdminCreateRequest,
) (AdminCreateResponse, error) {
	s.createRequest = request
	return s.createResponse, s.err
}

func (s *serviceStub) Claim(
	_ context.Context,
	_ auth.User,
	request ClaimRequest,
) (vehicle.Vehicle, error) {
	s.claimRequest = request
	return s.claimVehicle, s.err
}

func TestHandlerCreateRequiresAdmin(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())
	request := requestWithUser(
		http.MethodPost,
		"/api/v1/admin/vehicle-activations",
		`{"vin":"AUTONEXISDEMO0002"}`,
		auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode},
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestHandlerCreateReturnsActivationCodeOnce(t *testing.T) {
	expiresAt := time.Date(2026, 6, 18, 12, 0, 0, 0, time.UTC)
	service := &serviceStub{
		createResponse: AdminCreateResponse{
			Vehicle:        vehicle.Vehicle{ID: testVehicleID, Brand: "Toyota", Model: "Corolla"},
			Device:         device.Device{ID: testDeviceID, Status: "inactive"},
			ActivationCode: "AX7K-29QP",
			ActivationURI:  "autonexis://vehicle-activation?code=AX7K-29QP",
			ExpiresAt:      expiresAt,
		},
	}
	handler := NewHandler(service, testLogger())
	request := requestWithUser(
		http.MethodPost,
		"/api/v1/admin/vehicle-activations",
		`{
			"vin":"AUTONEXISDEMO0002",
			"brand":"Toyota",
			"model":"Corolla",
			"year":2022,
			"license_plate":"AX-0002",
			"device_uid":"esp32-demo-002",
			"device_name":"Owner ESP32"
		}`,
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if !strings.Contains(recorder.Body.String(), `"activation_code":"AX7K-29QP"`) {
		t.Fatalf("expected activation code in response, got %s", recorder.Body.String())
	}
	if !strings.Contains(recorder.Body.String(), `"activation_uri":"autonexis://vehicle-activation?code=AX7K-29QP"`) {
		t.Fatalf("expected activation URI in response, got %s", recorder.Body.String())
	}
	if service.createRequest.DeviceUID != "esp32-demo-002" {
		t.Fatalf("expected request body to be decoded, got %#v", service.createRequest)
	}
}

func TestHandlerCreateDuplicateConflict(t *testing.T) {
	handler := NewHandler(&serviceStub{err: ErrDuplicateDevice}, testLogger())
	request := requestWithUser(
		http.MethodPost,
		"/api/v1/admin/vehicle-activations",
		`{
			"vin":"AUTONEXISDEMO0002",
			"brand":"Toyota",
			"model":"Corolla",
			"year":2022,
			"license_plate":"AX-0002",
			"device_uid":"esp32-demo-002",
			"device_name":"Owner ESP32"
		}`,
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
	)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func TestHandlerClaimRequiresOwner(t *testing.T) {
	handler := NewHandler(&serviceStub{}, testLogger())
	request := requestWithUser(
		http.MethodPost,
		"/api/v1/me/vehicle-activations/claim",
		`{"activation_code":"AX7K-29QP"}`,
		auth.User{ID: testAdminID, Role: auth.AdministratorRoleCode},
	)
	recorder := httptest.NewRecorder()

	handler.Claim(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestHandlerClaimSuccess(t *testing.T) {
	service := &serviceStub{claimVehicle: vehicle.Vehicle{ID: testVehicleID, OwnerID: testOwnerID}}
	handler := NewHandler(service, testLogger())
	request := requestWithUser(
		http.MethodPost,
		"/api/v1/me/vehicle-activations/claim",
		`{"activation_code":"AX7K-29QP"}`,
		auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode},
	)
	recorder := httptest.NewRecorder()

	handler.Claim(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.claimRequest.ActivationCode != "AX7K-29QP" {
		t.Fatalf("expected claim request to be decoded, got %#v", service.claimRequest)
	}
	if !strings.Contains(recorder.Body.String(), `"owner_id":"`+testOwnerID+`"`) {
		t.Fatalf("expected claimed vehicle response, got %s", recorder.Body.String())
	}
}

func TestHandlerClaimUsedConflict(t *testing.T) {
	handler := NewHandler(&serviceStub{err: ErrAlreadyClaimed}, testLogger())
	request := requestWithUser(
		http.MethodPost,
		"/api/v1/me/vehicle-activations/claim",
		`{"activation_code":"AX7K-29QP"}`,
		auth.User{ID: testOwnerID, Role: auth.DefaultRoleCode},
	)
	recorder := httptest.NewRecorder()

	handler.Claim(recorder, request)

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func requestWithUser(method string, path string, body string, user auth.User) *http.Request {
	request := httptest.NewRequest(method, path, strings.NewReader(body))
	return request.WithContext(auth.WithUser(request.Context(), user))
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
