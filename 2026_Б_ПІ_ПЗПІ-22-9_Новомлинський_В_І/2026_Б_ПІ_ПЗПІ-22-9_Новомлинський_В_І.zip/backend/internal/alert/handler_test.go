package alert

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

const (
	testVehicleID = "22222222-2222-2222-2222-222222222222"
	testAlertID   = "44444444-4444-4444-4444-444444444441"
)

type stubService struct {
	alerts []Alert
	alert  Alert
	err    error
	limit  int
}

func (s *stubService) ListByVehicle(
	_ context.Context,
	_ string,
	limit int,
) ([]Alert, error) {
	s.limit = limit
	return s.alerts, s.err
}

func (s *stubService) ListByVehicleStatus(
	context.Context,
	string,
	string,
	int,
) ([]Alert, error) {
	return s.alerts, s.err
}

func (s *stubService) ListActiveByVehicle(
	context.Context,
	string,
) ([]Alert, error) {
	return s.alerts, s.err
}

func (s *stubService) GetByID(context.Context, string) (Alert, error) {
	return s.alert, s.err
}

func (s *stubService) ResolveBySpecialist(context.Context, SpecialistResolution) (Alert, error) {
	return s.alert, s.err
}

func TestHandlerListUsesDefaultLimit(t *testing.T) {
	service := &stubService{alerts: []Alert{}}
	handler := NewHandler(service, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/alerts",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, recorder.Code)
	}
	if service.limit != DefaultLimit {
		t.Fatalf("expected default limit %d, got %d", DefaultLimit, service.limit)
	}
	if body := strings.TrimSpace(recorder.Body.String()); body != "[]" {
		t.Fatalf("expected empty JSON array, got %s", body)
	}
}

func TestHandlerListActiveRejectsInvalidVehicleID(t *testing.T) {
	handler := NewHandler(
		&stubService{err: ErrInvalidVehicleID},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/invalid/alerts/active",
		nil,
	)
	request.SetPathValue("vehicle_id", "invalid")
	recorder := httptest.NewRecorder()

	handler.ListActiveByVehicle(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerGetRejectsInvalidID(t *testing.T) {
	handler := NewHandler(&stubService{err: ErrInvalidAlertID}, testLogger())
	request := httptest.NewRequest(http.MethodGet, "/api/v1/alerts/123", nil)
	request.SetPathValue("id", "123")
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func TestHandlerGetNotFound(t *testing.T) {
	handler := NewHandler(&stubService{err: ErrNotFound}, testLogger())
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/alerts/"+testAlertID,
		nil,
	)
	request.SetPathValue("id", testAlertID)
	recorder := httptest.NewRecorder()

	handler.GetByID(recorder, request)

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestHandlerDoesNotExposeInternalError(t *testing.T) {
	handler := NewHandler(
		&stubService{err: errors.New("database details")},
		testLogger(),
	)
	request := httptest.NewRequest(
		http.MethodGet,
		"/api/v1/vehicles/"+testVehicleID+"/alerts",
		nil,
	)
	request.SetPathValue("vehicle_id", testVehicleID)
	recorder := httptest.NewRecorder()

	handler.ListByVehicle(recorder, request)

	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, recorder.Code)
	}
	if strings.Contains(recorder.Body.String(), "database details") {
		t.Fatal("response exposed an internal error")
	}
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
