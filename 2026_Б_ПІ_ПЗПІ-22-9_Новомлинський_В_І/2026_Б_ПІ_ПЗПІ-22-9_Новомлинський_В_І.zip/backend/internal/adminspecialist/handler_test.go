package adminspecialist

import (
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
)

type serviceStub struct {
	request CreateRequest
	err     error
}

func (s *serviceStub) Create(_ context.Context, _ auth.User, request CreateRequest) (CreateResult, error) {
	s.request = request
	if s.err != nil {
		return CreateResult{}, s.err
	}

	return CreateResult{
		User: auth.User{
			ID:       "22222222-2222-2222-2222-222222222222",
			Role:     auth.TechnicalSpecialistRoleCode,
			Email:    request.Email,
			FullName: request.Name,
			IsActive: true,
		},
		Competencies: []specialistcompetency.Competency{{
			Code: specialistcompetency.CodeEngineDiagnostics,
			Name: "Engine diagnostics",
		}},
	}, nil
}

func TestCreateRequiresAdministrator(t *testing.T) {
	handler := newTestHandler(&serviceStub{})
	request := httptest.NewRequest(http.MethodPost, "/api/v1/admin/specialists", strings.NewReader(`{}`))
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:   testAdminID,
		Role: auth.DefaultRoleCode,
	}))
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusForbidden {
		t.Fatalf("expected status %d, got %d", http.StatusForbidden, recorder.Code)
	}
}

func TestCreateReturnsCreatedSpecialist(t *testing.T) {
	service := &serviceStub{}
	handler := newTestHandler(service)
	request := adminCreateRequest(`{"email":"specialist.new@example.com","password":"DemoPass123!","name":"Demo Specialist","competencies":["engine_diagnostics"]}`)
	recorder := httptest.NewRecorder()

	handler.Create(recorder, request)

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if service.request.Password != "DemoPass123!" {
		t.Fatal("request was not decoded")
	}
	var body CreateResult
	if err := json.NewDecoder(recorder.Body).Decode(&body); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	if body.User.Role != auth.TechnicalSpecialistRoleCode {
		t.Fatalf("expected technical specialist, got %q", body.User.Role)
	}
	payload := recorder.Body.String()
	if strings.Contains(payload, "DemoPass123!") || strings.Contains(payload, "password_hash") {
		t.Fatalf("response exposed password data: %s", payload)
	}
}

func TestCreateMapsValidationErrors(t *testing.T) {
	cases := []struct {
		name string
		err  error
		want int
	}{
		{name: "invalid input", err: ErrInvalidInput, want: http.StatusBadRequest},
		{name: "invalid competency", err: specialistcompetency.ErrInvalidCompetencyCode, want: http.StatusBadRequest},
		{name: "duplicate email", err: ErrDuplicateEmail, want: http.StatusConflict},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			handler := newTestHandler(&serviceStub{err: tc.err})
			recorder := httptest.NewRecorder()

			handler.Create(recorder, adminCreateRequest(`{"email":"specialist.new@example.com","password":"DemoPass123!","name":"Demo Specialist"}`))

			if recorder.Code != tc.want {
				t.Fatalf("expected status %d, got %d", tc.want, recorder.Code)
			}
		})
	}
}

func TestCreateRejectsInvalidJSON(t *testing.T) {
	handler := newTestHandler(&serviceStub{})
	recorder := httptest.NewRecorder()

	handler.Create(recorder, adminCreateRequest(`{"email":"specialist@example.com"`))

	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
	}
}

func newTestHandler(service Service) *Handler {
	return NewHandler(service, slog.New(slog.NewTextHandler(io.Discard, nil)))
}

func adminCreateRequest(body string) *http.Request {
	request := httptest.NewRequest(http.MethodPost, "/api/v1/admin/specialists", strings.NewReader(body))
	request = request.WithContext(auth.WithUser(request.Context(), testAdminUser()))

	return request
}
