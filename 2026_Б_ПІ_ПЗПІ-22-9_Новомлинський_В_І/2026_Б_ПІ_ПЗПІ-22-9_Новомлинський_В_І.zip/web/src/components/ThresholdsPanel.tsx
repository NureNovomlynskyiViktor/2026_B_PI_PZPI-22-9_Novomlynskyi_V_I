import { useLocale, useMessages } from '../i18n';
import { formatNumberWithUnit, formatStructuredLabel, formatThresholdDescription, structuredLabelKeyForValue } from '../utils/presentation';
import type { ThresholdRule } from '../api/types';

type Props = {
  thresholds: ThresholdRule[];
  isLoading: boolean;
  audience?: 'owner' | 'specialist';
};

export function ThresholdsPanel({
  thresholds,
  isLoading,
  audience = 'owner',
}: Props) {
  const { common, specialist, structuredLabels } = useMessages();
  const { locale } = useLocale();
  const diagnosticsMessages = specialist.diagnostics;
  const description =
    audience === 'specialist'
      ? diagnosticsMessages.specialistThresholdDescription
      : diagnosticsMessages.ownerThresholdDescription;

  return (
    <section className="panel thresholds-panel">
      <div className="panel-header">
        <div>
          <h2>{diagnosticsMessages.monitoringThresholds}</h2>
          <p className="muted">{description}</p>
        </div>
        {isLoading && <span className="badge">{common.refreshing}</span>}
      </div>

      {thresholds.length === 0 ? (
        <p className="empty-state">
          {diagnosticsMessages.noThresholds}
        </p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{diagnosticsMessages.metric}</th>
                <th>{diagnosticsMessages.severity}</th>
                <th>{diagnosticsMessages.value}</th>
                <th>{diagnosticsMessages.ruleType}</th>
                <th>{diagnosticsMessages.description}</th>
              </tr>
            </thead>
            <tbody>
              {thresholds.map((threshold) => (
                <tr key={`${threshold.id}-${threshold.severity}`}>
                  <td>{formatStructuredLabel(threshold.metric, common.notAvailable, structuredLabels)}</td>
                  <td>
                    <span className={`status-pill ${threshold.severity}`}>
                      {formatStructuredLabel(threshold.severity, common.notAvailable, structuredLabels)}
                    </span>
                  </td>
                  <td>
                    {formatThresholdValue(threshold, locale)}
                  </td>
                  <td>{formatStructuredLabel(threshold.rule_type, common.notAvailable, structuredLabels)}</td>
                  <td>{formatThresholdDescription(threshold.rule_type, threshold.description, locale)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function formatThresholdValue(threshold: ThresholdRule, locale: 'en' | 'uk') {
  const fractionDigits = Number.isInteger(threshold.value) ? 0 : 1;
  if (structuredLabelKeyForValue(threshold.metric) === 'vibration_level') {
    return threshold.value.toFixed(fractionDigits);
  }

  return formatNumberWithUnit(threshold.value, threshold.unit, fractionDigits, locale);
}
