BEGIN;

CREATE TABLE specialist_competencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    specialist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT specialist_competencies_unique
        UNIQUE (specialist_id, code)
);

CREATE INDEX specialist_competencies_specialist_idx
    ON specialist_competencies (specialist_id);

COMMIT;
