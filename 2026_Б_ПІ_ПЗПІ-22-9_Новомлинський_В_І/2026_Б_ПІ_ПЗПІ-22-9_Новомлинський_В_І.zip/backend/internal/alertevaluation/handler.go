package alertevaluation

import (
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

type Handler struct {
	service Service
	logger  *slog.Logger
}

func NewHandler(service Service, logger *slog.Logger) *Handler {
	return &Handler{
		service: service,
		logger:  logger,
	}
}

func (h *Handler) Evaluate(w http.ResponseWriter, r *http.Request) {
	vehicleID := r.PathValue("vehicle_id")

	result, err := h.service.Evaluate(r.Context(), vehicleID)
	if errors.Is(err, ErrInvalidVehicleID) {
		response.Error(w, http.StatusBadRequest, "invalid vehicle_id")
		return
	}
	if errors.Is(err, ErrVehicleNotFound) {
		response.Error(w, http.StatusNotFound, "vehicle not found")
		return
	}
	if errors.Is(err, ErrTelemetryNotFound) {
		response.Error(w, http.StatusNotFound, "telemetry not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to evaluate vehicle alerts",
			"vehicle_id", vehicleID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, result)
}
