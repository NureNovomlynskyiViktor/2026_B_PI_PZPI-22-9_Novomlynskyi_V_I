BEGIN;

ALTER TABLE threshold_settings
    ADD COLUMN recovery_margin NUMERIC(10, 3) NOT NULL DEFAULT 0,
    ADD COLUMN recovery_samples INTEGER NOT NULL DEFAULT 3;

UPDATE threshold_settings
SET recovery_margin = CASE parameter
    WHEN 'engine_temperature' THEN 3.0
    WHEN 'battery_voltage' THEN 0.2
    WHEN 'vibration_level' THEN 0.2
    WHEN 'rpm' THEN 200
    WHEN 'speed' THEN 5
    WHEN 'fuel_level' THEN 2
    ELSE recovery_margin
END;

ALTER TABLE threshold_settings
    ADD CONSTRAINT threshold_settings_recovery_margin_check
        CHECK (recovery_margin >= 0),
    ADD CONSTRAINT threshold_settings_recovery_samples_check
        CHECK (recovery_samples BETWEEN 1 AND 10);

ALTER TABLE alerts
    DROP CONSTRAINT IF EXISTS alerts_status_check;

ALTER TABLE alerts
    ADD COLUMN current_severity VARCHAR(32),
    ADD COLUMN cleared_at TIMESTAMPTZ,
    ADD COLUMN occurrence_count INTEGER NOT NULL DEFAULT 1,
    ADD COLUMN recovery_streak INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN last_triggered_at TIMESTAMPTZ;

UPDATE alerts
SET
    current_severity = severity,
    last_triggered_at = created_at
WHERE status = 'active';

ALTER TABLE alerts
    ADD CONSTRAINT alerts_status_check
        CHECK (status IN ('active', 'cleared', 'resolved')),
    ADD CONSTRAINT alerts_current_severity_check
        CHECK (current_severity IS NULL OR current_severity IN ('info', 'warning', 'critical')),
    ADD CONSTRAINT alerts_occurrence_count_check
        CHECK (occurrence_count >= 1),
    ADD CONSTRAINT alerts_recovery_streak_check
        CHECK (recovery_streak >= 0),
    ADD CONSTRAINT alerts_current_state_check
        CHECK (
            (status = 'active' AND current_severity IS NOT NULL AND cleared_at IS NULL)
            OR (status <> 'active' AND current_severity IS NULL)
        );

CREATE INDEX alerts_vehicle_type_status_idx
    ON alerts(vehicle_id, type, status, created_at DESC, id DESC);

COMMIT;
