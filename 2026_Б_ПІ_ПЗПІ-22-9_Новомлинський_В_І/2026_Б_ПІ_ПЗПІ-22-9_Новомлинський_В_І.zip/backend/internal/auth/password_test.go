package auth

import "testing"

func TestBcryptHasher(t *testing.T) {
	hasher := BcryptHasher{}
	hash, err := hasher.Hash("StrongPassword123!")
	if err != nil {
		t.Fatalf("Hash() returned an error: %v", err)
	}
	if hash == "StrongPassword123!" {
		t.Fatal("password hash must not equal the raw password")
	}
	if !hasher.Verify(hash, "StrongPassword123!") {
		t.Fatal("expected password verification to pass")
	}
	if hasher.Verify(hash, "WrongPassword123!") {
		t.Fatal("expected wrong password verification to fail")
	}
}
