package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import ua.autonexis.mobile.ui.account.AccountPresentation
import ua.autonexis.mobile.ui.account.AccountViewModel
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab

class AccountCenterStateTest {
    @Test
    fun ownerNavigationHasFourDestinationsInExpectedOrder() {
        assertEquals(
            listOf(
                OwnerNavigationTab.VEHICLES,
                OwnerNavigationTab.REQUESTS,
                OwnerNavigationTab.NOTIFICATIONS,
                OwnerNavigationTab.ACCOUNT,
            ),
            OwnerNavigationTab.entries,
        )
    }

    @Test
    fun accountInitialLoadingSuccessRefreshAndErrorStates() {
        val viewModel = AccountViewModel()
        val user = user()
        val methods = AuthMethods(passwordEnabled = true, googleLinked = false)

        viewModel.showInitialLoading(user, googleConfigured = true)
        assertTrue(viewModel.uiState.isLoading)
        assertEquals(user, viewModel.uiState.user)

        viewModel.showAccount(user, methods, googleConfigured = true)
        assertFalse(viewModel.uiState.isLoading)
        assertEquals(methods, viewModel.uiState.methods)

        assertTrue(viewModel.startRefresh())
        viewModel.finishRefresh(methods.copy(googleLinked = true), message = "Updated")
        assertFalse(viewModel.uiState.isRefreshing)
        assertEquals(true, viewModel.uiState.methods?.googleLinked)
        assertEquals("Updated", viewModel.uiState.message)

        assertTrue(viewModel.startRefresh())
        viewModel.failRefresh("Network unavailable")
        assertFalse(viewModel.uiState.isRefreshing)
        assertTrue(viewModel.uiState.isError)
        assertEquals(methods.copy(googleLinked = true), viewModel.uiState.methods)
    }

    @Test
    fun authMethodPresentationUsesReadableLabels() {
        assertEquals("Enabled", AccountPresentation.passwordMethodLabel(AuthMethods(true, false)))
        assertEquals("Not enabled", AccountPresentation.passwordMethodLabel(AuthMethods(false, true)))
        assertEquals("Connected", AccountPresentation.googleMethodLabel(AuthMethods(false, true)))
        assertEquals("Not connected", AccountPresentation.googleMethodLabel(AuthMethods(true, false)))
        assertEquals("Vehicle owner", AccountPresentation.roleLabel(user(role = "vehicle_owner")))
    }

    @Test
    fun googleLinkRequestLocksAndSuccessfulLinkUpdatesState() {
        val viewModel = AccountViewModel()
        viewModel.showAccount(
            user = user(),
            methods = AuthMethods(passwordEnabled = true, googleLinked = false),
            googleConfigured = true,
        )

        assertTrue(viewModel.startGoogleLink())
        assertFalse(viewModel.startGoogleLink())

        viewModel.finishGoogleLink(AuthMethods(passwordEnabled = true, googleLinked = true))
        assertFalse(viewModel.uiState.isLinkingGoogle)
        assertEquals(true, viewModel.uiState.methods?.googleLinked)
        assertEquals("Google account connected.", viewModel.uiState.googleLinkMessage)
        assertFalse(AccountPresentation.canConnectGoogle(viewModel.uiState))
    }

    @Test
    fun googleLinkFailurePreservesCurrentMethodsAndSessionState() {
        val viewModel = AccountViewModel()
        val methods = AuthMethods(passwordEnabled = true, googleLinked = false)
        viewModel.showAccount(user(), methods, googleConfigured = true)

        assertTrue(viewModel.startGoogleLink())
        viewModel.failGoogleLink("Could not connect Google account.")

        assertFalse(viewModel.uiState.isLinkingGoogle)
        assertEquals(methods, viewModel.uiState.methods)
        assertFalse(viewModel.uiState.isError)
        assertTrue(viewModel.uiState.googleLinkIsError)
        assertEquals("Could not connect Google account.", viewModel.uiState.googleLinkMessage)
    }

    @Test
    fun expiredSessionPolicyStillClassifiesHttp401ForAccountRequests() {
        assertTrue(SessionRecoveryPolicy.isExpiredSession(ApiException(401, "missing or invalid token")))
        assertFalse(SessionRecoveryPolicy.isExpiredSession(ApiException(500, "server error")))
    }

    private fun user(role: String = "vehicle_owner"): User {
        return User(
            id = "user-1",
            email = "owner@example.com",
            role = role,
            fullName = "Demo Owner",
        )
    }
}