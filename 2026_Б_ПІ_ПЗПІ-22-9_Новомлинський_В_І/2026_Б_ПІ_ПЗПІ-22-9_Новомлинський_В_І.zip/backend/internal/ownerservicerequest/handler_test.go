package ownerservicerequest

import (
	"bytes"
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
)

const (
	testOwnerID   = "11111111-1111-1111-1111-111111111111"
	testVehicleID = "22222222-2222-2222-2222-222222222222"
	testAlertID   = "33333333-3333-3333-3333-333333333333"
	testRequestID = "44444444-4444-4444-4444-444444444444"
)

func TestCreateWithEligibleSourceAlert(t *testing.T) {
	requests := &fakeServiceRequestService{}
	alerts := &fakeAlertService{item: alert.Alert{
		ID:        testAlertID,
		VehicleID: testVehicleID,
		Status:    "active",
		Severity:  "warning",
	}}
	handler := testHandler(requests, alerts)

	recorder := httptest.NewRecorder()
	handler.Create(recorder, newCreateHTTPRequest(`{
		"title":"Engine warning diagnostics",
		"description":"Please inspect the active engine warning.",
		"priority":"high",
		"source_alert_id":"33333333-3333-3333-3333-333333333333"
	}`))

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if !requests.createCalled {
		t.Fatal("expected service request creation")
	}
	if requests.created.SourceAlertID == nil || *requests.created.SourceAlertID != testAlertID {
		t.Fatalf("expected source alert ID to be passed, got %#v", requests.created.SourceAlertID)
	}
}

func TestCreateManualRequestDoesNotRequireAlertLookup(t *testing.T) {
	requests := &fakeServiceRequestService{}
	alerts := &fakeAlertService{}
	handler := testHandler(requests, alerts)

	recorder := httptest.NewRecorder()
	handler.Create(recorder, newCreateHTTPRequest(`{
		"title":"General diagnostics",
		"description":"Please inspect the vehicle.",
		"priority":"normal"
	}`))

	if recorder.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, recorder.Code)
	}
	if alerts.getCalls != 0 {
		t.Fatalf("expected no alert lookup, got %d", alerts.getCalls)
	}
	if requests.created.SourceAlertID != nil {
		t.Fatalf("expected no source alert ID, got %#v", requests.created.SourceAlertID)
	}
}

func TestCreateReturnsNotFoundForUnavailableSourceAlert(t *testing.T) {
	handler := testHandler(&fakeServiceRequestService{}, &fakeAlertService{
		err: alert.ErrNotFound,
	})

	recorder := httptest.NewRecorder()
	handler.Create(recorder, newCreateHTTPRequest(`{
		"title":"Engine warning diagnostics",
		"description":"Please inspect the active engine warning.",
		"priority":"high",
		"source_alert_id":"33333333-3333-3333-3333-333333333333"
	}`))

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestCreateReturnsNotFoundForAlertFromAnotherVehicle(t *testing.T) {
	handler := testHandler(&fakeServiceRequestService{}, &fakeAlertService{
		item: alert.Alert{
			ID:        testAlertID,
			VehicleID: "55555555-5555-5555-5555-555555555555",
			Status:    "active",
			Severity:  "critical",
		},
	})

	recorder := httptest.NewRecorder()
	handler.Create(recorder, newCreateHTTPRequest(`{
		"title":"Battery diagnostics",
		"description":"Please inspect the active battery alert.",
		"priority":"high",
		"source_alert_id":"33333333-3333-3333-3333-333333333333"
	}`))

	if recorder.Code != http.StatusNotFound {
		t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
	}
}

func TestCreateRejectsIneligibleSourceAlert(t *testing.T) {
	tests := []struct {
		name string
		item alert.Alert
	}{
		{
			name: "resolved alert",
			item: alert.Alert{
				ID:        testAlertID,
				VehicleID: testVehicleID,
				Status:    "resolved",
				Severity:  "critical",
			},
		},
		{
			name: "normal severity",
			item: alert.Alert{
				ID:        testAlertID,
				VehicleID: testVehicleID,
				Status:    "active",
				Severity:  "normal",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := testHandler(&fakeServiceRequestService{}, &fakeAlertService{item: tt.item})

			recorder := httptest.NewRecorder()
			handler.Create(recorder, newCreateHTTPRequest(`{
				"title":"Alert diagnostics",
				"description":"Please inspect this alert.",
				"priority":"high",
				"source_alert_id":"33333333-3333-3333-3333-333333333333"
			}`))

			if recorder.Code != http.StatusBadRequest {
				t.Fatalf("expected status %d, got %d", http.StatusBadRequest, recorder.Code)
			}
		})
	}
}

func TestCreateReturnsConflictForDuplicateOpenAlertRequest(t *testing.T) {
	handler := testHandler(
		&fakeServiceRequestService{createErr: servicerequest.ErrDuplicateOpenAlertRequest},
		&fakeAlertService{item: alert.Alert{
			ID:        testAlertID,
			VehicleID: testVehicleID,
			Status:    "active",
			Severity:  "warning",
		}},
	)

	recorder := httptest.NewRecorder()
	handler.Create(recorder, newCreateHTTPRequest(`{
		"title":"Engine warning diagnostics",
		"description":"Please inspect the active engine warning.",
		"priority":"high",
		"source_alert_id":"33333333-3333-3333-3333-333333333333"
	}`))

	if recorder.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, recorder.Code)
	}
}

func testHandler(
	requests *fakeServiceRequestService,
	alerts *fakeAlertService,
) *Handler {
	return NewHandler(
		requests,
		fakeVehicleService{},
		alerts,
		slog.New(slog.NewTextHandler(io.Discard, nil)),
	)
}

func newCreateHTTPRequest(body string) *http.Request {
	request := httptest.NewRequest(http.MethodPost, "/service-requests", bytes.NewBufferString(body))
	request.SetPathValue("vehicle_id", testVehicleID)
	request = request.WithContext(auth.WithUser(request.Context(), auth.User{
		ID:   testOwnerID,
		Role: auth.DefaultRoleCode,
	}))
	return request
}

type fakeServiceRequestService struct {
	created      servicerequest.CreateRequest
	createCalled bool
	createErr    error
}

func (s *fakeServiceRequestService) Create(
	_ context.Context,
	request servicerequest.CreateRequest,
) (servicerequest.Request, error) {
	s.created = request
	s.createCalled = true
	if s.createErr != nil {
		return servicerequest.Request{}, s.createErr
	}

	return servicerequest.Request{
		ID:            testRequestID,
		VehicleID:     request.VehicleID,
		OwnerID:       request.OwnerID,
		SourceAlertID: request.SourceAlertID,
		Title:         request.Title,
		Description:   request.Description,
		Priority:      request.Priority,
		Status:        servicerequest.StatusPending,
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}, nil
}

func (s *fakeServiceRequestService) ListForOwner(
	context.Context,
	string,
) ([]servicerequest.Request, error) {
	return []servicerequest.Request{}, nil
}

func (s *fakeServiceRequestService) GetForOwner(
	context.Context,
	string,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{}, nil
}

func (s *fakeServiceRequestService) CancelByOwner(
	context.Context,
	string,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{}, nil
}

type fakeVehicleService struct{}

func (fakeVehicleService) GetByIDForOwner(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testVehicleID, OwnerID: testOwnerID}, nil
}

type fakeAlertService struct {
	item     alert.Alert
	err      error
	getCalls int
}

func (s *fakeAlertService) GetByID(context.Context, string) (alert.Alert, error) {
	s.getCalls++
	if s.err != nil {
		return alert.Alert{}, s.err
	}

	return s.item, nil
}
