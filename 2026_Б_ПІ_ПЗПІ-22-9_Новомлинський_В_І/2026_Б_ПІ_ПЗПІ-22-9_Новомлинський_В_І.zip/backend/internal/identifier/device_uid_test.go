package identifier

import "testing"

func TestIsDeviceUID(t *testing.T) {
	tests := []struct {
		value string
		valid bool
	}{
		{value: "esp32-demo-001", valid: true},
		{value: "abc", valid: true},
		{value: "device_01", valid: true},
		{value: "", valid: false},
		{value: "ab", valid: false},
		{value: "device/01", valid: false},
		{value: "device 01", valid: false},
		{value: "device.01", valid: false},
	}

	for _, tt := range tests {
		t.Run(tt.value, func(t *testing.T) {
			if got := IsDeviceUID(tt.value); got != tt.valid {
				t.Fatalf("IsDeviceUID(%q) = %v, want %v", tt.value, got, tt.valid)
			}
		})
	}
}
