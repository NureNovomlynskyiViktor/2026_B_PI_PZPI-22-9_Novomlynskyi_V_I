package ownernotification

import (
	"context"
	"errors"
	"log/slog"
	"net/http"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/response"
)

type NotificationService interface {
	ListByUser(ctx context.Context, userID string) ([]notification.Notification, error)
	MarkReadForUser(
		ctx context.Context,
		userID string,
		notificationID string,
	) (notification.Notification, error)
}

type Handler struct {
	notifications NotificationService
	logger        *slog.Logger
}

func NewHandler(
	notifications NotificationService,
	logger *slog.Logger,
) *Handler {
	return &Handler{
		notifications: notifications,
		logger:        logger,
	}
}

func (h *Handler) List(w http.ResponseWriter, r *http.Request) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	items, err := h.notifications.ListByUser(r.Context(), user.ID)
	if errors.Is(err, notification.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "notifications not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to list owner notifications",
			"user_id", user.ID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, items)
}

func (h *Handler) MarkRead(w http.ResponseWriter, r *http.Request) {
	user, ok := auth.UserFromContext(r.Context())
	if !ok {
		response.Error(w, http.StatusUnauthorized, "missing or invalid token")
		return
	}

	notificationID := r.PathValue("notification_id")
	item, err := h.notifications.MarkReadForUser(
		r.Context(),
		user.ID,
		notificationID,
	)
	if errors.Is(err, notification.ErrNotFound) {
		response.Error(w, http.StatusNotFound, "notification not found")
		return
	}
	if err != nil {
		h.logger.Error(
			"failed to mark owner notification read",
			"user_id", user.ID,
			"notification_id", notificationID,
			"error", err,
		)
		response.Error(w, http.StatusInternalServerError, "internal server error")
		return
	}

	response.JSON(w, http.StatusOK, item)
}
