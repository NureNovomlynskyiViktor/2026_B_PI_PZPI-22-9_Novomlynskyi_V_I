package device

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var ErrInvalidInput = errors.New("invalid device input")

type Service interface {
	List(ctx context.Context) ([]Device, error)
	GetByID(ctx context.Context, id string) (Device, error)
	GetByUID(ctx context.Context, deviceUID string) (Device, error)
	GetByVehicleID(ctx context.Context, vehicleID string) (Device, error)
	ListByOwner(ctx context.Context, ownerID string) ([]Device, error)
	ListByVehicleForOwner(
		ctx context.Context,
		ownerID string,
		vehicleID string,
	) ([]Device, error)
	GetByIDForOwner(ctx context.Context, ownerID string, deviceID string) (Device, error)
	CreateForOwnedVehicle(
		ctx context.Context,
		ownerID string,
		vehicleID string,
		request CreateRequest,
	) (Device, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) List(ctx context.Context) ([]Device, error) {
	return s.repository.List(ctx)
}

func (s *service) GetByID(ctx context.Context, id string) (Device, error) {
	if !identifier.IsUUID(id) {
		return Device{}, ErrNotFound
	}

	return s.repository.GetByID(ctx, id)
}

func (s *service) GetByUID(
	ctx context.Context,
	deviceUID string,
) (Device, error) {
	if !identifier.IsDeviceUID(deviceUID) {
		return Device{}, ErrNotFound
	}

	return s.repository.GetByUID(ctx, deviceUID)
}

func (s *service) GetByVehicleID(
	ctx context.Context,
	vehicleID string,
) (Device, error) {
	if !identifier.IsUUID(vehicleID) {
		return Device{}, ErrNotFound
	}

	return s.repository.GetByVehicleID(ctx, vehicleID)
}

func (s *service) ListByOwner(
	ctx context.Context,
	ownerID string,
) ([]Device, error) {
	if !identifier.IsUUID(ownerID) {
		return nil, ErrNotFound
	}

	return s.repository.ListByOwner(ctx, ownerID)
}

func (s *service) ListByVehicleForOwner(
	ctx context.Context,
	ownerID string,
	vehicleID string,
) ([]Device, error) {
	if !identifier.IsUUID(ownerID) || !identifier.IsUUID(vehicleID) {
		return nil, ErrNotFound
	}

	return s.repository.ListByVehicleForOwner(ctx, ownerID, vehicleID)
}

func (s *service) GetByIDForOwner(
	ctx context.Context,
	ownerID string,
	deviceID string,
) (Device, error) {
	if !identifier.IsUUID(ownerID) || !identifier.IsUUID(deviceID) {
		return Device{}, ErrNotFound
	}

	return s.repository.GetByIDForOwner(ctx, ownerID, deviceID)
}

func (s *service) CreateForOwnedVehicle(
	ctx context.Context,
	ownerID string,
	vehicleID string,
	request CreateRequest,
) (Device, error) {
	if !identifier.IsUUID(ownerID) || !identifier.IsUUID(vehicleID) {
		return Device{}, ErrInvalidInput
	}

	normalized := normalizeCreateRequest(request)
	if !isValidCreateRequest(normalized) {
		return Device{}, ErrInvalidInput
	}

	return s.repository.CreateForOwnedVehicle(ctx, ownerID, vehicleID, normalized)
}

func normalizeCreateRequest(request CreateRequest) CreateRequest {
	return CreateRequest{
		DeviceUID: strings.TrimSpace(request.DeviceUID),
		Name:      strings.TrimSpace(request.Name),
	}
}

func isValidCreateRequest(request CreateRequest) bool {
	return identifier.IsDeviceUID(request.DeviceUID) &&
		request.Name != "" &&
		len(request.Name) <= 128
}
