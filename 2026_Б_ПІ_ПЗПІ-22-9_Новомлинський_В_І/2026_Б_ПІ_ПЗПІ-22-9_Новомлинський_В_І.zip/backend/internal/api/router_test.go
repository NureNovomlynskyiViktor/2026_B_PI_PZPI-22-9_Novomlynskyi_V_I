package api

import (
	"context"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/admin"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminaudit"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/adminuser"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/alertevaluation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/device"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/maintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/notification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/owneralert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerdevice"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownermaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownernotification"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerspecialist"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownertelemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownerthreshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/ownervehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/servicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistalert"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistassignment"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistcompetency"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistmaintenance"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistrecommendation"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistservicerequest"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/specialistvehicle"
	vehiclestatus "github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/status"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetry"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/telemetryingestion"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/threshold"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicle"
	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/vehicleactivation"
)

const testID = "11111111-1111-1111-1111-111111111111"

type vehicleService struct{}

func (vehicleService) List(context.Context) ([]vehicle.Vehicle, error) {
	return []vehicle.Vehicle{}, nil
}

func (vehicleService) GetByID(context.Context, string) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testID}, nil
}

func (vehicleService) ListByOwner(context.Context, string) ([]vehicle.Vehicle, error) {
	return []vehicle.Vehicle{}, nil
}

func (vehicleService) GetByIDForOwner(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testID}, nil
}

func (vehicleService) CreateForOwner(
	context.Context,
	string,
	vehicle.CreateRequest,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testID}, nil
}

type deviceService struct{}

func (deviceService) List(context.Context) ([]device.Device, error) {
	return []device.Device{}, nil
}

func (deviceService) GetByID(context.Context, string) (device.Device, error) {
	return device.Device{ID: testID}, nil
}

func (deviceService) GetByUID(context.Context, string) (device.Device, error) {
	return device.Device{ID: testID, VehicleID: testID}, nil
}

func (deviceService) GetByVehicleID(context.Context, string) (device.Device, error) {
	return device.Device{ID: testID}, nil
}

func (deviceService) ListByOwner(context.Context, string) ([]device.Device, error) {
	return []device.Device{}, nil
}

func (deviceService) ListByVehicleForOwner(
	context.Context,
	string,
	string,
) ([]device.Device, error) {
	return []device.Device{}, nil
}

func (deviceService) GetByIDForOwner(
	context.Context,
	string,
	string,
) (device.Device, error) {
	return device.Device{ID: testID, VehicleID: testID, DeviceUID: "esp32-user-001"}, nil
}

func (deviceService) CreateForOwnedVehicle(
	context.Context,
	string,
	string,
	device.CreateRequest,
) (device.Device, error) {
	return device.Device{ID: testID, VehicleID: testID, DeviceUID: "esp32-user-001"}, nil
}

type telemetryService struct{}

func (telemetryService) ListByVehicle(
	context.Context,
	string,
	int,
) ([]telemetry.Record, error) {
	return []telemetry.Record{}, nil
}

func (telemetryService) LatestByVehicle(
	context.Context,
	string,
) (telemetry.Record, error) {
	return telemetry.Record{VehicleID: testID}, nil
}

type alertService struct{}

func (alertService) ListByVehicle(
	context.Context,
	string,
	int,
) ([]alert.Alert, error) {
	return []alert.Alert{}, nil
}

func (alertService) ListByVehicleStatus(
	context.Context,
	string,
	string,
	int,
) ([]alert.Alert, error) {
	return []alert.Alert{}, nil
}

func (alertService) ListActiveByVehicle(
	context.Context,
	string,
) ([]alert.Alert, error) {
	return []alert.Alert{}, nil
}

func (alertService) GetByID(context.Context, string) (alert.Alert, error) {
	return alert.Alert{ID: testID}, nil
}

func (alertService) ResolveBySpecialist(
	context.Context,
	alert.SpecialistResolution,
) (alert.Alert, error) {
	return alert.Alert{ID: testID, Status: "resolved"}, nil
}

type thresholdService struct{}

func (thresholdService) ListByVehicle(
	context.Context,
	string,
) ([]threshold.Setting, error) {
	return []threshold.Setting{}, nil
}

type maintenanceService struct{}

func (maintenanceService) ListByVehicle(
	context.Context,
	string,
) ([]maintenance.Record, error) {
	return []maintenance.Record{}, nil
}

func (maintenanceService) Create(
	context.Context,
	maintenance.CreateRequest,
) (maintenance.Record, error) {
	return maintenance.Record{ID: testID}, nil
}

type notificationService struct{}

func (notificationService) ListByUser(
	context.Context,
	string,
) ([]notification.Notification, error) {
	return []notification.Notification{}, nil
}

func (notificationService) MarkReadForUser(
	context.Context,
	string,
	string,
) (notification.Notification, error) {
	return notification.Notification{
		ID:               testID,
		AlertID:          stringPtr(testID),
		NotificationType: notification.TypeVehicleAlert,
		IsRead:           true,
	}, nil
}

type serviceRequestService struct{}

func (serviceRequestService) Create(
	context.Context,
	servicerequest.CreateRequest,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusPending}, nil
}

func (serviceRequestService) ListForOwner(
	context.Context,
	string,
) ([]servicerequest.Request, error) {
	return []servicerequest.Request{}, nil
}

func (serviceRequestService) GetForOwner(
	context.Context,
	string,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusPending}, nil
}

func (serviceRequestService) CancelByOwner(
	context.Context,
	string,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusCancelled}, nil
}

func (serviceRequestService) ListForAdmin(
	context.Context,
	string,
) ([]servicerequest.Request, error) {
	return []servicerequest.Request{}, nil
}

func (serviceRequestService) GetForAdmin(
	context.Context,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusPending}, nil
}

func (serviceRequestService) Assign(
	context.Context,
	servicerequest.AssignRequest,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusAssigned}, nil
}

func (serviceRequestService) CancelByAdmin(
	context.Context,
	servicerequest.AdminCancelRequest,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusCancelled}, nil
}

func (serviceRequestService) ListForSpecialist(
	context.Context,
	string,
) ([]servicerequest.Request, error) {
	return []servicerequest.Request{}, nil
}

func (serviceRequestService) GetForSpecialist(
	context.Context,
	string,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusAssigned}, nil
}

func (serviceRequestService) Start(
	context.Context,
	string,
	string,
) (servicerequest.Request, error) {
	return servicerequest.Request{ID: testID, Status: servicerequest.StatusInProgress}, nil
}

func (serviceRequestService) Complete(
	context.Context,
	string,
	string,
	string,
) (servicerequest.Request, error) {
	summary := "Completed diagnostics."
	return servicerequest.Request{
		ID:            testID,
		Status:        servicerequest.StatusCompleted,
		ResultSummary: &summary,
	}, nil
}

type adminSpecialistService struct{}

func (adminSpecialistService) Create(
	context.Context,
	auth.User,
	adminspecialist.CreateRequest,
) (adminspecialist.CreateResult, error) {
	return adminspecialist.CreateResult{
		User: auth.User{
			ID:       testID,
			Role:     auth.TechnicalSpecialistRoleCode,
			Email:    "specialist.new@example.com",
			FullName: "New Specialist",
		},
	}, nil
}

type adminUserService struct{}

func (adminUserService) List(
	context.Context,
	adminuser.ListFilters,
) ([]adminuser.User, error) {
	return []adminuser.User{}, nil
}

func (adminUserService) Get(context.Context, string) (adminuser.User, error) {
	return adminuser.User{ID: testID, Role: auth.DefaultRoleCode}, nil
}

func (adminUserService) Deactivate(
	context.Context,
	auth.User,
	string,
	adminuser.DeactivateRequest,
) (adminuser.User, error) {
	return adminuser.User{ID: testID, Role: auth.DefaultRoleCode, IsActive: false}, nil
}

func (adminUserService) Reactivate(
	context.Context,
	auth.User,
	string,
) (adminuser.User, error) {
	return adminuser.User{ID: testID, Role: auth.DefaultRoleCode, IsActive: true}, nil
}

type adminAuditService struct{}

func (adminAuditService) List(
	context.Context,
	adminaudit.ListFilters,
) (adminaudit.ListResponse, error) {
	return adminaudit.ListResponse{}, nil
}

type specialistAssignmentService struct{}

func (specialistAssignmentService) AssignByEmail(
	context.Context,
	string,
	string,
	string,
) (specialistassignment.Assignment, error) {
	return specialistassignment.Assignment{
		ID:           testID,
		VehicleID:    testID,
		SpecialistID: testID,
		Specialist: auth.User{
			ID:    testID,
			Email: "specialist@example.com",
			Role:  auth.TechnicalSpecialistRoleCode,
		},
	}, nil
}

func (specialistAssignmentService) AssignByID(
	context.Context,
	string,
	string,
	string,
) (specialistassignment.Assignment, error) {
	return specialistassignment.Assignment{
		ID:           testID,
		VehicleID:    testID,
		SpecialistID: testID,
		Specialist: auth.User{
			ID:    testID,
			Email: "specialist@example.com",
			Role:  auth.TechnicalSpecialistRoleCode,
		},
	}, nil
}

func (specialistAssignmentService) ListByVehicle(
	context.Context,
	string,
) ([]specialistassignment.Assignment, error) {
	return []specialistassignment.Assignment{}, nil
}

func (specialistAssignmentService) ListSpecialists(
	context.Context,
) ([]auth.User, error) {
	return []auth.User{
		{
			ID:    testID,
			Email: "specialist@example.com",
			Role:  auth.TechnicalSpecialistRoleCode,
		},
	}, nil
}

func (specialistAssignmentService) CountBySpecialist(context.Context) (map[string]int, error) {
	return map[string]int{testID: 1}, nil
}

func (specialistAssignmentService) Remove(context.Context, string, string) error {
	return nil
}

func (specialistAssignmentService) ListVehiclesForSpecialist(
	context.Context,
	string,
) ([]vehicle.Vehicle, error) {
	return []vehicle.Vehicle{}, nil
}

func (specialistAssignmentService) GetAssignedVehicle(
	context.Context,
	string,
	string,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testID}, nil
}

type specialistCompetencyService struct{}

func (specialistCompetencyService) List(
	context.Context,
	string,
) ([]specialistcompetency.Competency, error) {
	return []specialistcompetency.Competency{}, nil
}

func (specialistCompetencyService) ListAll(
	context.Context,
) ([]specialistcompetency.Competency, error) {
	return []specialistcompetency.Competency{}, nil
}

func (specialistCompetencyService) Replace(
	context.Context,
	string,
	[]string,
) ([]specialistcompetency.Competency, error) {
	return []specialistcompetency.Competency{}, nil
}

type specialistRecommendationService struct{}

func (specialistRecommendationService) Recommend(
	context.Context,
	string,
) ([]specialistrecommendation.Recommendation, error) {
	return []specialistrecommendation.Recommendation{}, nil
}

type statusService struct{}

func (statusService) GetByVehicleID(
	context.Context,
	string,
) (vehiclestatus.VehicleStatus, error) {
	return vehiclestatus.VehicleStatus{
		Vehicle:       vehicle.Vehicle{ID: testID},
		ActiveAlerts:  []alert.Alert{},
		OverallStatus: "normal",
	}, nil
}

type alertEvaluationService struct{}

func (alertEvaluationService) Evaluate(
	context.Context,
	string,
) (alertevaluation.Result, error) {
	return alertevaluation.Result{
		VehicleID:      testID,
		CreatedAlerts:  []alert.Alert{},
		ExistingAlerts: []alert.Alert{},
		OverallResult:  "normal",
	}, nil
}

func (alertEvaluationService) EvaluateRecord(
	context.Context,
	telemetry.Record,
) (alertevaluation.Result, error) {
	return alertevaluation.Result{
		VehicleID:      testID,
		CreatedAlerts:  []alert.Alert{},
		ExistingAlerts: []alert.Alert{},
		OverallResult:  "normal",
	}, nil
}

type telemetryIngestionService struct{}

func (telemetryIngestionService) Ingest(
	context.Context,
	string,
	telemetryingestion.Input,
) (telemetryingestion.Result, error) {
	return telemetryingestion.Result{
		Telemetry:      telemetry.Record{ID: 1},
		CreatedAlerts:  []alert.Alert{},
		ExistingAlerts: []alert.Alert{},
		OverallResult:  "normal",
	}, nil
}

type vehicleActivationService struct{}

func (vehicleActivationService) Create(
	context.Context,
	auth.User,
	vehicleactivation.AdminCreateRequest,
) (vehicleactivation.AdminCreateResponse, error) {
	return vehicleactivation.AdminCreateResponse{
		Vehicle:        vehicle.Vehicle{ID: testID},
		Device:         device.Device{ID: testID, VehicleID: testID},
		ActivationCode: "AX7K-29QP",
	}, nil
}

func (vehicleActivationService) Claim(
	context.Context,
	auth.User,
	vehicleactivation.ClaimRequest,
) (vehicle.Vehicle, error) {
	return vehicle.Vehicle{ID: testID, OwnerID: testID}, nil
}

type authService struct{}

func (authService) Register(context.Context, auth.RegisterRequest) (auth.AuthResponse, error) {
	return auth.AuthResponse{AccessToken: "jwt"}, nil
}

func (authService) Login(context.Context, auth.LoginRequest) (auth.AuthResponse, error) {
	return auth.AuthResponse{AccessToken: "jwt"}, nil
}
func (authService) GoogleLogin(context.Context, auth.GoogleLoginRequest) (auth.AuthResponse, error) {
	return auth.AuthResponse{AccessToken: "jwt"}, nil
}

func (authService) AuthMethods(context.Context, auth.User) (auth.AuthMethodStatus, error) {
	return auth.AuthMethodStatus{PasswordEnabled: true, GoogleLinked: true}, nil
}

func (authService) LinkGoogle(context.Context, auth.User, auth.GoogleLinkRequest) (auth.AuthMethodStatus, error) {
	return auth.AuthMethodStatus{PasswordEnabled: true, GoogleLinked: true}, nil
}

func (authService) CurrentUser(_ context.Context, token string) (auth.User, error) {
	role := auth.DefaultRoleCode
	if token == "specialist-jwt" {
		role = auth.TechnicalSpecialistRoleCode
	}
	if token == "admin-jwt" {
		role = auth.AdministratorRoleCode
	}

	return auth.User{
		ID:    testID,
		Email: "user@example.com",
		Role:  role,
	}, nil
}

func TestRegisterRoutes(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	vehicleHandler := vehicle.NewHandler(vehicleService{}, logger)
	deviceHandler := device.NewHandler(deviceService{}, logger)
	telemetryHandler := telemetry.NewHandler(telemetryService{}, logger)
	alertHandler := alert.NewHandler(alertService{}, logger)
	statusHandler := vehiclestatus.NewHandler(statusService{}, logger)
	alertEvaluationHandler := alertevaluation.NewHandler(
		alertEvaluationService{},
		logger,
	)
	telemetryIngestionHandler := telemetryingestion.NewHandler(
		telemetryIngestionService{},
		logger,
	)
	authHandler := auth.NewHandler(authService{}, logger)
	vehicleActivationHandler := vehicleactivation.NewHandler(
		vehicleActivationService{},
		logger,
	)
	ownerVehicleHandler := ownervehicle.NewHandler(
		vehicleService{},
		statusService{},
		logger,
	)
	ownerDeviceHandler := ownerdevice.NewHandler(
		deviceService{},
		vehicleService{},
		logger,
	)
	ownerTelemetryHandler := ownertelemetry.NewHandler(
		telemetryService{},
		vehicleService{},
		logger,
	)
	ownerAlertHandler := owneralert.NewHandler(
		alertService{},
		vehicleService{},
		logger,
	)
	ownerThresholdHandler := ownerthreshold.NewHandler(
		thresholdService{},
		vehicleService{},
		logger,
	)
	ownerMaintenanceHandler := ownermaintenance.NewHandler(
		maintenanceService{},
		vehicleService{},
		logger,
	)
	ownerNotificationHandler := ownernotification.NewHandler(
		notificationService{},
		logger,
	)
	ownerServiceRequestHandler := ownerservicerequest.NewHandler(
		serviceRequestService{},
		vehicleService{},
		alertService{},
		logger,
	)
	ownerSpecialistHandler := ownerspecialist.NewHandler(
		specialistAssignmentService{},
		vehicleService{},
		logger,
	)
	specialistAlertHandler := specialistalert.NewHandler(
		alertService{},
		logger,
	)
	specialistMaintenanceHandler := specialistmaintenance.NewHandler(
		maintenanceService{},
		specialistAssignmentService{},
		vehicleService{},
		logger,
	)
	specialistServiceRequestHandler := specialistservicerequest.NewHandler(
		serviceRequestService{},
		logger,
	)
	specialistVehicleHandler := specialistvehicle.NewHandler(
		specialistAssignmentService{},
		statusService{},
		thresholdService{},
		telemetryService{},
		alertService{},
		logger,
	)
	adminServiceRequestHandler := adminservicerequest.NewHandler(
		serviceRequestService{},
		logger,
	)
	adminSpecialistHandler := adminspecialist.NewHandler(adminSpecialistService{}, logger)
	adminUserHandler := adminuser.NewHandler(adminUserService{}, logger)
	adminAuditHandler := adminaudit.NewHandler(adminAuditService{}, logger)
	adminHandler := admin.NewHandler(
		vehicleService{},
		specialistAssignmentService{},
		specialistCompetencyService{},
		specialistRecommendationService{},
		logger,
	)

	mux := http.NewServeMux()
	RegisterRoutes(
		mux,
		vehicleHandler,
		deviceHandler,
		telemetryHandler,
		alertHandler,
		statusHandler,
		alertEvaluationHandler,
		telemetryIngestionHandler,
		authHandler,
		vehicleActivationHandler,
		ownerVehicleHandler,
		ownerDeviceHandler,
		ownerTelemetryHandler,
		ownerAlertHandler,
		ownerThresholdHandler,
		ownerMaintenanceHandler,
		ownerNotificationHandler,
		ownerServiceRequestHandler,
		ownerSpecialistHandler,
		specialistAlertHandler,
		specialistMaintenanceHandler,
		specialistServiceRequestHandler,
		specialistVehicleHandler,
		adminServiceRequestHandler,
		adminSpecialistHandler,
		adminUserHandler,
		adminAuditHandler,
		adminHandler,
		authService{},
		logger,
	)

	routes := []struct {
		method string
		path   string
	}{
		{method: http.MethodGet, path: "/api/v1/vehicles"},
		{method: http.MethodGet, path: "/api/v1/vehicles/" + testID},
		{method: http.MethodGet, path: "/api/v1/devices"},
		{method: http.MethodGet, path: "/api/v1/devices/" + testID},
		{method: http.MethodGet, path: "/api/v1/vehicles/" + testID + "/telemetry"},
		{method: http.MethodGet, path: "/api/v1/vehicles/" + testID + "/telemetry/latest"},
		{method: http.MethodGet, path: "/api/v1/vehicles/" + testID + "/alerts"},
		{method: http.MethodGet, path: "/api/v1/vehicles/" + testID + "/alerts/active"},
		{method: http.MethodGet, path: "/api/v1/alerts/" + testID},
		{method: http.MethodGet, path: "/api/v1/vehicles/" + testID + "/status"},
		{
			method: http.MethodPost,
			path:   "/api/v1/vehicles/" + testID + "/alerts/evaluate",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/devices/esp32-demo-001/telemetry",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/auth/register",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/auth/login",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/auth/google",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/auth/methods",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/auth/google/link",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/auth/me",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/me/vehicle-activations/claim",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/me/vehicles",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID,
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/status",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/devices",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/telemetry",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/alerts",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/alerts/active",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/thresholds",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/maintenance-records",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/me/vehicles/" + testID + "/service-requests",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/service-requests",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/service-requests/" + testID,
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/me/service-requests/" + testID + "/cancel",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/vehicles/" + testID + "/specialists",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/me/vehicles/" + testID + "/specialists",
		},
		{
			method: http.MethodDelete,
			path:   "/api/v1/me/vehicles/" + testID + "/specialists/" + testID,
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/me/vehicles/" + testID + "/devices",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/devices",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/devices/" + testID,
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/me/notifications",
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/me/notifications/" + testID + "/read",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/vehicles",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/vehicles/" + testID + "/status",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/vehicles/" + testID + "/thresholds",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/vehicles/" + testID + "/telemetry",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/vehicles/" + testID + "/alerts",
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/specialist/alerts/" + testID + "/resolve",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/specialist/vehicles/" + testID + "/maintenance-records",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/service-requests",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/specialist/service-requests/" + testID,
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/specialist/service-requests/" + testID + "/start",
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/specialist/service-requests/" + testID + "/complete",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/vehicles",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/users",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/users/" + testID,
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/admin/users/" + testID + "/deactivate",
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/admin/users/" + testID + "/reactivate",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/audit-logs",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/service-requests",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/service-requests/" + testID,
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/admin/service-requests/" + testID + "/assign",
		},
		{
			method: http.MethodPatch,
			path:   "/api/v1/admin/service-requests/" + testID + "/cancel",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/admin/vehicle-activations",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/specialists",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/admin/specialists",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/specialists/" + testID + "/competencies",
		},
		{
			method: http.MethodPut,
			path:   "/api/v1/admin/specialists/" + testID + "/competencies",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/vehicles/" + testID + "/specialists",
		},
		{
			method: http.MethodGet,
			path:   "/api/v1/admin/vehicles/" + testID + "/recommended-specialists",
		},
		{
			method: http.MethodPost,
			path:   "/api/v1/admin/vehicles/" + testID + "/specialists",
		},
		{
			method: http.MethodDelete,
			path:   "/api/v1/admin/vehicles/" + testID + "/specialists/" + testID,
		},
	}

	for _, route := range routes {
		t.Run(route.method+" "+route.path, func(t *testing.T) {
			var body io.Reader
			if route.path == "/api/v1/devices/esp32-demo-001/telemetry" {
				body = strings.NewReader(`{
					"engine_temperature":96.5,
					"battery_voltage":13.6,
					"vibration_level":2.1,
					"rpm":2600,
					"speed":72,
					"fuel_level":63.5
				}`)
			}
			if route.path == "/api/v1/auth/register" {
				body = strings.NewReader(`{
					"email":"user@example.com",
					"password":"StrongPassword123!",
					"first_name":"Viktor"
				}`)
			}
			if route.path == "/api/v1/auth/login" {
				body = strings.NewReader(`{
					"email":"user@example.com",
					"password":"StrongPassword123!"
				}`)
			}
			if route.path == "/api/v1/auth/google" {
				body = strings.NewReader(`{
					"id_token":"google-id-token"
				}`)
			}
			if route.path == "/api/v1/auth/google/link" {
				body = strings.NewReader(`{
					"id_token":"google-id-token"
				}`)
			}
			if route.path == "/api/v1/me/vehicle-activations/claim" {
				body = strings.NewReader(`{
					"activation_code":"AX7K-29QP"
				}`)
			}
			if route.method == http.MethodPost && route.path == "/api/v1/me/vehicles" {
				body = strings.NewReader(`{
					"vin":"TESTVIN0000000001",
					"brand":"Toyota",
					"model":"Corolla",
					"year":2020,
					"license_plate":"AA1234BB"
				}`)
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/me/vehicles/") &&
				strings.HasSuffix(route.path, "/devices") {
				body = strings.NewReader(`{
					"device_uid":"esp32-user-001",
					"name":"My ESP32"
				}`)
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/me/vehicles/") &&
				strings.HasSuffix(route.path, "/specialists") {
				body = strings.NewReader(`{
					"email":"specialist@example.com"
				}`)
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/me/vehicles/") &&
				strings.HasSuffix(route.path, "/service-requests") {
				body = strings.NewReader(`{
					"title":"Engine warning",
					"description":"Owner reports dashboard warning light.",
					"priority":"normal"
				}`)
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/specialist/vehicles/") &&
				strings.HasSuffix(route.path, "/maintenance-records") {
				body = strings.NewReader(`{
					"title":"Oil service",
					"description":"Changed oil and filter.",
					"service_date":"2026-06-17"
				}`)
			}
			if route.method == http.MethodPatch &&
				strings.HasPrefix(route.path, "/api/v1/specialist/service-requests/") &&
				strings.HasSuffix(route.path, "/complete") {
				body = strings.NewReader(`{
					"result_summary":"Completed diagnostics."
				}`)
			}
			if route.method == http.MethodPatch &&
				strings.HasPrefix(route.path, "/api/v1/specialist/alerts/") &&
				strings.HasSuffix(route.path, "/resolve") {
				body = strings.NewReader(`{
					"resolution_note":"Cooling system repaired and verified."
				}`)
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/admin/vehicles/") &&
				strings.HasSuffix(route.path, "/specialists") {
				body = strings.NewReader(`{
					"specialist_id":"11111111-1111-1111-1111-111111111111"
				}`)
			}
			if route.method == http.MethodPatch &&
				strings.HasPrefix(route.path, "/api/v1/admin/service-requests/") &&
				strings.HasSuffix(route.path, "/assign") {
				body = strings.NewReader(`{
					"specialist_id":"11111111-1111-1111-1111-111111111111"
				}`)
			}
			if route.method == http.MethodPost && route.path == "/api/v1/admin/specialists" {
				body = strings.NewReader(`{
					"email":"specialist.new@example.com",
					"password":"StrongPassword123!",
					"name":"New Specialist",
					"competencies":["engine_diagnostics"]
				}`)
			}
			if route.method == http.MethodPost && route.path == "/api/v1/admin/vehicle-activations" {
				body = strings.NewReader(`{
					"vin":"AUTONEXISDEMO0002",
					"brand":"Toyota",
					"model":"Corolla",
					"year":2022,
					"license_plate":"AX-0002",
					"device_uid":"esp32-demo-002",
					"device_name":"Owner ESP32"
				}`)
			}
			if route.method == http.MethodPut &&
				strings.HasPrefix(route.path, "/api/v1/admin/specialists/") &&
				strings.HasSuffix(route.path, "/competencies") {
				body = strings.NewReader(`{
					"codes":["engine_diagnostics","vibration_analysis"]
				}`)
			}
			request := httptest.NewRequest(route.method, route.path, body)
			if route.path == "/api/v1/auth/me" ||
				route.path == "/api/v1/auth/methods" ||
				route.path == "/api/v1/auth/google/link" ||
				strings.HasPrefix(route.path, "/api/v1/me/") ||
				strings.HasPrefix(route.path, "/api/v1/specialist/") {
				request.Header.Set("Authorization", "Bearer jwt")
			}
			if strings.HasPrefix(route.path, "/api/v1/specialist/") {
				request.Header.Set("Authorization", "Bearer specialist-jwt")
			}
			if strings.HasPrefix(route.path, "/api/v1/admin/") {
				request.Header.Set("Authorization", "Bearer admin-jwt")
			}
			recorder := httptest.NewRecorder()

			mux.ServeHTTP(recorder, request)

			wantStatus := http.StatusOK
			if route.path == "/api/v1/devices/esp32-demo-001/telemetry" {
				wantStatus = http.StatusCreated
			}
			if route.path == "/api/v1/auth/register" {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost && route.path == "/api/v1/me/vehicles" {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/me/vehicles/") &&
				strings.HasSuffix(route.path, "/devices") {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/me/vehicles/") &&
				strings.HasSuffix(route.path, "/specialists") {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/me/vehicles/") &&
				strings.HasSuffix(route.path, "/service-requests") {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/specialist/vehicles/") &&
				strings.HasSuffix(route.path, "/maintenance-records") {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost &&
				strings.HasPrefix(route.path, "/api/v1/admin/vehicles/") &&
				strings.HasSuffix(route.path, "/specialists") {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost && route.path == "/api/v1/admin/vehicle-activations" {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodPost && route.path == "/api/v1/admin/specialists" {
				wantStatus = http.StatusCreated
			}
			if route.method == http.MethodDelete {
				wantStatus = http.StatusNoContent
			}
			if recorder.Code != wantStatus {
				t.Fatalf("expected status %d, got %d", wantStatus, recorder.Code)
			}
		})
	}

	t.Run("PATCH /api/v1/me/alerts/{alert_id}/resolve is not registered", func(t *testing.T) {
		request := httptest.NewRequest(
			http.MethodPatch,
			"/api/v1/me/alerts/"+testID+"/resolve",
			nil,
		)
		request.Header.Set("Authorization", "Bearer jwt")
		recorder := httptest.NewRecorder()

		mux.ServeHTTP(recorder, request)

		if recorder.Code != http.StatusNotFound {
			t.Fatalf("expected status %d, got %d", http.StatusNotFound, recorder.Code)
		}
	})
}

func stringPtr(value string) *string {
	return &value
}
