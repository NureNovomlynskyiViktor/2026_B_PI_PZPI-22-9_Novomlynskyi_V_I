package ua.autonexis.mobile.ui.service

import ua.autonexis.mobile.ServiceRequest
import ua.autonexis.mobile.ServiceRequestDraft
import java.util.Locale

internal enum class ServiceRequestsBackTarget {
    VEHICLE_DETAILS,
    VEHICLES,
    REQUESTS_LIST,
    NOTIFICATIONS,
    REQUEST_DETAILS,
}

internal object ServiceRequestsPresentation {
    private val openStatuses = setOf("pending", "assigned", "in_progress")
    private val priorities = setOf("low", "normal", "high")

    fun newestFirst(requests: List<ServiceRequest>): List<ServiceRequest> {
        return requests.sortedWith(
            compareByDescending<ServiceRequest> { sortTimestamp(it) }
                .thenByDescending { it.id },
        )
    }

    fun statusLabel(status: String): String {
        return when (status.trim().lowercase(Locale.US)) {
            "pending" -> "Pending"
            "assigned" -> "Assigned"
            "in_progress" -> "In progress"
            "completed" -> "Completed"
            "cancelled" -> "Cancelled"
            else -> "Unknown"
        }
    }

    fun priorityLabel(priority: String): String {
        return when (priority.trim().lowercase(Locale.US)) {
            "low" -> "Low"
            "normal" -> "Normal"
            "high" -> "High"
            else -> "Normal"
        }
    }

    fun normalizedPriority(priority: String): String {
        val normalized = priority.trim().lowercase(Locale.US)
        return if (normalized in priorities) normalized else "normal"
    }

    fun canCancel(request: ServiceRequest): Boolean {
        return request.status.equals("pending", ignoreCase = true)
    }

    fun isOpen(request: ServiceRequest): Boolean {
        return request.status.trim().lowercase(Locale.US) in openStatuses
    }

    fun createdFromAlert(request: ServiceRequest): Boolean = !request.sourceAlertId.isNullOrBlank()

    fun specialistAssignmentLabel(request: ServiceRequest): String {
        return if (request.assignedSpecialistId.isNullOrBlank()) {
            "No specialist assigned yet"
        } else {
            "Technical specialist assigned"
        }
    }

    fun vehicleLabel(request: ServiceRequest, labels: Map<String, String>): String {
        return labels[request.vehicleId]?.takeIf { it.isNotBlank() } ?: "Unknown vehicle"
    }

    fun canCreateInMode(mode: ServiceRequestsMode): Boolean {
        return mode == ServiceRequestsMode.VEHICLE
    }

    fun backTarget(
        mode: ServiceRequestsMode,
        destination: ServiceRequestsDestination,
        detailsOrigin: ServiceRequestDetailsOrigin,
        formOrigin: ServiceRequestFormOrigin,
    ): ServiceRequestsBackTarget {
        return when (destination) {
            ServiceRequestsDestination.LIST -> if (mode == ServiceRequestsMode.GLOBAL) {
                ServiceRequestsBackTarget.VEHICLES
            } else {
                ServiceRequestsBackTarget.VEHICLE_DETAILS
            }
            ServiceRequestsDestination.DETAILS -> when (detailsOrigin) {
                ServiceRequestDetailsOrigin.GLOBAL_LIST,
                ServiceRequestDetailsOrigin.LIST -> ServiceRequestsBackTarget.REQUESTS_LIST
                ServiceRequestDetailsOrigin.NOTIFICATIONS -> ServiceRequestsBackTarget.NOTIFICATIONS
            }
            ServiceRequestsDestination.CREATE -> when (formOrigin) {
                ServiceRequestFormOrigin.VEHICLE_DETAILS -> ServiceRequestsBackTarget.VEHICLE_DETAILS
                ServiceRequestFormOrigin.LIST -> ServiceRequestsBackTarget.REQUESTS_LIST
                ServiceRequestFormOrigin.DETAILS -> ServiceRequestsBackTarget.REQUEST_DETAILS
            }
        }
    }

    fun validateDraft(draft: ServiceRequestDraft): String? {
        return when {
            draft.title.trim().isBlank() -> "Title is required."
            draft.description.trim().isBlank() -> "Description is required."
            normalizedPriority(draft.priority) !in priorities -> "Choose a valid priority."
            else -> null
        }
    }

    fun sanitizedDraft(draft: ServiceRequestDraft): ServiceRequestDraft {
        return ServiceRequestDraft(
            title = draft.title.trim(),
            description = draft.description.trim(),
            priority = normalizedPriority(draft.priority),
            sourceAlertId = draft.sourceAlertId?.takeIf { it.isNotBlank() },
        )
    }

    fun duplicateAlertRequestMessage(baseMessage: String): String {
        val suffix = "An open service request already exists for this alert."
        return if (baseMessage.contains(suffix, ignoreCase = true)) baseMessage else "$baseMessage $suffix"
    }

    private fun sortTimestamp(request: ServiceRequest): String {
        return request.createdAt.ifBlank { request.updatedAt }
    }
}
