package adminaudit

import (
	"context"
	"errors"
	"strings"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/identifier"
)

var ErrInvalidInput = errors.New("invalid audit log filters")

const (
	maxActionLength      = 128
	maxActorSearchLength = 320
	maxEntityTypeLength  = 128
	maxEntityIDLength    = 255
)

type Service interface {
	List(ctx context.Context, filters ListFilters) (ListResponse, error)
}

type service struct {
	repository Repository
}

func NewService(repository Repository) Service {
	return &service{repository: repository}
}

func (s *service) List(ctx context.Context, filters ListFilters) (ListResponse, error) {
	normalized, err := normalizeFilters(filters)
	if err != nil {
		return ListResponse{}, err
	}

	items, total, err := s.repository.List(ctx, normalized)
	if err != nil {
		return ListResponse{}, err
	}

	return ListResponse{
		Items: items,
		Pagination: Pagination{
			Limit:   normalized.Limit,
			Offset:  normalized.Offset,
			Total:   total,
			HasMore: normalized.Offset+len(items) < total,
		},
	}, nil
}

func normalizeFilters(filters ListFilters) (ListFilters, error) {
	filters.Action = strings.TrimSpace(filters.Action)
	filters.ActorID = strings.TrimSpace(filters.ActorID)
	filters.ActorSearch = strings.TrimSpace(filters.ActorSearch)
	filters.EntityType = strings.TrimSpace(filters.EntityType)
	filters.EntityID = strings.TrimSpace(filters.EntityID)

	if len([]rune(filters.Action)) > maxActionLength ||
		len([]rune(filters.ActorSearch)) > maxActorSearchLength ||
		len([]rune(filters.EntityType)) > maxEntityTypeLength ||
		len([]rune(filters.EntityID)) > maxEntityIDLength {
		return ListFilters{}, ErrInvalidInput
	}
	if filters.ActorID != "" && !identifier.IsUUID(filters.ActorID) {
		return ListFilters{}, ErrInvalidInput
	}
	if filters.DateFrom != nil && filters.DateTo != nil && filters.DateFrom.After(*filters.DateTo) {
		return ListFilters{}, ErrInvalidInput
	}
	if filters.Limit == 0 && !filters.LimitSet {
		filters.Limit = DefaultLimit
	}
	if filters.Limit < 1 || filters.Limit > MaxLimit {
		return ListFilters{}, ErrInvalidInput
	}
	if filters.Offset < 0 {
		return ListFilters{}, ErrInvalidInput
	}

	return filters, nil
}
