BEGIN;

INSERT INTO users (
    id,
    role_id,
    email,
    password_hash,
    full_name,
    is_active,
    created_at,
    updated_at
)
VALUES
    (
        '11111111-1111-1111-1111-111111111111',
        '00000000-0000-0000-0000-000000000001',
        'owner@example.com',
        '$2a$12$sjlFoX1EcZOxsZyxJ6Rhle6VkZU6kgFbKNZU3mTxeayTpcU78JzAa',
        'Demo Vehicle Owner',
        TRUE,
        '2026-06-15T09:00:00Z',
        '2026-06-15T09:00:00Z'
    ),
    (
        '77777777-7777-7777-7777-777777777777',
        '00000000-0000-0000-0000-000000000002',
        'specialist@example.com',
        '$2a$12$sjlFoX1EcZOxsZyxJ6Rhle6VkZU6kgFbKNZU3mTxeayTpcU78JzAa',
        'Demo General Specialist',
        TRUE,
        '2026-06-15T09:00:00Z',
        '2026-06-15T09:00:00Z'
    ),
    (
        '88888888-8888-8888-8888-888888888888',
        '00000000-0000-0000-0000-000000000002',
        'specialist.engine@example.com',
        '$2a$12$sjlFoX1EcZOxsZyxJ6Rhle6VkZU6kgFbKNZU3mTxeayTpcU78JzAa',
        'Demo Engine Specialist',
        TRUE,
        '2026-06-15T09:00:00Z',
        '2026-06-15T09:00:00Z'
    ),
    (
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        '00000000-0000-0000-0000-000000000002',
        'specialist.electrical@example.com',
        '$2a$12$sjlFoX1EcZOxsZyxJ6Rhle6VkZU6kgFbKNZU3mTxeayTpcU78JzAa',
        'Demo Electrical Specialist',
        TRUE,
        '2026-06-15T09:00:00Z',
        '2026-06-15T09:00:00Z'
    ),
    (
        '99999999-9999-9999-9999-999999999999',
        '00000000-0000-0000-0000-000000000003',
        'admin@example.com',
        '$2a$12$sjlFoX1EcZOxsZyxJ6Rhle6VkZU6kgFbKNZU3mTxeayTpcU78JzAa',
        'Demo Administrator',
        TRUE,
        '2026-06-15T09:00:00Z',
        '2026-06-15T09:00:00Z'
    )
ON CONFLICT (id) DO UPDATE SET
    role_id = EXCLUDED.role_id,
    email = EXCLUDED.email,
    password_hash = EXCLUDED.password_hash,
    full_name = EXCLUDED.full_name,
    is_active = EXCLUDED.is_active,
    updated_at = EXCLUDED.updated_at;

INSERT INTO vehicles (
    id,
    owner_id,
    vin,
    brand,
    model,
    year,
    license_plate,
    created_at,
    updated_at
)
VALUES (
    '22222222-2222-2222-2222-222222222222',
    '11111111-1111-1111-1111-111111111111',
    'DEMOAUTONEXIS0001',
    'Autonexis',
    'Demo Car',
    2024,
    'DEMO-001',
    '2026-06-15T09:05:00Z',
    '2026-06-15T09:05:00Z'
)
ON CONFLICT DO NOTHING;

INSERT INTO devices (
    id,
    vehicle_id,
    device_uid,
    name,
    status,
    last_seen_at,
    created_at,
    updated_at
)
VALUES (
    '33333333-3333-3333-3333-333333333333',
    '22222222-2222-2222-2222-222222222222',
    'esp32-demo-001',
    'Demo ESP32',
    'active',
    '2026-06-15T10:20:00Z',
    '2026-06-15T09:10:00Z',
    '2026-06-15T10:20:00Z'
)
ON CONFLICT DO NOTHING;

INSERT INTO telemetry_records (
    vehicle_id,
    device_id,
    measured_at,
    received_at,
    engine_temperature,
    battery_voltage,
    vibration_level,
    rpm,
    speed,
    fuel_level
)
SELECT
    seed.vehicle_id::UUID,
    seed.device_id::UUID,
    seed.measured_at::TIMESTAMPTZ,
    seed.received_at::TIMESTAMPTZ,
    seed.engine_temperature,
    seed.battery_voltage,
    seed.vibration_level,
    seed.rpm,
    seed.speed,
    seed.fuel_level
FROM (
    VALUES
        (
            '22222222-2222-2222-2222-222222222222',
            '33333333-3333-3333-3333-333333333333',
            '2026-06-15T10:00:00Z',
            '2026-06-15T10:00:01Z',
            82.50,
            13.90,
            1.200,
            1800,
            45.00,
            68.00
        ),
        (
            '22222222-2222-2222-2222-222222222222',
            '33333333-3333-3333-3333-333333333333',
            '2026-06-15T10:05:00Z',
            '2026-06-15T10:05:01Z',
            87.20,
            13.80,
            1.500,
            2200,
            62.00,
            67.50
        ),
        (
            '22222222-2222-2222-2222-222222222222',
            '33333333-3333-3333-3333-333333333333',
            '2026-06-15T10:10:00Z',
            '2026-06-15T10:10:01Z',
            92.40,
            13.70,
            2.100,
            2600,
            78.00,
            66.80
        ),
        (
            '22222222-2222-2222-2222-222222222222',
            '33333333-3333-3333-3333-333333333333',
            '2026-06-15T10:15:00Z',
            '2026-06-15T10:15:01Z',
            96.80,
            13.60,
            2.600,
            2900,
            86.00,
            66.20
        ),
        (
            '22222222-2222-2222-2222-222222222222',
            '33333333-3333-3333-3333-333333333333',
            '2026-06-15T10:20:00Z',
            '2026-06-15T10:20:01Z',
            94.10,
            13.70,
            1.900,
            2400,
            70.00,
            65.70
        )
) AS seed (
    vehicle_id,
    device_id,
    measured_at,
    received_at,
    engine_temperature,
    battery_voltage,
    vibration_level,
    rpm,
    speed,
    fuel_level
)
WHERE NOT EXISTS (
    SELECT 1
    FROM telemetry_records existing
    WHERE existing.vehicle_id = seed.vehicle_id::UUID
      AND existing.device_id = seed.device_id::UUID
      AND existing.measured_at = seed.measured_at::TIMESTAMPTZ
);

INSERT INTO threshold_settings (
    id,
    vehicle_id,
    parameter,
    warning_value,
    critical_value,
    created_at,
    updated_at
)
VALUES
    (
        '55555555-5555-5555-5555-555555555551',
        '22222222-2222-2222-2222-222222222222',
        'engine_temperature',
        90.000,
        105.000,
        '2026-06-15T09:15:00Z',
        '2026-06-15T09:15:00Z'
    ),
    (
        '55555555-5555-5555-5555-555555555552',
        '22222222-2222-2222-2222-222222222222',
        'battery_voltage',
        12.200,
        11.500,
        '2026-06-15T09:15:00Z',
        '2026-06-15T09:15:00Z'
    ),
    (
        '55555555-5555-5555-5555-555555555553',
        '22222222-2222-2222-2222-222222222222',
        'vibration_level',
        1.500,
        1.800,
        '2026-06-15T09:15:00Z',
        '2026-06-15T09:15:00Z'
    ),
    (
        '55555555-5555-5555-5555-555555555554',
        '22222222-2222-2222-2222-222222222222',
        'rpm',
        2200.000,
        3500.000,
        '2026-06-15T09:15:00Z',
        '2026-06-15T09:15:00Z'
    )
ON CONFLICT (id) DO UPDATE SET
    vehicle_id = EXCLUDED.vehicle_id,
    parameter = EXCLUDED.parameter,
    warning_value = EXCLUDED.warning_value,
    critical_value = EXCLUDED.critical_value,
    updated_at = EXCLUDED.updated_at;

INSERT INTO alerts (
    id,
    vehicle_id,
    telemetry_record_id,
    type,
    severity,
    status,
    message,
    recommendation,
    created_at,
    resolved_at
)
SELECT
    '44444444-4444-4444-4444-444444444441',
    telemetry.vehicle_id,
    telemetry.id,
    'engine_temperature',
    'warning',
    'active',
    'Engine temperature is above the warning threshold.',
    'Reduce engine load and monitor the temperature.',
    '2026-06-15T10:12:00Z',
    NULL
FROM telemetry_records telemetry
WHERE telemetry.vehicle_id = '22222222-2222-2222-2222-222222222222'
  AND telemetry.device_id = '33333333-3333-3333-3333-333333333333'
  AND telemetry.measured_at = '2026-06-15T10:10:00Z'
ON CONFLICT (id) DO UPDATE SET
    vehicle_id = EXCLUDED.vehicle_id,
    telemetry_record_id = EXCLUDED.telemetry_record_id,
    type = EXCLUDED.type,
    severity = EXCLUDED.severity,
    status = EXCLUDED.status,
    message = EXCLUDED.message,
    recommendation = EXCLUDED.recommendation,
    created_at = EXCLUDED.created_at,
    resolved_at = EXCLUDED.resolved_at;

INSERT INTO alerts (
    id,
    vehicle_id,
    telemetry_record_id,
    type,
    severity,
    status,
    message,
    recommendation,
    created_at,
    resolved_at
)
SELECT
    '44444444-4444-4444-4444-444444444442',
    telemetry.vehicle_id,
    telemetry.id,
    'vibration_level',
    'critical',
    'active',
    'Vehicle vibration reached a critical level.',
    'Stop the vehicle safely and inspect the engine and mounting components.',
    '2026-06-15T10:17:00Z',
    NULL
FROM telemetry_records telemetry
WHERE telemetry.vehicle_id = '22222222-2222-2222-2222-222222222222'
  AND telemetry.device_id = '33333333-3333-3333-3333-333333333333'
  AND telemetry.measured_at = '2026-06-15T10:15:00Z'
ON CONFLICT (id) DO UPDATE SET
    vehicle_id = EXCLUDED.vehicle_id,
    telemetry_record_id = EXCLUDED.telemetry_record_id,
    type = EXCLUDED.type,
    severity = EXCLUDED.severity,
    status = EXCLUDED.status,
    message = EXCLUDED.message,
    recommendation = EXCLUDED.recommendation,
    created_at = EXCLUDED.created_at,
    resolved_at = EXCLUDED.resolved_at;

INSERT INTO alerts (
    id,
    vehicle_id,
    telemetry_record_id,
    type,
    severity,
    status,
    message,
    recommendation,
    created_at,
    resolved_at
)
SELECT
    '44444444-4444-4444-4444-444444444443',
    telemetry.vehicle_id,
    telemetry.id,
    'battery_voltage',
    'warning',
    'resolved',
    'Battery voltage temporarily dropped below the expected level.',
    'Check battery terminals during the next maintenance inspection.',
    '2026-06-15T10:03:00Z',
    '2026-06-15T10:08:00Z'
FROM telemetry_records telemetry
WHERE telemetry.vehicle_id = '22222222-2222-2222-2222-222222222222'
  AND telemetry.device_id = '33333333-3333-3333-3333-333333333333'
  AND telemetry.measured_at = '2026-06-15T10:00:00Z'
ON CONFLICT (id) DO UPDATE SET
    vehicle_id = EXCLUDED.vehicle_id,
    telemetry_record_id = EXCLUDED.telemetry_record_id,
    type = EXCLUDED.type,
    severity = EXCLUDED.severity,
    status = EXCLUDED.status,
    message = EXCLUDED.message,
    recommendation = EXCLUDED.recommendation,
    created_at = EXCLUDED.created_at,
    resolved_at = EXCLUDED.resolved_at;

INSERT INTO maintenance_records (
    id,
    vehicle_id,
    created_by,
    title,
    description,
    service_date,
    created_at
)
VALUES
    (
        '66666666-6666-6666-6666-666666666661',
        '22222222-2222-2222-2222-222222222222',
        '77777777-7777-7777-7777-777777777777',
        'Oil and filter replacement',
        'Replaced engine oil and oil filter after scheduled inspection.',
        '2026-05-20',
        '2026-05-20T11:30:00Z'
    ),
    (
        '66666666-6666-6666-6666-666666666662',
        '22222222-2222-2222-2222-222222222222',
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        'Battery and charging check',
        'Checked battery terminals, charging voltage, and alternator output. No replacement required.',
        '2026-04-12',
        '2026-04-12T14:10:00Z'
    ),
    (
        '66666666-6666-6666-6666-666666666663',
        '22222222-2222-2222-2222-222222222222',
        '88888888-8888-8888-8888-888888888888',
        'Vibration inspection',
        'Inspected engine mounts and suspension after elevated vibration readings.',
        '2026-03-18',
        '2026-03-18T09:45:00Z'
    )
ON CONFLICT (id) DO UPDATE SET
    vehicle_id = EXCLUDED.vehicle_id,
    created_by = EXCLUDED.created_by,
    title = EXCLUDED.title,
    description = EXCLUDED.description,
    service_date = EXCLUDED.service_date,
    created_at = EXCLUDED.created_at;

INSERT INTO vehicle_specialist_assignments (
    id,
    vehicle_id,
    specialist_id,
    assigned_by,
    created_at
)
VALUES (
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    '22222222-2222-2222-2222-222222222222',
    '77777777-7777-7777-7777-777777777777',
    '99999999-9999-9999-9999-999999999999',
    '2026-06-15T09:30:00Z'
)
ON CONFLICT (vehicle_id, specialist_id) DO UPDATE SET
    assigned_by = EXCLUDED.assigned_by,
    created_at = EXCLUDED.created_at;

INSERT INTO specialist_competencies (
    id,
    specialist_id,
    code,
    name,
    created_at
)
VALUES
    (
        'c0000000-0000-0000-0000-000000000001',
        '77777777-7777-7777-7777-777777777777',
        'general_maintenance',
        'General maintenance',
        '2026-06-15T09:35:00Z'
    ),
    (
        'c0000000-0000-0000-0000-000000000002',
        '77777777-7777-7777-7777-777777777777',
        'iot_device_setup',
        'IoT device setup',
        '2026-06-15T09:35:00Z'
    ),
    (
        'c0000000-0000-0000-0000-000000000003',
        '88888888-8888-8888-8888-888888888888',
        'engine_diagnostics',
        'Engine diagnostics',
        '2026-06-15T09:35:00Z'
    ),
    (
        'c0000000-0000-0000-0000-000000000004',
        '88888888-8888-8888-8888-888888888888',
        'vibration_analysis',
        'Vibration analysis',
        '2026-06-15T09:35:00Z'
    ),
    (
        'c0000000-0000-0000-0000-000000000005',
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        'battery_and_electrical',
        'Battery and electrical systems',
        '2026-06-15T09:35:00Z'
    ),
    (
        'c0000000-0000-0000-0000-000000000006',
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        'fuel_system',
        'Fuel system',
        '2026-06-15T09:35:00Z'
    )
ON CONFLICT (specialist_id, code) DO UPDATE SET
    name = EXCLUDED.name;

COMMIT;
