package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class NotificationPresentationTest {
    @Test
    fun supportsNullableNotificationReferences() {
        val notification = notification(
            alertId = null,
            serviceRequestId = "request-1",
            notificationType = NotificationPresentation.TYPE_SERVICE_REQUEST_COMPLETED,
        )

        assertNull(notification.alertId)
        assertEquals("request-1", notification.serviceRequestId)
        assertTrue(NotificationPresentation.canViewServiceRequest(notification))
    }

    @Test
    fun returnsHumanReadableNotificationTypeLabels() {
        assertEquals(
            "Vehicle alert",
            NotificationPresentation.typeLabel(NotificationPresentation.TYPE_VEHICLE_ALERT),
        )
        assertEquals(
            "Service request assigned",
            NotificationPresentation.typeLabel(NotificationPresentation.TYPE_SERVICE_REQUEST_ASSIGNED),
        )
        assertEquals(
            "Service work started",
            NotificationPresentation.typeLabel(NotificationPresentation.TYPE_SERVICE_REQUEST_STARTED),
        )
        assertEquals(
            "Service request completed",
            NotificationPresentation.typeLabel(NotificationPresentation.TYPE_SERVICE_REQUEST_COMPLETED),
        )
    }

    @Test
    fun showsSeverityOnlyForVehicleAlertNotifications() {
        val alertNotification = notification(
            alertId = "alert-1",
            notificationType = NotificationPresentation.TYPE_VEHICLE_ALERT,
            title = "CRITICAL alert: rpm",
        )
        val serviceNotification = notification(
            serviceRequestId = "request-1",
            notificationType = NotificationPresentation.TYPE_SERVICE_REQUEST_STARTED,
            title = "Service work started",
        )

        assertTrue(NotificationPresentation.shouldShowSeverity(alertNotification))
        assertEquals("CRITICAL", NotificationPresentation.severityLabel(alertNotification))
        assertFalse(NotificationPresentation.shouldShowSeverity(serviceNotification))
        assertNull(NotificationPresentation.severityLabel(serviceNotification))
    }

    @Test
    fun viewServiceRequestIsAvailableOnlyWithServiceRequestReference() {
        assertTrue(
            NotificationPresentation.canViewServiceRequest(
                notification(serviceRequestId = "request-1"),
            ),
        )
        assertFalse(
            NotificationPresentation.canViewServiceRequest(
                notification(serviceRequestId = null),
            ),
        )
        assertFalse(
            NotificationPresentation.canViewServiceRequest(
                notification(serviceRequestId = "   "),
            ),
        )
    }

    @Test
    fun keepsUnknownNotificationTypesReadable() {
        val unknown = notification(notificationType = "future_domain_event")

        assertEquals("Future domain event", NotificationPresentation.typeLabel(unknown.notificationType))
        assertFalse(NotificationPresentation.shouldShowSeverity(unknown))
        assertNull(NotificationPresentation.severityLabel(unknown))
    }

    private fun notification(
        alertId: String? = null,
        serviceRequestId: String? = null,
        notificationType: String = NotificationPresentation.TYPE_VEHICLE_ALERT,
        title: String = "Notification title",
        message: String = "Notification message",
    ): OwnerNotification {
        return OwnerNotification(
            id = "notification-1",
            alertId = alertId,
            serviceRequestId = serviceRequestId,
            notificationType = notificationType,
            title = title,
            message = message,
            isRead = false,
            createdAt = "2026-06-18T10:00:00Z",
        )
    }
}
