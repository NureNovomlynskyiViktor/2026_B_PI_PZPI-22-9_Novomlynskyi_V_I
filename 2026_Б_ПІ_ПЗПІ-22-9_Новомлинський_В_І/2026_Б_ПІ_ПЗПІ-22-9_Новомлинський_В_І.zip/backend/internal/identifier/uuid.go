package identifier

import "regexp"

var deviceUIDPattern = regexp.MustCompile(`^[A-Za-z0-9_-]{3,64}$`)

func IsUUID(value string) bool {
	if len(value) != 36 {
		return false
	}

	for index, character := range value {
		switch index {
		case 8, 13, 18, 23:
			if character != '-' {
				return false
			}
		default:
			if !isHex(character) {
				return false
			}
		}
	}

	return true
}

func IsDeviceUID(value string) bool {
	return deviceUIDPattern.MatchString(value)
}

func isHex(character rune) bool {
	return character >= '0' && character <= '9' ||
		character >= 'a' && character <= 'f' ||
		character >= 'A' && character <= 'F'
}
