package adminuser

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/NureNovomlynskyiViktor/2026_B_PI_PZPI-22-9_Novomlynskyi_V_I/backend/internal/auth"
)

const (
	testAdminID      = "11111111-1111-1111-1111-111111111111"
	testTargetUserID = "22222222-2222-2222-2222-222222222222"
)

func TestListNormalizesFiltersAndSearch(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)
	active := true

	_, err := service.List(context.Background(), ListFilters{
		Role:     "technical_specialist",
		IsActive: &active,
		Search:   "  Specialist@Example.com  ",
	})
	if err != nil {
		t.Fatalf("List returned error: %v", err)
	}
	if repository.filters.Role != auth.TechnicalSpecialistRoleCode {
		t.Fatalf("unexpected role filter: %q", repository.filters.Role)
	}
	if repository.filters.Search != "Specialist@Example.com" {
		t.Fatalf("unexpected search filter: %q", repository.filters.Search)
	}

	_, err = service.List(context.Background(), ListFilters{Role: "super_admin"})
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for unsupported role, got %v", err)
	}
}

func TestDeactivateAndReactivate(t *testing.T) {
	repository := &repositoryStub{}
	service := NewService(repository)
	actor := testAdminUser()

	deactivated, err := service.Deactivate(
		context.Background(),
		actor,
		testTargetUserID,
		DeactivateRequest{Reason: "  Administrative decision  "},
	)
	if err != nil {
		t.Fatalf("Deactivate returned error: %v", err)
	}
	if deactivated.IsActive {
		t.Fatal("expected deactivated user")
	}
	if repository.reason == nil || *repository.reason != "Administrative decision" {
		t.Fatalf("expected normalized reason, got %#v", repository.reason)
	}

	reactivated, err := service.Reactivate(context.Background(), actor, testTargetUserID)
	if err != nil {
		t.Fatalf("Reactivate returned error: %v", err)
	}
	if !reactivated.IsActive {
		t.Fatal("expected reactivated user")
	}
}

func TestDeactivateRejectsSelfAndLongReason(t *testing.T) {
	service := NewService(&repositoryStub{})
	actor := testAdminUser()

	_, err := service.Deactivate(
		context.Background(),
		actor,
		actor.ID,
		DeactivateRequest{},
	)
	if !errors.Is(err, ErrSelfDeactivation) {
		t.Fatalf("expected ErrSelfDeactivation, got %v", err)
	}

	_, err = service.Deactivate(
		context.Background(),
		actor,
		testTargetUserID,
		DeactivateRequest{Reason: strings.Repeat("a", maxReasonLength+1)},
	)
	if !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for long reason, got %v", err)
	}
}

func TestLifecycleConflictsAreReturned(t *testing.T) {
	tests := []error{
		ErrLastAdministrator,
		ErrSpecialistActiveWork,
		ErrAlreadyInactive,
		ErrAuditInsertFailed,
	}
	for _, expected := range tests {
		t.Run(expected.Error(), func(t *testing.T) {
			service := NewService(&repositoryStub{deactivateErr: expected})

			_, err := service.Deactivate(
				context.Background(),
				testAdminUser(),
				testTargetUserID,
				DeactivateRequest{},
			)
			if !errors.Is(err, expected) {
				t.Fatalf("expected %v, got %v", expected, err)
			}
		})
	}

	service := NewService(&repositoryStub{reactivateErr: ErrAlreadyActive})
	_, err := service.Reactivate(context.Background(), testAdminUser(), testTargetUserID)
	if !errors.Is(err, ErrAlreadyActive) {
		t.Fatalf("expected ErrAlreadyActive, got %v", err)
	}
}

func TestInvalidIDs(t *testing.T) {
	service := NewService(&repositoryStub{})

	if _, err := service.Get(context.Background(), "bad"); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for Get, got %v", err)
	}
	if _, err := service.Reactivate(context.Background(), testAdminUser(), "bad"); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("expected ErrInvalidInput for Reactivate, got %v", err)
	}
}

type repositoryStub struct {
	filters       ListFilters
	reason        *string
	deactivateErr error
	reactivateErr error
}

func (r *repositoryStub) List(_ context.Context, filters ListFilters) ([]User, error) {
	r.filters = filters
	return []User{}, nil
}

func (r *repositoryStub) GetByID(context.Context, string) (User, error) {
	return User{ID: testTargetUserID}, nil
}

func (r *repositoryStub) Deactivate(
	_ context.Context,
	_ string,
	_ string,
	reason *string,
) (User, error) {
	r.reason = reason
	if r.deactivateErr != nil {
		return User{}, r.deactivateErr
	}
	return User{ID: testTargetUserID, IsActive: false}, nil
}

func (r *repositoryStub) Reactivate(context.Context, string, string) (User, error) {
	if r.reactivateErr != nil {
		return User{}, r.reactivateErr
	}
	return User{ID: testTargetUserID, IsActive: true}, nil
}

func testAdminUser() auth.User {
	return auth.User{
		ID:   testAdminID,
		Role: auth.AdministratorRoleCode,
	}
}
