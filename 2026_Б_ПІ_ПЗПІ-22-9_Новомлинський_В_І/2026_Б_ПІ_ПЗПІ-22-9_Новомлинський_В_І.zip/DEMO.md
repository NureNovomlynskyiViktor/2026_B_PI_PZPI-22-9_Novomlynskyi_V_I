# Autonexis Local Demo Runbook

Practical runbook for running, testing, and recording a local Autonexis demo on Windows.

Autonexis is a software system for monitoring the technical condition of a vehicle using IoT. The demo stack includes:

- Go backend modular monolith;
- PostgreSQL database;
- MQTT telemetry consumer;
- ESP32/Wokwi telemetry demo;
- Web app for administrators and technical specialists;
- Android app for vehicle owners.

Vehicle owners primarily use the Android app. The web owner experience is only for Android onboarding, APK download guidance, and activation guidance. The old owner web dashboard is intentionally not part of the product demo.

## Demo Values

Replace these values if your local network changes:

| Purpose | Current demo value |
|---|---|
| Android emulator backend URL | `http://10.0.2.2:8080` |
| Physical phone backend URL | `http://192.168.0.163:8080` |
| Local APK download URL | `http://192.168.0.163:8000/autonexis-demo-phone-debug.apk` |
| MQTT broker | `broker.hivemq.com:1883` |
| MQTT telemetry topic filter | `autonexis/devices/+/telemetry` |

## Prerequisites

- PostgreSQL/database is running and migrations are applied.
- Go is installed.
- Node.js and npm are installed.
- Android Studio/Android SDK is installed for APK builds.
- Python or the Windows `py` launcher is available for the local APK server.
- Android phone is connected to the same Wi-Fi network as the laptop.
- The Android phone allows installing local debug APKs when prompted.

## Check Laptop Wi-Fi IP

The physical phone must reach the laptop over Wi-Fi. Check the laptop IPv4 address:

```powershell
Get-NetIPAddress -AddressFamily IPv4 |
  Where-Object { $_.IPAddress -like "192.168.*" -or $_.IPAddress -like "10.*" } |
  Select-Object InterfaceAlias, IPAddress
```

The currently tested local demo value is:

```text
192.168.0.163
```

If the IP changes, replace it in:

- `mobile/android/local.properties`;
- `web/.env.local`;
- any local APK server URL used in QR codes or recording notes.

## Start Backend with MQTT and Google Auth

Start from `backend/`:

```powershell
cd backend

$env:MQTT_ENABLED = "true"
$env:MQTT_BROKER_HOST = "broker.hivemq.com"
$env:MQTT_BROKER_PORT = "1883"
$env:MQTT_CLIENT_ID = "autonexis-backend-viktor"
$env:MQTT_TELEMETRY_TOPIC = "autonexis/devices/+/telemetry"
$env:GOOGLE_AUTH_ENABLED = "true"
$env:GOOGLE_OAUTH_CLIENT_IDS = "575488984120-g9lvgggtd8nrhdv5jlk2i9p0dflic30h.apps.googleusercontent.com"

go run ./cmd/server
```

Expected backend log meanings:

- database connection established;
- `MQTT telemetry consumer background startup begins`;
- HTTP server starts on `0.0.0.0:8080`;
- `MQTT telemetry consumer started` when the broker is reachable.

MQTT is an optional runtime dependency. If `broker.hivemq.com` is temporarily unavailable, HTTP should still start and the MQTT supervisor should keep retrying in the background.

## Build Android APK for Physical Phone

Use the physical phone backend URL, not the emulator URL.

In `mobile/android/local.properties`, keep your existing `sdk.dir` and Google client ID settings, and add or update:

```properties
autonexis.apiBaseUrl=http://192.168.0.163:8080
```

Build:

```powershell
cd mobile/android
.\gradlew.bat clean assembleDebug
```

APK output:

```text
mobile/android/app/build/outputs/apk/debug/app-debug.apk
```

Copy the APK outside the repository:

```powershell
New-Item -ItemType Directory -Force D:\AutonexisDemo\apk
Copy-Item .\app\build\outputs\apk\debug\app-debug.apk D:\AutonexisDemo\apk\autonexis-demo-phone-debug.apk
```

Do not commit APK files or `local.properties`.

## Serve APK Locally

Start a local static file server outside the repository:

```powershell
cd D:\AutonexisDemo\apk
py -m http.server 8000 --bind 0.0.0.0
```

Fallback if `py` is not available:

```powershell
python -m http.server 8000 --bind 0.0.0.0
```

APK URL:

```text
http://192.168.0.163:8000/autonexis-demo-phone-debug.apk
```

Android security warnings are expected for sideloaded debug APKs distributed outside Google Play.

## Web QR Setup

Create `web/.env.local` locally:

```env
VITE_ANDROID_APK_URL=http://192.168.0.163:8000/autonexis-demo-phone-debug.apk
```

Start the web app:

```powershell
cd web
npm run dev
```

Open on the laptop:

```text
http://localhost:5173
```

Use the owner onboarding page to show the APK QR/download link.

Important distinction:

- APK QR downloads the Android application.
- Vehicle activation QR connects a specific vehicle to an owner account.

These are different QR codes. The phone does not need to open the Vite site directly; it only needs to scan the laptop screen QR and download the APK URL.

If `VITE_ANDROID_APK_URL` changes, restart Vite so the new value is loaded.

## Optional Local Demo Launcher

You may keep a local `.bat` file outside the repository, for example under:

```text
D:\AutonexisDemo
```

It can start:

- backend;
- APK HTTP server;
- web QR page.

Do not commit local launcher scripts.

## Demo Recording Flow Under 5 Minutes

1. Start backend and show healthy logs briefly.
2. Open the web public landing page.
3. Show the owner Android onboarding/download page.
4. Show the APK QR and APK download flow.
5. Open the Android app on the phone.
6. Log in as a vehicle owner.
7. Show Android tabs:
   - Vehicles;
   - Requests;
   - Notifications;
   - Account.
8. Briefly show administrator web workspace.
9. Briefly show technical specialist web workspace.
10. Optional if time permits: show Wokwi/MQTT telemetry logs and Android status updates.

## Final Validation Commands

Backend:

```powershell
cd backend
go test ./...
go vet ./...
```

Web:

```powershell
cd web
npm run build
```

Repository hygiene:

```powershell
git diff --check
git status --short
```

`git status --short` should not show APK files, local env files, logs, keystores, build outputs, or local launcher scripts.

## Troubleshooting

### Phone cannot reach backend

- Confirm the phone is on the same Wi-Fi network as the laptop.
- Recheck the laptop Wi-Fi IP with `Get-NetIPAddress`.
- Confirm the Android app was built with `autonexis.apiBaseUrl=http://192.168.0.163:8080` or the current laptop IP.
- Check Windows Firewall for port `8080`.

### APK download QR does not work

- Confirm the APK server is running:

  ```powershell
  cd D:\AutonexisDemo\apk
  py -m http.server 8000 --bind 0.0.0.0
  ```

- Open the APK URL from the phone browser:

  ```text
  http://192.168.0.163:8000/autonexis-demo-phone-debug.apk
  ```

- Check Windows Firewall for port `8000`.
- Confirm `web/.env.local` has the current URL.
- Restart Vite after changing `VITE_ANDROID_APK_URL`.

### Android blocks installation

This is expected for a local debug APK outside Google Play. Allow installation from the browser/file source when Android prompts.

### App connects to emulator URL

The APK was likely built with the emulator URL. Update `mobile/android/local.properties`:

```properties
autonexis.apiBaseUrl=http://192.168.0.163:8080
```

Then rebuild and reinstall the APK.

### PostgreSQL is not running

- Start the database stack according to the project backend documentation.
- Confirm migrations are applied.
- Check backend readiness:

  ```powershell
  Invoke-RestMethod http://localhost:8080/ready
  ```

### MQTT broker is unavailable

The backend HTTP API should still start. MQTT logs should show retry behavior. If HTTP does not start, check for static configuration errors such as an invalid topic filter, empty broker host, or database startup errors.

## Do Not Commit

Never commit:

- APK files;
- `mobile/android/local.properties`;
- `web/.env.local`;
- keystores and signing property files;
- local launcher `.bat` files;
- build outputs;
- local logs;
- local secrets or passwords.

