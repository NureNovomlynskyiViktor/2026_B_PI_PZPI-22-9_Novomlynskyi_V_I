package ua.autonexis.mobile

import androidx.annotation.StringRes
import java.net.URI
import java.net.URLDecoder

object ActivationCodeParser {
    private const val SCHEME = "autonexis"
    private const val HOST = "vehicle-activation"
    private val activationCodePattern = Regex("^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$")

    fun normalizeManualCode(value: String): String? {
        val compact = value.trim()
            .uppercase()
            .replace(" ", "")
            .replace("-", "")

        if (compact.length != 8) {
            return null
        }

        val normalized = compact.take(4) + "-" + compact.drop(4)
        return if (activationCodePattern.matches(normalized)) normalized else null
    }

    fun parseScannedValue(value: String): ParseResult {
        val trimmed = value.trim()
        if (trimmed.isBlank()) {
            return ParseResult.Invalid(R.string.qr_blank)
        }

        if (!trimmed.contains("://")) {
            return normalizeManualCode(trimmed)?.let(ParseResult::Success)
                ?: ParseResult.Invalid(R.string.qr_invalid_code)
        }

        val uri = try {
            URI(trimmed)
        } catch (_: Exception) {
            return ParseResult.Invalid(R.string.qr_invalid_link)
        }

        if (uri.scheme != SCHEME || uri.host != HOST) {
            return ParseResult.Invalid(R.string.qr_wrong_activation_link)
        }

        val code = queryParameter(uri.rawQuery, "code")
            ?: return ParseResult.Invalid(R.string.qr_missing_code)

        return normalizeManualCode(code)?.let(ParseResult::Success)
            ?: ParseResult.Invalid(R.string.qr_invalid_activation_code)
    }

    private fun queryParameter(rawQuery: String?, name: String): String? {
        if (rawQuery.isNullOrBlank()) {
            return null
        }

        return rawQuery.split("&")
            .mapNotNull { part ->
                val pieces = part.split("=", limit = 2)
                if (pieces.size != 2) {
                    return@mapNotNull null
                }
                val key = decode(pieces[0])
                val value = decode(pieces[1])
                if (key == name) value else null
            }
            .firstOrNull()
    }

    private fun decode(value: String): String {
        return URLDecoder.decode(value, Charsets.UTF_8.name())
    }
}

sealed class ParseResult {
    data class Success(val activationCode: String) : ParseResult()
    data class Invalid(@StringRes val messageRes: Int) : ParseResult()
}
