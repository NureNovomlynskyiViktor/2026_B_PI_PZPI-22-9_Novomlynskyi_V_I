BEGIN;

DROP TABLE IF EXISTS vehicle_activation_codes;

ALTER TABLE vehicles
    ALTER COLUMN owner_id SET NOT NULL;

COMMIT;
