﻿package ua.autonexis.mobile.ui.telemetry

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ua.autonexis.mobile.R
import ua.autonexis.mobile.TelemetryRecord
import ua.autonexis.mobile.ui.UiStringResources
import ua.autonexis.mobile.ui.owner.OwnerNavigationBar
import ua.autonexis.mobile.ui.owner.OwnerNavigationTab
import ua.autonexis.mobile.ui.theme.AutonexisColors
import ua.autonexis.mobile.ui.theme.AutonexisSpacing
import ua.autonexis.mobile.ui.theme.autonexisTopBarInsets

@Composable
internal fun RecentTelemetryRoot(
    state: RecentTelemetryUiState,
    notificationUnreadCount: Int,
    onBackToVehicleDetails: () -> Unit,
    onRefresh: () -> Unit,
    onRetry: () -> Unit,
    onMetricSelected: (String) -> Unit,
    onToggleHistoryExpanded: () -> Unit,
    onRequests: () -> Unit,
    onNotifications: () -> Unit,
    onAccount: () -> Unit,
) {
    val isBusy = state.isLoading || state.isRefreshing
    BackHandler(onBack = onBackToVehicleDetails)

    Scaffold(
        topBar = {
            RecentTelemetryTopBar(
                vehicleLabel = state.vehicleLabel,
                isBusy = isBusy,
                onBack = onBackToVehicleDetails,
                onRefresh = onRefresh,
            )
        },
        bottomBar = {
            OwnerNavigationBar(
                selected = OwnerNavigationTab.VEHICLES,
                notificationUnreadCount = notificationUnreadCount,
                onVehicles = onBackToVehicleDetails,
                onRequests = onRequests,
                onNotifications = onNotifications,
            onAccount = onAccount,
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.records.isEmpty() -> BrandedLoadingState(
                    message = state.message ?: stringResource(R.string.loading_recent_telemetry),
                )
                state.isError && state.records.isEmpty() -> InitialErrorState(
                    message = state.message ?: stringResource(R.string.could_not_load_recent_telemetry_message),
                    onRetry = onRetry,
                    onBack = onBackToVehicleDetails,
                )
                else -> RecentTelemetryContent(
                    state = state,
                    onMetricSelected = onMetricSelected,
                    onToggleHistoryExpanded = onToggleHistoryExpanded,
                )
            }
        }
    }
}

@Composable
private fun localizedMetricLabel(metricKey: String): String {
    return UiStringResources.metricLabelRes(metricKey)?.let { stringResource(it) }
        ?: RecentTelemetryPresentation.metricFor(metricKey).label
}

@Composable
private fun localizedRecordMetrics(record: TelemetryRecord): List<Pair<String, String>> {
    val values = RecentTelemetryPresentation.metrics(record)
    val keys = listOf("engine_temperature", "battery_voltage", "vibration_level", "rpm", "speed", "fuel_level")
    return values.mapIndexed { index, metric ->
        val label = keys.getOrNull(index)?.let { localizedMetricLabel(it) } ?: metric.first
        label to metric.second
    }
}

@Composable
private fun RecentTelemetryTopBar(
    vehicleLabel: String,
    isBusy: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
) {
    Surface(modifier = Modifier.autonexisTopBarInsets(), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AutonexisSpacing.lg, vertical = AutonexisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack, enabled = !isBusy) { Text(stringResource(R.string.back)) }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.recent_telemetry),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = vehicleLabel,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            TextButton(onClick = onRefresh, enabled = !isBusy) { Text(stringResource(R.string.refresh)) }
        }
    }
}

@Composable
private fun RecentTelemetryContent(
    state: RecentTelemetryUiState,
    onMetricSelected: (String) -> Unit,
    onToggleHistoryExpanded: () -> Unit,
) {
    LazyDashboardColumn {
        if (!state.message.isNullOrBlank()) {
            item { StateMessage(state.message, state.isError) }
        }
        if (state.isRefreshing) {
            item { InlineProgress(stringResource(R.string.refreshing_telemetry)) }
        }
        if (state.records.isEmpty()) {
            item { EmptyTelemetryState() }
        } else {
            RecentTelemetryPresentation.latestRecord(state.records)?.let { latest ->
                item { LatestSnapshotCard(latest) }
            }
            RecentTelemetryPresentation.overview(state.records)?.let { overview ->
                item { DataOverviewCard(overview) }
            }
            item {
                MetricTrendSection(
                    records = state.records,
                    selectedMetricKey = state.selectedMetricKey,
                    onMetricSelected = onMetricSelected,
                )
            }
            item {
                MetricStatisticsCard(
                    records = state.records,
                    selectedMetricKey = state.selectedMetricKey,
                )
            }
            item {
                RecentMeasurementsSection(
                    records = state.records,
                    expanded = state.isHistoryExpanded,
                    onToggleExpanded = onToggleHistoryExpanded,
                )
            }
        }
    }
}

@Composable
private fun LazyDashboardColumn(content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = AutonexisSpacing.lg,
            top = AutonexisSpacing.lg,
            end = AutonexisSpacing.lg,
            bottom = 112.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
        content = content,
    )
}

@Composable
private fun LatestSnapshotCard(record: TelemetryRecord) {
    InfoCard {
        Text(stringResource(R.string.latest_snapshot), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            text = stringResource(R.string.measured_label, RecentTelemetryPresentation.measuredAtLabel(record)),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        localizedRecordMetrics(record).chunked(2).forEach { rowMetrics ->
            Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
                rowMetrics.forEach { metric ->
                    MetricTile(metric.first, metric.second, Modifier.weight(1f))
                }
                if (rowMetrics.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun DataOverviewCard(overview: TelemetryOverview) {
    InfoCard {
        Text(stringResource(R.string.data_overview), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OverviewRow(stringResource(R.string.loaded_readings), overview.readingCount.toString())
        OverviewRow(stringResource(R.string.oldest_measurement), overview.oldestTimestamp)
        OverviewRow(stringResource(R.string.newest_measurement), overview.newestTimestamp)
    }
}

@Composable
private fun MetricTrendSection(
    records: List<TelemetryRecord>,
    selectedMetricKey: String,
    onMetricSelected: (String) -> Unit,
) {
    val selectedMetric = RecentTelemetryPresentation.metricFor(selectedMetricKey)
    val series = RecentTelemetryPresentation.chartSeries(records, selectedMetric.key)
    InfoCard {
        Text(stringResource(R.string.metric_trends), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        MetricSelector(selectedMetric.key, onMetricSelected)
        Text(
            text = "${localizedMetricLabel(selectedMetric.key)} (${selectedMetric.unit})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        TelemetryChart(metric = selectedMetric, series = series)
        val first = series.firstOrNull()?.timestamp ?: "n/a"
        val last = series.lastOrNull()?.timestamp ?: "n/a"
        Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
            OverviewTile(stringResource(R.string.oldest), first, Modifier.weight(1f))
            OverviewTile(stringResource(R.string.newest), last, Modifier.weight(1f))
        }
        Text(
            text = stringResource(R.string.chart_description, localizedMetricLabel(selectedMetric.key).lowercase()),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun MetricSelector(selectedMetricKey: String, onMetricSelected: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
    ) {
        RecentTelemetryPresentation.metrics.forEach { metric ->
            val selected = metric.key == selectedMetricKey
            Surface(
                modifier = Modifier.clickable { onMetricSelected(metric.key) },
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                shape = RoundedCornerShape(999.dp),
            ) {
                Text(
                    text = localizedMetricLabel(metric.key),
                    modifier = Modifier.padding(horizontal = AutonexisSpacing.md, vertical = AutonexisSpacing.sm),
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun TelemetryChart(metric: TelemetryMetricSpec, series: List<TelemetryChartPoint>) {
    val lineColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outline
    val pointFillColor = MaterialTheme.colorScheme.surface
    val description = stringResource(R.string.telemetry_chart_cd, localizedMetricLabel(metric.key), series.size)
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .semantics { contentDescription = description },
    ) {
        val left = 12.dp.toPx()
        val right = size.width - 12.dp.toPx()
        val top = 14.dp.toPx()
        val bottom = size.height - 16.dp.toPx()
        val plotWidth = (right - left).coerceAtLeast(1f)
        val plotHeight = (bottom - top).coerceAtLeast(1f)

        repeat(4) { index ->
            val y = top + (plotHeight * index / 3f)
            drawLine(
                color = gridColor.copy(alpha = 0.55f),
                start = Offset(left, y),
                end = Offset(right, y),
                strokeWidth = 1.dp.toPx(),
            )
        }

        if (series.isEmpty()) {
            return@Canvas
        }

        val values = series.map { it.value }
        val min = values.minOrNull() ?: return@Canvas
        val max = values.maxOrNull() ?: return@Canvas
        val range = max - min
        val points = values.mapIndexed { index, value ->
            val x = if (values.size == 1) {
                left + plotWidth / 2f
            } else {
                left + plotWidth * (index.toFloat() / (values.size - 1).toFloat())
            }
            val normalized = if (range == 0.0) 0.5 else ((value - min) / range).coerceIn(0.0, 1.0)
            val y = bottom - (normalized.toFloat() * plotHeight)
            Offset(x, y)
        }

        if (points.size > 1) {
            val area = Path().apply {
                moveTo(points.first().x, bottom)
                points.forEach { point -> lineTo(point.x, point.y) }
                lineTo(points.last().x, bottom)
                close()
            }
            drawPath(area, color = lineColor.copy(alpha = 0.12f))
        }

        val line = Path().apply {
            moveTo(points.first().x, points.first().y)
            points.drop(1).forEach { point -> lineTo(point.x, point.y) }
        }
        drawPath(line, color = lineColor, style = Stroke(width = 3.dp.toPx()))
        points.forEach { point ->
            drawCircle(color = pointFillColor, radius = 4.8.dp.toPx(), center = point)
            drawCircle(color = lineColor, radius = 3.2.dp.toPx(), center = point)
        }
    }
}

@Composable
private fun MetricStatisticsCard(records: List<TelemetryRecord>, selectedMetricKey: String) {
    val metric = RecentTelemetryPresentation.metricFor(selectedMetricKey)
    val stats = RecentTelemetryPresentation.statistics(records, metric.key) ?: return
    InfoCard {
        Text(stringResource(R.string.selected_metric_statistics), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
            OverviewTile(stringResource(R.string.current), stats.current, Modifier.weight(1f))
            OverviewTile(stringResource(R.string.minimum), stats.minimum, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
            OverviewTile(stringResource(R.string.average), stats.average, Modifier.weight(1f))
            OverviewTile(stringResource(R.string.maximum), stats.maximum, Modifier.weight(1f))
        }
    }
}

@Composable
private fun RecentMeasurementsSection(
    records: List<TelemetryRecord>,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
) {
    val visibleRecords = RecentTelemetryPresentation.historyRecords(records, expanded)
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.recent_measurements), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    text = if (expanded) stringResource(R.string.showing_all_loaded_readings) else stringResource(R.string.showing_newest_readings, visibleRecords.size),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            if (RecentTelemetryPresentation.canToggleHistory(records)) {
                TextButton(onClick = onToggleExpanded) {
                    Text(if (expanded) stringResource(R.string.show_fewer_readings) else stringResource(R.string.show_all_readings))
                }
            }
        }
        visibleRecords.forEach { record ->
            CompactTelemetryRecord(record)
        }
    }
}

@Composable
private fun CompactTelemetryRecord(record: TelemetryRecord) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
    ) {
        Text(
            text = RecentTelemetryPresentation.measuredAtLabel(record),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        localizedRecordMetrics(record).chunked(2).forEach { rowMetrics ->
            Row(horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm)) {
                rowMetrics.forEach { metric ->
                    CompactMetricRow(metric.first, metric.second, Modifier.weight(1f))
                }
                if (rowMetrics.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun CompactMetricRow(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.58f), RoundedCornerShape(10.dp))
            .padding(horizontal = AutonexisSpacing.sm, vertical = AutonexisSpacing.xs),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyLarge,
        )
    }
}

@Composable
private fun OverviewRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OverviewTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(value, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun MetricTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(AutonexisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.xs),
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BrandedLoadingState(message: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.autonexis_emblem),
            contentDescription = stringResource(R.string.brand_name),
            modifier = Modifier.size(72.dp),
        )
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(AutonexisSpacing.md))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InitialErrorState(message: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(AutonexisSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(stringResource(R.string.could_not_load_recent_telemetry), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(AutonexisSpacing.sm))
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(AutonexisSpacing.lg))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.retry)) }
        TextButton(onClick = onBack) { Text(stringResource(R.string.back_to_vehicle_details)) }
    }
}

@Composable
private fun EmptyTelemetryState() {
    InfoCard {
        Text(stringResource(R.string.no_telemetry_history_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            text = stringResource(R.string.no_telemetry_history_message),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(AutonexisSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(AutonexisSpacing.md),
            content = content,
        )
    }
}

@Composable
private fun StateMessage(message: String, isError: Boolean) {
    Text(
        text = message,
        color = if (isError) MaterialTheme.colorScheme.error else AutonexisColors.EmeraldGreen,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
private fun InlineProgress(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(AutonexisSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
