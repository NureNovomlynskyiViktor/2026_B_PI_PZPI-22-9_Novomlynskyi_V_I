package ua.autonexis.mobile

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ServiceRequestDefaultsTest {
    @Test
    fun criticalAlertDefaultsToHighPriority() {
        val draft = ServiceRequestDefaults.fromAlert(
            Alert(
                id = "alert-1",
                type = "engine_temperature",
                severity = "critical",
                currentSeverity = "critical",
                status = "active",
                occurrenceCount = 1,
                recoveryStreak = 0,
                lastTriggeredAt = "2026-06-18T10:00:00Z",
                message = "Engine temperature is 118 C.",
                recommendation = "Stop the vehicle safely.",
                createdAt = "2026-06-18T10:00:00Z",
                clearedAt = null,
                resolvedAt = null,
            ),
            title = "Engine temperature alert",
            recommendationLabel = "Recommendation",
        )

        assertEquals("high", draft.priority)
        assertEquals("alert-1", draft.sourceAlertId)
        assertEquals("Engine temperature alert", draft.title)
        assertTrue(draft.description.contains("Engine temperature is 118 C."))
        assertTrue(draft.description.contains("Recommendation: Stop the vehicle safely."))
    }

    @Test
    fun warningAlertDefaultsToNormalPriority() {
        val draft = ServiceRequestDefaults.fromAlert(
            Alert(
                id = "alert-2",
                type = "battery_voltage",
                severity = "warning",
                currentSeverity = "warning",
                status = "active",
                occurrenceCount = 1,
                recoveryStreak = 0,
                lastTriggeredAt = "2026-06-18T10:00:00Z",
                message = "Battery voltage is low.",
                recommendation = null,
                createdAt = "2026-06-18T10:00:00Z",
                clearedAt = null,
                resolvedAt = null,
            ),
            title = "Battery voltage alert",
            recommendationLabel = "Recommendation",
        )

        assertEquals("normal", draft.priority)
        assertEquals("Battery voltage alert", draft.title)
        assertEquals("Battery voltage is low.", draft.description)
    }
}
