package config

import (
	"fmt"
	"net"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

const (
	defaultAppEnv              = "local"
	defaultHTTPHost            = "0.0.0.0"
	defaultHTTPPort            = 8080
	defaultPostgresHost        = "localhost"
	defaultPostgresPort        = 5432
	defaultPostgresDatabase    = "vehicle_monitoring"
	defaultPostgresUser        = "vehicle_monitoring"
	defaultPostgresPassword    = "change_me"
	defaultPostgresSSLMode     = "disable"
	defaultMQTTEnabled         = false
	defaultMQTTBrokerHost      = "localhost"
	defaultMQTTBrokerPort      = 1883
	defaultMQTTClientID        = "autonexis-backend"
	defaultMQTTTopic           = "autonexis/devices/+/telemetry"
	defaultJWTSecret           = "local-development-autonexis-change-me"
	defaultJWTAccessTTL        = time.Hour
	defaultCORSOrigins         = "http://localhost:5173"
	defaultGoogleAuthEnabled   = false
	defaultGoogleOAuthClientID = ""
)

type Config struct {
	AppEnv     string
	HTTP       HTTPConfig
	Database   DatabaseConfig
	MQTT       MQTTConfig
	JWT        JWTConfig
	CORS       CORSConfig
	GoogleAuth GoogleAuthConfig
}

type HTTPConfig struct {
	Host string
	Port int
}

func (c HTTPConfig) Address() string {
	return net.JoinHostPort(c.Host, strconv.Itoa(c.Port))
}

type DatabaseConfig struct {
	Host     string
	Port     int
	Name     string
	User     string
	Password string
	SSLMode  string
}

type MQTTConfig struct {
	Enabled        bool
	BrokerHost     string
	BrokerPort     int
	ClientID       string
	TelemetryTopic string
}

type JWTConfig struct {
	Secret         string
	AccessTokenTTL time.Duration
}

type CORSConfig struct {
	AllowedOrigins []string
}

type GoogleAuthConfig struct {
	Enabled   bool
	ClientIDs []string
}

func (c MQTTConfig) BrokerURL() string {
	return "tcp://" + net.JoinHostPort(c.BrokerHost, strconv.Itoa(c.BrokerPort))
}

func (c DatabaseConfig) DSN() string {
	dsn := &url.URL{
		Scheme: "postgres",
		User:   url.UserPassword(c.User, c.Password),
		Host:   net.JoinHostPort(c.Host, strconv.Itoa(c.Port)),
		Path:   c.Name,
	}

	query := dsn.Query()
	query.Set("sslmode", c.SSLMode)
	dsn.RawQuery = query.Encode()

	return dsn.String()
}

func Load() (Config, error) {
	httpPort, err := envPort("HTTP_PORT", defaultHTTPPort)
	if err != nil {
		return Config{}, err
	}

	postgresPort, err := envPort("POSTGRES_PORT", defaultPostgresPort)
	if err != nil {
		return Config{}, err
	}

	mqttEnabled, err := envBool("MQTT_ENABLED", defaultMQTTEnabled)
	if err != nil {
		return Config{}, err
	}

	mqttBrokerPort, err := envPort("MQTT_BROKER_PORT", defaultMQTTBrokerPort)
	if err != nil {
		return Config{}, err
	}

	jwtAccessTTL, err := envDuration("JWT_ACCESS_TOKEN_TTL", defaultJWTAccessTTL)
	if err != nil {
		return Config{}, err
	}

	googleAuthEnabled, err := envBool("GOOGLE_AUTH_ENABLED", defaultGoogleAuthEnabled)
	if err != nil {
		return Config{}, err
	}

	googleClientIDs, err := envStrictList("GOOGLE_OAUTH_CLIENT_IDS", defaultGoogleOAuthClientID)
	if err != nil {
		return Config{}, err
	}

	cfg := Config{
		AppEnv: envOrDefault("APP_ENV", defaultAppEnv),
		HTTP: HTTPConfig{
			Host: envOrDefault("HTTP_HOST", defaultHTTPHost),
			Port: httpPort,
		},
		Database: DatabaseConfig{
			Host:     envOrDefault("POSTGRES_HOST", defaultPostgresHost),
			Port:     postgresPort,
			Name:     envOrDefault("POSTGRES_DB", defaultPostgresDatabase),
			User:     envOrDefault("POSTGRES_USER", defaultPostgresUser),
			Password: envOrDefault("POSTGRES_PASSWORD", defaultPostgresPassword),
			SSLMode:  envOrDefault("POSTGRES_SSLMODE", defaultPostgresSSLMode),
		},
		MQTT: MQTTConfig{
			Enabled:        mqttEnabled,
			BrokerHost:     envOrDefault("MQTT_BROKER_HOST", defaultMQTTBrokerHost),
			BrokerPort:     mqttBrokerPort,
			ClientID:       envOrDefault("MQTT_CLIENT_ID", defaultMQTTClientID),
			TelemetryTopic: envOrDefault("MQTT_TELEMETRY_TOPIC", defaultMQTTTopic),
		},
		JWT: JWTConfig{
			Secret:         envOrDefault("JWT_SECRET", defaultJWTSecret),
			AccessTokenTTL: jwtAccessTTL,
		},
		CORS: CORSConfig{
			AllowedOrigins: envList("CORS_ALLOWED_ORIGINS", defaultCORSOrigins),
		},
		GoogleAuth: GoogleAuthConfig{
			Enabled:   googleAuthEnabled,
			ClientIDs: googleClientIDs,
		},
	}

	if cfg.HTTP.Host == "" {
		return Config{}, fmt.Errorf("HTTP_HOST must not be empty")
	}
	if cfg.Database.Host == "" {
		return Config{}, fmt.Errorf("POSTGRES_HOST must not be empty")
	}
	if cfg.Database.Name == "" {
		return Config{}, fmt.Errorf("POSTGRES_DB must not be empty")
	}
	if cfg.Database.User == "" {
		return Config{}, fmt.Errorf("POSTGRES_USER must not be empty")
	}
	if cfg.MQTT.Enabled {
		if cfg.MQTT.BrokerHost == "" {
			return Config{}, fmt.Errorf("MQTT_BROKER_HOST must not be empty")
		}
		if cfg.MQTT.ClientID == "" {
			return Config{}, fmt.Errorf("MQTT_CLIENT_ID must not be empty")
		}
		if cfg.MQTT.TelemetryTopic == "" {
			return Config{}, fmt.Errorf("MQTT_TELEMETRY_TOPIC must not be empty")
		}
	}
	if cfg.JWT.Secret == "" {
		return Config{}, fmt.Errorf("JWT_SECRET must not be empty")
	}
	if cfg.JWT.AccessTokenTTL <= 0 {
		return Config{}, fmt.Errorf("JWT_ACCESS_TOKEN_TTL must be positive")
	}
	if len(cfg.CORS.AllowedOrigins) == 0 {
		return Config{}, fmt.Errorf("CORS_ALLOWED_ORIGINS must contain at least one origin")
	}
	if cfg.GoogleAuth.Enabled && len(cfg.GoogleAuth.ClientIDs) == 0 {
		return Config{}, fmt.Errorf("GOOGLE_OAUTH_CLIENT_IDS must contain at least one client ID when GOOGLE_AUTH_ENABLED is true")
	}

	return cfg, nil
}

func envOrDefault(key, fallback string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}

	return fallback
}

func envPort(key string, fallback int) (int, error) {
	value, ok := os.LookupEnv(key)
	if !ok {
		return fallback, nil
	}

	port, err := strconv.Atoi(value)
	if err != nil || port < 1 || port > 65535 {
		return 0, fmt.Errorf("%s must be a number between 1 and 65535", key)
	}

	return port, nil
}

func envBool(key string, fallback bool) (bool, error) {
	value, ok := os.LookupEnv(key)
	if !ok {
		return fallback, nil
	}

	parsed, err := strconv.ParseBool(value)
	if err != nil {
		return false, fmt.Errorf("%s must be true or false", key)
	}

	return parsed, nil
}

func envDuration(key string, fallback time.Duration) (time.Duration, error) {
	value, ok := os.LookupEnv(key)
	if !ok {
		return fallback, nil
	}

	parsed, err := time.ParseDuration(value)
	if err != nil || parsed <= 0 {
		return 0, fmt.Errorf("%s must be a positive duration", key)
	}

	return parsed, nil
}

func envList(key, fallback string) []string {
	value := envOrDefault(key, fallback)
	parts := strings.Split(value, ",")
	items := make([]string, 0, len(parts))
	for _, part := range parts {
		item := strings.TrimSpace(part)
		if item != "" {
			items = append(items, item)
		}
	}

	return items
}

func envStrictList(key, fallback string) ([]string, error) {
	value := envOrDefault(key, fallback)
	if strings.TrimSpace(value) == "" {
		return []string{}, nil
	}

	parts := strings.Split(value, ",")
	items := make([]string, 0, len(parts))
	for _, part := range parts {
		item := strings.TrimSpace(part)
		if item == "" {
			return nil, fmt.Errorf("%s must not contain empty entries", key)
		}
		items = append(items, item)
	}

	return items, nil
}
