export type Locale = 'en' | 'uk';
export type LanguageMode = 'system' | Locale;

export type StructuredLabelKey =
  | 'active'
  | 'administrator'
  | 'assigned'
  | 'battery_and_electrical'
  | 'battery_voltage'
  | 'battery_voltage_critical'
  | 'battery_voltage_warning'
  | 'cancelled'
  | 'cleared'
  | 'completed'
  | 'critical'
  | 'engine_diagnostics'
  | 'engine_temperature'
  | 'engine_temperature_critical'
  | 'engine_temperature_warning'
  | 'fuel_level'
  | 'fuel_level_critical'
  | 'fuel_level_warning'
  | 'fuel_system'
  | 'general_maintenance'
  | 'high'
  | 'in_progress'
  | 'iot_device_setup'
  | 'low'
  | 'normal'
  | 'pending'
  | 'resolved'
  | 'rpm'
  | 'rpm_critical'
  | 'rpm_warning'
  | 'speed'
  | 'technical_specialist'
  | 'vehicle_owner'
  | 'vibration_analysis'
  | 'vibration_level'
  | 'vibration_level_critical'
  | 'vibration_level_warning'
  | 'warning';

type TextBlock = {
  title: string;
  body: string;
};

type WorkflowStep = TextBlock;

type PreviewMetric = {
  label: string;
  value: string;
};

export type LocaleMessages = {
  brand: {
    name: string;
    purpose: string;
  };
  language: {
    label: string;
    system: string;
    english: string;
    ukrainian: string;
  };
  appearance: {
    label: string;
    system: string;
    light: string;
    dark: string;
  };
  common: {
    account: string;
    logout: string;
    close: string;
    refresh: string;
    refreshing: string;
    refreshAll: string;
    refreshUsers: string;
    refreshRequests: string;
    manualRefresh: string;
    loading: string;
    notSet: string;
    notAssigned: string;
    noData: string;
    notAvailable: string;
    loadingStatus: string;
    loadingIncidents: string;
    loadingTelemetryHistory: string;
    loadingAuditLogs: string;
    loadingUsers: string;
    loadingServiceRequests: string;
    loadingAssignedVehicles: string;
    loadingDiagnosticTelemetry: string;
    polling: string;
    created: string;
    assignedAt: string;
    started: string;
    completedAt: string;
    cancelledAt: string;
    measuredAt: string;
  };
  structuredLabels: Record<StructuredLabelKey, string>;
  workspace: {
    admin: {
      kicker: string;
      title: string;
      description: string;
      sections: {
        overview: string;
        vehicleOnboarding: string;
        serviceRequests: string;
        specialistAssignments: string;
        users: string;
        auditLog: string;
      };
      metrics: {
        vehicles: string;
        technicalSpecialists: string;
        openServiceRequests: string;
        usersInCurrentFilter: string;
      };
    };
    specialist: {
      kicker: string;
      title: string;
      description: string;
      sections: {
        overview: string;
        assignedVehicles: string;
        diagnostics: string;
        serviceRequests: string;
        maintenance: string;
        incidentResolution: string;
      };
      metrics: {
        assignedVehicles: string;
        assignedRequests: string;
        activeConditions: string;
        clearedIncidents: string;
      };
    };
    navigationLabel: string;
    sectionsLabel: string;
    metricsLabel: string;
  };
  app: {
    loadingWorkspaceTitle: string;
    loadingWorkspaceBody: string;
    sessionErrorTitle: string;
    sessionExpired: string;
    failedToLoadUser: string;
    backToLogin: string;
  };
  auth: {
    brandHeading: string;
    brandBody: string;
    emailDivider: string;
    backToHome: string;
    modeLabel: string;
    loginTab: string;
    registerTab: string;
    emailLabel: string;
    passwordLabel: string;
    firstNameLabel: string;
    lastNameLabel: string;
    submitLogin: string;
    submitRegister: string;
    submitting: string;
    failed: string;
    googleRegionLabel: string;
    googleLoading: string;
    googleExchangeInProgress: string;
    googleUnavailable: string;
    googleInvalidCredential: string;
    googleNotConfigured: string;
    googleRolePolicy: string;
  };
  account: {
    button: string;
    heading: string;
    close: string;
    emailLabel: string;
    roleLabel: string;
    passwordMethod: string;
    googleMethod: string;
    enabled: string;
    notEnabled: string;
    connected: string;
    notConnected: string;
    loading: string;
    refreshError: string;
    linkHeading: string;
    linkExplanation: string;
    linkNotConfigured: string;
    linkSuccess: string;
    googleRegionLabel: string;
    googleLoading: string;
    googleExchangeInProgress: string;
    googleUnavailable: string;
    googleInvalidCredential: string;
    roles: {
      vehicleOwner: string;
      technicalSpecialist: string;
      administrator: string;
      unknown: string;
    };
  };
  admin: {
    overview: Record<string, string>;
    onboarding: Record<string, string>;
    serviceRequests: Record<string, string>;
    assignments: Record<string, string>;
    users: Record<string, string>;
    audit: Record<string, string>;
  };
  specialist: {
    overview: Record<string, string>;
    assignedVehicles: Record<string, string>;
    diagnostics: Record<string, string>;
    serviceRequests: Record<string, string>;
    maintenance: Record<string, string>;
    incidents: Record<string, string>;
  };
  landing: {
    navigation: {
      ariaLabel: string;
      menu: string;
      about: string;
      capabilities: string;
      howItWorks: string;
      connectVehicle: string;
      signIn: string;
    };
    hero: {
      kicker: string;
      heading: string;
      supportingText: string;
      primaryAction: string;
      secondaryAction: string;
    };
    preview: {
      ariaLabel: string;
      label: string;
      vehicle: string;
      deviceOnline: string;
      overallStatus: string;
      updated: string;
      metrics: ReadonlyArray<PreviewMetric>;
    };
    about: {
      kicker: string;
      heading: string;
      body: string;
      points: ReadonlyArray<TextBlock>;
    };
    capabilities: {
      kicker: string;
      heading: string;
      items: ReadonlyArray<TextBlock>;
    };
    workflow: {
      kicker: string;
      heading: string;
      steps: ReadonlyArray<WorkflowStep>;
    };
    roles: {
      kicker: string;
      heading: string;
      items: ReadonlyArray<TextBlock>;
    };
    connect: {
      kicker: string;
      heading: string;
      body: string;
      steps: ReadonlyArray<string>;
      contactHeading: string;
      contactConfigured: string;
      contactFallback: string;
      contactAction: string;
      infoHeading: string;
      infoRequired: ReadonlyArray<string>;
    };
    footer: {
      description: string;
      navigationLabel: string;
      copyright: string;
    };
  };
  ownerOnboarding: {
    account: string;
    logout: string;
    eyebrow: string;
    heading: string;
    body: string;
    signedInAs: string;
    downloadKicker: string;
    downloadHeading: string;
    qrAlt: string;
    qrPreparing: string;
    qrError: string;
    downloadAction: string;
    downloadNote: string;
    apkNotConfigured: string;
    distinctionKicker: string;
    distinctionHeading: string;
    apkQrTitle: string;
    apkQrBody: string;
    activationQrTitle: string;
    activationQrBody: string;
    setupKicker: string;
    setupHeading: string;
    steps: ReadonlyArray<TextBlock>;
    iotKicker: string;
    iotHeading: string;
    iotBody: string;
  };
};
