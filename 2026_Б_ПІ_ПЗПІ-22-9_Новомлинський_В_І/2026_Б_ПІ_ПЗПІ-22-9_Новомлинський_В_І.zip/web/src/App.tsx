import { useEffect, useState } from 'react';
import { api, isUnauthorizedError } from './api/client';
import type { AuthResponse, User } from './api/types';
import { AdminDashboard } from './components/AdminDashboard';
import { AccountMethodsPanel } from './components/account/AccountMethodsPanel';
import { AuthScreen } from './components/AuthScreen';
import { OwnerMobileOnboarding } from './components/OwnerMobileOnboarding';
import { LandingPage } from './components/public';
import { SpecialistDashboard } from './components/SpecialistDashboard';
import { useMessages } from './i18n';
import {
  getCurrentPublicPath,
  navigatePublic,
  normalizePublicPath,
  type PublicPath,
} from './navigation/publicNavigation';

const tokenStorageKey = 'autonexis_access_token';
export function App() {
  const t = useMessages();
  const [publicPath, setPublicPath] = useState<PublicPath>(() => getCurrentPublicPath());
  const [token, setToken] = useState<string | null>(() =>
    localStorage.getItem(tokenStorageKey),
  );
  const [user, setUser] = useState<User | null>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(false);
  const [isAccountPanelOpen, setIsAccountPanelOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    function handleLocationChange() {
      setPublicPath(getCurrentPublicPath());
    }

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  useEffect(() => {
    if (!token) {
      normalizePublicPath();
      setPublicPath(getCurrentPublicPath());
    }
  }, [token]);

  useEffect(() => {
    if (!token) {
      setUser(null);
      return;
    }

    let isCurrent = true;
    setIsLoadingUser(true);
    setError(null);

    api
      .me(token)
      .then((currentUser) => {
        if (isCurrent) {
          setUser(currentUser);
        }
      })
      .catch((err) => {
        if (!isCurrent) {
          return;
        }
        if (isUnauthorizedError(err)) {
          handleSessionExpired();
          return;
        }

        setError(err instanceof Error ? err.message : t.app.failedToLoadUser);
      })
      .finally(() => {
        if (isCurrent) {
          setIsLoadingUser(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [token]);

  function handleAuthenticated(response: AuthResponse) {
    localStorage.setItem(tokenStorageKey, response.access_token);
    setError(null);
    setIsAccountPanelOpen(false);
    setToken(response.access_token);
    setUser(response.user);
  }

  function clearSessionState() {
    localStorage.removeItem(tokenStorageKey);
    setIsAccountPanelOpen(false);
    setToken(null);
    setUser(null);
  }

  function handleSessionExpired() {
    clearSessionState();
    setError(t.app.sessionExpired);
    navigatePublic('/login', { replace: true });
  }

  function handleLogout() {
    clearSessionState();
    setError(null);
    navigatePublic('/', { replace: true });
  }

  function handleBackToLogin() {
    clearSessionState();
    setError(null);
    navigatePublic('/login', { replace: true });
  }

  if (!token) {
    return publicPath === '/login' ? (
      <AuthScreen onAuthenticated={handleAuthenticated} sessionMessage={error} />
    ) : (
      <LandingPage />
    );
  }

  if (isLoadingUser && !user) {
    return (
      <main className="auth-layout">
        <section className="auth-card">
          <p className="eyebrow">Autonexis</p>
          <h1>{t.app.loadingWorkspaceTitle}</h1>
          <p className="muted">{t.app.loadingWorkspaceBody}</p>
        </section>
      </main>
    );
  }

  if (error && !user) {
    return (
      <main className="auth-layout">
        <section className="auth-card">
          <p className="eyebrow">Autonexis</p>
          <h1>{t.app.sessionErrorTitle}</h1>
          <p className="error-box">{error}</p>
          <button className="primary-button" type="button" onClick={handleBackToLogin}>
            {t.app.backToLogin}
          </button>
        </section>
      </main>
    );
  }

  if (!user) {
    return null;
  }

  if (user.role === 'technical_specialist') {
    return (
      <>
        <SpecialistDashboard
          token={token}
          user={user}
          onLogout={handleLogout}
          onOpenAccount={() => setIsAccountPanelOpen(true)}
          onSessionExpired={handleSessionExpired}
        />
        {isAccountPanelOpen && (
          <AccountMethodsPanel
            token={token}
            user={user}
            onClose={() => setIsAccountPanelOpen(false)}
            onSessionExpired={handleSessionExpired}
          />
        )}
      </>
    );
  }

  if (user.role === 'administrator') {
    return (
      <>
        <AdminDashboard
          token={token}
          user={user}
          onLogout={handleLogout}
          onOpenAccount={() => setIsAccountPanelOpen(true)}
          onSessionExpired={handleSessionExpired}
        />
        {isAccountPanelOpen && (
          <AccountMethodsPanel
            token={token}
            user={user}
            onClose={() => setIsAccountPanelOpen(false)}
            onSessionExpired={handleSessionExpired}
          />
        )}
      </>
    );
  }

  return (
    <>
      <OwnerMobileOnboarding
        user={user}
        onLogout={handleLogout}
        onOpenAccount={() => setIsAccountPanelOpen(true)}
      />
      {isAccountPanelOpen && (
        <AccountMethodsPanel
          token={token}
          user={user}
          onClose={() => setIsAccountPanelOpen(false)}
          onSessionExpired={handleSessionExpired}
        />
      )}
    </>
  );
}
