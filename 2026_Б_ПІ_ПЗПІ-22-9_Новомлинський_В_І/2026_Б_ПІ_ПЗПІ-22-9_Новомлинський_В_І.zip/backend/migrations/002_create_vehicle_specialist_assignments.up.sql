BEGIN;

CREATE TABLE vehicle_specialist_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
    specialist_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    assigned_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT vehicle_specialist_assignments_unique
        UNIQUE (vehicle_id, specialist_id)
);

CREATE INDEX vehicle_specialist_assignments_vehicle_idx
    ON vehicle_specialist_assignments (vehicle_id);

CREATE INDEX vehicle_specialist_assignments_specialist_idx
    ON vehicle_specialist_assignments (specialist_id);

COMMIT;
