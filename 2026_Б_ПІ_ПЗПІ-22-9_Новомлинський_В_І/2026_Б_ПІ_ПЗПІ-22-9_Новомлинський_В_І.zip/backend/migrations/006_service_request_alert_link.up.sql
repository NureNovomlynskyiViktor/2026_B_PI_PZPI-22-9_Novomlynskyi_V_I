BEGIN;

ALTER TABLE vehicle_service_requests
	ADD COLUMN source_alert_id UUID REFERENCES alerts(id) ON DELETE SET NULL;

CREATE INDEX vehicle_service_requests_source_alert_idx
	ON vehicle_service_requests(source_alert_id);

CREATE UNIQUE INDEX vehicle_service_requests_open_source_alert_unique
	ON vehicle_service_requests(source_alert_id)
	WHERE source_alert_id IS NOT NULL
	  AND status IN ('pending', 'assigned', 'in_progress');

COMMIT;
