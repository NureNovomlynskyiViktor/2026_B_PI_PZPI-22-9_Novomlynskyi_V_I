BEGIN;

ALTER TABLE users
	ADD COLUMN deactivated_at TIMESTAMPTZ;

UPDATE users
SET deactivated_at = updated_at
WHERE is_active = FALSE
  AND deactivated_at IS NULL;

ALTER TABLE users
	ADD CONSTRAINT users_deactivation_consistency_check
	CHECK (
		(is_active = TRUE AND deactivated_at IS NULL)
		OR (is_active = FALSE AND deactivated_at IS NOT NULL)
	);

CREATE INDEX users_role_active_created_idx
	ON users(role_id, is_active, created_at DESC, id DESC);

COMMIT;
