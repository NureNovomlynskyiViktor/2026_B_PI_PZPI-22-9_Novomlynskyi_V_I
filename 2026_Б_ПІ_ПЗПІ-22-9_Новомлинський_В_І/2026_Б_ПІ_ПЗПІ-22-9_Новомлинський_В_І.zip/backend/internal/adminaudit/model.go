package adminaudit

import "time"

const (
	DefaultLimit = 50
	MaxLimit     = 100
)

type Actor struct {
	ID       string `json:"id"`
	Email    string `json:"email"`
	FullName string `json:"full_name"`
	Role     string `json:"role"`
}

type Log struct {
	ID         int64          `json:"id"`
	Actor      *Actor         `json:"actor"`
	Action     string         `json:"action"`
	EntityType string         `json:"entity_type"`
	EntityID   *string        `json:"entity_id"`
	Metadata   map[string]any `json:"metadata"`
	CreatedAt  time.Time      `json:"created_at"`
}

type ListFilters struct {
	Action      string
	ActorID     string
	ActorSearch string
	EntityType  string
	EntityID    string
	DateFrom    *time.Time
	DateTo      *time.Time
	Limit       int
	LimitSet    bool
	Offset      int
}

type Pagination struct {
	Limit   int  `json:"limit"`
	Offset  int  `json:"offset"`
	Total   int  `json:"total"`
	HasMore bool `json:"has_more"`
}

type ListResponse struct {
	Items      []Log      `json:"items"`
	Pagination Pagination `json:"pagination"`
}
