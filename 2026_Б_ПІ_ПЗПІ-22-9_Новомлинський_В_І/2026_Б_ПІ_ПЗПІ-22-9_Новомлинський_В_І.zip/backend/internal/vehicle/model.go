package vehicle

import "time"

type Vehicle struct {
	ID           string    `json:"id"`
	OwnerID      string    `json:"owner_id"`
	VIN          *string   `json:"vin"`
	Brand        string    `json:"brand"`
	Model        string    `json:"model"`
	Year         *int16    `json:"year"`
	LicensePlate *string   `json:"license_plate"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

type CreateRequest struct {
	VIN          string `json:"vin"`
	Brand        string `json:"brand"`
	Model        string `json:"model"`
	Year         int    `json:"year"`
	LicensePlate string `json:"license_plate"`
}
